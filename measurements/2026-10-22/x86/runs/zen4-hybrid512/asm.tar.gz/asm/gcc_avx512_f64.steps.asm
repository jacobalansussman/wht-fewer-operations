000000000000a5f0 <hs_tb2_nat>:
    a5f0:	endbr64
    a5f4:	vbroadcastsd 0x529c2(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
    a5fe:	test   %rsi,%rsi
    a601:	je     a667 <hs_tb2_nat+0x77>
    a603:	lea    (%rdx,%rdx,1),%r11
    a607:	test   %rdx,%rdx
    a60a:	je     a667 <hs_tb2_nat+0x77>
    a60c:	lea    -0x1(%rdx),%r9
    a610:	xor    %r8d,%r8d
    a613:	lea    0x40(%rdi),%r10
    a617:	and    $0xfffffffffffffff8,%r9
    a61b:	nopl   0x0(%rax,%rax,1)
    a620:	lea    (%r9,%r8,1),%rcx
    a624:	lea    (%rdi,%r8,8),%rax
    a628:	lea    (%r10,%rcx,8),%rcx
    a62c:	nopl   0x0(%rax)
    a630:	vmovupd (%rax),%zmm0
    a636:	vmovupd (%rax,%rdx,8),%zmm1
    a63d:	vaddpd %zmm1,%zmm0,%zmm2
    a643:	vsubpd %zmm1,%zmm0,%zmm0
    a649:	vmovupd %zmm2,(%rax)
    a64f:	vmovupd %zmm0,(%rax,%rdx,8)
    a656:	add    $0x40,%rax
    a65a:	cmp    %rax,%rcx
    a65d:	jne    a630 <hs_tb2_nat+0x40>
    a65f:	add    %r11,%r8
    a662:	cmp    %rsi,%r8
    a665:	jb     a620 <hs_tb2_nat+0x30>
    a667:	vzeroupper
    a66a:	ret
    a66b:	nopl   0x0(%rax,%rax,1)

000000000000a670 <hs_tb4_nat>:
    a670:	endbr64
    a674:	vbroadcastsd 0x52942(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
    a67e:	test   %rsi,%rsi
    a681:	je     a747 <hs_tb4_nat+0xd7>
    a687:	push   %rbp
    a688:	mov    %rsp,%rbp
    a68b:	push   %r12
    a68d:	lea    0x0(,%rdx,4),%r12
    a695:	push   %rbx
    a696:	test   %rdx,%rdx
    a699:	je     a73f <hs_tb4_nat+0xcf>
    a69f:	lea    -0x1(%rdx),%r11
    a6a3:	mov    %rdx,%r8
    a6a6:	lea    (%rdx,%rdx,2),%rcx
    a6aa:	xor    %r10d,%r10d
    a6ad:	shl    $0x4,%r8
    a6b1:	and    $0xfffffffffffffff8,%r11
    a6b5:	shl    $0x3,%rcx
    a6b9:	lea    0x40(%rdi),%rbx
    a6bd:	nopl   (%rax)
    a6c0:	lea    (%r11,%r10,1),%r9
    a6c4:	lea    (%rdi,%r10,8),%rax
    a6c8:	lea    (%rbx,%r9,8),%r9
    a6cc:	nopl   0x0(%rax)
    a6d0:	vmovupd (%rax),%zmm5
    a6d6:	vmovupd (%rax,%r8,1),%zmm7
    a6dd:	vaddpd (%rax,%rdx,8),%zmm5,%zmm2
    a6e4:	vaddpd (%rax,%rcx,1),%zmm7,%zmm3
    a6eb:	vsubpd (%rax,%rdx,8),%zmm5,%zmm0
    a6f2:	vsubpd (%rax,%rcx,1),%zmm7,%zmm1
    a6f9:	vaddpd %zmm3,%zmm2,%zmm4
    a6ff:	vsubpd %zmm3,%zmm2,%zmm2
    a705:	vmovupd %zmm4,(%rax)
    a70b:	vaddpd %zmm1,%zmm0,%zmm4
    a711:	vsubpd %zmm1,%zmm0,%zmm0
    a717:	vmovupd %zmm4,(%rax,%rdx,8)
    a71e:	add    $0x40,%rax
    a722:	vmovupd %zmm2,-0x40(%rax,%r8,1)
    a72a:	vmovupd %zmm0,-0x40(%rax,%rcx,1)
    a732:	cmp    %rax,%r9
    a735:	jne    a6d0 <hs_tb4_nat+0x60>
    a737:	add    %r12,%r10
    a73a:	cmp    %rsi,%r10
    a73d:	jb     a6c0 <hs_tb4_nat+0x50>
    a73f:	vzeroupper
    a742:	pop    %rbx
    a743:	pop    %r12
    a745:	pop    %rbp
    a746:	ret
    a747:	vzeroupper
    a74a:	ret
    a74b:	nopl   0x0(%rax,%rax,1)

000000000000aaf0 <hf2_kid_nat>:
    aaf0:	endbr64
    aaf4:	vbroadcastsd 0x524c2(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
    aafe:	test   %rsi,%rsi
    ab01:	je     ab9f <hf2_kid_nat+0xaf>
    ab07:	lea    -0x8(,%rsi,8),%rax
    ab0f:	mov    $0xffffffaa,%edx
    ab14:	vmovdqa64 0x52322(%rip),%zmm5        # 5ce40 <_IO_stdin_used+0xe40>
    ab1e:	vmovdqa64 0x52358(%rip),%zmm4        # 5ce80 <_IO_stdin_used+0xe80>
    ab28:	and    $0xffffffffffffffc0,%rax
    ab2c:	mov    $0xffffffcc,%ecx
    ab31:	kmovw  %edx,%k3
    ab35:	vmovdqa64 0x52381(%rip),%zmm3        # 5cec0 <_IO_stdin_used+0xec0>
    ab3f:	mov    $0xfffffff0,%edx
    ab44:	lea    0x40(%rdi,%rax,1),%rax
    ab49:	kmovw  %ecx,%k2
    ab4d:	kmovw  %edx,%k1
    ab51:	nopl   0x0(%rax)
    ab58:	vpermpd (%rdi),%zmm5,%zmm0
    ab5e:	vaddpd (%rdi),%zmm0,%zmm1
    ab64:	add    $0x40,%rdi
    ab68:	vsubpd -0x40(%rdi),%zmm0,%zmm1{%k3}
    ab6f:	vpermpd %zmm1,%zmm4,%zmm2
    ab75:	vaddpd %zmm1,%zmm2,%zmm0
    ab7b:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
    ab81:	vpermpd %zmm0,%zmm3,%zmm2
    ab87:	vaddpd %zmm2,%zmm0,%zmm1
    ab8d:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
    ab93:	vmovupd %zmm1,-0x40(%rdi)
    ab9a:	cmp    %rax,%rdi
    ab9d:	jne    ab58 <hf2_kid_nat+0x68>
    ab9f:	vzeroupper
    aba2:	ret
    aba3:	data16 cs nopw 0x0(%rax,%rax,1)
    abae:	xchg   %ax,%ax

000000000000abb0 <hf2_tb2_nat>:
    abb0:	endbr64
    abb4:	vbroadcastsd 0x52402(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
    abbe:	test   %rsi,%rsi
    abc1:	je     acaf <hf2_tb2_nat+0xff>
    abc7:	lea    -0x8(,%rsi,8),%rax
    abcf:	mov    $0xffffffaa,%edx
    abd4:	vmovdqa64 0x52262(%rip),%zmm6        # 5ce40 <_IO_stdin_used+0xe40>
    abde:	vmovdqa64 0x52298(%rip),%zmm5        # 5ce80 <_IO_stdin_used+0xe80>
    abe8:	and    $0xffffffffffffff80,%rax
    abec:	mov    $0xffffffcc,%ecx
    abf1:	kmovw  %edx,%k3
    abf5:	vmovdqa64 0x522c1(%rip),%zmm4        # 5cec0 <_IO_stdin_used+0xec0>
    abff:	mov    $0xfffffff0,%edx
    ac04:	lea    0x80(%rdi,%rax,1),%rax
    ac0c:	kmovw  %ecx,%k2
    ac10:	kmovw  %edx,%k1
    ac14:	nopl   0x0(%rax)
    ac18:	vpermpd (%rdi),%zmm6,%zmm1
    ac1e:	vaddpd (%rdi),%zmm1,%zmm0
    ac24:	sub    $0xffffffffffffff80,%rdi
    ac28:	vsubpd -0x80(%rdi),%zmm1,%zmm0{%k3}
    ac2f:	vpermpd %zmm0,%zmm5,%zmm2
    ac35:	vaddpd %zmm0,%zmm2,%zmm1
    ac3b:	vsubpd %zmm0,%zmm2,%zmm1{%k2}
    ac41:	vpermpd %zmm1,%zmm4,%zmm2
    ac47:	vaddpd %zmm2,%zmm1,%zmm0
    ac4d:	vsubpd %zmm1,%zmm2,%zmm0{%k1}
    ac53:	vpermpd -0x40(%rdi),%zmm6,%zmm1
    ac5a:	vaddpd -0x40(%rdi),%zmm1,%zmm2
    ac61:	vsubpd -0x40(%rdi),%zmm1,%zmm2{%k3}
    ac68:	vpermpd %zmm2,%zmm5,%zmm3
    ac6e:	vaddpd %zmm2,%zmm3,%zmm1
    ac74:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
    ac7a:	vpermpd %zmm1,%zmm4,%zmm3
    ac80:	vaddpd %zmm3,%zmm1,%zmm2
    ac86:	vsubpd %zmm1,%zmm3,%zmm2{%k1}
    ac8c:	vaddpd %zmm2,%zmm0,%zmm1
    ac92:	vsubpd %zmm2,%zmm0,%zmm0
    ac98:	vmovupd %zmm1,-0x80(%rdi)
    ac9f:	vmovupd %zmm0,-0x40(%rdi)
    aca6:	cmp    %rax,%rdi
    aca9:	jne    ac18 <hf2_tb2_nat+0x68>
    acaf:	vzeroupper
    acb2:	ret
    acb3:	data16 cs nopw 0x0(%rax,%rax,1)
    acbe:	xchg   %ax,%ax

000000000000acc0 <hf2_tb4_nat>:
    acc0:	endbr64
    acc4:	vbroadcastsd 0x522f2(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
    acce:	test   %rsi,%rsi
    acd1:	je     ae65 <hf2_tb4_nat+0x1a5>
    acd7:	mov    $0xffffffaa,%ecx
    acdc:	mov    %rdi,%rax
    acdf:	lea    -0x8(,%rsi,8),%rdx
    ace7:	vmovdqa64 0x5214f(%rip),%zmm7        # 5ce40 <_IO_stdin_used+0xe40>
    acf1:	vmovdqa64 0x52185(%rip),%zmm6        # 5ce80 <_IO_stdin_used+0xe80>
    acfb:	xor    %dl,%dl
    acfd:	kmovw  %ecx,%k3
    ad01:	vmovdqa64 0x521b5(%rip),%zmm5        # 5cec0 <_IO_stdin_used+0xec0>
    ad0b:	mov    $0xffffffcc,%ecx
    ad10:	lea    0x100(%rdi,%rdx,1),%rdx
    ad18:	kmovw  %ecx,%k2
    ad1c:	mov    $0xfffffff0,%ecx
    ad21:	kmovw  %ecx,%k1
    ad25:	nopl   (%rax)
    ad28:	vpermpd (%rax),%zmm7,%zmm1
    ad2e:	vaddpd (%rax),%zmm1,%zmm0
    ad34:	add    $0x100,%rax
    ad3a:	vsubpd -0x100(%rax),%zmm1,%zmm0{%k3}
    ad41:	vpermpd %zmm0,%zmm6,%zmm2
    ad47:	vaddpd %zmm2,%zmm0,%zmm1
    ad4d:	vsubpd %zmm0,%zmm2,%zmm1{%k2}
    ad53:	vpermpd %zmm1,%zmm5,%zmm2
    ad59:	vaddpd %zmm2,%zmm1,%zmm0
    ad5f:	vsubpd %zmm1,%zmm2,%zmm0{%k1}
    ad65:	vpermpd -0xc0(%rax),%zmm7,%zmm1
    ad6c:	vaddpd -0xc0(%rax),%zmm1,%zmm2
    ad73:	vsubpd -0xc0(%rax),%zmm1,%zmm2{%k3}
    ad7a:	vpermpd %zmm2,%zmm6,%zmm3
    ad80:	vaddpd %zmm3,%zmm2,%zmm1
    ad86:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
    ad8c:	vpermpd %zmm1,%zmm5,%zmm2
    ad92:	vaddpd %zmm2,%zmm1,%zmm4
    ad98:	vsubpd %zmm1,%zmm2,%zmm4{%k1}
    ad9e:	vpermpd -0x80(%rax),%zmm7,%zmm2
    ada5:	vaddpd -0x80(%rax),%zmm2,%zmm1
    adac:	vsubpd -0x80(%rax),%zmm2,%zmm1{%k3}
    adb3:	vpermpd %zmm1,%zmm6,%zmm3
    adb9:	vaddpd %zmm3,%zmm1,%zmm2
    adbf:	vsubpd %zmm1,%zmm3,%zmm2{%k2}
    adc5:	vpermpd %zmm2,%zmm5,%zmm3
    adcb:	vaddpd %zmm3,%zmm2,%zmm1
    add1:	vsubpd %zmm2,%zmm3,%zmm1{%k1}
    add7:	vpermpd -0x40(%rax),%zmm7,%zmm2
    adde:	vaddpd -0x40(%rax),%zmm2,%zmm3
    ade5:	vsubpd -0x40(%rax),%zmm2,%zmm3{%k3}
    adec:	vpermpd %zmm3,%zmm6,%zmm8
    adf2:	vaddpd %zmm3,%zmm8,%zmm2
    adf8:	vsubpd %zmm3,%zmm8,%zmm2{%k2}
    adfe:	vpermpd %zmm2,%zmm5,%zmm8
    ae04:	vaddpd %zmm8,%zmm2,%zmm3
    ae0a:	vsubpd %zmm2,%zmm8,%zmm3{%k1}
    ae10:	vaddpd %zmm4,%zmm0,%zmm2
    ae16:	vsubpd %zmm4,%zmm0,%zmm0
    ae1c:	vaddpd %zmm1,%zmm3,%zmm4
    ae22:	vsubpd %zmm3,%zmm1,%zmm1
    ae28:	vaddpd %zmm4,%zmm2,%zmm3
    ae2e:	vsubpd %zmm4,%zmm2,%zmm2
    ae34:	vmovupd %zmm3,-0x100(%rax)
    ae3b:	vaddpd %zmm1,%zmm0,%zmm3
    ae41:	vsubpd %zmm1,%zmm0,%zmm0
    ae47:	vmovupd %zmm2,-0x80(%rax)
    ae4e:	vmovupd %zmm3,-0xc0(%rax)
    ae55:	vmovupd %zmm0,-0x40(%rax)
    ae5c:	cmp    %rdx,%rax
    ae5f:	jne    ad28 <hf2_tb4_nat+0x68>
    ae65:	vzeroupper
    ae68:	ret
    ae69:	nopl   0x0(%rax)

000000000000b170 <pass_tb16_bal_1>:
    b170:	endbr64
    b174:	lea    0x8(%rsp),%r10
    b179:	and    $0xffffffffffffffc0,%rsp
    b17d:	push   -0x8(%r10)
    b181:	push   %rbp
    b182:	mov    %rsp,%rbp
    b185:	push   %r14
    b187:	push   %r13
    b189:	push   %r12
    b18b:	push   %r10
    b18d:	push   %rbx
    b18e:	sub    $0x448,%rsp
    b195:	vbroadcastsd 0x51e21(%rip),%zmm24        # 5cfc0 <_IO_stdin_used+0xfc0>
    b19f:	mov    %fs:0x28,%rax
    b1a8:	mov    %rax,-0x38(%rbp)
    b1ac:	xor    %eax,%eax
    b1ae:	test   %rsi,%rsi
    b1b1:	je     b467 <pass_tb16_bal_1+0x2f7>
    b1b7:	mov    %rsi,%r10
    b1ba:	mov    %rsi,%r8
    b1bd:	lea    -0x470(%rbp),%r14
    b1c4:	xor    %r12d,%r12d
    b1c7:	shl    $0x4,%r8
    b1cb:	lea    (%r10,%r10,2),%rdx
    b1cf:	lea    -0x1(%r10),%r13
    b1d3:	mov    %r10,%rbx
    b1d6:	lea    0x0(,%rsi,8),%r11
    b1de:	lea    (%rdi,%r8,1),%rsi
    b1e2:	neg    %rbx
    b1e5:	shr    $0x3,%r13
    b1e9:	lea    0x0(,%rdx,8),%r9
    b1f1:	shl    $0x4,%rdx
    b1f5:	neg    %r8
    b1f8:	shl    $0x5,%rbx
    b1fc:	lea    (%rsi,%r9,1),%rax
    b200:	add    %rax,%rdx
    b203:	lea    (%rdx,%r11,1),%rcx
    b207:	neg    %r11
    b20a:	nopw   0x0(%rax,%rax,1)
    b210:	vmovupd (%rdx,%rbx,1),%zmm0
    b217:	vmovupd (%rsi,%r8,1),%zmm1
    b21e:	mov    %r14,%rdi
    b221:	add    $0x40,%rsi
    b225:	vmovupd (%rax,%rbx,1),%zmm2
    b22c:	vmovupd (%rax),%zmm6
    b232:	add    $0x40,%rdx
    b236:	vmovupd (%rax,%r8,1),%zmm4
    b23d:	vmovupd (%rax,%r11,1),%zmm5
    b244:	vmovapd %zmm0,-0x2b0(%rbp)
    b24e:	vmovupd (%rax,%r10,8),%zmm7
    b255:	vmovupd -0x40(%rsi),%zmm3
    b25c:	vmovapd %zmm1,-0x470(%rbp)
    b266:	vmovupd (%rcx,%r9,1),%zmm0
    b26d:	vmovupd (%rax,%r9,1),%zmm1
    b274:	vmovapd %zmm2,-0x430(%rbp)
    b27e:	vmovapd %zmm3,-0x3f0(%rbp)
    b288:	vmovupd -0x40(%rdx,%r8,1),%zmm2
    b290:	vmovupd -0x40(%rdx,%r11,1),%zmm3
    b298:	vmovapd %zmm4,-0x3b0(%rbp)
    b2a2:	vmovupd -0x40(%rdx),%zmm4
    b2a9:	vmovapd %zmm5,-0x370(%rbp)
    b2b3:	vmovupd (%rcx),%zmm5
    b2b9:	vmovapd %zmm6,-0x330(%rbp)
    b2c3:	vmovupd (%rcx,%r10,8),%zmm6
    b2ca:	vmovapd %zmm7,-0x2f0(%rbp)
    b2d4:	vmovupd -0x40(%rdx,%r9,1),%zmm7
    b2dc:	vmovapd %zmm0,-0xb0(%rbp)
    b2e6:	vmovapd %zmm24,%zmm0
    b2ec:	vmovapd %zmm1,-0x270(%rbp)
    b2f6:	vmovapd %zmm2,-0x230(%rbp)
    b300:	vmovapd %zmm3,-0x1f0(%rbp)
    b30a:	vmovapd %zmm4,-0x1b0(%rbp)
    b314:	vmovapd %zmm5,-0x170(%rbp)
    b31e:	vmovapd %zmm6,-0x130(%rbp)
    b328:	vmovapd %zmm7,-0xf0(%rbp)
    b332:	call   ae70 <tb16_bal>
    b337:	mov    %r12,%rdi
    b33a:	add    $0x1,%r12
    b33e:	vmovapd -0x470(%rbp),%zmm1
    b348:	vmovapd -0x430(%rbp),%zmm2
    b352:	vmovapd -0x3f0(%rbp),%zmm3
    b35c:	vmovapd -0x3b0(%rbp),%zmm4
    b366:	vmovapd -0x370(%rbp),%zmm5
    b370:	vmovupd %zmm1,-0x40(%rsi,%r8,1)
    b378:	vmovapd -0x330(%rbp),%zmm6
    b382:	vmovupd %zmm2,(%rax,%rbx,1)
    b389:	vmovapd -0x2f0(%rbp),%zmm7
    b393:	vmovapd -0x2b0(%rbp),%zmm0
    b39d:	vmovupd %zmm3,-0x40(%rsi)
    b3a4:	vmovapd -0x270(%rbp),%zmm1
    b3ae:	vmovupd %zmm4,(%rax,%r8,1)
    b3b5:	vmovapd -0x230(%rbp),%zmm2
    b3bf:	vmovapd -0x1f0(%rbp),%zmm3
    b3c9:	vmovupd %zmm5,(%rax,%r11,1)
    b3d0:	vmovapd -0x1b0(%rbp),%zmm4
    b3da:	vmovapd -0x170(%rbp),%zmm5
    b3e4:	vmovupd %zmm6,(%rax)
    b3ea:	vmovapd -0x130(%rbp),%zmm6
    b3f4:	vmovupd %zmm7,(%rax,%r10,8)
    b3fb:	add    $0x40,%rax
    b3ff:	vmovapd -0xf0(%rbp),%zmm7
    b409:	vmovupd %zmm0,-0x40(%rdx,%rbx,1)
    b411:	vmovapd -0xb0(%rbp),%zmm0
    b41b:	vmovupd %zmm1,-0x40(%rax,%r9,1)
    b423:	vmovupd %zmm2,-0x40(%rdx,%r8,1)
    b42b:	vmovupd %zmm3,-0x40(%rdx,%r11,1)
    b433:	vmovupd %zmm4,-0x40(%rdx)
    b43a:	vmovupd %zmm5,(%rcx)
    b440:	vmovupd %zmm6,(%rcx,%r10,8)
    b447:	add    $0x40,%rcx
    b44b:	vmovupd %zmm7,-0x40(%rdx,%r9,1)
    b453:	vmovupd %zmm0,-0x40(%rcx,%r9,1)
    b45b:	cmp    %rdi,%r13
    b45e:	jne    b210 <pass_tb16_bal_1+0xa0>
    b464:	vzeroupper
    b467:	mov    -0x38(%rbp),%rax
    b46b:	sub    %fs:0x28,%rax
    b474:	jne    b48c <pass_tb16_bal_1+0x31c>
    b476:	add    $0x448,%rsp
    b47d:	pop    %rbx
    b47e:	pop    %r10
    b480:	pop    %r12
    b482:	pop    %r13
    b484:	pop    %r14
    b486:	pop    %rbp
    b487:	lea    -0x8(%r10),%rsp
    b48b:	ret
    b48c:	call   4280 <__stack_chk_fail@plt>
    b491:	data16 cs nopw 0x0(%rax,%rax,1)
    b49c:	nopl   0x0(%rax)

000000000000c570 <pass_tb16_balS_1>:
    c570:	endbr64
    c574:	lea    0x8(%rsp),%r10
    c579:	and    $0xffffffffffffffc0,%rsp
    c57d:	push   -0x8(%r10)
    c581:	push   %rbp
    c582:	mov    %rsp,%rbp
    c585:	push   %r14
    c587:	push   %r13
    c589:	push   %r12
    c58b:	push   %r10
    c58d:	push   %rbx
    c58e:	sub    $0x448,%rsp
    c595:	vbroadcastsd 0x50a21(%rip),%zmm24        # 5cfc0 <_IO_stdin_used+0xfc0>
    c59f:	mov    %fs:0x28,%rax
    c5a8:	mov    %rax,-0x38(%rbp)
    c5ac:	xor    %eax,%eax
    c5ae:	test   %rsi,%rsi
    c5b1:	je     c867 <pass_tb16_balS_1+0x2f7>
    c5b7:	mov    %rsi,%r10
    c5ba:	mov    %rsi,%r8
    c5bd:	lea    -0x470(%rbp),%r14
    c5c4:	xor    %r12d,%r12d
    c5c7:	shl    $0x4,%r8
    c5cb:	lea    (%r10,%r10,2),%rdx
    c5cf:	lea    -0x1(%r10),%r13
    c5d3:	mov    %r10,%rbx
    c5d6:	lea    0x0(,%rsi,8),%r11
    c5de:	lea    (%rdi,%r8,1),%rsi
    c5e2:	neg    %rbx
    c5e5:	shr    $0x3,%r13
    c5e9:	lea    0x0(,%rdx,8),%r9
    c5f1:	shl    $0x4,%rdx
    c5f5:	neg    %r8
    c5f8:	shl    $0x5,%rbx
    c5fc:	lea    (%rsi,%r9,1),%rax
    c600:	add    %rax,%rdx
    c603:	lea    (%rdx,%r11,1),%rcx
    c607:	neg    %r11
    c60a:	nopw   0x0(%rax,%rax,1)
    c610:	vmovupd (%rdx,%rbx,1),%zmm0
    c617:	vmovupd (%rsi,%r8,1),%zmm1
    c61e:	mov    %r14,%rdi
    c621:	add    $0x40,%rsi
    c625:	vmovupd (%rax,%rbx,1),%zmm2
    c62c:	vmovupd (%rax),%zmm6
    c632:	add    $0x40,%rdx
    c636:	vmovupd (%rax,%r8,1),%zmm4
    c63d:	vmovupd (%rax,%r11,1),%zmm5
    c644:	vmovapd %zmm0,-0x2b0(%rbp)
    c64e:	vmovupd (%rax,%r10,8),%zmm7
    c655:	vmovupd -0x40(%rsi),%zmm3
    c65c:	vmovapd %zmm1,-0x470(%rbp)
    c666:	vmovupd (%rcx,%r9,1),%zmm0
    c66d:	vmovupd (%rax,%r9,1),%zmm1
    c674:	vmovapd %zmm2,-0x430(%rbp)
    c67e:	vmovapd %zmm3,-0x3f0(%rbp)
    c688:	vmovupd -0x40(%rdx,%r8,1),%zmm2
    c690:	vmovupd -0x40(%rdx,%r11,1),%zmm3
    c698:	vmovapd %zmm4,-0x3b0(%rbp)
    c6a2:	vmovupd -0x40(%rdx),%zmm4
    c6a9:	vmovapd %zmm5,-0x370(%rbp)
    c6b3:	vmovupd (%rcx),%zmm5
    c6b9:	vmovapd %zmm6,-0x330(%rbp)
    c6c3:	vmovupd (%rcx,%r10,8),%zmm6
    c6ca:	vmovapd %zmm7,-0x2f0(%rbp)
    c6d4:	vmovupd -0x40(%rdx,%r9,1),%zmm7
    c6dc:	vmovapd %zmm0,-0xb0(%rbp)
    c6e6:	vmovapd %zmm24,%zmm0
    c6ec:	vmovapd %zmm1,-0x270(%rbp)
    c6f6:	vmovapd %zmm2,-0x230(%rbp)
    c700:	vmovapd %zmm3,-0x1f0(%rbp)
    c70a:	vmovapd %zmm4,-0x1b0(%rbp)
    c714:	vmovapd %zmm5,-0x170(%rbp)
    c71e:	vmovapd %zmm6,-0x130(%rbp)
    c728:	vmovapd %zmm7,-0xf0(%rbp)
    c732:	call   c2d0 <tb16_balS>
    c737:	mov    %r12,%rdi
    c73a:	add    $0x1,%r12
    c73e:	vmovapd -0x470(%rbp),%zmm1
    c748:	vmovapd -0x430(%rbp),%zmm2
    c752:	vmovapd -0x3f0(%rbp),%zmm3
    c75c:	vmovapd -0x3b0(%rbp),%zmm4
    c766:	vmovapd -0x370(%rbp),%zmm5
    c770:	vmovupd %zmm1,-0x40(%rsi,%r8,1)
    c778:	vmovapd -0x330(%rbp),%zmm6
    c782:	vmovupd %zmm2,(%rax,%rbx,1)
    c789:	vmovapd -0x2f0(%rbp),%zmm7
    c793:	vmovapd -0x2b0(%rbp),%zmm0
    c79d:	vmovupd %zmm3,-0x40(%rsi)
    c7a4:	vmovapd -0x270(%rbp),%zmm1
    c7ae:	vmovupd %zmm4,(%rax,%r8,1)
    c7b5:	vmovapd -0x230(%rbp),%zmm2
    c7bf:	vmovapd -0x1f0(%rbp),%zmm3
    c7c9:	vmovupd %zmm5,(%rax,%r11,1)
    c7d0:	vmovapd -0x1b0(%rbp),%zmm4
    c7da:	vmovapd -0x170(%rbp),%zmm5
    c7e4:	vmovupd %zmm6,(%rax)
    c7ea:	vmovapd -0x130(%rbp),%zmm6
    c7f4:	vmovupd %zmm7,(%rax,%r10,8)
    c7fb:	add    $0x40,%rax
    c7ff:	vmovapd -0xf0(%rbp),%zmm7
    c809:	vmovupd %zmm0,-0x40(%rdx,%rbx,1)
    c811:	vmovapd -0xb0(%rbp),%zmm0
    c81b:	vmovupd %zmm1,-0x40(%rax,%r9,1)
    c823:	vmovupd %zmm2,-0x40(%rdx,%r8,1)
    c82b:	vmovupd %zmm3,-0x40(%rdx,%r11,1)
    c833:	vmovupd %zmm4,-0x40(%rdx)
    c83a:	vmovupd %zmm5,(%rcx)
    c840:	vmovupd %zmm6,(%rcx,%r10,8)
    c847:	add    $0x40,%rcx
    c84b:	vmovupd %zmm7,-0x40(%rdx,%r9,1)
    c853:	vmovupd %zmm0,-0x40(%rcx,%r9,1)
    c85b:	cmp    %rdi,%r13
    c85e:	jne    c610 <pass_tb16_balS_1+0xa0>
    c864:	vzeroupper
    c867:	mov    -0x38(%rbp),%rax
    c86b:	sub    %fs:0x28,%rax
    c874:	jne    c88c <pass_tb16_balS_1+0x31c>
    c876:	add    $0x448,%rsp
    c87d:	pop    %rbx
    c87e:	pop    %r10
    c880:	pop    %r12
    c882:	pop    %r13
    c884:	pop    %r14
    c886:	pop    %rbp
    c887:	lea    -0x8(%r10),%rsp
    c88b:	ret
    c88c:	call   4280 <__stack_chk_fail@plt>
    c891:	data16 cs nopw 0x0(%rax,%rax,1)
    c89c:	nopl   0x0(%rax)

000000000000df60 <hf1_kid_nat>:
    df60:	endbr64
    df64:	push   %rbp
    df65:	mov    %rdi,%rdx
    df68:	mov    %rsp,%rbp
    df6b:	and    $0xffffffffffffffc0,%rsp
    df6f:	sub    $0x100,%rsp
    df76:	vbroadcastsd 0x4f040(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
    df80:	mov    %fs:0x28,%rax
    df89:	mov    %rax,0xf8(%rsp)
    df91:	xor    %eax,%eax
    df93:	mov    %rsp,%rdi
    df96:	vzeroupper
    df99:	call   df20 <inl_consts.constprop.0>
    df9e:	vmovapd (%rsp),%zmm4
    dfa5:	vmovapd 0x40(%rsp),%zmm3
    dfad:	vmovapd 0x80(%rsp),%zmm2
    dfb5:	test   %rsi,%rsi
    dfb8:	je     e019 <hf1_kid_nat+0xb9>
    dfba:	lea    -0x8(,%rsi,8),%rax
    dfc2:	mov    %rdx,%rdi
    dfc5:	and    $0xffffffffffffffc0,%rax
    dfc9:	lea    0x40(%rdx,%rax,1),%rax
    dfce:	xchg   %ax,%ax
    dfd0:	vpxord (%rdi),%zmm4,%zmm1
    dfd6:	vpermilpd $0x55,(%rdi),%zmm0
    dfdd:	add    $0x40,%rdi
    dfe1:	vaddpd %zmm1,%zmm0,%zmm0
    dfe7:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    dfee:	vpxord %zmm0,%zmm3,%zmm0
    dff4:	vaddpd %zmm0,%zmm1,%zmm0
    dffa:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e001:	vpxord %zmm0,%zmm2,%zmm0
    e007:	vaddpd %zmm0,%zmm1,%zmm0
    e00d:	vmovupd %zmm0,-0x40(%rdi)
    e014:	cmp    %rdi,%rax
    e017:	jne    dfd0 <hf1_kid_nat+0x70>
    e019:	mov    0xf8(%rsp),%rax
    e021:	sub    %fs:0x28,%rax
    e02a:	jne    e031 <hf1_kid_nat+0xd1>
    e02c:	vzeroupper
    e02f:	leave
    e030:	ret
    e031:	vzeroupper
    e034:	call   4280 <__stack_chk_fail@plt>
    e039:	nopl   0x0(%rax)

000000000000e040 <hf1_tb2_nat>:
    e040:	endbr64
    e044:	push   %rbp
    e045:	mov    %rdi,%rdx
    e048:	mov    %rsp,%rbp
    e04b:	and    $0xffffffffffffffc0,%rsp
    e04f:	sub    $0x100,%rsp
    e056:	vbroadcastsd 0x4ef60(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
    e060:	mov    %fs:0x28,%rax
    e069:	mov    %rax,0xf8(%rsp)
    e071:	xor    %eax,%eax
    e073:	mov    %rsp,%rdi
    e076:	vzeroupper
    e079:	call   df20 <inl_consts.constprop.0>
    e07e:	vmovapd (%rsp),%zmm5
    e085:	vmovapd 0x40(%rsp),%zmm4
    e08d:	vmovapd 0x80(%rsp),%zmm3
    e095:	test   %rsi,%rsi
    e098:	je     e153 <hf1_tb2_nat+0x113>
    e09e:	lea    -0x8(,%rsi,8),%rax
    e0a6:	mov    %rdx,%rdi
    e0a9:	and    $0xffffffffffffff80,%rax
    e0ad:	lea    0x80(%rdx,%rax,1),%rax
    e0b5:	nopl   (%rax)
    e0b8:	vpxord (%rdi),%zmm5,%zmm1
    e0be:	vpermilpd $0x55,(%rdi),%zmm0
    e0c5:	sub    $0xffffffffffffff80,%rdi
    e0c9:	vaddpd %zmm1,%zmm0,%zmm0
    e0cf:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e0d6:	vpxord %zmm0,%zmm4,%zmm0
    e0dc:	vaddpd %zmm0,%zmm1,%zmm0
    e0e2:	vpxord -0x40(%rdi),%zmm5,%zmm1
    e0e9:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm2
    e0f0:	vpxord %zmm0,%zmm3,%zmm0
    e0f6:	vaddpd %zmm0,%zmm2,%zmm2
    e0fc:	vpermilpd $0x55,-0x40(%rdi),%zmm0
    e104:	vaddpd %zmm1,%zmm0,%zmm0
    e10a:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e111:	vpxord %zmm0,%zmm4,%zmm0
    e117:	vaddpd %zmm0,%zmm1,%zmm0
    e11d:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e124:	vpxord %zmm0,%zmm3,%zmm0
    e12a:	vaddpd %zmm0,%zmm1,%zmm0
    e130:	vaddpd %zmm0,%zmm2,%zmm1
    e136:	vsubpd %zmm0,%zmm2,%zmm2
    e13c:	vmovupd %zmm1,-0x80(%rdi)
    e143:	vmovupd %zmm2,-0x40(%rdi)
    e14a:	cmp    %rdi,%rax
    e14d:	jne    e0b8 <hf1_tb2_nat+0x78>
    e153:	mov    0xf8(%rsp),%rax
    e15b:	sub    %fs:0x28,%rax
    e164:	jne    e16b <hf1_tb2_nat+0x12b>
    e166:	vzeroupper
    e169:	leave
    e16a:	ret
    e16b:	vzeroupper
    e16e:	call   4280 <__stack_chk_fail@plt>
    e173:	data16 cs nopw 0x0(%rax,%rax,1)
    e17e:	xchg   %ax,%ax

000000000000e180 <hf1_tb4_nat>:
    e180:	endbr64
    e184:	push   %rbp
    e185:	mov    %rdi,%rdx
    e188:	mov    %rsp,%rbp
    e18b:	and    $0xffffffffffffffc0,%rsp
    e18f:	sub    $0x100,%rsp
    e196:	vbroadcastsd 0x4ee20(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
    e1a0:	mov    %fs:0x28,%rax
    e1a9:	mov    %rax,0xf8(%rsp)
    e1b1:	xor    %eax,%eax
    e1b3:	mov    %rsp,%rdi
    e1b6:	vzeroupper
    e1b9:	call   df20 <inl_consts.constprop.0>
    e1be:	vmovapd (%rsp),%zmm6
    e1c5:	vmovapd 0x40(%rsp),%zmm5
    e1cd:	vmovapd 0x80(%rsp),%zmm4
    e1d5:	test   %rsi,%rsi
    e1d8:	je     e33d <hf1_tb4_nat+0x1bd>
    e1de:	mov    %rdx,%rax
    e1e1:	lea    -0x8(,%rsi,8),%rdx
    e1e9:	xor    %dl,%dl
    e1eb:	lea    0x100(%rax,%rdx,1),%rdx
    e1f3:	nopl   0x0(%rax,%rax,1)
    e1f8:	vpxord (%rax),%zmm6,%zmm1
    e1fe:	vpermilpd $0x55,(%rax),%zmm0
    e205:	add    $0x100,%rax
    e20b:	vpxord -0xc0(%rax),%zmm6,%zmm2
    e212:	vpxord -0x40(%rax),%zmm6,%zmm3
    e219:	vaddpd %zmm1,%zmm0,%zmm0
    e21f:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e226:	vpxord %zmm0,%zmm5,%zmm0
    e22c:	vaddpd %zmm0,%zmm1,%zmm1
    e232:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm0
    e239:	vpxord %zmm1,%zmm4,%zmm1
    e23f:	vaddpd %zmm1,%zmm0,%zmm1
    e245:	vpermilpd $0x55,-0xc0(%rax),%zmm0
    e24d:	vaddpd %zmm2,%zmm0,%zmm0
    e253:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm2
    e25a:	vpxord %zmm0,%zmm5,%zmm0
    e260:	vaddpd %zmm0,%zmm2,%zmm0
    e266:	vpxord -0x80(%rax),%zmm6,%zmm2
    e26d:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm8
    e274:	vpxord %zmm0,%zmm4,%zmm0
    e27a:	vaddpd %zmm0,%zmm8,%zmm8
    e280:	vpermilpd $0x55,-0x80(%rax),%zmm0
    e288:	vaddpd %zmm2,%zmm0,%zmm0
    e28e:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm2
    e295:	vpxord %zmm0,%zmm5,%zmm0
    e29b:	vaddpd %zmm0,%zmm2,%zmm0
    e2a1:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm2
    e2a8:	vpxord %zmm0,%zmm4,%zmm0
    e2ae:	vaddpd %zmm0,%zmm2,%zmm2
    e2b4:	vpermilpd $0x55,-0x40(%rax),%zmm0
    e2bc:	vaddpd %zmm3,%zmm0,%zmm0
    e2c2:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm3
    e2c9:	vpxord %zmm0,%zmm5,%zmm0
    e2cf:	vaddpd %zmm0,%zmm3,%zmm0
    e2d5:	vaddpd %zmm8,%zmm1,%zmm3
    e2db:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm7
    e2e2:	vpxord %zmm0,%zmm4,%zmm0
    e2e8:	vaddpd %zmm0,%zmm7,%zmm7
    e2ee:	vsubpd %zmm8,%zmm1,%zmm0
    e2f4:	vaddpd %zmm7,%zmm2,%zmm8
    e2fa:	vsubpd %zmm7,%zmm2,%zmm1
    e300:	vaddpd %zmm8,%zmm3,%zmm2
    e306:	vsubpd %zmm8,%zmm3,%zmm3
    e30c:	vmovupd %zmm2,-0x100(%rax)
    e313:	vaddpd %zmm1,%zmm0,%zmm2
    e319:	vsubpd %zmm1,%zmm0,%zmm0
    e31f:	vmovupd %zmm3,-0x80(%rax)
    e326:	vmovupd %zmm2,-0xc0(%rax)
    e32d:	vmovupd %zmm0,-0x40(%rax)
    e334:	cmp    %rax,%rdx
    e337:	jne    e1f8 <hf1_tb4_nat+0x78>
    e33d:	mov    0xf8(%rsp),%rax
    e345:	sub    %fs:0x28,%rax
    e34e:	jne    e355 <hf1_tb4_nat+0x1d5>
    e350:	vzeroupper
    e353:	leave
    e354:	ret
    e355:	vzeroupper
    e358:	call   4280 <__stack_chk_fail@plt>
    e35d:	nopl   (%rax)

000000000000e360 <hf1_tb8_bal>:
    e360:	endbr64
    e364:	lea    0x8(%rsp),%r10
    e369:	and    $0xffffffffffffffc0,%rsp
    e36d:	mov    %rdi,%rdx
    e370:	push   -0x8(%r10)
    e374:	push   %rbp
    e375:	mov    %rsp,%rbp
    e378:	push   %r10
    e37a:	sub    $0x328,%rsp
    e381:	vbroadcastsd 0x4ec35(%rip),%zmm16        # 5cfc0 <_IO_stdin_used+0xfc0>
    e38b:	mov    %fs:0x28,%rax
    e394:	mov    %rax,-0x38(%rbp)
    e398:	xor    %eax,%eax
    e39a:	lea    -0x330(%rbp),%rdi
    e3a1:	call   df20 <inl_consts.constprop.0>
    e3a6:	vmovapd -0x330(%rbp),%zmm14
    e3b0:	vmovapd -0x2f0(%rbp),%zmm13
    e3ba:	vmovapd -0x2b0(%rbp),%zmm12
    e3c4:	test   %rsi,%rsi
    e3c7:	je     e6b7 <hf1_tb8_bal+0x357>
    e3cd:	sub    $0x1,%rsi
    e3d1:	mov    %rdx,%rax
    e3d4:	lea    -0x270(%rbp),%rdi
    e3db:	xor    %edx,%edx
    e3dd:	shr    $0x6,%rsi
    e3e1:	nopl   0x0(%rax)
    e3e8:	vpxord (%rax),%zmm14,%zmm1
    e3ee:	vpermilpd $0x55,(%rax),%zmm0
    e3f5:	mov    %rdx,%rcx
    e3f8:	add    $0x200,%rax
    e3fe:	add    $0x1,%rdx
    e402:	vaddpd %zmm1,%zmm0,%zmm0
    e408:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e40f:	vpxord %zmm0,%zmm13,%zmm0
    e415:	vaddpd %zmm0,%zmm1,%zmm0
    e41b:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e422:	vpxord %zmm0,%zmm12,%zmm0
    e428:	vaddpd %zmm0,%zmm1,%zmm0
    e42e:	vpxord -0x1c0(%rax),%zmm14,%zmm1
    e435:	vmovapd %zmm0,-0x270(%rbp)
    e43f:	vpermilpd $0x55,-0x1c0(%rax),%zmm0
    e447:	vaddpd %zmm1,%zmm0,%zmm0
    e44d:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e454:	vpxord %zmm0,%zmm13,%zmm0
    e45a:	vaddpd %zmm0,%zmm1,%zmm0
    e460:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e467:	vpxord %zmm0,%zmm12,%zmm0
    e46d:	vaddpd %zmm0,%zmm1,%zmm0
    e473:	vpxord -0x180(%rax),%zmm14,%zmm1
    e47a:	vmovapd %zmm0,-0x230(%rbp)
    e484:	vpermilpd $0x55,-0x180(%rax),%zmm0
    e48c:	vaddpd %zmm1,%zmm0,%zmm0
    e492:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e499:	vpxord %zmm0,%zmm13,%zmm0
    e49f:	vaddpd %zmm0,%zmm1,%zmm0
    e4a5:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e4ac:	vpxord %zmm0,%zmm12,%zmm0
    e4b2:	vaddpd %zmm0,%zmm1,%zmm0
    e4b8:	vpxord -0x140(%rax),%zmm14,%zmm1
    e4bf:	vmovapd %zmm0,-0x1f0(%rbp)
    e4c9:	vpermilpd $0x55,-0x140(%rax),%zmm0
    e4d1:	vaddpd %zmm1,%zmm0,%zmm0
    e4d7:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e4de:	vpxord %zmm0,%zmm13,%zmm0
    e4e4:	vaddpd %zmm0,%zmm1,%zmm0
    e4ea:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e4f1:	vpxord %zmm0,%zmm12,%zmm0
    e4f7:	vaddpd %zmm0,%zmm1,%zmm0
    e4fd:	vpxord -0x100(%rax),%zmm14,%zmm1
    e504:	vmovapd %zmm0,-0x1b0(%rbp)
    e50e:	vpermilpd $0x55,-0x100(%rax),%zmm0
    e516:	vaddpd %zmm1,%zmm0,%zmm0
    e51c:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e523:	vpxord %zmm0,%zmm13,%zmm0
    e529:	vaddpd %zmm0,%zmm1,%zmm0
    e52f:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e536:	vpxord %zmm0,%zmm12,%zmm0
    e53c:	vaddpd %zmm0,%zmm1,%zmm0
    e542:	vpxord -0xc0(%rax),%zmm14,%zmm1
    e549:	vmovapd %zmm0,-0x170(%rbp)
    e553:	vpermilpd $0x55,-0xc0(%rax),%zmm0
    e55b:	vaddpd %zmm1,%zmm0,%zmm0
    e561:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e568:	vpxord %zmm0,%zmm13,%zmm0
    e56e:	vaddpd %zmm0,%zmm1,%zmm0
    e574:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e57b:	vpxord %zmm0,%zmm12,%zmm0
    e581:	vaddpd %zmm0,%zmm1,%zmm0
    e587:	vpxord -0x80(%rax),%zmm14,%zmm1
    e58e:	vmovapd %zmm0,-0x130(%rbp)
    e598:	vpermilpd $0x55,-0x80(%rax),%zmm0
    e5a0:	vaddpd %zmm1,%zmm0,%zmm0
    e5a6:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e5ad:	vpxord %zmm0,%zmm13,%zmm0
    e5b3:	vaddpd %zmm0,%zmm1,%zmm0
    e5b9:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e5c0:	vpxord %zmm0,%zmm12,%zmm0
    e5c6:	vaddpd %zmm0,%zmm1,%zmm0
    e5cc:	vpxord -0x40(%rax),%zmm14,%zmm1
    e5d3:	vmovapd %zmm0,-0xf0(%rbp)
    e5dd:	vpermilpd $0x55,-0x40(%rax),%zmm0
    e5e5:	vaddpd %zmm1,%zmm0,%zmm0
    e5eb:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e5f2:	vpxord %zmm0,%zmm13,%zmm0
    e5f8:	vaddpd %zmm0,%zmm1,%zmm0
    e5fe:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e605:	vpxord %zmm0,%zmm12,%zmm0
    e60b:	vaddpd %zmm0,%zmm1,%zmm0
    e611:	vmovapd %zmm0,-0xb0(%rbp)
    e61b:	vmovapd %zmm16,%zmm0
    e621:	call   bf70 <tb8_bal>
    e626:	vmovapd -0x270(%rbp),%zmm2
    e630:	vmovapd -0x230(%rbp),%zmm3
    e63a:	vmovapd -0x1f0(%rbp),%zmm4
    e644:	vmovapd -0x1b0(%rbp),%zmm5
    e64e:	vmovupd %zmm2,-0x200(%rax)
    e655:	vmovapd -0x170(%rbp),%zmm6
    e65f:	vmovapd -0x130(%rbp),%zmm7
    e669:	vmovupd %zmm3,-0x1c0(%rax)
    e670:	vmovapd -0xf0(%rbp),%zmm2
    e67a:	vmovapd -0xb0(%rbp),%zmm3
    e684:	vmovupd %zmm4,-0x180(%rax)
    e68b:	vmovupd %zmm5,-0x140(%rax)
    e692:	vmovupd %zmm6,-0x100(%rax)
    e699:	vmovupd %zmm7,-0xc0(%rax)
    e6a0:	vmovupd %zmm2,-0x80(%rax)
    e6a7:	vmovupd %zmm3,-0x40(%rax)
    e6ae:	cmp    %rcx,%rsi
    e6b1:	jne    e3e8 <hf1_tb8_bal+0x88>
    e6b7:	mov    -0x38(%rbp),%rax
    e6bb:	sub    %fs:0x28,%rax
    e6c4:	jne    e6d3 <hf1_tb8_bal+0x373>
    e6c6:	vzeroupper
    e6c9:	mov    -0x8(%rbp),%r10
    e6cd:	leave
    e6ce:	lea    -0x8(%r10),%rsp
    e6d2:	ret
    e6d3:	vzeroupper
    e6d6:	call   4280 <__stack_chk_fail@plt>
    e6db:	nopl   0x0(%rax,%rax,1)

000000000000e6e0 <hf1_tb8_balS>:
    e6e0:	endbr64
    e6e4:	lea    0x8(%rsp),%r10
    e6e9:	and    $0xffffffffffffffc0,%rsp
    e6ed:	mov    %rdi,%rdx
    e6f0:	push   -0x8(%r10)
    e6f4:	push   %rbp
    e6f5:	mov    %rsp,%rbp
    e6f8:	push   %r10
    e6fa:	sub    $0x328,%rsp
    e701:	vbroadcastsd 0x4e8b5(%rip),%zmm16        # 5cfc0 <_IO_stdin_used+0xfc0>
    e70b:	mov    %fs:0x28,%rax
    e714:	mov    %rax,-0x38(%rbp)
    e718:	xor    %eax,%eax
    e71a:	lea    -0x330(%rbp),%rdi
    e721:	call   df20 <inl_consts.constprop.0>
    e726:	vmovapd -0x330(%rbp),%zmm14
    e730:	vmovapd -0x2f0(%rbp),%zmm13
    e73a:	vmovapd -0x2b0(%rbp),%zmm12
    e744:	test   %rsi,%rsi
    e747:	je     ea37 <hf1_tb8_balS+0x357>
    e74d:	sub    $0x1,%rsi
    e751:	mov    %rdx,%rax
    e754:	lea    -0x270(%rbp),%rdi
    e75b:	xor    %edx,%edx
    e75d:	shr    $0x6,%rsi
    e761:	nopl   0x0(%rax)
    e768:	vpxord (%rax),%zmm14,%zmm1
    e76e:	vpermilpd $0x55,(%rax),%zmm0
    e775:	mov    %rdx,%rcx
    e778:	add    $0x200,%rax
    e77e:	add    $0x1,%rdx
    e782:	vaddpd %zmm1,%zmm0,%zmm0
    e788:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e78f:	vpxord %zmm0,%zmm13,%zmm0
    e795:	vaddpd %zmm0,%zmm1,%zmm0
    e79b:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e7a2:	vpxord %zmm0,%zmm12,%zmm0
    e7a8:	vaddpd %zmm0,%zmm1,%zmm0
    e7ae:	vpxord -0x1c0(%rax),%zmm14,%zmm1
    e7b5:	vmovapd %zmm0,-0x270(%rbp)
    e7bf:	vpermilpd $0x55,-0x1c0(%rax),%zmm0
    e7c7:	vaddpd %zmm1,%zmm0,%zmm0
    e7cd:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e7d4:	vpxord %zmm0,%zmm13,%zmm0
    e7da:	vaddpd %zmm0,%zmm1,%zmm0
    e7e0:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e7e7:	vpxord %zmm0,%zmm12,%zmm0
    e7ed:	vaddpd %zmm0,%zmm1,%zmm0
    e7f3:	vpxord -0x180(%rax),%zmm14,%zmm1
    e7fa:	vmovapd %zmm0,-0x230(%rbp)
    e804:	vpermilpd $0x55,-0x180(%rax),%zmm0
    e80c:	vaddpd %zmm1,%zmm0,%zmm0
    e812:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e819:	vpxord %zmm0,%zmm13,%zmm0
    e81f:	vaddpd %zmm0,%zmm1,%zmm0
    e825:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e82c:	vpxord %zmm0,%zmm12,%zmm0
    e832:	vaddpd %zmm0,%zmm1,%zmm0
    e838:	vpxord -0x140(%rax),%zmm14,%zmm1
    e83f:	vmovapd %zmm0,-0x1f0(%rbp)
    e849:	vpermilpd $0x55,-0x140(%rax),%zmm0
    e851:	vaddpd %zmm1,%zmm0,%zmm0
    e857:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e85e:	vpxord %zmm0,%zmm13,%zmm0
    e864:	vaddpd %zmm0,%zmm1,%zmm0
    e86a:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e871:	vpxord %zmm0,%zmm12,%zmm0
    e877:	vaddpd %zmm0,%zmm1,%zmm0
    e87d:	vpxord -0x100(%rax),%zmm14,%zmm1
    e884:	vmovapd %zmm0,-0x1b0(%rbp)
    e88e:	vpermilpd $0x55,-0x100(%rax),%zmm0
    e896:	vaddpd %zmm1,%zmm0,%zmm0
    e89c:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e8a3:	vpxord %zmm0,%zmm13,%zmm0
    e8a9:	vaddpd %zmm0,%zmm1,%zmm0
    e8af:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e8b6:	vpxord %zmm0,%zmm12,%zmm0
    e8bc:	vaddpd %zmm0,%zmm1,%zmm0
    e8c2:	vpxord -0xc0(%rax),%zmm14,%zmm1
    e8c9:	vmovapd %zmm0,-0x170(%rbp)
    e8d3:	vpermilpd $0x55,-0xc0(%rax),%zmm0
    e8db:	vaddpd %zmm1,%zmm0,%zmm0
    e8e1:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e8e8:	vpxord %zmm0,%zmm13,%zmm0
    e8ee:	vaddpd %zmm0,%zmm1,%zmm0
    e8f4:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e8fb:	vpxord %zmm0,%zmm12,%zmm0
    e901:	vaddpd %zmm0,%zmm1,%zmm0
    e907:	vpxord -0x80(%rax),%zmm14,%zmm1
    e90e:	vmovapd %zmm0,-0x130(%rbp)
    e918:	vpermilpd $0x55,-0x80(%rax),%zmm0
    e920:	vaddpd %zmm1,%zmm0,%zmm0
    e926:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e92d:	vpxord %zmm0,%zmm13,%zmm0
    e933:	vaddpd %zmm0,%zmm1,%zmm0
    e939:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e940:	vpxord %zmm0,%zmm12,%zmm0
    e946:	vaddpd %zmm0,%zmm1,%zmm0
    e94c:	vpxord -0x40(%rax),%zmm14,%zmm1
    e953:	vmovapd %zmm0,-0xf0(%rbp)
    e95d:	vpermilpd $0x55,-0x40(%rax),%zmm0
    e965:	vaddpd %zmm1,%zmm0,%zmm0
    e96b:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    e972:	vpxord %zmm0,%zmm13,%zmm0
    e978:	vaddpd %zmm0,%zmm1,%zmm0
    e97e:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    e985:	vpxord %zmm0,%zmm12,%zmm0
    e98b:	vaddpd %zmm0,%zmm1,%zmm0
    e991:	vmovapd %zmm0,-0xb0(%rbp)
    e99b:	vmovapd %zmm16,%zmm0
    e9a1:	call   c1b0 <tb8_balS>
    e9a6:	vmovapd -0x270(%rbp),%zmm2
    e9b0:	vmovapd -0x230(%rbp),%zmm3
    e9ba:	vmovapd -0x1f0(%rbp),%zmm4
    e9c4:	vmovapd -0x1b0(%rbp),%zmm5
    e9ce:	vmovupd %zmm2,-0x200(%rax)
    e9d5:	vmovapd -0x170(%rbp),%zmm6
    e9df:	vmovapd -0x130(%rbp),%zmm7
    e9e9:	vmovupd %zmm3,-0x1c0(%rax)
    e9f0:	vmovapd -0xf0(%rbp),%zmm2
    e9fa:	vmovapd -0xb0(%rbp),%zmm3
    ea04:	vmovupd %zmm4,-0x180(%rax)
    ea0b:	vmovupd %zmm5,-0x140(%rax)
    ea12:	vmovupd %zmm6,-0x100(%rax)
    ea19:	vmovupd %zmm7,-0xc0(%rax)
    ea20:	vmovupd %zmm2,-0x80(%rax)
    ea27:	vmovupd %zmm3,-0x40(%rax)
    ea2e:	cmp    %rcx,%rsi
    ea31:	jne    e768 <hf1_tb8_balS+0x88>
    ea37:	mov    -0x38(%rbp),%rax
    ea3b:	sub    %fs:0x28,%rax
    ea44:	jne    ea53 <hf1_tb8_balS+0x373>
    ea46:	vzeroupper
    ea49:	mov    -0x8(%rbp),%r10
    ea4d:	leave
    ea4e:	lea    -0x8(%r10),%rsp
    ea52:	ret
    ea53:	vzeroupper
    ea56:	call   4280 <__stack_chk_fail@plt>
    ea5b:	nopl   0x0(%rax,%rax,1)

000000000000eaa0 <hf0_kid_nat>:
    eaa0:	endbr64
    eaa4:	push   %rbp
    eaa5:	mov    %rdi,%rdx
    eaa8:	mov    %rsp,%rbp
    eaab:	and    $0xffffffffffffffc0,%rsp
    eaaf:	sub    $0x100,%rsp
    eab6:	vbroadcastsd 0x4e500(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
    eac0:	mov    %fs:0x28,%rax
    eac9:	mov    %rax,0xf8(%rsp)
    ead1:	xor    %eax,%eax
    ead3:	mov    %rsp,%rdi
    ead6:	vzeroupper
    ead9:	call   ea60 <inl_consts.constprop.1>
    eade:	vmovapd (%rsp),%zmm2
    eae5:	vmovapd 0x40(%rsp),%zmm3
    eaed:	vmovapd 0x80(%rsp),%zmm4
    eaf5:	test   %rsi,%rsi
    eaf8:	je     eb47 <hf0_kid_nat+0xa7>
    eafa:	lea    -0x8(,%rsi,8),%rax
    eb02:	mov    %rdx,%rdi
    eb05:	and    $0xffffffffffffffc0,%rax
    eb09:	lea    0x40(%rdx,%rax,1),%rax
    eb0e:	xchg   %ax,%ax
    eb10:	vpermilpd $0x55,(%rdi),%zmm0
    eb17:	vfmadd231pd (%rdi),%zmm2,%zmm0
    eb1d:	add    $0x40,%rdi
    eb21:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    eb28:	vfmadd132pd %zmm3,%zmm1,%zmm0
    eb2e:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    eb35:	vfmadd132pd %zmm4,%zmm1,%zmm0
    eb3b:	vmovupd %zmm0,-0x40(%rdi)
    eb42:	cmp    %rdi,%rax
    eb45:	jne    eb10 <hf0_kid_nat+0x70>
    eb47:	mov    0xf8(%rsp),%rax
    eb4f:	sub    %fs:0x28,%rax
    eb58:	jne    eb5f <hf0_kid_nat+0xbf>
    eb5a:	vzeroupper
    eb5d:	leave
    eb5e:	ret
    eb5f:	vzeroupper
    eb62:	call   4280 <__stack_chk_fail@plt>
    eb67:	nopw   0x0(%rax,%rax,1)

000000000000eb70 <hf0_tb2_nat>:
    eb70:	endbr64
    eb74:	push   %rbp
    eb75:	mov    %rdi,%rdx
    eb78:	mov    %rsp,%rbp
    eb7b:	and    $0xffffffffffffffc0,%rsp
    eb7f:	sub    $0x100,%rsp
    eb86:	vbroadcastsd 0x4e430(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
    eb90:	mov    %fs:0x28,%rax
    eb99:	mov    %rax,0xf8(%rsp)
    eba1:	xor    %eax,%eax
    eba3:	mov    %rsp,%rdi
    eba6:	vzeroupper
    eba9:	call   ea60 <inl_consts.constprop.1>
    ebae:	vmovapd (%rsp),%zmm2
    ebb5:	vmovapd 0x40(%rsp),%zmm3
    ebbd:	vmovapd 0x80(%rsp),%zmm4
    ebc5:	test   %rsi,%rsi
    ebc8:	je     ec5b <hf0_tb2_nat+0xeb>
    ebce:	lea    -0x8(,%rsi,8),%rax
    ebd6:	mov    %rdx,%rdi
    ebd9:	and    $0xffffffffffffff80,%rax
    ebdd:	lea    0x80(%rdx,%rax,1),%rax
    ebe5:	nopl   (%rax)
    ebe8:	vpermilpd $0x55,(%rdi),%zmm0
    ebef:	vfmadd231pd (%rdi),%zmm2,%zmm0
    ebf5:	sub    $0xffffffffffffff80,%rdi
    ebf9:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    ec00:	vfmadd132pd %zmm3,%zmm1,%zmm0
    ec06:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    ec0d:	vfmadd132pd %zmm4,%zmm1,%zmm0
    ec13:	vpermilpd $0x55,-0x40(%rdi),%zmm1
    ec1b:	vfmadd231pd -0x40(%rdi),%zmm2,%zmm1
    ec22:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm5
    ec29:	vfmadd132pd %zmm3,%zmm5,%zmm1
    ec2f:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm5
    ec36:	vfmadd132pd %zmm4,%zmm5,%zmm1
    ec3c:	vaddpd %zmm1,%zmm0,%zmm5
    ec42:	vsubpd %zmm1,%zmm0,%zmm0
    ec48:	vmovupd %zmm5,-0x80(%rdi)
    ec4f:	vmovupd %zmm0,-0x40(%rdi)
    ec56:	cmp    %rdi,%rax
    ec59:	jne    ebe8 <hf0_tb2_nat+0x78>
    ec5b:	mov    0xf8(%rsp),%rax
    ec63:	sub    %fs:0x28,%rax
    ec6c:	jne    ec73 <hf0_tb2_nat+0x103>
    ec6e:	vzeroupper
    ec71:	leave
    ec72:	ret
    ec73:	vzeroupper
    ec76:	call   4280 <__stack_chk_fail@plt>
    ec7b:	nopl   0x0(%rax,%rax,1)

000000000000ec80 <hf0_tb4_nat>:
    ec80:	endbr64
    ec84:	push   %rbp
    ec85:	mov    %rdi,%rdx
    ec88:	mov    %rsp,%rbp
    ec8b:	and    $0xffffffffffffffc0,%rsp
    ec8f:	sub    $0x100,%rsp
    ec96:	vbroadcastsd 0x4e320(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
    eca0:	mov    %fs:0x28,%rax
    eca9:	mov    %rax,0xf8(%rsp)
    ecb1:	xor    %eax,%eax
    ecb3:	mov    %rsp,%rdi
    ecb6:	vzeroupper
    ecb9:	call   ea60 <inl_consts.constprop.1>
    ecbe:	vmovapd (%rsp),%zmm5
    ecc5:	vmovapd 0x40(%rsp),%zmm6
    eccd:	vmovapd 0x80(%rsp),%zmm7
    ecd5:	test   %rsi,%rsi
    ecd8:	je     edfb <hf0_tb4_nat+0x17b>
    ecde:	mov    %rdx,%rax
    ece1:	lea    -0x8(,%rsi,8),%rdx
    ece9:	xor    %dl,%dl
    eceb:	lea    0x100(%rax,%rdx,1),%rdx
    ecf3:	nopl   0x0(%rax,%rax,1)
    ecf8:	vpermilpd $0x55,(%rax),%zmm0
    ecff:	vfmadd231pd (%rax),%zmm5,%zmm0
    ed05:	add    $0x100,%rax
    ed0b:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    ed12:	vfmadd132pd %zmm6,%zmm1,%zmm0
    ed18:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    ed1f:	vfmadd132pd %zmm7,%zmm1,%zmm0
    ed25:	vpermilpd $0x55,-0xc0(%rax),%zmm1
    ed2d:	vfmadd231pd -0xc0(%rax),%zmm5,%zmm1
    ed34:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm2
    ed3b:	vfmadd132pd %zmm6,%zmm2,%zmm1
    ed41:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm2
    ed48:	vmovapd %zmm1,%zmm3
    ed4e:	vpermilpd $0x55,-0x80(%rax),%zmm1
    ed56:	vfmadd231pd -0x80(%rax),%zmm5,%zmm1
    ed5d:	vfmadd132pd %zmm7,%zmm2,%zmm3
    ed63:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm2
    ed6a:	vfmadd132pd %zmm6,%zmm2,%zmm1
    ed70:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm2
    ed77:	vfmadd132pd %zmm7,%zmm2,%zmm1
    ed7d:	vpermilpd $0x55,-0x40(%rax),%zmm2
    ed85:	vfmadd231pd -0x40(%rax),%zmm5,%zmm2
    ed8c:	vshuff64x2 $0xb1,%zmm2,%zmm2,%zmm4
    ed93:	vfmadd132pd %zmm6,%zmm4,%zmm2
    ed99:	vshuff64x2 $0x4e,%zmm2,%zmm2,%zmm4
    eda0:	vfmadd132pd %zmm7,%zmm4,%zmm2
    eda6:	vaddpd %zmm3,%zmm0,%zmm4
    edac:	vsubpd %zmm3,%zmm0,%zmm0
    edb2:	vaddpd %zmm2,%zmm1,%zmm3
    edb8:	vsubpd %zmm2,%zmm1,%zmm1
    edbe:	vaddpd %zmm3,%zmm4,%zmm2
    edc4:	vsubpd %zmm3,%zmm4,%zmm4
    edca:	vmovupd %zmm2,-0x100(%rax)
    edd1:	vaddpd %zmm1,%zmm0,%zmm2
    edd7:	vsubpd %zmm1,%zmm0,%zmm0
    eddd:	vmovupd %zmm4,-0x80(%rax)
    ede4:	vmovupd %zmm2,-0xc0(%rax)
    edeb:	vmovupd %zmm0,-0x40(%rax)
    edf2:	cmp    %rax,%rdx
    edf5:	jne    ecf8 <hf0_tb4_nat+0x78>
    edfb:	mov    0xf8(%rsp),%rax
    ee03:	sub    %fs:0x28,%rax
    ee0c:	jne    ee13 <hf0_tb4_nat+0x193>
    ee0e:	vzeroupper
    ee11:	leave
    ee12:	ret
    ee13:	vzeroupper
    ee16:	call   4280 <__stack_chk_fail@plt>
    ee1b:	nopl   0x0(%rax,%rax,1)

000000000000ee20 <hf0_tb8_bal>:
    ee20:	endbr64
    ee24:	lea    0x8(%rsp),%r10
    ee29:	and    $0xffffffffffffffc0,%rsp
    ee2d:	mov    %rdi,%rdx
    ee30:	push   -0x8(%r10)
    ee34:	push   %rbp
    ee35:	mov    %rsp,%rbp
    ee38:	push   %r10
    ee3a:	sub    $0x328,%rsp
    ee41:	vbroadcastsd 0x4e175(%rip),%zmm16        # 5cfc0 <_IO_stdin_used+0xfc0>
    ee4b:	mov    %fs:0x28,%rax
    ee54:	mov    %rax,-0x38(%rbp)
    ee58:	xor    %eax,%eax
    ee5a:	lea    -0x330(%rbp),%rdi
    ee61:	call   ea60 <inl_consts.constprop.1>
    ee66:	vmovapd -0x330(%rbp),%zmm12
    ee70:	vmovapd -0x2f0(%rbp),%zmm13
    ee7a:	vmovapd -0x2b0(%rbp),%zmm14
    ee84:	test   %rsi,%rsi
    ee87:	je     f0e7 <hf0_tb8_bal+0x2c7>
    ee8d:	sub    $0x1,%rsi
    ee91:	mov    %rdx,%rax
    ee94:	lea    -0x270(%rbp),%rdi
    ee9b:	xor    %edx,%edx
    ee9d:	shr    $0x6,%rsi
    eea1:	nopl   0x0(%rax)
    eea8:	vpermilpd $0x55,(%rax),%zmm0
    eeaf:	vfmadd231pd (%rax),%zmm12,%zmm0
    eeb5:	mov    %rdx,%rcx
    eeb8:	add    $0x200,%rax
    eebe:	add    $0x1,%rdx
    eec2:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    eec9:	vfmadd132pd %zmm13,%zmm1,%zmm0
    eecf:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    eed6:	vfmadd132pd %zmm14,%zmm1,%zmm0
    eedc:	vmovapd %zmm0,-0x270(%rbp)
    eee6:	vpermilpd $0x55,-0x1c0(%rax),%zmm0
    eeee:	vfmadd231pd -0x1c0(%rax),%zmm12,%zmm0
    eef5:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    eefc:	vfmadd132pd %zmm13,%zmm1,%zmm0
    ef02:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    ef09:	vfmadd132pd %zmm14,%zmm1,%zmm0
    ef0f:	vmovapd %zmm0,-0x230(%rbp)
    ef19:	vpermilpd $0x55,-0x180(%rax),%zmm0
    ef21:	vfmadd231pd -0x180(%rax),%zmm12,%zmm0
    ef28:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    ef2f:	vfmadd132pd %zmm13,%zmm1,%zmm0
    ef35:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    ef3c:	vfmadd132pd %zmm14,%zmm1,%zmm0
    ef42:	vmovapd %zmm0,-0x1f0(%rbp)
    ef4c:	vpermilpd $0x55,-0x140(%rax),%zmm0
    ef54:	vfmadd231pd -0x140(%rax),%zmm12,%zmm0
    ef5b:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    ef62:	vfmadd132pd %zmm13,%zmm1,%zmm0
    ef68:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    ef6f:	vfmadd132pd %zmm14,%zmm1,%zmm0
    ef75:	vmovapd %zmm0,-0x1b0(%rbp)
    ef7f:	vpermilpd $0x55,-0x100(%rax),%zmm0
    ef87:	vfmadd231pd -0x100(%rax),%zmm12,%zmm0
    ef8e:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    ef95:	vfmadd132pd %zmm13,%zmm1,%zmm0
    ef9b:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    efa2:	vfmadd132pd %zmm14,%zmm1,%zmm0
    efa8:	vmovapd %zmm0,-0x170(%rbp)
    efb2:	vpermilpd $0x55,-0xc0(%rax),%zmm0
    efba:	vfmadd231pd -0xc0(%rax),%zmm12,%zmm0
    efc1:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    efc8:	vfmadd132pd %zmm13,%zmm1,%zmm0
    efce:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    efd5:	vfmadd132pd %zmm14,%zmm1,%zmm0
    efdb:	vmovapd %zmm0,-0x130(%rbp)
    efe5:	vpermilpd $0x55,-0x80(%rax),%zmm0
    efed:	vfmadd231pd -0x80(%rax),%zmm12,%zmm0
    eff4:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    effb:	vfmadd132pd %zmm13,%zmm1,%zmm0
    f001:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    f008:	vfmadd132pd %zmm14,%zmm1,%zmm0
    f00e:	vmovapd %zmm0,-0xf0(%rbp)
    f018:	vpermilpd $0x55,-0x40(%rax),%zmm0
    f020:	vfmadd231pd -0x40(%rax),%zmm12,%zmm0
    f027:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    f02e:	vfmadd132pd %zmm13,%zmm1,%zmm0
    f034:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    f03b:	vfmadd132pd %zmm14,%zmm1,%zmm0
    f041:	vmovapd %zmm0,-0xb0(%rbp)
    f04b:	vmovapd %zmm16,%zmm0
    f051:	call   bf70 <tb8_bal>
    f056:	vmovapd -0x270(%rbp),%zmm2
    f060:	vmovapd -0x230(%rbp),%zmm3
    f06a:	vmovapd -0x1f0(%rbp),%zmm4
    f074:	vmovapd -0x1b0(%rbp),%zmm5
    f07e:	vmovupd %zmm2,-0x200(%rax)
    f085:	vmovapd -0x170(%rbp),%zmm6
    f08f:	vmovapd -0x130(%rbp),%zmm7
    f099:	vmovupd %zmm3,-0x1c0(%rax)
    f0a0:	vmovapd -0xf0(%rbp),%zmm2
    f0aa:	vmovapd -0xb0(%rbp),%zmm3
    f0b4:	vmovupd %zmm4,-0x180(%rax)
    f0bb:	vmovupd %zmm5,-0x140(%rax)
    f0c2:	vmovupd %zmm6,-0x100(%rax)
    f0c9:	vmovupd %zmm7,-0xc0(%rax)
    f0d0:	vmovupd %zmm2,-0x80(%rax)
    f0d7:	vmovupd %zmm3,-0x40(%rax)
    f0de:	cmp    %rcx,%rsi
    f0e1:	jne    eea8 <hf0_tb8_bal+0x88>
    f0e7:	mov    -0x38(%rbp),%rax
    f0eb:	sub    %fs:0x28,%rax
    f0f4:	jne    f103 <hf0_tb8_bal+0x2e3>
    f0f6:	vzeroupper
    f0f9:	mov    -0x8(%rbp),%r10
    f0fd:	leave
    f0fe:	lea    -0x8(%r10),%rsp
    f102:	ret
    f103:	vzeroupper
    f106:	call   4280 <__stack_chk_fail@plt>
    f10b:	nopl   0x0(%rax,%rax,1)

000000000000f110 <hf0_tb8_balS>:
    f110:	endbr64
    f114:	lea    0x8(%rsp),%r10
    f119:	and    $0xffffffffffffffc0,%rsp
    f11d:	mov    %rdi,%rdx
    f120:	push   -0x8(%r10)
    f124:	push   %rbp
    f125:	mov    %rsp,%rbp
    f128:	push   %r10
    f12a:	sub    $0x328,%rsp
    f131:	vbroadcastsd 0x4de85(%rip),%zmm16        # 5cfc0 <_IO_stdin_used+0xfc0>
    f13b:	mov    %fs:0x28,%rax
    f144:	mov    %rax,-0x38(%rbp)
    f148:	xor    %eax,%eax
    f14a:	lea    -0x330(%rbp),%rdi
    f151:	call   ea60 <inl_consts.constprop.1>
    f156:	vmovapd -0x330(%rbp),%zmm12
    f160:	vmovapd -0x2f0(%rbp),%zmm13
    f16a:	vmovapd -0x2b0(%rbp),%zmm14
    f174:	test   %rsi,%rsi
    f177:	je     f3d7 <hf0_tb8_balS+0x2c7>
    f17d:	sub    $0x1,%rsi
    f181:	mov    %rdx,%rax
    f184:	lea    -0x270(%rbp),%rdi
    f18b:	xor    %edx,%edx
    f18d:	shr    $0x6,%rsi
    f191:	nopl   0x0(%rax)
    f198:	vpermilpd $0x55,(%rax),%zmm0
    f19f:	vfmadd231pd (%rax),%zmm12,%zmm0
    f1a5:	mov    %rdx,%rcx
    f1a8:	add    $0x200,%rax
    f1ae:	add    $0x1,%rdx
    f1b2:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    f1b9:	vfmadd132pd %zmm13,%zmm1,%zmm0
    f1bf:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    f1c6:	vfmadd132pd %zmm14,%zmm1,%zmm0
    f1cc:	vmovapd %zmm0,-0x270(%rbp)
    f1d6:	vpermilpd $0x55,-0x1c0(%rax),%zmm0
    f1de:	vfmadd231pd -0x1c0(%rax),%zmm12,%zmm0
    f1e5:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    f1ec:	vfmadd132pd %zmm13,%zmm1,%zmm0
    f1f2:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    f1f9:	vfmadd132pd %zmm14,%zmm1,%zmm0
    f1ff:	vmovapd %zmm0,-0x230(%rbp)
    f209:	vpermilpd $0x55,-0x180(%rax),%zmm0
    f211:	vfmadd231pd -0x180(%rax),%zmm12,%zmm0
    f218:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    f21f:	vfmadd132pd %zmm13,%zmm1,%zmm0
    f225:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    f22c:	vfmadd132pd %zmm14,%zmm1,%zmm0
    f232:	vmovapd %zmm0,-0x1f0(%rbp)
    f23c:	vpermilpd $0x55,-0x140(%rax),%zmm0
    f244:	vfmadd231pd -0x140(%rax),%zmm12,%zmm0
    f24b:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    f252:	vfmadd132pd %zmm13,%zmm1,%zmm0
    f258:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    f25f:	vfmadd132pd %zmm14,%zmm1,%zmm0
    f265:	vmovapd %zmm0,-0x1b0(%rbp)
    f26f:	vpermilpd $0x55,-0x100(%rax),%zmm0
    f277:	vfmadd231pd -0x100(%rax),%zmm12,%zmm0
    f27e:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    f285:	vfmadd132pd %zmm13,%zmm1,%zmm0
    f28b:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    f292:	vfmadd132pd %zmm14,%zmm1,%zmm0
    f298:	vmovapd %zmm0,-0x170(%rbp)
    f2a2:	vpermilpd $0x55,-0xc0(%rax),%zmm0
    f2aa:	vfmadd231pd -0xc0(%rax),%zmm12,%zmm0
    f2b1:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    f2b8:	vfmadd132pd %zmm13,%zmm1,%zmm0
    f2be:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    f2c5:	vfmadd132pd %zmm14,%zmm1,%zmm0
    f2cb:	vmovapd %zmm0,-0x130(%rbp)
    f2d5:	vpermilpd $0x55,-0x80(%rax),%zmm0
    f2dd:	vfmadd231pd -0x80(%rax),%zmm12,%zmm0
    f2e4:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    f2eb:	vfmadd132pd %zmm13,%zmm1,%zmm0
    f2f1:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    f2f8:	vfmadd132pd %zmm14,%zmm1,%zmm0
    f2fe:	vmovapd %zmm0,-0xf0(%rbp)
    f308:	vpermilpd $0x55,-0x40(%rax),%zmm0
    f310:	vfmadd231pd -0x40(%rax),%zmm12,%zmm0
    f317:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
    f31e:	vfmadd132pd %zmm13,%zmm1,%zmm0
    f324:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
    f32b:	vfmadd132pd %zmm14,%zmm1,%zmm0
    f331:	vmovapd %zmm0,-0xb0(%rbp)
    f33b:	vmovapd %zmm16,%zmm0
    f341:	call   c1b0 <tb8_balS>
    f346:	vmovapd -0x270(%rbp),%zmm2
    f350:	vmovapd -0x230(%rbp),%zmm3
    f35a:	vmovapd -0x1f0(%rbp),%zmm4
    f364:	vmovapd -0x1b0(%rbp),%zmm5
    f36e:	vmovupd %zmm2,-0x200(%rax)
    f375:	vmovapd -0x170(%rbp),%zmm6
    f37f:	vmovapd -0x130(%rbp),%zmm7
    f389:	vmovupd %zmm3,-0x1c0(%rax)
    f390:	vmovapd -0xf0(%rbp),%zmm2
    f39a:	vmovapd -0xb0(%rbp),%zmm3
    f3a4:	vmovupd %zmm4,-0x180(%rax)
    f3ab:	vmovupd %zmm5,-0x140(%rax)
    f3b2:	vmovupd %zmm6,-0x100(%rax)
    f3b9:	vmovupd %zmm7,-0xc0(%rax)
    f3c0:	vmovupd %zmm2,-0x80(%rax)
    f3c7:	vmovupd %zmm3,-0x40(%rax)
    f3ce:	cmp    %rcx,%rsi
    f3d1:	jne    f198 <hf0_tb8_balS+0x88>
    f3d7:	mov    -0x38(%rbp),%rax
    f3db:	sub    %fs:0x28,%rax
    f3e4:	jne    f3f3 <hf0_tb8_balS+0x2e3>
    f3e6:	vzeroupper
    f3e9:	mov    -0x8(%rbp),%r10
    f3ed:	leave
    f3ee:	lea    -0x8(%r10),%rsp
    f3f2:	ret
    f3f3:	vzeroupper
    f3f6:	call   4280 <__stack_chk_fail@plt>
    f3fb:	nopl   0x0(%rax,%rax,1)

0000000000011790 <hf1_h20_nat>:
   11790:	endbr64
   11794:	push   %rbp
   11795:	mov    %rdi,%rdx
   11798:	mov    %rsp,%rbp
   1179b:	and    $0xffffffffffffffc0,%rsp
   1179f:	sub    $0x100,%rsp
   117a6:	vbroadcastsd 0x4b810(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   117b0:	mov    %fs:0x28,%rax
   117b9:	mov    %rax,0xf8(%rsp)
   117c1:	xor    %eax,%eax
   117c3:	mov    %rsp,%rdi
   117c6:	vzeroupper
   117c9:	call   df20 <inl_consts.constprop.0>
   117ce:	vmovapd (%rsp),%zmm3
   117d5:	vmovapd 0x40(%rsp),%zmm2
   117dd:	vmovapd 0x80(%rsp),%zmm1
   117e5:	test   %rsi,%rsi
   117e8:	je     11aa7 <hf1_h20_nat+0x317>
   117ee:	vbroadcastsd 0x4b5c0(%rip),%zmm4        # 5cdb8 <_IO_stdin_used+0xdb8>
   117f8:	mov    %rdx,%rax
   117fb:	lea    -0x8(,%rsi,8),%rdx
   11803:	and    $0xfffffffffffffe00,%rdx
   1180a:	lea    0x200(%rax,%rdx,1),%rdx
   11812:	nopw   0x0(%rax,%rax,1)
   11818:	vpxord (%rax),%zmm3,%zmm5
   1181e:	vpermilpd $0x55,(%rax),%zmm0
   11825:	add    $0x200,%rax
   1182b:	vpxord -0x1c0(%rax),%zmm3,%zmm6
   11832:	vpxord -0x140(%rax),%zmm3,%zmm9
   11839:	vaddpd %zmm5,%zmm0,%zmm0
   1183f:	vpxord -0xc0(%rax),%zmm3,%zmm12
   11846:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm5
   1184d:	vpxord %zmm0,%zmm2,%zmm0
   11853:	vaddpd %zmm0,%zmm5,%zmm5
   11859:	vpermilpd $0x55,-0x1c0(%rax),%zmm0
   11861:	vaddpd %zmm6,%zmm0,%zmm0
   11867:	vshuff64x2 $0x4e,%zmm5,%zmm5,%zmm8
   1186e:	vpxord %zmm5,%zmm1,%zmm5
   11874:	vaddpd %zmm5,%zmm8,%zmm8
   1187a:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm6
   11881:	vpxord %zmm0,%zmm2,%zmm0
   11887:	vaddpd %zmm0,%zmm6,%zmm0
   1188d:	vpxord -0x180(%rax),%zmm3,%zmm6
   11894:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm7
   1189b:	vpxord %zmm0,%zmm1,%zmm0
   118a1:	vaddpd %zmm0,%zmm7,%zmm7
   118a7:	vpermilpd $0x55,-0x180(%rax),%zmm0
   118af:	vaddpd %zmm6,%zmm0,%zmm0
   118b5:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm10
   118bc:	vpxord %zmm0,%zmm2,%zmm0
   118c2:	vaddpd %zmm0,%zmm10,%zmm10
   118c8:	vpermilpd $0x55,-0x140(%rax),%zmm0
   118d0:	vaddpd %zmm9,%zmm0,%zmm0
   118d6:	vshuff64x2 $0x4e,%zmm10,%zmm10,%zmm6
   118dd:	vpxord %zmm10,%zmm1,%zmm10
   118e3:	vaddpd %zmm10,%zmm6,%zmm6
   118e9:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm9
   118f0:	vpxord %zmm0,%zmm2,%zmm0
   118f6:	vaddpd %zmm0,%zmm9,%zmm0
   118fc:	vpxord -0x100(%rax),%zmm3,%zmm9
   11903:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm11
   1190a:	vpxord %zmm0,%zmm1,%zmm0
   11910:	vaddpd %zmm0,%zmm11,%zmm11
   11916:	vpermilpd $0x55,-0x100(%rax),%zmm0
   1191e:	vaddpd %zmm9,%zmm0,%zmm0
   11924:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm9
   1192b:	vpxord %zmm0,%zmm2,%zmm0
   11931:	vaddpd %zmm0,%zmm9,%zmm0
   11937:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm9
   1193e:	vpxord %zmm0,%zmm1,%zmm0
   11944:	vaddpd %zmm0,%zmm9,%zmm9
   1194a:	vpermilpd $0x55,-0xc0(%rax),%zmm0
   11952:	vaddpd %zmm12,%zmm0,%zmm0
   11958:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm12
   1195f:	vpxord %zmm0,%zmm2,%zmm0
   11965:	vaddpd %zmm0,%zmm12,%zmm0
   1196b:	vpxord -0x80(%rax),%zmm3,%zmm12
   11972:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm13
   11979:	vpxord %zmm0,%zmm1,%zmm0
   1197f:	vaddpd %zmm0,%zmm13,%zmm13
   11985:	vpermilpd $0x55,-0x80(%rax),%zmm0
   1198d:	vaddpd %zmm12,%zmm0,%zmm0
   11993:	vsubpd %zmm13,%zmm6,%zmm6
   11999:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm12
   119a0:	vpxord %zmm0,%zmm2,%zmm0
   119a6:	vaddpd %zmm0,%zmm12,%zmm0
   119ac:	vpxord -0x40(%rax),%zmm3,%zmm12
   119b3:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm14
   119ba:	vpxord %zmm0,%zmm1,%zmm0
   119c0:	vaddpd %zmm0,%zmm14,%zmm14
   119c6:	vpermilpd $0x55,-0x40(%rax),%zmm0
   119ce:	vaddpd %zmm12,%zmm0,%zmm0
   119d4:	vaddpd %zmm14,%zmm7,%zmm15
   119da:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm12
   119e1:	vpxord %zmm0,%zmm2,%zmm0
   119e7:	vaddpd %zmm0,%zmm12,%zmm12
   119ed:	vshuff64x2 $0x4e,%zmm12,%zmm12,%zmm0
   119f4:	vpxord %zmm12,%zmm1,%zmm12
   119fa:	vaddpd %zmm12,%zmm0,%zmm0
   11a00:	vsubpd %zmm9,%zmm11,%zmm12
   11a06:	vaddpd %zmm0,%zmm8,%zmm8
   11a0c:	vaddpd %zmm12,%zmm6,%zmm17
   11a12:	vsubpd %zmm15,%zmm8,%zmm16
   11a18:	vsubpd %zmm17,%zmm16,%zmm5
   11a1e:	vfmsub231pd %zmm4,%zmm5,%zmm0
   11a24:	vfmsub132pd %zmm4,%zmm13,%zmm5
   11a2a:	vaddpd %zmm14,%zmm0,%zmm10
   11a30:	vsubpd %zmm9,%zmm5,%zmm9
   11a36:	vaddpd %zmm7,%zmm0,%zmm0
   11a3c:	vaddpd %zmm11,%zmm5,%zmm5
   11a42:	vsubpd %zmm9,%zmm8,%zmm8
   11a48:	vaddpd %zmm10,%zmm6,%zmm6
   11a4e:	vaddpd %zmm0,%zmm17,%zmm17
   11a54:	vsubpd %zmm5,%zmm16,%zmm16
   11a5a:	vmovupd %zmm0,-0x180(%rax)
   11a61:	vaddpd %zmm9,%zmm15,%zmm15
   11a67:	vaddpd %zmm10,%zmm12,%zmm12
   11a6d:	vmovupd %zmm5,-0x140(%rax)
   11a74:	vmovupd %zmm8,-0x200(%rax)
   11a7b:	vmovupd %zmm6,-0x1c0(%rax)
   11a82:	vmovupd %zmm17,-0x100(%rax)
   11a89:	vmovupd %zmm16,-0xc0(%rax)
   11a90:	vmovupd %zmm15,-0x80(%rax)
   11a97:	vmovupd %zmm12,-0x40(%rax)
   11a9e:	cmp    %rax,%rdx
   11aa1:	jne    11818 <hf1_h20_nat+0x88>
   11aa7:	mov    0xf8(%rsp),%rax
   11aaf:	sub    %fs:0x28,%rax
   11ab8:	jne    11abf <hf1_h20_nat+0x32f>
   11aba:	vzeroupper
   11abd:	leave
   11abe:	ret
   11abf:	vzeroupper
   11ac2:	call   4280 <__stack_chk_fail@plt>
   11ac7:	nopw   0x0(%rax,%rax,1)

0000000000011d20 <hf1_g19_nat>:
   11d20:	endbr64
   11d24:	push   %rbp
   11d25:	mov    %rdi,%rdx
   11d28:	mov    %rsp,%rbp
   11d2b:	and    $0xffffffffffffffc0,%rsp
   11d2f:	sub    $0x100,%rsp
   11d36:	vbroadcastsd 0x4b280(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   11d40:	mov    %fs:0x28,%rax
   11d49:	mov    %rax,0xf8(%rsp)
   11d51:	xor    %eax,%eax
   11d53:	mov    %rsp,%rdi
   11d56:	vzeroupper
   11d59:	call   df20 <inl_consts.constprop.0>
   11d5e:	vmovapd (%rsp),%zmm5
   11d65:	vmovapd 0x40(%rsp),%zmm4
   11d6d:	vmovapd 0x80(%rsp),%zmm3
   11d75:	test   %rsi,%rsi
   11d78:	je     1203d <hf1_g19_nat+0x31d>
   11d7e:	vbroadcastsd 0x4b038(%rip),%zmm0        # 5cdc0 <_IO_stdin_used+0xdc0>
   11d88:	mov    %rdx,%rax
   11d8b:	lea    -0x8(,%rsi,8),%rdx
   11d93:	and    $0xfffffffffffffe00,%rdx
   11d9a:	lea    0x200(%rax,%rdx,1),%rdx
   11da2:	nopw   0x0(%rax,%rax,1)
   11da8:	vpxord (%rax),%zmm5,%zmm2
   11dae:	vpermilpd $0x55,(%rax),%zmm1
   11db5:	add    $0x200,%rax
   11dbb:	vpxord -0x140(%rax),%zmm5,%zmm7
   11dc2:	vpxord -0x100(%rax),%zmm5,%zmm9
   11dc9:	vaddpd %zmm2,%zmm1,%zmm1
   11dcf:	vpxord -0x1c0(%rax),%zmm5,%zmm2
   11dd6:	vpxord -0xc0(%rax),%zmm5,%zmm10
   11ddd:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm11
   11de4:	vpxord %zmm1,%zmm4,%zmm1
   11dea:	vaddpd %zmm1,%zmm11,%zmm11
   11df0:	vpermilpd $0x55,-0x1c0(%rax),%zmm1
   11df8:	vaddpd %zmm2,%zmm1,%zmm1
   11dfe:	vshuff64x2 $0x4e,%zmm11,%zmm11,%zmm6
   11e05:	vpxord %zmm11,%zmm3,%zmm11
   11e0b:	vaddpd %zmm11,%zmm6,%zmm6
   11e11:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm2
   11e18:	vpxord %zmm1,%zmm4,%zmm1
   11e1e:	vaddpd %zmm1,%zmm2,%zmm1
   11e24:	vpxord -0x180(%rax),%zmm5,%zmm2
   11e2b:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm8
   11e32:	vpxord %zmm1,%zmm3,%zmm1
   11e38:	vaddpd %zmm1,%zmm8,%zmm8
   11e3e:	vpermilpd $0x55,-0x180(%rax),%zmm1
   11e46:	vaddpd %zmm2,%zmm1,%zmm1
   11e4c:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm12
   11e53:	vpxord %zmm1,%zmm4,%zmm1
   11e59:	vaddpd %zmm1,%zmm12,%zmm12
   11e5f:	vpermilpd $0x55,-0x140(%rax),%zmm1
   11e67:	vaddpd %zmm7,%zmm1,%zmm1
   11e6d:	vshuff64x2 $0x4e,%zmm12,%zmm12,%zmm2
   11e74:	vpxord %zmm12,%zmm3,%zmm12
   11e7a:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm7
   11e81:	vpxord %zmm1,%zmm4,%zmm1
   11e87:	vaddpd %zmm1,%zmm7,%zmm1
   11e8d:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm7
   11e94:	vpxord %zmm1,%zmm3,%zmm1
   11e9a:	vaddpd %zmm1,%zmm7,%zmm7
   11ea0:	vpermilpd $0x55,-0x100(%rax),%zmm1
   11ea8:	vaddpd %zmm9,%zmm1,%zmm1
   11eae:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm9
   11eb5:	vpxord %zmm1,%zmm4,%zmm1
   11ebb:	vaddpd %zmm1,%zmm9,%zmm1
   11ec1:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm9
   11ec8:	vpxord %zmm1,%zmm3,%zmm1
   11ece:	vaddpd %zmm1,%zmm9,%zmm9
   11ed4:	vpermilpd $0x55,-0xc0(%rax),%zmm1
   11edc:	vaddpd %zmm10,%zmm1,%zmm1
   11ee2:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm10
   11ee9:	vpxord %zmm1,%zmm4,%zmm1
   11eef:	vaddpd %zmm1,%zmm10,%zmm1
   11ef5:	vpxord -0x80(%rax),%zmm5,%zmm10
   11efc:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm14
   11f03:	vpxord %zmm1,%zmm3,%zmm1
   11f09:	vaddpd %zmm1,%zmm14,%zmm14
   11f0f:	vpermilpd $0x55,-0x80(%rax),%zmm1
   11f17:	vaddpd %zmm10,%zmm1,%zmm1
   11f1d:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm10
   11f24:	vpxord %zmm1,%zmm4,%zmm1
   11f2a:	vaddpd %zmm1,%zmm10,%zmm1
   11f30:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm10
   11f37:	vpxord %zmm1,%zmm3,%zmm1
   11f3d:	vaddpd %zmm1,%zmm10,%zmm13
   11f43:	vpxord -0x40(%rax),%zmm5,%zmm10
   11f4a:	vpermilpd $0x55,-0x40(%rax),%zmm1
   11f52:	vaddpd %zmm10,%zmm1,%zmm1
   11f58:	vaddpd %zmm13,%zmm8,%zmm15
   11f5e:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm10
   11f65:	vpxord %zmm1,%zmm4,%zmm1
   11f6b:	vaddpd %zmm1,%zmm10,%zmm1
   11f71:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm10
   11f78:	vpxord %zmm1,%zmm3,%zmm1
   11f7e:	vaddpd %zmm1,%zmm10,%zmm10
   11f84:	vaddpd %zmm12,%zmm2,%zmm1
   11f8a:	vsubpd %zmm9,%zmm7,%zmm12
   11f90:	vaddpd %zmm10,%zmm6,%zmm6
   11f96:	vsubpd %zmm14,%zmm1,%zmm1
   11f9c:	vmovapd %zmm10,%zmm2
   11fa2:	vsubpd %zmm15,%zmm6,%zmm16
   11fa8:	vaddpd %zmm12,%zmm1,%zmm17
   11fae:	vsubpd %zmm17,%zmm16,%zmm11
   11fb4:	vfnmadd132pd %zmm0,%zmm11,%zmm2
   11fba:	vfnmadd231pd %zmm0,%zmm14,%zmm11
   11fc0:	vfmadd132pd %zmm0,%zmm2,%zmm13
   11fc6:	vfnmadd132pd %zmm0,%zmm11,%zmm9
   11fcc:	vfmadd132pd %zmm0,%zmm11,%zmm7
   11fd2:	vfmadd132pd %zmm0,%zmm2,%zmm8
   11fd8:	vfmadd132pd %zmm0,%zmm13,%zmm12
   11fde:	vfmadd132pd %zmm0,%zmm13,%zmm1
   11fe4:	vfmsub132pd %zmm0,%zmm7,%zmm16
   11fea:	vfmadd132pd %zmm0,%zmm9,%zmm15
   11ff0:	vmovupd %zmm8,-0x180(%rax)
   11ff7:	vfmadd132pd %zmm0,%zmm8,%zmm17
   11ffd:	vfmsub132pd %zmm0,%zmm9,%zmm6
   12003:	vmovupd %zmm7,-0x140(%rax)
   1200a:	vmovupd %zmm1,-0x1c0(%rax)
   12011:	vmovupd %zmm16,-0xc0(%rax)
   12018:	vmovupd %zmm6,-0x200(%rax)
   1201f:	vmovupd %zmm17,-0x100(%rax)
   12026:	vmovupd %zmm15,-0x80(%rax)
   1202d:	vmovupd %zmm12,-0x40(%rax)
   12034:	cmp    %rax,%rdx
   12037:	jne    11da8 <hf1_g19_nat+0x88>
   1203d:	mov    0xf8(%rsp),%rax
   12045:	sub    %fs:0x28,%rax
   1204e:	jne    12055 <hf1_g19_nat+0x335>
   12050:	vzeroupper
   12053:	leave
   12054:	ret
   12055:	vzeroupper
   12058:	call   4280 <__stack_chk_fail@plt>
   1205d:	nopl   (%rax)

0000000000012060 <hf1_tb8_nat>:
   12060:	endbr64
   12064:	push   %rbp
   12065:	mov    %rdi,%rdx
   12068:	mov    %rsp,%rbp
   1206b:	and    $0xffffffffffffffc0,%rsp
   1206f:	sub    $0x100,%rsp
   12076:	vbroadcastsd 0x4af40(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   12080:	mov    %fs:0x28,%rax
   12089:	mov    %rax,0xf8(%rsp)
   12091:	xor    %eax,%eax
   12093:	mov    %rsp,%rdi
   12096:	vzeroupper
   12099:	call   df20 <inl_consts.constprop.0>
   1209e:	vmovapd (%rsp),%zmm4
   120a5:	vmovapd 0x40(%rsp),%zmm3
   120ad:	vmovapd 0x80(%rsp),%zmm2
   120b5:	test   %rsi,%rsi
   120b8:	je     1238d <hf1_tb8_nat+0x32d>
   120be:	mov    %rdx,%rax
   120c1:	lea    -0x8(,%rsi,8),%rdx
   120c9:	and    $0xfffffffffffffe00,%rdx
   120d0:	lea    0x200(%rax,%rdx,1),%rdx
   120d8:	nopl   0x0(%rax,%rax,1)
   120e0:	vpxord (%rax),%zmm4,%zmm1
   120e6:	vpermilpd $0x55,(%rax),%zmm0
   120ed:	add    $0x200,%rax
   120f3:	vpxord -0x1c0(%rax),%zmm4,%zmm5
   120fa:	vaddpd %zmm1,%zmm0,%zmm0
   12100:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   12107:	vpxord %zmm0,%zmm3,%zmm0
   1210d:	vaddpd %zmm0,%zmm1,%zmm1
   12113:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm0
   1211a:	vpxord %zmm1,%zmm2,%zmm1
   12120:	vaddpd %zmm1,%zmm0,%zmm0
   12126:	vpermilpd $0x55,-0x1c0(%rax),%zmm1
   1212e:	vaddpd %zmm5,%zmm1,%zmm1
   12134:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm5
   1213b:	vpxord %zmm1,%zmm3,%zmm1
   12141:	vaddpd %zmm1,%zmm5,%zmm1
   12147:	vpxord -0x180(%rax),%zmm4,%zmm5
   1214e:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm9
   12155:	vpxord %zmm1,%zmm2,%zmm1
   1215b:	vaddpd %zmm1,%zmm9,%zmm9
   12161:	vpermilpd $0x55,-0x180(%rax),%zmm1
   12169:	vaddpd %zmm5,%zmm1,%zmm1
   1216f:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm5
   12176:	vpxord %zmm1,%zmm3,%zmm1
   1217c:	vaddpd %zmm1,%zmm5,%zmm1
   12182:	vpxord -0x140(%rax),%zmm4,%zmm5
   12189:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm8
   12190:	vpxord %zmm1,%zmm2,%zmm1
   12196:	vaddpd %zmm1,%zmm8,%zmm8
   1219c:	vpermilpd $0x55,-0x140(%rax),%zmm1
   121a4:	vaddpd %zmm5,%zmm1,%zmm1
   121aa:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm5
   121b1:	vpxord %zmm1,%zmm3,%zmm1
   121b7:	vaddpd %zmm1,%zmm5,%zmm1
   121bd:	vpxord -0x100(%rax),%zmm4,%zmm5
   121c4:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm10
   121cb:	vpxord %zmm1,%zmm2,%zmm1
   121d1:	vaddpd %zmm1,%zmm10,%zmm10
   121d7:	vpermilpd $0x55,-0x100(%rax),%zmm1
   121df:	vaddpd %zmm5,%zmm1,%zmm1
   121e5:	vaddpd %zmm10,%zmm8,%zmm14
   121eb:	vsubpd %zmm10,%zmm8,%zmm8
   121f1:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm6
   121f8:	vpxord %zmm1,%zmm3,%zmm1
   121fe:	vaddpd %zmm1,%zmm6,%zmm6
   12204:	vshuff64x2 $0x4e,%zmm6,%zmm6,%zmm1
   1220b:	vpxord %zmm6,%zmm2,%zmm6
   12211:	vaddpd %zmm6,%zmm1,%zmm5
   12217:	vpxord -0xc0(%rax),%zmm4,%zmm6
   1221e:	vpermilpd $0x55,-0xc0(%rax),%zmm1
   12226:	vaddpd %zmm6,%zmm1,%zmm1
   1222c:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm6
   12233:	vpxord %zmm1,%zmm3,%zmm1
   12239:	vaddpd %zmm1,%zmm6,%zmm1
   1223f:	vpxord -0x80(%rax),%zmm4,%zmm6
   12246:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm12
   1224d:	vpxord %zmm1,%zmm2,%zmm1
   12253:	vaddpd %zmm1,%zmm12,%zmm12
   12259:	vpermilpd $0x55,-0x80(%rax),%zmm1
   12261:	vaddpd %zmm6,%zmm1,%zmm1
   12267:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm6
   1226e:	vpxord %zmm1,%zmm3,%zmm1
   12274:	vaddpd %zmm1,%zmm6,%zmm1
   1227a:	vpxord -0x40(%rax),%zmm4,%zmm6
   12281:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm7
   12288:	vpxord %zmm1,%zmm2,%zmm1
   1228e:	vaddpd %zmm1,%zmm7,%zmm7
   12294:	vpermilpd $0x55,-0x40(%rax),%zmm1
   1229c:	vaddpd %zmm6,%zmm1,%zmm1
   122a2:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm6
   122a9:	vpxord %zmm1,%zmm3,%zmm1
   122af:	vaddpd %zmm1,%zmm6,%zmm1
   122b5:	vaddpd %zmm9,%zmm0,%zmm6
   122bb:	vsubpd %zmm9,%zmm0,%zmm0
   122c1:	vaddpd %zmm12,%zmm5,%zmm9
   122c7:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm11
   122ce:	vpxord %zmm1,%zmm2,%zmm1
   122d4:	vaddpd %zmm1,%zmm11,%zmm11
   122da:	vsubpd %zmm12,%zmm5,%zmm1
   122e0:	vaddpd %zmm8,%zmm0,%zmm10
   122e6:	vsubpd %zmm8,%zmm0,%zmm0
   122ec:	vsubpd %zmm14,%zmm6,%zmm5
   122f2:	vaddpd %zmm11,%zmm7,%zmm13
   122f8:	vsubpd %zmm11,%zmm7,%zmm7
   122fe:	vaddpd %zmm14,%zmm6,%zmm11
   12304:	vaddpd %zmm13,%zmm9,%zmm12
   1230a:	vaddpd %zmm7,%zmm1,%zmm8
   12310:	vsubpd %zmm7,%zmm1,%zmm1
   12316:	vsubpd %zmm13,%zmm9,%zmm6
   1231c:	vaddpd %zmm12,%zmm11,%zmm7
   12322:	vsubpd %zmm12,%zmm11,%zmm11
   12328:	vmovupd %zmm7,-0x200(%rax)
   1232f:	vaddpd %zmm8,%zmm10,%zmm7
   12335:	vsubpd %zmm8,%zmm10,%zmm10
   1233b:	vmovupd %zmm11,-0x100(%rax)
   12342:	vmovupd %zmm7,-0x1c0(%rax)
   12349:	vaddpd %zmm6,%zmm5,%zmm7
   1234f:	vsubpd %zmm6,%zmm5,%zmm5
   12355:	vmovupd %zmm10,-0xc0(%rax)
   1235c:	vmovupd %zmm7,-0x180(%rax)
   12363:	vaddpd %zmm1,%zmm0,%zmm7
   12369:	vsubpd %zmm1,%zmm0,%zmm0
   1236f:	vmovupd %zmm5,-0x80(%rax)
   12376:	vmovupd %zmm7,-0x140(%rax)
   1237d:	vmovupd %zmm0,-0x40(%rax)
   12384:	cmp    %rax,%rdx
   12387:	jne    120e0 <hf1_tb8_nat+0x80>
   1238d:	mov    0xf8(%rsp),%rax
   12395:	sub    %fs:0x28,%rax
   1239e:	jne    123a5 <hf1_tb8_nat+0x345>
   123a0:	vzeroupper
   123a3:	leave
   123a4:	ret
   123a5:	vzeroupper
   123a8:	call   4280 <__stack_chk_fail@plt>
   123ad:	nopl   (%rax)

0000000000013f90 <hf2_broken_g52>:
   13f90:	endbr64
   13f94:	push   %rbp
   13f95:	mov    %rsp,%rbp
   13f98:	and    $0xffffffffffffffc0,%rsp
   13f9c:	sub    $0x440,%rsp
   13fa3:	vbroadcastsd 0x49013(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   13fad:	mov    %fs:0x28,%rcx
   13fb6:	mov    %rcx,0x438(%rsp)
   13fbe:	xor    %ecx,%ecx
   13fc0:	test   %rsi,%rsi
   13fc3:	je     1453b <hf2_broken_g52+0x5ab>
   13fc9:	mov    %rsi,%rdx
   13fcc:	mov    %rdi,%rax
   13fcf:	vmovdqa64 0x48e67(%rip),%zmm20        # 5ce40 <_IO_stdin_used+0xe40>
   13fd9:	vmovdqa64 0x48e9d(%rip),%zmm19        # 5ce80 <_IO_stdin_used+0xe80>
   13fe3:	sub    $0x1,%rdx
   13fe7:	mov    $0xffffffaa,%ecx
   13fec:	mov    %rsp,%rdi
   13fef:	vmovdqa64 0x48ec7(%rip),%zmm18        # 5cec0 <_IO_stdin_used+0xec0>
   13ff9:	mov    %rdx,%rsi
   13ffc:	xor    %edx,%edx
   13ffe:	kmovw  %ecx,%k3
   14002:	shr    $0x7,%rsi
   14006:	cs nopw 0x0(%rax,%rax,1)
   14010:	vpermpd (%rax),%zmm20,%zmm0
   14016:	vaddpd (%rax),%zmm0,%zmm1
   1401c:	mov    $0xffffffcc,%ecx
   14021:	vsubpd (%rax),%zmm0,%zmm1{%k3}
   14027:	kmovw  %ecx,%k2
   1402b:	mov    $0xfffffff0,%ecx
   14030:	kmovw  %ecx,%k1
   14034:	mov    %rdx,%rcx
   14037:	vpermpd %zmm1,%zmm19,%zmm2
   1403d:	vaddpd %zmm2,%zmm1,%zmm0
   14043:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   14049:	vpermpd %zmm0,%zmm18,%zmm2
   1404f:	vaddpd %zmm2,%zmm0,%zmm1
   14055:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   1405b:	vpermpd 0x40(%rax),%zmm20,%zmm0
   14062:	vmovapd %zmm1,(%rsp)
   14069:	vaddpd 0x40(%rax),%zmm0,%zmm1
   14070:	vsubpd 0x40(%rax),%zmm0,%zmm1{%k3}
   14077:	vpermpd %zmm1,%zmm19,%zmm2
   1407d:	vaddpd %zmm2,%zmm1,%zmm0
   14083:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   14089:	vpermpd %zmm0,%zmm18,%zmm2
   1408f:	vaddpd %zmm2,%zmm0,%zmm1
   14095:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   1409b:	vpermpd 0x80(%rax),%zmm20,%zmm0
   140a2:	vmovapd %zmm1,0x40(%rsp)
   140aa:	vaddpd 0x80(%rax),%zmm0,%zmm1
   140b1:	vsubpd 0x80(%rax),%zmm0,%zmm1{%k3}
   140b8:	vpermpd %zmm1,%zmm19,%zmm2
   140be:	vaddpd %zmm2,%zmm1,%zmm0
   140c4:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   140ca:	vpermpd %zmm0,%zmm18,%zmm2
   140d0:	vaddpd %zmm2,%zmm0,%zmm1
   140d6:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   140dc:	vpermpd 0xc0(%rax),%zmm20,%zmm0
   140e3:	vmovapd %zmm1,0x80(%rsp)
   140eb:	vaddpd 0xc0(%rax),%zmm0,%zmm1
   140f2:	vsubpd 0xc0(%rax),%zmm0,%zmm1{%k3}
   140f9:	vpermpd %zmm1,%zmm19,%zmm2
   140ff:	vaddpd %zmm2,%zmm1,%zmm0
   14105:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   1410b:	vpermpd %zmm0,%zmm18,%zmm2
   14111:	vaddpd %zmm2,%zmm0,%zmm1
   14117:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   1411d:	vpermpd 0x100(%rax),%zmm20,%zmm0
   14124:	vmovapd %zmm1,0xc0(%rsp)
   1412c:	vaddpd 0x100(%rax),%zmm0,%zmm1
   14133:	vsubpd 0x100(%rax),%zmm0,%zmm1{%k3}
   1413a:	vpermpd %zmm1,%zmm19,%zmm2
   14140:	vaddpd %zmm2,%zmm1,%zmm0
   14146:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   1414c:	vpermpd %zmm0,%zmm18,%zmm2
   14152:	vaddpd %zmm2,%zmm0,%zmm1
   14158:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   1415e:	vpermpd 0x140(%rax),%zmm20,%zmm0
   14165:	vmovapd %zmm1,0x100(%rsp)
   1416d:	vaddpd 0x140(%rax),%zmm0,%zmm1
   14174:	vsubpd 0x140(%rax),%zmm0,%zmm1{%k3}
   1417b:	vpermpd %zmm1,%zmm19,%zmm2
   14181:	vaddpd %zmm2,%zmm1,%zmm0
   14187:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   1418d:	vpermpd %zmm0,%zmm18,%zmm2
   14193:	vaddpd %zmm2,%zmm0,%zmm1
   14199:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   1419f:	vpermpd 0x180(%rax),%zmm20,%zmm0
   141a6:	vmovapd %zmm1,0x140(%rsp)
   141ae:	vaddpd 0x180(%rax),%zmm0,%zmm1
   141b5:	vsubpd 0x180(%rax),%zmm0,%zmm1{%k3}
   141bc:	vpermpd %zmm1,%zmm19,%zmm2
   141c2:	vaddpd %zmm2,%zmm1,%zmm0
   141c8:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   141ce:	vpermpd %zmm0,%zmm18,%zmm2
   141d4:	vaddpd %zmm2,%zmm0,%zmm1
   141da:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   141e0:	vpermpd 0x1c0(%rax),%zmm20,%zmm0
   141e7:	vmovapd %zmm1,0x180(%rsp)
   141ef:	vaddpd 0x1c0(%rax),%zmm0,%zmm1
   141f6:	vsubpd 0x1c0(%rax),%zmm0,%zmm1{%k3}
   141fd:	vpermpd %zmm1,%zmm19,%zmm2
   14203:	vaddpd %zmm2,%zmm1,%zmm0
   14209:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   1420f:	vpermpd %zmm0,%zmm18,%zmm2
   14215:	vaddpd %zmm2,%zmm0,%zmm1
   1421b:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   14221:	vmovapd %zmm1,0x1c0(%rsp)
   14229:	vpermpd 0x200(%rax),%zmm20,%zmm0
   14230:	vaddpd 0x200(%rax),%zmm0,%zmm1
   14237:	vsubpd 0x200(%rax),%zmm0,%zmm1{%k3}
   1423e:	vpermpd %zmm1,%zmm19,%zmm2
   14244:	vaddpd %zmm2,%zmm1,%zmm0
   1424a:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   14250:	vpermpd %zmm0,%zmm18,%zmm2
   14256:	vaddpd %zmm2,%zmm0,%zmm1
   1425c:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   14262:	vpermpd 0x240(%rax),%zmm20,%zmm0
   14269:	vmovapd %zmm1,0x200(%rsp)
   14271:	vaddpd 0x240(%rax),%zmm0,%zmm1
   14278:	vsubpd 0x240(%rax),%zmm0,%zmm1{%k3}
   1427f:	vpermpd %zmm1,%zmm19,%zmm2
   14285:	vaddpd %zmm2,%zmm1,%zmm0
   1428b:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   14291:	vpermpd %zmm0,%zmm18,%zmm2
   14297:	vaddpd %zmm2,%zmm0,%zmm1
   1429d:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   142a3:	vpermpd 0x280(%rax),%zmm20,%zmm0
   142aa:	vmovapd %zmm1,0x240(%rsp)
   142b2:	vaddpd 0x280(%rax),%zmm0,%zmm1
   142b9:	vsubpd 0x280(%rax),%zmm0,%zmm1{%k3}
   142c0:	vpermpd %zmm1,%zmm19,%zmm2
   142c6:	vaddpd %zmm2,%zmm1,%zmm0
   142cc:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   142d2:	vpermpd %zmm0,%zmm18,%zmm2
   142d8:	vaddpd %zmm2,%zmm0,%zmm1
   142de:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   142e4:	vpermpd 0x2c0(%rax),%zmm20,%zmm0
   142eb:	vmovapd %zmm1,0x280(%rsp)
   142f3:	vaddpd 0x2c0(%rax),%zmm0,%zmm1
   142fa:	vsubpd 0x2c0(%rax),%zmm0,%zmm1{%k3}
   14301:	vpermpd %zmm1,%zmm19,%zmm2
   14307:	vaddpd %zmm2,%zmm1,%zmm0
   1430d:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   14313:	vpermpd %zmm0,%zmm18,%zmm2
   14319:	vaddpd %zmm2,%zmm0,%zmm1
   1431f:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   14325:	vpermpd 0x300(%rax),%zmm20,%zmm0
   1432c:	vmovapd %zmm1,0x2c0(%rsp)
   14334:	vaddpd 0x300(%rax),%zmm0,%zmm1
   1433b:	vsubpd 0x300(%rax),%zmm0,%zmm1{%k3}
   14342:	vpermpd %zmm1,%zmm19,%zmm2
   14348:	vaddpd %zmm2,%zmm1,%zmm0
   1434e:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   14354:	vpermpd %zmm0,%zmm18,%zmm2
   1435a:	vaddpd %zmm2,%zmm0,%zmm1
   14360:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   14366:	vpermpd 0x340(%rax),%zmm20,%zmm0
   1436d:	vmovapd %zmm1,0x300(%rsp)
   14375:	vaddpd 0x340(%rax),%zmm0,%zmm1
   1437c:	vsubpd 0x340(%rax),%zmm0,%zmm1{%k3}
   14383:	vpermpd %zmm1,%zmm19,%zmm2
   14389:	vaddpd %zmm2,%zmm1,%zmm0
   1438f:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   14395:	vpermpd %zmm0,%zmm18,%zmm2
   1439b:	vaddpd %zmm2,%zmm0,%zmm1
   143a1:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   143a7:	vpermpd 0x380(%rax),%zmm20,%zmm0
   143ae:	vmovapd %zmm1,0x340(%rsp)
   143b6:	vaddpd 0x380(%rax),%zmm0,%zmm1
   143bd:	vsubpd 0x380(%rax),%zmm0,%zmm1{%k3}
   143c4:	vpermpd %zmm1,%zmm19,%zmm2
   143ca:	vaddpd %zmm2,%zmm1,%zmm0
   143d0:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   143d6:	vpermpd %zmm0,%zmm18,%zmm2
   143dc:	vaddpd %zmm2,%zmm0,%zmm1
   143e2:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   143e8:	vpermpd 0x3c0(%rax),%zmm20,%zmm0
   143ef:	vmovapd %zmm1,0x380(%rsp)
   143f7:	vaddpd 0x3c0(%rax),%zmm0,%zmm1
   143fe:	vsubpd 0x3c0(%rax),%zmm0,%zmm1{%k3}
   14405:	vpermpd %zmm1,%zmm19,%zmm2
   1440b:	vaddpd %zmm2,%zmm1,%zmm0
   14411:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   14417:	vpermpd %zmm0,%zmm18,%zmm2
   1441d:	vaddpd %zmm2,%zmm0,%zmm1
   14423:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   14429:	vmovapd %zmm1,0x3c0(%rsp)
   14431:	vzeroupper
   14434:	call   13d70 <g52_nat.constprop.0>
   14439:	vmovapd (%rsp),%zmm3
   14440:	vmovapd 0x40(%rsp),%zmm4
   14448:	vmovapd 0x80(%rsp),%zmm5
   14450:	add    $0x1,%rdx
   14454:	add    $0x400,%rax
   1445a:	vmovapd 0xc0(%rsp),%zmm6
   14462:	vmovapd 0x100(%rsp),%zmm7
   1446a:	vmovupd %zmm3,-0x400(%rax)
   14471:	vmovapd 0x180(%rsp),%zmm3
   14479:	vmovupd %zmm4,-0x3c0(%rax)
   14480:	vmovapd 0x140(%rsp),%zmm4
   14488:	vmovupd %zmm5,-0x380(%rax)
   1448f:	vmovapd 0x1c0(%rsp),%zmm5
   14497:	vmovupd %zmm6,-0x340(%rax)
   1449e:	vmovapd 0x200(%rsp),%zmm6
   144a6:	vmovupd %zmm7,-0x300(%rax)
   144ad:	vmovapd 0x240(%rsp),%zmm7
   144b5:	vmovupd %zmm3,-0x2c0(%rax)
   144bc:	vmovapd 0x280(%rsp),%zmm3
   144c4:	vmovupd %zmm4,-0x280(%rax)
   144cb:	vmovapd 0x2c0(%rsp),%zmm4
   144d3:	vmovupd %zmm5,-0x240(%rax)
   144da:	vmovapd 0x300(%rsp),%zmm5
   144e2:	vmovupd %zmm6,-0x200(%rax)
   144e9:	vmovapd 0x340(%rsp),%zmm6
   144f1:	vmovupd %zmm7,-0x1c0(%rax)
   144f8:	vmovapd 0x380(%rsp),%zmm7
   14500:	vmovupd %zmm3,-0x180(%rax)
   14507:	vmovapd 0x3c0(%rsp),%zmm3
   1450f:	vmovupd %zmm4,-0x140(%rax)
   14516:	vmovupd %zmm5,-0x100(%rax)
   1451d:	vmovupd %zmm6,-0xc0(%rax)
   14524:	vmovupd %zmm7,-0x80(%rax)
   1452b:	vmovupd %zmm3,-0x40(%rax)
   14532:	cmp    %rsi,%rcx
   14535:	jne    14010 <hf2_broken_g52+0x80>
   1453b:	mov    0x438(%rsp),%rax
   14543:	sub    %fs:0x28,%rax
   1454c:	jne    14553 <hf2_broken_g52+0x5c3>
   1454e:	vzeroupper
   14551:	leave
   14552:	ret
   14553:	vzeroupper
   14556:	call   4280 <__stack_chk_fail@plt>
   1455b:	nopl   0x0(%rax,%rax,1)

0000000000014560 <hf1_broken_g52>:
   14560:	endbr64
   14564:	push   %rbp
   14565:	mov    %rdi,%rdx
   14568:	mov    %rsp,%rbp
   1456b:	and    $0xffffffffffffffc0,%rsp
   1456f:	sub    $0x500,%rsp
   14576:	vbroadcastsd 0x48a40(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   14580:	mov    %fs:0x28,%rax
   14589:	mov    %rax,0x4f8(%rsp)
   14591:	xor    %eax,%eax
   14593:	mov    %rsp,%rdi
   14596:	vzeroupper
   14599:	call   df20 <inl_consts.constprop.0>
   1459e:	vmovapd (%rsp),%zmm20
   145a5:	vmovapd 0x40(%rsp),%zmm19
   145ad:	vmovapd 0x80(%rsp),%zmm18
   145b5:	test   %rsi,%rsi
   145b8:	je     14b1f <hf1_broken_g52+0x5bf>
   145be:	mov    %rsi,%rcx
   145c1:	mov    %rdx,%rax
   145c4:	lea    0xc0(%rsp),%rdi
   145cc:	xor    %edx,%edx
   145ce:	sub    $0x1,%rcx
   145d2:	mov    %rcx,%rsi
   145d5:	shr    $0x7,%rsi
   145d9:	nopl   0x0(%rax)
   145e0:	vpxord (%rax),%zmm20,%zmm1
   145e6:	vpermilpd $0x55,(%rax),%zmm0
   145ed:	mov    %rdx,%rcx
   145f0:	vaddpd %zmm1,%zmm0,%zmm0
   145f6:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   145fd:	vpxord %zmm0,%zmm19,%zmm0
   14603:	vaddpd %zmm0,%zmm1,%zmm0
   14609:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14610:	vpxord %zmm0,%zmm18,%zmm0
   14616:	vaddpd %zmm0,%zmm1,%zmm0
   1461c:	vpxord 0x40(%rax),%zmm20,%zmm1
   14623:	vmovapd %zmm0,0xc0(%rsp)
   1462b:	vpermilpd $0x55,0x40(%rax),%zmm0
   14633:	vaddpd %zmm1,%zmm0,%zmm0
   14639:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14640:	vpxord %zmm0,%zmm19,%zmm0
   14646:	vaddpd %zmm0,%zmm1,%zmm0
   1464c:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14653:	vpxord %zmm0,%zmm18,%zmm0
   14659:	vaddpd %zmm0,%zmm1,%zmm0
   1465f:	vpxord 0x80(%rax),%zmm20,%zmm1
   14666:	vmovapd %zmm0,0x100(%rsp)
   1466e:	vpermilpd $0x55,0x80(%rax),%zmm0
   14676:	vaddpd %zmm1,%zmm0,%zmm0
   1467c:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14683:	vpxord %zmm0,%zmm19,%zmm0
   14689:	vaddpd %zmm0,%zmm1,%zmm0
   1468f:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14696:	vpxord %zmm0,%zmm18,%zmm0
   1469c:	vaddpd %zmm0,%zmm1,%zmm0
   146a2:	vpxord 0xc0(%rax),%zmm20,%zmm1
   146a9:	vmovapd %zmm0,0x140(%rsp)
   146b1:	vpermilpd $0x55,0xc0(%rax),%zmm0
   146b9:	vaddpd %zmm1,%zmm0,%zmm0
   146bf:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   146c6:	vpxord %zmm0,%zmm19,%zmm0
   146cc:	vaddpd %zmm0,%zmm1,%zmm0
   146d2:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   146d9:	vpxord %zmm0,%zmm18,%zmm0
   146df:	vaddpd %zmm0,%zmm1,%zmm0
   146e5:	vpxord 0x100(%rax),%zmm20,%zmm1
   146ec:	vmovapd %zmm0,0x180(%rsp)
   146f4:	vpermilpd $0x55,0x100(%rax),%zmm0
   146fc:	vaddpd %zmm1,%zmm0,%zmm0
   14702:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14709:	vpxord %zmm0,%zmm19,%zmm0
   1470f:	vaddpd %zmm0,%zmm1,%zmm0
   14715:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   1471c:	vpxord %zmm0,%zmm18,%zmm0
   14722:	vaddpd %zmm0,%zmm1,%zmm0
   14728:	vpxord 0x140(%rax),%zmm20,%zmm1
   1472f:	vmovapd %zmm0,0x1c0(%rsp)
   14737:	vpermilpd $0x55,0x140(%rax),%zmm0
   1473f:	vaddpd %zmm1,%zmm0,%zmm0
   14745:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   1474c:	vpxord %zmm0,%zmm19,%zmm0
   14752:	vaddpd %zmm0,%zmm1,%zmm0
   14758:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   1475f:	vpxord %zmm0,%zmm18,%zmm0
   14765:	vaddpd %zmm0,%zmm1,%zmm0
   1476b:	vpxord 0x180(%rax),%zmm20,%zmm1
   14772:	vmovapd %zmm0,0x200(%rsp)
   1477a:	vpermilpd $0x55,0x180(%rax),%zmm0
   14782:	vaddpd %zmm1,%zmm0,%zmm0
   14788:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   1478f:	vpxord %zmm0,%zmm19,%zmm0
   14795:	vaddpd %zmm0,%zmm1,%zmm0
   1479b:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   147a2:	vpxord %zmm0,%zmm18,%zmm0
   147a8:	vaddpd %zmm0,%zmm1,%zmm0
   147ae:	vpxord 0x1c0(%rax),%zmm20,%zmm1
   147b5:	vmovapd %zmm0,0x240(%rsp)
   147bd:	vpermilpd $0x55,0x1c0(%rax),%zmm0
   147c5:	vaddpd %zmm1,%zmm0,%zmm0
   147cb:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   147d2:	vpxord %zmm0,%zmm19,%zmm0
   147d8:	vaddpd %zmm0,%zmm1,%zmm0
   147de:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   147e5:	vpxord %zmm0,%zmm18,%zmm0
   147eb:	vaddpd %zmm0,%zmm1,%zmm0
   147f1:	vpxord 0x200(%rax),%zmm20,%zmm1
   147f8:	vmovapd %zmm0,0x280(%rsp)
   14800:	vpermilpd $0x55,0x200(%rax),%zmm0
   14808:	vaddpd %zmm1,%zmm0,%zmm0
   1480e:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14815:	vpxord %zmm0,%zmm19,%zmm0
   1481b:	vaddpd %zmm0,%zmm1,%zmm0
   14821:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14828:	vpxord %zmm0,%zmm18,%zmm0
   1482e:	vaddpd %zmm0,%zmm1,%zmm0
   14834:	vpxord 0x240(%rax),%zmm20,%zmm1
   1483b:	vmovapd %zmm0,0x2c0(%rsp)
   14843:	vpermilpd $0x55,0x240(%rax),%zmm0
   1484b:	vaddpd %zmm1,%zmm0,%zmm0
   14851:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14858:	vpxord %zmm0,%zmm19,%zmm0
   1485e:	vaddpd %zmm0,%zmm1,%zmm0
   14864:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   1486b:	vpxord %zmm0,%zmm18,%zmm0
   14871:	vaddpd %zmm0,%zmm1,%zmm0
   14877:	vpxord 0x280(%rax),%zmm20,%zmm1
   1487e:	vmovapd %zmm0,0x300(%rsp)
   14886:	vpermilpd $0x55,0x280(%rax),%zmm0
   1488e:	vaddpd %zmm1,%zmm0,%zmm0
   14894:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   1489b:	vpxord %zmm0,%zmm19,%zmm0
   148a1:	vaddpd %zmm0,%zmm1,%zmm0
   148a7:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   148ae:	vpxord %zmm0,%zmm18,%zmm0
   148b4:	vaddpd %zmm0,%zmm1,%zmm0
   148ba:	vmovapd %zmm0,0x340(%rsp)
   148c2:	vpxord 0x2c0(%rax),%zmm20,%zmm1
   148c9:	vpermilpd $0x55,0x2c0(%rax),%zmm0
   148d1:	vaddpd %zmm1,%zmm0,%zmm0
   148d7:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   148de:	vpxord %zmm0,%zmm19,%zmm0
   148e4:	vaddpd %zmm0,%zmm1,%zmm0
   148ea:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   148f1:	vpxord %zmm0,%zmm18,%zmm0
   148f7:	vaddpd %zmm0,%zmm1,%zmm0
   148fd:	vpxord 0x300(%rax),%zmm20,%zmm1
   14904:	vmovapd %zmm0,0x380(%rsp)
   1490c:	vpermilpd $0x55,0x300(%rax),%zmm0
   14914:	vaddpd %zmm1,%zmm0,%zmm0
   1491a:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14921:	vpxord %zmm0,%zmm19,%zmm0
   14927:	vaddpd %zmm0,%zmm1,%zmm0
   1492d:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14934:	vpxord %zmm0,%zmm18,%zmm0
   1493a:	vaddpd %zmm0,%zmm1,%zmm0
   14940:	vpxord 0x340(%rax),%zmm20,%zmm1
   14947:	vmovapd %zmm0,0x3c0(%rsp)
   1494f:	vpermilpd $0x55,0x340(%rax),%zmm0
   14957:	vaddpd %zmm1,%zmm0,%zmm0
   1495d:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14964:	vpxord %zmm0,%zmm19,%zmm0
   1496a:	vaddpd %zmm0,%zmm1,%zmm0
   14970:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14977:	vpxord %zmm0,%zmm18,%zmm0
   1497d:	vaddpd %zmm0,%zmm1,%zmm0
   14983:	vpxord 0x380(%rax),%zmm20,%zmm1
   1498a:	vmovapd %zmm0,0x400(%rsp)
   14992:	vpermilpd $0x55,0x380(%rax),%zmm0
   1499a:	vaddpd %zmm1,%zmm0,%zmm0
   149a0:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   149a7:	vpxord %zmm0,%zmm19,%zmm0
   149ad:	vaddpd %zmm0,%zmm1,%zmm0
   149b3:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   149ba:	vpxord %zmm0,%zmm18,%zmm0
   149c0:	vaddpd %zmm0,%zmm1,%zmm0
   149c6:	vpxord 0x3c0(%rax),%zmm20,%zmm1
   149cd:	vmovapd %zmm0,0x440(%rsp)
   149d5:	vpermilpd $0x55,0x3c0(%rax),%zmm0
   149dd:	vaddpd %zmm1,%zmm0,%zmm0
   149e3:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   149ea:	vpxord %zmm0,%zmm19,%zmm0
   149f0:	vaddpd %zmm0,%zmm1,%zmm0
   149f6:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   149fd:	vpxord %zmm0,%zmm18,%zmm0
   14a03:	vaddpd %zmm0,%zmm1,%zmm0
   14a09:	vmovapd %zmm0,0x480(%rsp)
   14a11:	vzeroupper
   14a14:	call   13d70 <g52_nat.constprop.0>
   14a19:	add    $0x1,%rdx
   14a1d:	vmovapd 0xc0(%rsp),%zmm2
   14a25:	vmovapd 0x100(%rsp),%zmm3
   14a2d:	vmovapd 0x140(%rsp),%zmm4
   14a35:	add    $0x400,%rax
   14a3b:	vmovapd 0x180(%rsp),%zmm5
   14a43:	vmovapd 0x1c0(%rsp),%zmm6
   14a4b:	vmovupd %zmm2,-0x400(%rax)
   14a52:	vmovapd 0x240(%rsp),%zmm7
   14a5a:	vmovapd 0x200(%rsp),%zmm2
   14a62:	vmovupd %zmm3,-0x3c0(%rax)
   14a69:	vmovupd %zmm4,-0x380(%rax)
   14a70:	vmovapd 0x280(%rsp),%zmm3
   14a78:	vmovapd 0x2c0(%rsp),%zmm4
   14a80:	vmovupd %zmm5,-0x340(%rax)
   14a87:	vmovapd 0x300(%rsp),%zmm5
   14a8f:	vmovupd %zmm6,-0x300(%rax)
   14a96:	vmovapd 0x340(%rsp),%zmm6
   14a9e:	vmovupd %zmm7,-0x2c0(%rax)
   14aa5:	vmovapd 0x380(%rsp),%zmm7
   14aad:	vmovupd %zmm2,-0x280(%rax)
   14ab4:	vmovapd 0x3c0(%rsp),%zmm2
   14abc:	vmovupd %zmm3,-0x240(%rax)
   14ac3:	vmovapd 0x400(%rsp),%zmm3
   14acb:	vmovupd %zmm4,-0x200(%rax)
   14ad2:	vmovapd 0x440(%rsp),%zmm4
   14ada:	vmovupd %zmm5,-0x1c0(%rax)
   14ae1:	vmovapd 0x480(%rsp),%zmm5
   14ae9:	vmovupd %zmm6,-0x180(%rax)
   14af0:	vmovupd %zmm7,-0x140(%rax)
   14af7:	vmovupd %zmm2,-0x100(%rax)
   14afe:	vmovupd %zmm3,-0xc0(%rax)
   14b05:	vmovupd %zmm4,-0x80(%rax)
   14b0c:	vmovupd %zmm5,-0x40(%rax)
   14b13:	cmp    %rcx,%rsi
   14b16:	jne    145e0 <hf1_broken_g52+0x80>
   14b1c:	vzeroupper
   14b1f:	mov    0x4f8(%rsp),%rax
   14b27:	sub    %fs:0x28,%rax
   14b30:	jne    14b34 <hf1_broken_g52+0x5d4>
   14b32:	leave
   14b33:	ret
   14b34:	call   4280 <__stack_chk_fail@plt>
   14b39:	nopl   0x0(%rax)

0000000000014b40 <hf0_broken_g52>:
   14b40:	endbr64
   14b44:	push   %rbp
   14b45:	mov    %rdi,%rdx
   14b48:	mov    %rsp,%rbp
   14b4b:	and    $0xffffffffffffffc0,%rsp
   14b4f:	sub    $0x500,%rsp
   14b56:	vbroadcastsd 0x48460(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   14b60:	mov    %fs:0x28,%rax
   14b69:	mov    %rax,0x4f8(%rsp)
   14b71:	xor    %eax,%eax
   14b73:	mov    %rsp,%rdi
   14b76:	vzeroupper
   14b79:	call   ea60 <inl_consts.constprop.1>
   14b7e:	vmovapd (%rsp),%zmm18
   14b85:	vmovapd 0x40(%rsp),%zmm19
   14b8d:	vmovapd 0x80(%rsp),%zmm20
   14b95:	test   %rsi,%rsi
   14b98:	je     14fdf <hf0_broken_g52+0x49f>
   14b9e:	mov    %rsi,%rcx
   14ba1:	mov    %rdx,%rax
   14ba4:	lea    0xc0(%rsp),%rdi
   14bac:	xor    %edx,%edx
   14bae:	sub    $0x1,%rcx
   14bb2:	mov    %rcx,%rsi
   14bb5:	shr    $0x7,%rsi
   14bb9:	nopl   0x0(%rax)
   14bc0:	vpermilpd $0x55,(%rax),%zmm0
   14bc7:	vfmadd231pd (%rax),%zmm18,%zmm0
   14bcd:	mov    %rdx,%rcx
   14bd0:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14bd7:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14bdd:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14be4:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14bea:	vmovapd %zmm0,0xc0(%rsp)
   14bf2:	vpermilpd $0x55,0x40(%rax),%zmm0
   14bfa:	vfmadd231pd 0x40(%rax),%zmm18,%zmm0
   14c01:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14c08:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14c0e:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14c15:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14c1b:	vmovapd %zmm0,0x100(%rsp)
   14c23:	vpermilpd $0x55,0x80(%rax),%zmm0
   14c2b:	vfmadd231pd 0x80(%rax),%zmm18,%zmm0
   14c32:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14c39:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14c3f:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14c46:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14c4c:	vmovapd %zmm0,0x140(%rsp)
   14c54:	vpermilpd $0x55,0xc0(%rax),%zmm0
   14c5c:	vfmadd231pd 0xc0(%rax),%zmm18,%zmm0
   14c63:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14c6a:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14c70:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14c77:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14c7d:	vmovapd %zmm0,0x180(%rsp)
   14c85:	vpermilpd $0x55,0x100(%rax),%zmm0
   14c8d:	vfmadd231pd 0x100(%rax),%zmm18,%zmm0
   14c94:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14c9b:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14ca1:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14ca8:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14cae:	vmovapd %zmm0,0x1c0(%rsp)
   14cb6:	vpermilpd $0x55,0x140(%rax),%zmm0
   14cbe:	vfmadd231pd 0x140(%rax),%zmm18,%zmm0
   14cc5:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14ccc:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14cd2:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14cd9:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14cdf:	vmovapd %zmm0,0x200(%rsp)
   14ce7:	vpermilpd $0x55,0x180(%rax),%zmm0
   14cef:	vfmadd231pd 0x180(%rax),%zmm18,%zmm0
   14cf6:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14cfd:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14d03:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14d0a:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14d10:	vmovapd %zmm0,0x240(%rsp)
   14d18:	vpermilpd $0x55,0x1c0(%rax),%zmm0
   14d20:	vfmadd231pd 0x1c0(%rax),%zmm18,%zmm0
   14d27:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14d2e:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14d34:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14d3b:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14d41:	vmovapd %zmm0,0x280(%rsp)
   14d49:	vpermilpd $0x55,0x200(%rax),%zmm0
   14d51:	vfmadd231pd 0x200(%rax),%zmm18,%zmm0
   14d58:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14d5f:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14d65:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14d6c:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14d72:	vmovapd %zmm0,0x2c0(%rsp)
   14d7a:	vpermilpd $0x55,0x240(%rax),%zmm0
   14d82:	vfmadd231pd 0x240(%rax),%zmm18,%zmm0
   14d89:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14d90:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14d96:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14d9d:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14da3:	vmovapd %zmm0,0x300(%rsp)
   14dab:	vpermilpd $0x55,0x280(%rax),%zmm0
   14db3:	vfmadd231pd 0x280(%rax),%zmm18,%zmm0
   14dba:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14dc1:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14dc7:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14dce:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14dd4:	vmovapd %zmm0,0x340(%rsp)
   14ddc:	vpermilpd $0x55,0x2c0(%rax),%zmm0
   14de4:	vfmadd231pd 0x2c0(%rax),%zmm18,%zmm0
   14deb:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14df2:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14df8:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14dff:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14e05:	vmovapd %zmm0,0x380(%rsp)
   14e0d:	vpermilpd $0x55,0x300(%rax),%zmm0
   14e15:	vfmadd231pd 0x300(%rax),%zmm18,%zmm0
   14e1c:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14e23:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14e29:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14e30:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14e36:	vmovapd %zmm0,0x3c0(%rsp)
   14e3e:	vpermilpd $0x55,0x340(%rax),%zmm0
   14e46:	vfmadd231pd 0x340(%rax),%zmm18,%zmm0
   14e4d:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14e54:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14e5a:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14e61:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14e67:	vmovapd %zmm0,0x400(%rsp)
   14e6f:	vpermilpd $0x55,0x380(%rax),%zmm0
   14e77:	vfmadd231pd 0x380(%rax),%zmm18,%zmm0
   14e7e:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14e85:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14e8b:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14e92:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14e98:	vmovapd %zmm0,0x440(%rsp)
   14ea0:	vpermilpd $0x55,0x3c0(%rax),%zmm0
   14ea8:	vfmadd231pd 0x3c0(%rax),%zmm18,%zmm0
   14eaf:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   14eb6:	vfmadd132pd %zmm19,%zmm1,%zmm0
   14ebc:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   14ec3:	vfmadd132pd %zmm20,%zmm1,%zmm0
   14ec9:	vmovapd %zmm0,0x480(%rsp)
   14ed1:	vzeroupper
   14ed4:	call   13d70 <g52_nat.constprop.0>
   14ed9:	add    $0x1,%rdx
   14edd:	vmovapd 0xc0(%rsp),%zmm2
   14ee5:	vmovapd 0x100(%rsp),%zmm3
   14eed:	vmovapd 0x140(%rsp),%zmm4
   14ef5:	add    $0x400,%rax
   14efb:	vmovapd 0x180(%rsp),%zmm5
   14f03:	vmovapd 0x1c0(%rsp),%zmm6
   14f0b:	vmovupd %zmm2,-0x400(%rax)
   14f12:	vmovapd 0x240(%rsp),%zmm7
   14f1a:	vmovapd 0x200(%rsp),%zmm2
   14f22:	vmovupd %zmm3,-0x3c0(%rax)
   14f29:	vmovupd %zmm4,-0x380(%rax)
   14f30:	vmovapd 0x280(%rsp),%zmm3
   14f38:	vmovapd 0x2c0(%rsp),%zmm4
   14f40:	vmovupd %zmm5,-0x340(%rax)
   14f47:	vmovapd 0x300(%rsp),%zmm5
   14f4f:	vmovupd %zmm6,-0x300(%rax)
   14f56:	vmovapd 0x340(%rsp),%zmm6
   14f5e:	vmovupd %zmm7,-0x2c0(%rax)
   14f65:	vmovapd 0x380(%rsp),%zmm7
   14f6d:	vmovupd %zmm2,-0x280(%rax)
   14f74:	vmovapd 0x3c0(%rsp),%zmm2
   14f7c:	vmovupd %zmm3,-0x240(%rax)
   14f83:	vmovapd 0x400(%rsp),%zmm3
   14f8b:	vmovupd %zmm4,-0x200(%rax)
   14f92:	vmovapd 0x440(%rsp),%zmm4
   14f9a:	vmovupd %zmm5,-0x1c0(%rax)
   14fa1:	vmovapd 0x480(%rsp),%zmm5
   14fa9:	vmovupd %zmm6,-0x180(%rax)
   14fb0:	vmovupd %zmm7,-0x140(%rax)
   14fb7:	vmovupd %zmm2,-0x100(%rax)
   14fbe:	vmovupd %zmm3,-0xc0(%rax)
   14fc5:	vmovupd %zmm4,-0x80(%rax)
   14fcc:	vmovupd %zmm5,-0x40(%rax)
   14fd3:	cmp    %rcx,%rsi
   14fd6:	jne    14bc0 <hf0_broken_g52+0x80>
   14fdc:	vzeroupper
   14fdf:	mov    0x4f8(%rsp),%rax
   14fe7:	sub    %fs:0x28,%rax
   14ff0:	jne    14ff4 <hf0_broken_g52+0x4b4>
   14ff2:	leave
   14ff3:	ret
   14ff4:	call   4280 <__stack_chk_fail@plt>
   14ff9:	nopl   0x0(%rax)

0000000000015000 <hf2_g52_nat>:
   15000:	endbr64
   15004:	push   %rbp
   15005:	mov    %rsp,%rbp
   15008:	and    $0xffffffffffffffc0,%rsp
   1500c:	sub    $0x440,%rsp
   15013:	vbroadcastsd 0x47fa3(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   1501d:	mov    %fs:0x28,%rcx
   15026:	mov    %rcx,0x438(%rsp)
   1502e:	xor    %ecx,%ecx
   15030:	test   %rsi,%rsi
   15033:	je     155ab <hf2_g52_nat+0x5ab>
   15039:	mov    %rsi,%rdx
   1503c:	mov    %rdi,%rax
   1503f:	vmovdqa64 0x47df7(%rip),%zmm20        # 5ce40 <_IO_stdin_used+0xe40>
   15049:	vmovdqa64 0x47e2d(%rip),%zmm19        # 5ce80 <_IO_stdin_used+0xe80>
   15053:	sub    $0x1,%rdx
   15057:	mov    $0xffffffaa,%ecx
   1505c:	mov    %rsp,%rdi
   1505f:	vmovdqa64 0x47e57(%rip),%zmm18        # 5cec0 <_IO_stdin_used+0xec0>
   15069:	mov    %rdx,%rsi
   1506c:	xor    %edx,%edx
   1506e:	kmovw  %ecx,%k3
   15072:	shr    $0x7,%rsi
   15076:	cs nopw 0x0(%rax,%rax,1)
   15080:	vpermpd (%rax),%zmm20,%zmm0
   15086:	vaddpd (%rax),%zmm0,%zmm1
   1508c:	mov    $0xffffffcc,%ecx
   15091:	vsubpd (%rax),%zmm0,%zmm1{%k3}
   15097:	kmovw  %ecx,%k2
   1509b:	mov    $0xfffffff0,%ecx
   150a0:	kmovw  %ecx,%k1
   150a4:	mov    %rdx,%rcx
   150a7:	vpermpd %zmm1,%zmm19,%zmm2
   150ad:	vaddpd %zmm2,%zmm1,%zmm0
   150b3:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   150b9:	vpermpd %zmm0,%zmm18,%zmm2
   150bf:	vaddpd %zmm2,%zmm0,%zmm1
   150c5:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   150cb:	vpermpd 0x40(%rax),%zmm20,%zmm0
   150d2:	vmovapd %zmm1,(%rsp)
   150d9:	vaddpd 0x40(%rax),%zmm0,%zmm1
   150e0:	vsubpd 0x40(%rax),%zmm0,%zmm1{%k3}
   150e7:	vpermpd %zmm1,%zmm19,%zmm2
   150ed:	vaddpd %zmm2,%zmm1,%zmm0
   150f3:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   150f9:	vpermpd %zmm0,%zmm18,%zmm2
   150ff:	vaddpd %zmm2,%zmm0,%zmm1
   15105:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   1510b:	vpermpd 0x80(%rax),%zmm20,%zmm0
   15112:	vmovapd %zmm1,0x40(%rsp)
   1511a:	vaddpd 0x80(%rax),%zmm0,%zmm1
   15121:	vsubpd 0x80(%rax),%zmm0,%zmm1{%k3}
   15128:	vpermpd %zmm1,%zmm19,%zmm2
   1512e:	vaddpd %zmm2,%zmm1,%zmm0
   15134:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   1513a:	vpermpd %zmm0,%zmm18,%zmm2
   15140:	vaddpd %zmm2,%zmm0,%zmm1
   15146:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   1514c:	vpermpd 0xc0(%rax),%zmm20,%zmm0
   15153:	vmovapd %zmm1,0x80(%rsp)
   1515b:	vaddpd 0xc0(%rax),%zmm0,%zmm1
   15162:	vsubpd 0xc0(%rax),%zmm0,%zmm1{%k3}
   15169:	vpermpd %zmm1,%zmm19,%zmm2
   1516f:	vaddpd %zmm2,%zmm1,%zmm0
   15175:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   1517b:	vpermpd %zmm0,%zmm18,%zmm2
   15181:	vaddpd %zmm2,%zmm0,%zmm1
   15187:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   1518d:	vpermpd 0x100(%rax),%zmm20,%zmm0
   15194:	vmovapd %zmm1,0xc0(%rsp)
   1519c:	vaddpd 0x100(%rax),%zmm0,%zmm1
   151a3:	vsubpd 0x100(%rax),%zmm0,%zmm1{%k3}
   151aa:	vpermpd %zmm1,%zmm19,%zmm2
   151b0:	vaddpd %zmm2,%zmm1,%zmm0
   151b6:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   151bc:	vpermpd %zmm0,%zmm18,%zmm2
   151c2:	vaddpd %zmm2,%zmm0,%zmm1
   151c8:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   151ce:	vpermpd 0x140(%rax),%zmm20,%zmm0
   151d5:	vmovapd %zmm1,0x100(%rsp)
   151dd:	vaddpd 0x140(%rax),%zmm0,%zmm1
   151e4:	vsubpd 0x140(%rax),%zmm0,%zmm1{%k3}
   151eb:	vpermpd %zmm1,%zmm19,%zmm2
   151f1:	vaddpd %zmm2,%zmm1,%zmm0
   151f7:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   151fd:	vpermpd %zmm0,%zmm18,%zmm2
   15203:	vaddpd %zmm2,%zmm0,%zmm1
   15209:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   1520f:	vpermpd 0x180(%rax),%zmm20,%zmm0
   15216:	vmovapd %zmm1,0x140(%rsp)
   1521e:	vaddpd 0x180(%rax),%zmm0,%zmm1
   15225:	vsubpd 0x180(%rax),%zmm0,%zmm1{%k3}
   1522c:	vpermpd %zmm1,%zmm19,%zmm2
   15232:	vaddpd %zmm2,%zmm1,%zmm0
   15238:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   1523e:	vpermpd %zmm0,%zmm18,%zmm2
   15244:	vaddpd %zmm2,%zmm0,%zmm1
   1524a:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   15250:	vpermpd 0x1c0(%rax),%zmm20,%zmm0
   15257:	vmovapd %zmm1,0x180(%rsp)
   1525f:	vaddpd 0x1c0(%rax),%zmm0,%zmm1
   15266:	vsubpd 0x1c0(%rax),%zmm0,%zmm1{%k3}
   1526d:	vpermpd %zmm1,%zmm19,%zmm2
   15273:	vaddpd %zmm2,%zmm1,%zmm0
   15279:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   1527f:	vpermpd %zmm0,%zmm18,%zmm2
   15285:	vaddpd %zmm2,%zmm0,%zmm1
   1528b:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   15291:	vmovapd %zmm1,0x1c0(%rsp)
   15299:	vpermpd 0x200(%rax),%zmm20,%zmm0
   152a0:	vaddpd 0x200(%rax),%zmm0,%zmm1
   152a7:	vsubpd 0x200(%rax),%zmm0,%zmm1{%k3}
   152ae:	vpermpd %zmm1,%zmm19,%zmm2
   152b4:	vaddpd %zmm2,%zmm1,%zmm0
   152ba:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   152c0:	vpermpd %zmm0,%zmm18,%zmm2
   152c6:	vaddpd %zmm2,%zmm0,%zmm1
   152cc:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   152d2:	vpermpd 0x240(%rax),%zmm20,%zmm0
   152d9:	vmovapd %zmm1,0x200(%rsp)
   152e1:	vaddpd 0x240(%rax),%zmm0,%zmm1
   152e8:	vsubpd 0x240(%rax),%zmm0,%zmm1{%k3}
   152ef:	vpermpd %zmm1,%zmm19,%zmm2
   152f5:	vaddpd %zmm2,%zmm1,%zmm0
   152fb:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   15301:	vpermpd %zmm0,%zmm18,%zmm2
   15307:	vaddpd %zmm2,%zmm0,%zmm1
   1530d:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   15313:	vpermpd 0x280(%rax),%zmm20,%zmm0
   1531a:	vmovapd %zmm1,0x240(%rsp)
   15322:	vaddpd 0x280(%rax),%zmm0,%zmm1
   15329:	vsubpd 0x280(%rax),%zmm0,%zmm1{%k3}
   15330:	vpermpd %zmm1,%zmm19,%zmm2
   15336:	vaddpd %zmm2,%zmm1,%zmm0
   1533c:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   15342:	vpermpd %zmm0,%zmm18,%zmm2
   15348:	vaddpd %zmm2,%zmm0,%zmm1
   1534e:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   15354:	vpermpd 0x2c0(%rax),%zmm20,%zmm0
   1535b:	vmovapd %zmm1,0x280(%rsp)
   15363:	vaddpd 0x2c0(%rax),%zmm0,%zmm1
   1536a:	vsubpd 0x2c0(%rax),%zmm0,%zmm1{%k3}
   15371:	vpermpd %zmm1,%zmm19,%zmm2
   15377:	vaddpd %zmm2,%zmm1,%zmm0
   1537d:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   15383:	vpermpd %zmm0,%zmm18,%zmm2
   15389:	vaddpd %zmm2,%zmm0,%zmm1
   1538f:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   15395:	vpermpd 0x300(%rax),%zmm20,%zmm0
   1539c:	vmovapd %zmm1,0x2c0(%rsp)
   153a4:	vaddpd 0x300(%rax),%zmm0,%zmm1
   153ab:	vsubpd 0x300(%rax),%zmm0,%zmm1{%k3}
   153b2:	vpermpd %zmm1,%zmm19,%zmm2
   153b8:	vaddpd %zmm2,%zmm1,%zmm0
   153be:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   153c4:	vpermpd %zmm0,%zmm18,%zmm2
   153ca:	vaddpd %zmm2,%zmm0,%zmm1
   153d0:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   153d6:	vpermpd 0x340(%rax),%zmm20,%zmm0
   153dd:	vmovapd %zmm1,0x300(%rsp)
   153e5:	vaddpd 0x340(%rax),%zmm0,%zmm1
   153ec:	vsubpd 0x340(%rax),%zmm0,%zmm1{%k3}
   153f3:	vpermpd %zmm1,%zmm19,%zmm2
   153f9:	vaddpd %zmm2,%zmm1,%zmm0
   153ff:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   15405:	vpermpd %zmm0,%zmm18,%zmm2
   1540b:	vaddpd %zmm2,%zmm0,%zmm1
   15411:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   15417:	vpermpd 0x380(%rax),%zmm20,%zmm0
   1541e:	vmovapd %zmm1,0x340(%rsp)
   15426:	vaddpd 0x380(%rax),%zmm0,%zmm1
   1542d:	vsubpd 0x380(%rax),%zmm0,%zmm1{%k3}
   15434:	vpermpd %zmm1,%zmm19,%zmm2
   1543a:	vaddpd %zmm2,%zmm1,%zmm0
   15440:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   15446:	vpermpd %zmm0,%zmm18,%zmm2
   1544c:	vaddpd %zmm2,%zmm0,%zmm1
   15452:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   15458:	vpermpd 0x3c0(%rax),%zmm20,%zmm0
   1545f:	vmovapd %zmm1,0x380(%rsp)
   15467:	vaddpd 0x3c0(%rax),%zmm0,%zmm1
   1546e:	vsubpd 0x3c0(%rax),%zmm0,%zmm1{%k3}
   15475:	vpermpd %zmm1,%zmm19,%zmm2
   1547b:	vaddpd %zmm2,%zmm1,%zmm0
   15481:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   15487:	vpermpd %zmm0,%zmm18,%zmm2
   1548d:	vaddpd %zmm2,%zmm0,%zmm1
   15493:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   15499:	vmovapd %zmm1,0x3c0(%rsp)
   154a1:	vzeroupper
   154a4:	call   13d70 <g52_nat.constprop.0>
   154a9:	vmovapd (%rsp),%zmm3
   154b0:	vmovapd 0x40(%rsp),%zmm4
   154b8:	vmovapd 0x80(%rsp),%zmm5
   154c0:	add    $0x1,%rdx
   154c4:	add    $0x400,%rax
   154ca:	vmovapd 0xc0(%rsp),%zmm6
   154d2:	vmovapd 0x100(%rsp),%zmm7
   154da:	vmovupd %zmm3,-0x400(%rax)
   154e1:	vmovapd 0x140(%rsp),%zmm3
   154e9:	vmovupd %zmm4,-0x3c0(%rax)
   154f0:	vmovapd 0x180(%rsp),%zmm4
   154f8:	vmovupd %zmm5,-0x380(%rax)
   154ff:	vmovapd 0x1c0(%rsp),%zmm5
   15507:	vmovupd %zmm6,-0x340(%rax)
   1550e:	vmovapd 0x200(%rsp),%zmm6
   15516:	vmovupd %zmm7,-0x300(%rax)
   1551d:	vmovapd 0x240(%rsp),%zmm7
   15525:	vmovupd %zmm3,-0x2c0(%rax)
   1552c:	vmovapd 0x280(%rsp),%zmm3
   15534:	vmovupd %zmm4,-0x280(%rax)
   1553b:	vmovapd 0x2c0(%rsp),%zmm4
   15543:	vmovupd %zmm5,-0x240(%rax)
   1554a:	vmovapd 0x300(%rsp),%zmm5
   15552:	vmovupd %zmm6,-0x200(%rax)
   15559:	vmovapd 0x340(%rsp),%zmm6
   15561:	vmovupd %zmm7,-0x1c0(%rax)
   15568:	vmovapd 0x380(%rsp),%zmm7
   15570:	vmovupd %zmm3,-0x180(%rax)
   15577:	vmovapd 0x3c0(%rsp),%zmm3
   1557f:	vmovupd %zmm4,-0x140(%rax)
   15586:	vmovupd %zmm5,-0x100(%rax)
   1558d:	vmovupd %zmm6,-0xc0(%rax)
   15594:	vmovupd %zmm7,-0x80(%rax)
   1559b:	vmovupd %zmm3,-0x40(%rax)
   155a2:	cmp    %rsi,%rcx
   155a5:	jne    15080 <hf2_g52_nat+0x80>
   155ab:	mov    0x438(%rsp),%rax
   155b3:	sub    %fs:0x28,%rax
   155bc:	jne    155c3 <hf2_g52_nat+0x5c3>
   155be:	vzeroupper
   155c1:	leave
   155c2:	ret
   155c3:	vzeroupper
   155c6:	call   4280 <__stack_chk_fail@plt>
   155cb:	nopl   0x0(%rax,%rax,1)

00000000000155d0 <hf1_g52_nat>:
   155d0:	endbr64
   155d4:	push   %rbp
   155d5:	mov    %rdi,%rdx
   155d8:	mov    %rsp,%rbp
   155db:	and    $0xffffffffffffffc0,%rsp
   155df:	sub    $0x500,%rsp
   155e6:	vbroadcastsd 0x479d0(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   155f0:	mov    %fs:0x28,%rax
   155f9:	mov    %rax,0x4f8(%rsp)
   15601:	xor    %eax,%eax
   15603:	mov    %rsp,%rdi
   15606:	vzeroupper
   15609:	call   df20 <inl_consts.constprop.0>
   1560e:	vmovapd (%rsp),%zmm20
   15615:	vmovapd 0x40(%rsp),%zmm19
   1561d:	vmovapd 0x80(%rsp),%zmm18
   15625:	test   %rsi,%rsi
   15628:	je     15b8f <hf1_g52_nat+0x5bf>
   1562e:	mov    %rsi,%rcx
   15631:	mov    %rdx,%rax
   15634:	lea    0xc0(%rsp),%rdi
   1563c:	xor    %edx,%edx
   1563e:	sub    $0x1,%rcx
   15642:	mov    %rcx,%rsi
   15645:	shr    $0x7,%rsi
   15649:	nopl   0x0(%rax)
   15650:	vpxord (%rax),%zmm20,%zmm1
   15656:	vpermilpd $0x55,(%rax),%zmm0
   1565d:	mov    %rdx,%rcx
   15660:	vaddpd %zmm1,%zmm0,%zmm0
   15666:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   1566d:	vpxord %zmm0,%zmm19,%zmm0
   15673:	vaddpd %zmm0,%zmm1,%zmm0
   15679:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15680:	vpxord %zmm0,%zmm18,%zmm0
   15686:	vaddpd %zmm0,%zmm1,%zmm0
   1568c:	vpxord 0x40(%rax),%zmm20,%zmm1
   15693:	vmovapd %zmm0,0xc0(%rsp)
   1569b:	vpermilpd $0x55,0x40(%rax),%zmm0
   156a3:	vaddpd %zmm1,%zmm0,%zmm0
   156a9:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   156b0:	vpxord %zmm0,%zmm19,%zmm0
   156b6:	vaddpd %zmm0,%zmm1,%zmm0
   156bc:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   156c3:	vpxord %zmm0,%zmm18,%zmm0
   156c9:	vaddpd %zmm0,%zmm1,%zmm0
   156cf:	vpxord 0x80(%rax),%zmm20,%zmm1
   156d6:	vmovapd %zmm0,0x100(%rsp)
   156de:	vpermilpd $0x55,0x80(%rax),%zmm0
   156e6:	vaddpd %zmm1,%zmm0,%zmm0
   156ec:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   156f3:	vpxord %zmm0,%zmm19,%zmm0
   156f9:	vaddpd %zmm0,%zmm1,%zmm0
   156ff:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15706:	vpxord %zmm0,%zmm18,%zmm0
   1570c:	vaddpd %zmm0,%zmm1,%zmm0
   15712:	vpxord 0xc0(%rax),%zmm20,%zmm1
   15719:	vmovapd %zmm0,0x140(%rsp)
   15721:	vpermilpd $0x55,0xc0(%rax),%zmm0
   15729:	vaddpd %zmm1,%zmm0,%zmm0
   1572f:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15736:	vpxord %zmm0,%zmm19,%zmm0
   1573c:	vaddpd %zmm0,%zmm1,%zmm0
   15742:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15749:	vpxord %zmm0,%zmm18,%zmm0
   1574f:	vaddpd %zmm0,%zmm1,%zmm0
   15755:	vpxord 0x100(%rax),%zmm20,%zmm1
   1575c:	vmovapd %zmm0,0x180(%rsp)
   15764:	vpermilpd $0x55,0x100(%rax),%zmm0
   1576c:	vaddpd %zmm1,%zmm0,%zmm0
   15772:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15779:	vpxord %zmm0,%zmm19,%zmm0
   1577f:	vaddpd %zmm0,%zmm1,%zmm0
   15785:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   1578c:	vpxord %zmm0,%zmm18,%zmm0
   15792:	vaddpd %zmm0,%zmm1,%zmm0
   15798:	vpxord 0x140(%rax),%zmm20,%zmm1
   1579f:	vmovapd %zmm0,0x1c0(%rsp)
   157a7:	vpermilpd $0x55,0x140(%rax),%zmm0
   157af:	vaddpd %zmm1,%zmm0,%zmm0
   157b5:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   157bc:	vpxord %zmm0,%zmm19,%zmm0
   157c2:	vaddpd %zmm0,%zmm1,%zmm0
   157c8:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   157cf:	vpxord %zmm0,%zmm18,%zmm0
   157d5:	vaddpd %zmm0,%zmm1,%zmm0
   157db:	vpxord 0x180(%rax),%zmm20,%zmm1
   157e2:	vmovapd %zmm0,0x200(%rsp)
   157ea:	vpermilpd $0x55,0x180(%rax),%zmm0
   157f2:	vaddpd %zmm1,%zmm0,%zmm0
   157f8:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   157ff:	vpxord %zmm0,%zmm19,%zmm0
   15805:	vaddpd %zmm0,%zmm1,%zmm0
   1580b:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15812:	vpxord %zmm0,%zmm18,%zmm0
   15818:	vaddpd %zmm0,%zmm1,%zmm0
   1581e:	vpxord 0x1c0(%rax),%zmm20,%zmm1
   15825:	vmovapd %zmm0,0x240(%rsp)
   1582d:	vpermilpd $0x55,0x1c0(%rax),%zmm0
   15835:	vaddpd %zmm1,%zmm0,%zmm0
   1583b:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15842:	vpxord %zmm0,%zmm19,%zmm0
   15848:	vaddpd %zmm0,%zmm1,%zmm0
   1584e:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15855:	vpxord %zmm0,%zmm18,%zmm0
   1585b:	vaddpd %zmm0,%zmm1,%zmm0
   15861:	vpxord 0x200(%rax),%zmm20,%zmm1
   15868:	vmovapd %zmm0,0x280(%rsp)
   15870:	vpermilpd $0x55,0x200(%rax),%zmm0
   15878:	vaddpd %zmm1,%zmm0,%zmm0
   1587e:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15885:	vpxord %zmm0,%zmm19,%zmm0
   1588b:	vaddpd %zmm0,%zmm1,%zmm0
   15891:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15898:	vpxord %zmm0,%zmm18,%zmm0
   1589e:	vaddpd %zmm0,%zmm1,%zmm0
   158a4:	vpxord 0x240(%rax),%zmm20,%zmm1
   158ab:	vmovapd %zmm0,0x2c0(%rsp)
   158b3:	vpermilpd $0x55,0x240(%rax),%zmm0
   158bb:	vaddpd %zmm1,%zmm0,%zmm0
   158c1:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   158c8:	vpxord %zmm0,%zmm19,%zmm0
   158ce:	vaddpd %zmm0,%zmm1,%zmm0
   158d4:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   158db:	vpxord %zmm0,%zmm18,%zmm0
   158e1:	vaddpd %zmm0,%zmm1,%zmm0
   158e7:	vpxord 0x280(%rax),%zmm20,%zmm1
   158ee:	vmovapd %zmm0,0x300(%rsp)
   158f6:	vpermilpd $0x55,0x280(%rax),%zmm0
   158fe:	vaddpd %zmm1,%zmm0,%zmm0
   15904:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   1590b:	vpxord %zmm0,%zmm19,%zmm0
   15911:	vaddpd %zmm0,%zmm1,%zmm0
   15917:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   1591e:	vpxord %zmm0,%zmm18,%zmm0
   15924:	vaddpd %zmm0,%zmm1,%zmm0
   1592a:	vmovapd %zmm0,0x340(%rsp)
   15932:	vpxord 0x2c0(%rax),%zmm20,%zmm1
   15939:	vpermilpd $0x55,0x2c0(%rax),%zmm0
   15941:	vaddpd %zmm1,%zmm0,%zmm0
   15947:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   1594e:	vpxord %zmm0,%zmm19,%zmm0
   15954:	vaddpd %zmm0,%zmm1,%zmm0
   1595a:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15961:	vpxord %zmm0,%zmm18,%zmm0
   15967:	vaddpd %zmm0,%zmm1,%zmm0
   1596d:	vpxord 0x300(%rax),%zmm20,%zmm1
   15974:	vmovapd %zmm0,0x380(%rsp)
   1597c:	vpermilpd $0x55,0x300(%rax),%zmm0
   15984:	vaddpd %zmm1,%zmm0,%zmm0
   1598a:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15991:	vpxord %zmm0,%zmm19,%zmm0
   15997:	vaddpd %zmm0,%zmm1,%zmm0
   1599d:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   159a4:	vpxord %zmm0,%zmm18,%zmm0
   159aa:	vaddpd %zmm0,%zmm1,%zmm0
   159b0:	vpxord 0x340(%rax),%zmm20,%zmm1
   159b7:	vmovapd %zmm0,0x3c0(%rsp)
   159bf:	vpermilpd $0x55,0x340(%rax),%zmm0
   159c7:	vaddpd %zmm1,%zmm0,%zmm0
   159cd:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   159d4:	vpxord %zmm0,%zmm19,%zmm0
   159da:	vaddpd %zmm0,%zmm1,%zmm0
   159e0:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   159e7:	vpxord %zmm0,%zmm18,%zmm0
   159ed:	vaddpd %zmm0,%zmm1,%zmm0
   159f3:	vpxord 0x380(%rax),%zmm20,%zmm1
   159fa:	vmovapd %zmm0,0x400(%rsp)
   15a02:	vpermilpd $0x55,0x380(%rax),%zmm0
   15a0a:	vaddpd %zmm1,%zmm0,%zmm0
   15a10:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15a17:	vpxord %zmm0,%zmm19,%zmm0
   15a1d:	vaddpd %zmm0,%zmm1,%zmm0
   15a23:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15a2a:	vpxord %zmm0,%zmm18,%zmm0
   15a30:	vaddpd %zmm0,%zmm1,%zmm0
   15a36:	vpxord 0x3c0(%rax),%zmm20,%zmm1
   15a3d:	vmovapd %zmm0,0x440(%rsp)
   15a45:	vpermilpd $0x55,0x3c0(%rax),%zmm0
   15a4d:	vaddpd %zmm1,%zmm0,%zmm0
   15a53:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15a5a:	vpxord %zmm0,%zmm19,%zmm0
   15a60:	vaddpd %zmm0,%zmm1,%zmm0
   15a66:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15a6d:	vpxord %zmm0,%zmm18,%zmm0
   15a73:	vaddpd %zmm0,%zmm1,%zmm0
   15a79:	vmovapd %zmm0,0x480(%rsp)
   15a81:	vzeroupper
   15a84:	call   13d70 <g52_nat.constprop.0>
   15a89:	add    $0x1,%rdx
   15a8d:	vmovapd 0xc0(%rsp),%zmm2
   15a95:	vmovapd 0x100(%rsp),%zmm3
   15a9d:	vmovapd 0x140(%rsp),%zmm4
   15aa5:	add    $0x400,%rax
   15aab:	vmovapd 0x180(%rsp),%zmm5
   15ab3:	vmovapd 0x1c0(%rsp),%zmm6
   15abb:	vmovupd %zmm2,-0x400(%rax)
   15ac2:	vmovapd 0x200(%rsp),%zmm7
   15aca:	vmovapd 0x240(%rsp),%zmm2
   15ad2:	vmovupd %zmm3,-0x3c0(%rax)
   15ad9:	vmovupd %zmm4,-0x380(%rax)
   15ae0:	vmovapd 0x280(%rsp),%zmm3
   15ae8:	vmovapd 0x2c0(%rsp),%zmm4
   15af0:	vmovupd %zmm5,-0x340(%rax)
   15af7:	vmovapd 0x300(%rsp),%zmm5
   15aff:	vmovupd %zmm6,-0x300(%rax)
   15b06:	vmovapd 0x340(%rsp),%zmm6
   15b0e:	vmovupd %zmm7,-0x2c0(%rax)
   15b15:	vmovapd 0x380(%rsp),%zmm7
   15b1d:	vmovupd %zmm2,-0x280(%rax)
   15b24:	vmovapd 0x3c0(%rsp),%zmm2
   15b2c:	vmovupd %zmm3,-0x240(%rax)
   15b33:	vmovapd 0x400(%rsp),%zmm3
   15b3b:	vmovupd %zmm4,-0x200(%rax)
   15b42:	vmovapd 0x440(%rsp),%zmm4
   15b4a:	vmovupd %zmm5,-0x1c0(%rax)
   15b51:	vmovapd 0x480(%rsp),%zmm5
   15b59:	vmovupd %zmm6,-0x180(%rax)
   15b60:	vmovupd %zmm7,-0x140(%rax)
   15b67:	vmovupd %zmm2,-0x100(%rax)
   15b6e:	vmovupd %zmm3,-0xc0(%rax)
   15b75:	vmovupd %zmm4,-0x80(%rax)
   15b7c:	vmovupd %zmm5,-0x40(%rax)
   15b83:	cmp    %rcx,%rsi
   15b86:	jne    15650 <hf1_g52_nat+0x80>
   15b8c:	vzeroupper
   15b8f:	mov    0x4f8(%rsp),%rax
   15b97:	sub    %fs:0x28,%rax
   15ba0:	jne    15ba4 <hf1_g52_nat+0x5d4>
   15ba2:	leave
   15ba3:	ret
   15ba4:	call   4280 <__stack_chk_fail@plt>
   15ba9:	nopl   0x0(%rax)

0000000000015bb0 <hf0_g52_nat>:
   15bb0:	endbr64
   15bb4:	push   %rbp
   15bb5:	mov    %rdi,%rdx
   15bb8:	mov    %rsp,%rbp
   15bbb:	and    $0xffffffffffffffc0,%rsp
   15bbf:	sub    $0x500,%rsp
   15bc6:	vbroadcastsd 0x473f0(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   15bd0:	mov    %fs:0x28,%rax
   15bd9:	mov    %rax,0x4f8(%rsp)
   15be1:	xor    %eax,%eax
   15be3:	mov    %rsp,%rdi
   15be6:	vzeroupper
   15be9:	call   ea60 <inl_consts.constprop.1>
   15bee:	vmovapd (%rsp),%zmm18
   15bf5:	vmovapd 0x40(%rsp),%zmm19
   15bfd:	vmovapd 0x80(%rsp),%zmm20
   15c05:	test   %rsi,%rsi
   15c08:	je     1604f <hf0_g52_nat+0x49f>
   15c0e:	mov    %rsi,%rcx
   15c11:	mov    %rdx,%rax
   15c14:	lea    0xc0(%rsp),%rdi
   15c1c:	xor    %edx,%edx
   15c1e:	sub    $0x1,%rcx
   15c22:	mov    %rcx,%rsi
   15c25:	shr    $0x7,%rsi
   15c29:	nopl   0x0(%rax)
   15c30:	vpermilpd $0x55,(%rax),%zmm0
   15c37:	vfmadd231pd (%rax),%zmm18,%zmm0
   15c3d:	mov    %rdx,%rcx
   15c40:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15c47:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15c4d:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15c54:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15c5a:	vmovapd %zmm0,0xc0(%rsp)
   15c62:	vpermilpd $0x55,0x40(%rax),%zmm0
   15c6a:	vfmadd231pd 0x40(%rax),%zmm18,%zmm0
   15c71:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15c78:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15c7e:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15c85:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15c8b:	vmovapd %zmm0,0x100(%rsp)
   15c93:	vpermilpd $0x55,0x80(%rax),%zmm0
   15c9b:	vfmadd231pd 0x80(%rax),%zmm18,%zmm0
   15ca2:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15ca9:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15caf:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15cb6:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15cbc:	vmovapd %zmm0,0x140(%rsp)
   15cc4:	vpermilpd $0x55,0xc0(%rax),%zmm0
   15ccc:	vfmadd231pd 0xc0(%rax),%zmm18,%zmm0
   15cd3:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15cda:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15ce0:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15ce7:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15ced:	vmovapd %zmm0,0x180(%rsp)
   15cf5:	vpermilpd $0x55,0x100(%rax),%zmm0
   15cfd:	vfmadd231pd 0x100(%rax),%zmm18,%zmm0
   15d04:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15d0b:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15d11:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15d18:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15d1e:	vmovapd %zmm0,0x1c0(%rsp)
   15d26:	vpermilpd $0x55,0x140(%rax),%zmm0
   15d2e:	vfmadd231pd 0x140(%rax),%zmm18,%zmm0
   15d35:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15d3c:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15d42:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15d49:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15d4f:	vmovapd %zmm0,0x200(%rsp)
   15d57:	vpermilpd $0x55,0x180(%rax),%zmm0
   15d5f:	vfmadd231pd 0x180(%rax),%zmm18,%zmm0
   15d66:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15d6d:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15d73:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15d7a:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15d80:	vmovapd %zmm0,0x240(%rsp)
   15d88:	vpermilpd $0x55,0x1c0(%rax),%zmm0
   15d90:	vfmadd231pd 0x1c0(%rax),%zmm18,%zmm0
   15d97:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15d9e:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15da4:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15dab:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15db1:	vmovapd %zmm0,0x280(%rsp)
   15db9:	vpermilpd $0x55,0x200(%rax),%zmm0
   15dc1:	vfmadd231pd 0x200(%rax),%zmm18,%zmm0
   15dc8:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15dcf:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15dd5:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15ddc:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15de2:	vmovapd %zmm0,0x2c0(%rsp)
   15dea:	vpermilpd $0x55,0x240(%rax),%zmm0
   15df2:	vfmadd231pd 0x240(%rax),%zmm18,%zmm0
   15df9:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15e00:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15e06:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15e0d:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15e13:	vmovapd %zmm0,0x300(%rsp)
   15e1b:	vpermilpd $0x55,0x280(%rax),%zmm0
   15e23:	vfmadd231pd 0x280(%rax),%zmm18,%zmm0
   15e2a:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15e31:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15e37:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15e3e:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15e44:	vmovapd %zmm0,0x340(%rsp)
   15e4c:	vpermilpd $0x55,0x2c0(%rax),%zmm0
   15e54:	vfmadd231pd 0x2c0(%rax),%zmm18,%zmm0
   15e5b:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15e62:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15e68:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15e6f:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15e75:	vmovapd %zmm0,0x380(%rsp)
   15e7d:	vpermilpd $0x55,0x300(%rax),%zmm0
   15e85:	vfmadd231pd 0x300(%rax),%zmm18,%zmm0
   15e8c:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15e93:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15e99:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15ea0:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15ea6:	vmovapd %zmm0,0x3c0(%rsp)
   15eae:	vpermilpd $0x55,0x340(%rax),%zmm0
   15eb6:	vfmadd231pd 0x340(%rax),%zmm18,%zmm0
   15ebd:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15ec4:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15eca:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15ed1:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15ed7:	vmovapd %zmm0,0x400(%rsp)
   15edf:	vpermilpd $0x55,0x380(%rax),%zmm0
   15ee7:	vfmadd231pd 0x380(%rax),%zmm18,%zmm0
   15eee:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15ef5:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15efb:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15f02:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15f08:	vmovapd %zmm0,0x440(%rsp)
   15f10:	vpermilpd $0x55,0x3c0(%rax),%zmm0
   15f18:	vfmadd231pd 0x3c0(%rax),%zmm18,%zmm0
   15f1f:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   15f26:	vfmadd132pd %zmm19,%zmm1,%zmm0
   15f2c:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   15f33:	vfmadd132pd %zmm20,%zmm1,%zmm0
   15f39:	vmovapd %zmm0,0x480(%rsp)
   15f41:	vzeroupper
   15f44:	call   13d70 <g52_nat.constprop.0>
   15f49:	add    $0x1,%rdx
   15f4d:	vmovapd 0xc0(%rsp),%zmm2
   15f55:	vmovapd 0x100(%rsp),%zmm3
   15f5d:	vmovapd 0x140(%rsp),%zmm4
   15f65:	add    $0x400,%rax
   15f6b:	vmovapd 0x180(%rsp),%zmm5
   15f73:	vmovapd 0x1c0(%rsp),%zmm6
   15f7b:	vmovupd %zmm2,-0x400(%rax)
   15f82:	vmovapd 0x200(%rsp),%zmm7
   15f8a:	vmovapd 0x240(%rsp),%zmm2
   15f92:	vmovupd %zmm3,-0x3c0(%rax)
   15f99:	vmovupd %zmm4,-0x380(%rax)
   15fa0:	vmovapd 0x280(%rsp),%zmm3
   15fa8:	vmovapd 0x2c0(%rsp),%zmm4
   15fb0:	vmovupd %zmm5,-0x340(%rax)
   15fb7:	vmovapd 0x300(%rsp),%zmm5
   15fbf:	vmovupd %zmm6,-0x300(%rax)
   15fc6:	vmovapd 0x340(%rsp),%zmm6
   15fce:	vmovupd %zmm7,-0x2c0(%rax)
   15fd5:	vmovapd 0x380(%rsp),%zmm7
   15fdd:	vmovupd %zmm2,-0x280(%rax)
   15fe4:	vmovapd 0x3c0(%rsp),%zmm2
   15fec:	vmovupd %zmm3,-0x240(%rax)
   15ff3:	vmovapd 0x400(%rsp),%zmm3
   15ffb:	vmovupd %zmm4,-0x200(%rax)
   16002:	vmovapd 0x440(%rsp),%zmm4
   1600a:	vmovupd %zmm5,-0x1c0(%rax)
   16011:	vmovapd 0x480(%rsp),%zmm5
   16019:	vmovupd %zmm6,-0x180(%rax)
   16020:	vmovupd %zmm7,-0x140(%rax)
   16027:	vmovupd %zmm2,-0x100(%rax)
   1602e:	vmovupd %zmm3,-0xc0(%rax)
   16035:	vmovupd %zmm4,-0x80(%rax)
   1603c:	vmovupd %zmm5,-0x40(%rax)
   16043:	cmp    %rcx,%rsi
   16046:	jne    15c30 <hf0_g52_nat+0x80>
   1604c:	vzeroupper
   1604f:	mov    0x4f8(%rsp),%rax
   16057:	sub    %fs:0x28,%rax
   16060:	jne    16064 <hf0_g52_nat+0x4b4>
   16062:	leave
   16063:	ret
   16064:	call   4280 <__stack_chk_fail@plt>
   16069:	nopl   0x0(%rax)

0000000000016d40 <hf2_tb16_nat>:
   16d40:	endbr64
   16d44:	push   %rbp
   16d45:	mov    %rsp,%rbp
   16d48:	and    $0xffffffffffffffc0,%rsp
   16d4c:	sub    $0x440,%rsp
   16d53:	vbroadcastsd 0x46263(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   16d5d:	mov    %fs:0x28,%rcx
   16d66:	mov    %rcx,0x438(%rsp)
   16d6e:	xor    %ecx,%ecx
   16d70:	test   %rsi,%rsi
   16d73:	je     172eb <hf2_tb16_nat+0x5ab>
   16d79:	mov    %rsi,%rdx
   16d7c:	mov    %rdi,%rax
   16d7f:	vmovdqa64 0x460b7(%rip),%zmm22        # 5ce40 <_IO_stdin_used+0xe40>
   16d89:	vmovdqa64 0x460ed(%rip),%zmm21        # 5ce80 <_IO_stdin_used+0xe80>
   16d93:	sub    $0x1,%rdx
   16d97:	mov    $0xffffffaa,%ecx
   16d9c:	mov    %rsp,%rdi
   16d9f:	vmovdqa64 0x46117(%rip),%zmm20        # 5cec0 <_IO_stdin_used+0xec0>
   16da9:	mov    %rdx,%rsi
   16dac:	xor    %edx,%edx
   16dae:	kmovw  %ecx,%k3
   16db2:	shr    $0x7,%rsi
   16db6:	cs nopw 0x0(%rax,%rax,1)
   16dc0:	vpermpd (%rax),%zmm22,%zmm0
   16dc6:	vaddpd (%rax),%zmm0,%zmm1
   16dcc:	mov    $0xffffffcc,%ecx
   16dd1:	vsubpd (%rax),%zmm0,%zmm1{%k3}
   16dd7:	kmovw  %ecx,%k2
   16ddb:	mov    $0xfffffff0,%ecx
   16de0:	kmovw  %ecx,%k1
   16de4:	mov    %rdx,%rcx
   16de7:	vpermpd %zmm1,%zmm21,%zmm2
   16ded:	vaddpd %zmm2,%zmm1,%zmm0
   16df3:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   16df9:	vpermpd %zmm0,%zmm20,%zmm2
   16dff:	vaddpd %zmm2,%zmm0,%zmm1
   16e05:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   16e0b:	vpermpd 0x40(%rax),%zmm22,%zmm0
   16e12:	vmovapd %zmm1,(%rsp)
   16e19:	vaddpd 0x40(%rax),%zmm0,%zmm1
   16e20:	vsubpd 0x40(%rax),%zmm0,%zmm1{%k3}
   16e27:	vpermpd %zmm1,%zmm21,%zmm2
   16e2d:	vaddpd %zmm2,%zmm1,%zmm0
   16e33:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   16e39:	vpermpd %zmm0,%zmm20,%zmm2
   16e3f:	vaddpd %zmm2,%zmm0,%zmm1
   16e45:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   16e4b:	vpermpd 0x80(%rax),%zmm22,%zmm0
   16e52:	vmovapd %zmm1,0x40(%rsp)
   16e5a:	vaddpd 0x80(%rax),%zmm0,%zmm1
   16e61:	vsubpd 0x80(%rax),%zmm0,%zmm1{%k3}
   16e68:	vpermpd %zmm1,%zmm21,%zmm2
   16e6e:	vaddpd %zmm2,%zmm1,%zmm0
   16e74:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   16e7a:	vpermpd %zmm0,%zmm20,%zmm2
   16e80:	vaddpd %zmm2,%zmm0,%zmm1
   16e86:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   16e8c:	vpermpd 0xc0(%rax),%zmm22,%zmm0
   16e93:	vmovapd %zmm1,0x80(%rsp)
   16e9b:	vaddpd 0xc0(%rax),%zmm0,%zmm1
   16ea2:	vsubpd 0xc0(%rax),%zmm0,%zmm1{%k3}
   16ea9:	vpermpd %zmm1,%zmm21,%zmm2
   16eaf:	vaddpd %zmm2,%zmm1,%zmm0
   16eb5:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   16ebb:	vpermpd %zmm0,%zmm20,%zmm2
   16ec1:	vaddpd %zmm2,%zmm0,%zmm1
   16ec7:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   16ecd:	vpermpd 0x100(%rax),%zmm22,%zmm0
   16ed4:	vmovapd %zmm1,0xc0(%rsp)
   16edc:	vaddpd 0x100(%rax),%zmm0,%zmm1
   16ee3:	vsubpd 0x100(%rax),%zmm0,%zmm1{%k3}
   16eea:	vpermpd %zmm1,%zmm21,%zmm2
   16ef0:	vaddpd %zmm2,%zmm1,%zmm0
   16ef6:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   16efc:	vpermpd %zmm0,%zmm20,%zmm2
   16f02:	vaddpd %zmm2,%zmm0,%zmm1
   16f08:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   16f0e:	vpermpd 0x140(%rax),%zmm22,%zmm0
   16f15:	vmovapd %zmm1,0x100(%rsp)
   16f1d:	vaddpd 0x140(%rax),%zmm0,%zmm1
   16f24:	vsubpd 0x140(%rax),%zmm0,%zmm1{%k3}
   16f2b:	vpermpd %zmm1,%zmm21,%zmm2
   16f31:	vaddpd %zmm2,%zmm1,%zmm0
   16f37:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   16f3d:	vpermpd %zmm0,%zmm20,%zmm2
   16f43:	vaddpd %zmm2,%zmm0,%zmm1
   16f49:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   16f4f:	vpermpd 0x180(%rax),%zmm22,%zmm0
   16f56:	vmovapd %zmm1,0x140(%rsp)
   16f5e:	vaddpd 0x180(%rax),%zmm0,%zmm1
   16f65:	vsubpd 0x180(%rax),%zmm0,%zmm1{%k3}
   16f6c:	vpermpd %zmm1,%zmm21,%zmm2
   16f72:	vaddpd %zmm2,%zmm1,%zmm0
   16f78:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   16f7e:	vpermpd %zmm0,%zmm20,%zmm2
   16f84:	vaddpd %zmm2,%zmm0,%zmm1
   16f8a:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   16f90:	vpermpd 0x1c0(%rax),%zmm22,%zmm0
   16f97:	vmovapd %zmm1,0x180(%rsp)
   16f9f:	vaddpd 0x1c0(%rax),%zmm0,%zmm1
   16fa6:	vsubpd 0x1c0(%rax),%zmm0,%zmm1{%k3}
   16fad:	vpermpd %zmm1,%zmm21,%zmm2
   16fb3:	vaddpd %zmm2,%zmm1,%zmm0
   16fb9:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   16fbf:	vpermpd %zmm0,%zmm20,%zmm2
   16fc5:	vaddpd %zmm2,%zmm0,%zmm1
   16fcb:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   16fd1:	vmovapd %zmm1,0x1c0(%rsp)
   16fd9:	vpermpd 0x200(%rax),%zmm22,%zmm0
   16fe0:	vaddpd 0x200(%rax),%zmm0,%zmm1
   16fe7:	vsubpd 0x200(%rax),%zmm0,%zmm1{%k3}
   16fee:	vpermpd %zmm1,%zmm21,%zmm2
   16ff4:	vaddpd %zmm2,%zmm1,%zmm0
   16ffa:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   17000:	vpermpd %zmm0,%zmm20,%zmm2
   17006:	vaddpd %zmm2,%zmm0,%zmm1
   1700c:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   17012:	vpermpd 0x240(%rax),%zmm22,%zmm0
   17019:	vmovapd %zmm1,0x200(%rsp)
   17021:	vaddpd 0x240(%rax),%zmm0,%zmm1
   17028:	vsubpd 0x240(%rax),%zmm0,%zmm1{%k3}
   1702f:	vpermpd %zmm1,%zmm21,%zmm2
   17035:	vaddpd %zmm2,%zmm1,%zmm0
   1703b:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   17041:	vpermpd %zmm0,%zmm20,%zmm2
   17047:	vaddpd %zmm2,%zmm0,%zmm1
   1704d:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   17053:	vpermpd 0x280(%rax),%zmm22,%zmm0
   1705a:	vmovapd %zmm1,0x240(%rsp)
   17062:	vaddpd 0x280(%rax),%zmm0,%zmm1
   17069:	vsubpd 0x280(%rax),%zmm0,%zmm1{%k3}
   17070:	vpermpd %zmm1,%zmm21,%zmm2
   17076:	vaddpd %zmm2,%zmm1,%zmm0
   1707c:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   17082:	vpermpd %zmm0,%zmm20,%zmm2
   17088:	vaddpd %zmm2,%zmm0,%zmm1
   1708e:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   17094:	vpermpd 0x2c0(%rax),%zmm22,%zmm0
   1709b:	vmovapd %zmm1,0x280(%rsp)
   170a3:	vaddpd 0x2c0(%rax),%zmm0,%zmm1
   170aa:	vsubpd 0x2c0(%rax),%zmm0,%zmm1{%k3}
   170b1:	vpermpd %zmm1,%zmm21,%zmm2
   170b7:	vaddpd %zmm2,%zmm1,%zmm0
   170bd:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   170c3:	vpermpd %zmm0,%zmm20,%zmm2
   170c9:	vaddpd %zmm2,%zmm0,%zmm1
   170cf:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   170d5:	vpermpd 0x300(%rax),%zmm22,%zmm0
   170dc:	vmovapd %zmm1,0x2c0(%rsp)
   170e4:	vaddpd 0x300(%rax),%zmm0,%zmm1
   170eb:	vsubpd 0x300(%rax),%zmm0,%zmm1{%k3}
   170f2:	vpermpd %zmm1,%zmm21,%zmm2
   170f8:	vaddpd %zmm2,%zmm1,%zmm0
   170fe:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   17104:	vpermpd %zmm0,%zmm20,%zmm2
   1710a:	vaddpd %zmm2,%zmm0,%zmm1
   17110:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   17116:	vpermpd 0x340(%rax),%zmm22,%zmm0
   1711d:	vmovapd %zmm1,0x300(%rsp)
   17125:	vaddpd 0x340(%rax),%zmm0,%zmm1
   1712c:	vsubpd 0x340(%rax),%zmm0,%zmm1{%k3}
   17133:	vpermpd %zmm1,%zmm21,%zmm2
   17139:	vaddpd %zmm2,%zmm1,%zmm0
   1713f:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   17145:	vpermpd %zmm0,%zmm20,%zmm2
   1714b:	vaddpd %zmm2,%zmm0,%zmm1
   17151:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   17157:	vpermpd 0x380(%rax),%zmm22,%zmm0
   1715e:	vmovapd %zmm1,0x340(%rsp)
   17166:	vaddpd 0x380(%rax),%zmm0,%zmm1
   1716d:	vsubpd 0x380(%rax),%zmm0,%zmm1{%k3}
   17174:	vpermpd %zmm1,%zmm21,%zmm2
   1717a:	vaddpd %zmm2,%zmm1,%zmm0
   17180:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   17186:	vpermpd %zmm0,%zmm20,%zmm2
   1718c:	vaddpd %zmm2,%zmm0,%zmm1
   17192:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   17198:	vpermpd 0x3c0(%rax),%zmm22,%zmm0
   1719f:	vmovapd %zmm1,0x380(%rsp)
   171a7:	vaddpd 0x3c0(%rax),%zmm0,%zmm1
   171ae:	vsubpd 0x3c0(%rax),%zmm0,%zmm1{%k3}
   171b5:	vpermpd %zmm1,%zmm21,%zmm2
   171bb:	vaddpd %zmm2,%zmm1,%zmm0
   171c1:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   171c7:	vpermpd %zmm0,%zmm20,%zmm2
   171cd:	vaddpd %zmm2,%zmm0,%zmm1
   171d3:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
   171d9:	vmovapd %zmm1,0x3c0(%rsp)
   171e1:	vzeroupper
   171e4:	call   16af0 <tb16_nat.constprop.0>
   171e9:	vmovapd (%rsp),%zmm3
   171f0:	vmovapd 0x40(%rsp),%zmm4
   171f8:	vmovapd 0x80(%rsp),%zmm5
   17200:	add    $0x1,%rdx
   17204:	add    $0x400,%rax
   1720a:	vmovapd 0xc0(%rsp),%zmm6
   17212:	vmovapd 0x100(%rsp),%zmm7
   1721a:	vmovupd %zmm3,-0x400(%rax)
   17221:	vmovapd 0x140(%rsp),%zmm3
   17229:	vmovupd %zmm4,-0x3c0(%rax)
   17230:	vmovapd 0x180(%rsp),%zmm4
   17238:	vmovupd %zmm5,-0x380(%rax)
   1723f:	vmovapd 0x1c0(%rsp),%zmm5
   17247:	vmovupd %zmm6,-0x340(%rax)
   1724e:	vmovapd 0x200(%rsp),%zmm6
   17256:	vmovupd %zmm7,-0x300(%rax)
   1725d:	vmovapd 0x240(%rsp),%zmm7
   17265:	vmovupd %zmm3,-0x2c0(%rax)
   1726c:	vmovapd 0x280(%rsp),%zmm3
   17274:	vmovupd %zmm4,-0x280(%rax)
   1727b:	vmovapd 0x2c0(%rsp),%zmm4
   17283:	vmovupd %zmm5,-0x240(%rax)
   1728a:	vmovapd 0x300(%rsp),%zmm5
   17292:	vmovupd %zmm6,-0x200(%rax)
   17299:	vmovapd 0x340(%rsp),%zmm6
   172a1:	vmovupd %zmm7,-0x1c0(%rax)
   172a8:	vmovapd 0x380(%rsp),%zmm7
   172b0:	vmovupd %zmm3,-0x180(%rax)
   172b7:	vmovapd 0x3c0(%rsp),%zmm3
   172bf:	vmovupd %zmm4,-0x140(%rax)
   172c6:	vmovupd %zmm5,-0x100(%rax)
   172cd:	vmovupd %zmm6,-0xc0(%rax)
   172d4:	vmovupd %zmm7,-0x80(%rax)
   172db:	vmovupd %zmm3,-0x40(%rax)
   172e2:	cmp    %rsi,%rcx
   172e5:	jne    16dc0 <hf2_tb16_nat+0x80>
   172eb:	mov    0x438(%rsp),%rax
   172f3:	sub    %fs:0x28,%rax
   172fc:	jne    17303 <hf2_tb16_nat+0x5c3>
   172fe:	vzeroupper
   17301:	leave
   17302:	ret
   17303:	vzeroupper
   17306:	call   4280 <__stack_chk_fail@plt>
   1730b:	nopl   0x0(%rax,%rax,1)

0000000000017310 <hf1_tb16_nat>:
   17310:	endbr64
   17314:	push   %rbp
   17315:	mov    %rdi,%rdx
   17318:	mov    %rsp,%rbp
   1731b:	and    $0xffffffffffffffc0,%rsp
   1731f:	sub    $0x500,%rsp
   17326:	vbroadcastsd 0x45c90(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   17330:	mov    %fs:0x28,%rax
   17339:	mov    %rax,0x4f8(%rsp)
   17341:	xor    %eax,%eax
   17343:	mov    %rsp,%rdi
   17346:	vzeroupper
   17349:	call   df20 <inl_consts.constprop.0>
   1734e:	vmovapd (%rsp),%zmm22
   17355:	vmovapd 0x40(%rsp),%zmm21
   1735d:	vmovapd 0x80(%rsp),%zmm20
   17365:	test   %rsi,%rsi
   17368:	je     178cf <hf1_tb16_nat+0x5bf>
   1736e:	mov    %rsi,%rcx
   17371:	mov    %rdx,%rax
   17374:	lea    0xc0(%rsp),%rdi
   1737c:	xor    %edx,%edx
   1737e:	sub    $0x1,%rcx
   17382:	mov    %rcx,%rsi
   17385:	shr    $0x7,%rsi
   17389:	nopl   0x0(%rax)
   17390:	vpxord (%rax),%zmm22,%zmm1
   17396:	vpermilpd $0x55,(%rax),%zmm0
   1739d:	mov    %rdx,%rcx
   173a0:	vaddpd %zmm1,%zmm0,%zmm0
   173a6:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   173ad:	vpxord %zmm0,%zmm21,%zmm0
   173b3:	vaddpd %zmm0,%zmm1,%zmm0
   173b9:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   173c0:	vpxord %zmm0,%zmm20,%zmm0
   173c6:	vaddpd %zmm0,%zmm1,%zmm0
   173cc:	vpxord 0x40(%rax),%zmm22,%zmm1
   173d3:	vmovapd %zmm0,0xc0(%rsp)
   173db:	vpermilpd $0x55,0x40(%rax),%zmm0
   173e3:	vaddpd %zmm1,%zmm0,%zmm0
   173e9:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   173f0:	vpxord %zmm0,%zmm21,%zmm0
   173f6:	vaddpd %zmm0,%zmm1,%zmm0
   173fc:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17403:	vpxord %zmm0,%zmm20,%zmm0
   17409:	vaddpd %zmm0,%zmm1,%zmm0
   1740f:	vpxord 0x80(%rax),%zmm22,%zmm1
   17416:	vmovapd %zmm0,0x100(%rsp)
   1741e:	vpermilpd $0x55,0x80(%rax),%zmm0
   17426:	vaddpd %zmm1,%zmm0,%zmm0
   1742c:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17433:	vpxord %zmm0,%zmm21,%zmm0
   17439:	vaddpd %zmm0,%zmm1,%zmm0
   1743f:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17446:	vpxord %zmm0,%zmm20,%zmm0
   1744c:	vaddpd %zmm0,%zmm1,%zmm0
   17452:	vpxord 0xc0(%rax),%zmm22,%zmm1
   17459:	vmovapd %zmm0,0x140(%rsp)
   17461:	vpermilpd $0x55,0xc0(%rax),%zmm0
   17469:	vaddpd %zmm1,%zmm0,%zmm0
   1746f:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17476:	vpxord %zmm0,%zmm21,%zmm0
   1747c:	vaddpd %zmm0,%zmm1,%zmm0
   17482:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17489:	vpxord %zmm0,%zmm20,%zmm0
   1748f:	vaddpd %zmm0,%zmm1,%zmm0
   17495:	vpxord 0x100(%rax),%zmm22,%zmm1
   1749c:	vmovapd %zmm0,0x180(%rsp)
   174a4:	vpermilpd $0x55,0x100(%rax),%zmm0
   174ac:	vaddpd %zmm1,%zmm0,%zmm0
   174b2:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   174b9:	vpxord %zmm0,%zmm21,%zmm0
   174bf:	vaddpd %zmm0,%zmm1,%zmm0
   174c5:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   174cc:	vpxord %zmm0,%zmm20,%zmm0
   174d2:	vaddpd %zmm0,%zmm1,%zmm0
   174d8:	vpxord 0x140(%rax),%zmm22,%zmm1
   174df:	vmovapd %zmm0,0x1c0(%rsp)
   174e7:	vpermilpd $0x55,0x140(%rax),%zmm0
   174ef:	vaddpd %zmm1,%zmm0,%zmm0
   174f5:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   174fc:	vpxord %zmm0,%zmm21,%zmm0
   17502:	vaddpd %zmm0,%zmm1,%zmm0
   17508:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   1750f:	vpxord %zmm0,%zmm20,%zmm0
   17515:	vaddpd %zmm0,%zmm1,%zmm0
   1751b:	vpxord 0x180(%rax),%zmm22,%zmm1
   17522:	vmovapd %zmm0,0x200(%rsp)
   1752a:	vpermilpd $0x55,0x180(%rax),%zmm0
   17532:	vaddpd %zmm1,%zmm0,%zmm0
   17538:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   1753f:	vpxord %zmm0,%zmm21,%zmm0
   17545:	vaddpd %zmm0,%zmm1,%zmm0
   1754b:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17552:	vpxord %zmm0,%zmm20,%zmm0
   17558:	vaddpd %zmm0,%zmm1,%zmm0
   1755e:	vpxord 0x1c0(%rax),%zmm22,%zmm1
   17565:	vmovapd %zmm0,0x240(%rsp)
   1756d:	vpermilpd $0x55,0x1c0(%rax),%zmm0
   17575:	vaddpd %zmm1,%zmm0,%zmm0
   1757b:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17582:	vpxord %zmm0,%zmm21,%zmm0
   17588:	vaddpd %zmm0,%zmm1,%zmm0
   1758e:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17595:	vpxord %zmm0,%zmm20,%zmm0
   1759b:	vaddpd %zmm0,%zmm1,%zmm0
   175a1:	vpxord 0x200(%rax),%zmm22,%zmm1
   175a8:	vmovapd %zmm0,0x280(%rsp)
   175b0:	vpermilpd $0x55,0x200(%rax),%zmm0
   175b8:	vaddpd %zmm1,%zmm0,%zmm0
   175be:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   175c5:	vpxord %zmm0,%zmm21,%zmm0
   175cb:	vaddpd %zmm0,%zmm1,%zmm0
   175d1:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   175d8:	vpxord %zmm0,%zmm20,%zmm0
   175de:	vaddpd %zmm0,%zmm1,%zmm0
   175e4:	vpxord 0x240(%rax),%zmm22,%zmm1
   175eb:	vmovapd %zmm0,0x2c0(%rsp)
   175f3:	vpermilpd $0x55,0x240(%rax),%zmm0
   175fb:	vaddpd %zmm1,%zmm0,%zmm0
   17601:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17608:	vpxord %zmm0,%zmm21,%zmm0
   1760e:	vaddpd %zmm0,%zmm1,%zmm0
   17614:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   1761b:	vpxord %zmm0,%zmm20,%zmm0
   17621:	vaddpd %zmm0,%zmm1,%zmm0
   17627:	vpxord 0x280(%rax),%zmm22,%zmm1
   1762e:	vmovapd %zmm0,0x300(%rsp)
   17636:	vpermilpd $0x55,0x280(%rax),%zmm0
   1763e:	vaddpd %zmm1,%zmm0,%zmm0
   17644:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   1764b:	vpxord %zmm0,%zmm21,%zmm0
   17651:	vaddpd %zmm0,%zmm1,%zmm0
   17657:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   1765e:	vpxord %zmm0,%zmm20,%zmm0
   17664:	vaddpd %zmm0,%zmm1,%zmm0
   1766a:	vmovapd %zmm0,0x340(%rsp)
   17672:	vpxord 0x2c0(%rax),%zmm22,%zmm1
   17679:	vpermilpd $0x55,0x2c0(%rax),%zmm0
   17681:	vaddpd %zmm1,%zmm0,%zmm0
   17687:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   1768e:	vpxord %zmm0,%zmm21,%zmm0
   17694:	vaddpd %zmm0,%zmm1,%zmm0
   1769a:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   176a1:	vpxord %zmm0,%zmm20,%zmm0
   176a7:	vaddpd %zmm0,%zmm1,%zmm0
   176ad:	vpxord 0x300(%rax),%zmm22,%zmm1
   176b4:	vmovapd %zmm0,0x380(%rsp)
   176bc:	vpermilpd $0x55,0x300(%rax),%zmm0
   176c4:	vaddpd %zmm1,%zmm0,%zmm0
   176ca:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   176d1:	vpxord %zmm0,%zmm21,%zmm0
   176d7:	vaddpd %zmm0,%zmm1,%zmm0
   176dd:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   176e4:	vpxord %zmm0,%zmm20,%zmm0
   176ea:	vaddpd %zmm0,%zmm1,%zmm0
   176f0:	vpxord 0x340(%rax),%zmm22,%zmm1
   176f7:	vmovapd %zmm0,0x3c0(%rsp)
   176ff:	vpermilpd $0x55,0x340(%rax),%zmm0
   17707:	vaddpd %zmm1,%zmm0,%zmm0
   1770d:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17714:	vpxord %zmm0,%zmm21,%zmm0
   1771a:	vaddpd %zmm0,%zmm1,%zmm0
   17720:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17727:	vpxord %zmm0,%zmm20,%zmm0
   1772d:	vaddpd %zmm0,%zmm1,%zmm0
   17733:	vpxord 0x380(%rax),%zmm22,%zmm1
   1773a:	vmovapd %zmm0,0x400(%rsp)
   17742:	vpermilpd $0x55,0x380(%rax),%zmm0
   1774a:	vaddpd %zmm1,%zmm0,%zmm0
   17750:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17757:	vpxord %zmm0,%zmm21,%zmm0
   1775d:	vaddpd %zmm0,%zmm1,%zmm0
   17763:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   1776a:	vpxord %zmm0,%zmm20,%zmm0
   17770:	vaddpd %zmm0,%zmm1,%zmm0
   17776:	vpxord 0x3c0(%rax),%zmm22,%zmm1
   1777d:	vmovapd %zmm0,0x440(%rsp)
   17785:	vpermilpd $0x55,0x3c0(%rax),%zmm0
   1778d:	vaddpd %zmm1,%zmm0,%zmm0
   17793:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   1779a:	vpxord %zmm0,%zmm21,%zmm0
   177a0:	vaddpd %zmm0,%zmm1,%zmm0
   177a6:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   177ad:	vpxord %zmm0,%zmm20,%zmm0
   177b3:	vaddpd %zmm0,%zmm1,%zmm0
   177b9:	vmovapd %zmm0,0x480(%rsp)
   177c1:	vzeroupper
   177c4:	call   16af0 <tb16_nat.constprop.0>
   177c9:	add    $0x1,%rdx
   177cd:	vmovapd 0xc0(%rsp),%zmm2
   177d5:	vmovapd 0x100(%rsp),%zmm3
   177dd:	vmovapd 0x140(%rsp),%zmm4
   177e5:	add    $0x400,%rax
   177eb:	vmovapd 0x180(%rsp),%zmm5
   177f3:	vmovapd 0x1c0(%rsp),%zmm6
   177fb:	vmovupd %zmm2,-0x400(%rax)
   17802:	vmovapd 0x200(%rsp),%zmm7
   1780a:	vmovapd 0x240(%rsp),%zmm2
   17812:	vmovupd %zmm3,-0x3c0(%rax)
   17819:	vmovupd %zmm4,-0x380(%rax)
   17820:	vmovapd 0x280(%rsp),%zmm3
   17828:	vmovapd 0x2c0(%rsp),%zmm4
   17830:	vmovupd %zmm5,-0x340(%rax)
   17837:	vmovapd 0x300(%rsp),%zmm5
   1783f:	vmovupd %zmm6,-0x300(%rax)
   17846:	vmovapd 0x340(%rsp),%zmm6
   1784e:	vmovupd %zmm7,-0x2c0(%rax)
   17855:	vmovapd 0x380(%rsp),%zmm7
   1785d:	vmovupd %zmm2,-0x280(%rax)
   17864:	vmovapd 0x3c0(%rsp),%zmm2
   1786c:	vmovupd %zmm3,-0x240(%rax)
   17873:	vmovapd 0x400(%rsp),%zmm3
   1787b:	vmovupd %zmm4,-0x200(%rax)
   17882:	vmovapd 0x440(%rsp),%zmm4
   1788a:	vmovupd %zmm5,-0x1c0(%rax)
   17891:	vmovapd 0x480(%rsp),%zmm5
   17899:	vmovupd %zmm6,-0x180(%rax)
   178a0:	vmovupd %zmm7,-0x140(%rax)
   178a7:	vmovupd %zmm2,-0x100(%rax)
   178ae:	vmovupd %zmm3,-0xc0(%rax)
   178b5:	vmovupd %zmm4,-0x80(%rax)
   178bc:	vmovupd %zmm5,-0x40(%rax)
   178c3:	cmp    %rcx,%rsi
   178c6:	jne    17390 <hf1_tb16_nat+0x80>
   178cc:	vzeroupper
   178cf:	mov    0x4f8(%rsp),%rax
   178d7:	sub    %fs:0x28,%rax
   178e0:	jne    178e4 <hf1_tb16_nat+0x5d4>
   178e2:	leave
   178e3:	ret
   178e4:	call   4280 <__stack_chk_fail@plt>
   178e9:	nopl   0x0(%rax)

00000000000178f0 <hf0_tb16_nat>:
   178f0:	endbr64
   178f4:	push   %rbp
   178f5:	mov    %rdi,%rdx
   178f8:	mov    %rsp,%rbp
   178fb:	and    $0xffffffffffffffc0,%rsp
   178ff:	sub    $0x500,%rsp
   17906:	vbroadcastsd 0x456b0(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   17910:	mov    %fs:0x28,%rax
   17919:	mov    %rax,0x4f8(%rsp)
   17921:	xor    %eax,%eax
   17923:	mov    %rsp,%rdi
   17926:	vzeroupper
   17929:	call   ea60 <inl_consts.constprop.1>
   1792e:	vmovapd (%rsp),%zmm20
   17935:	vmovapd 0x40(%rsp),%zmm21
   1793d:	vmovapd 0x80(%rsp),%zmm22
   17945:	test   %rsi,%rsi
   17948:	je     17d8f <hf0_tb16_nat+0x49f>
   1794e:	mov    %rsi,%rcx
   17951:	mov    %rdx,%rax
   17954:	lea    0xc0(%rsp),%rdi
   1795c:	xor    %edx,%edx
   1795e:	sub    $0x1,%rcx
   17962:	mov    %rcx,%rsi
   17965:	shr    $0x7,%rsi
   17969:	nopl   0x0(%rax)
   17970:	vpermilpd $0x55,(%rax),%zmm0
   17977:	vfmadd231pd (%rax),%zmm20,%zmm0
   1797d:	mov    %rdx,%rcx
   17980:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17987:	vfmadd132pd %zmm21,%zmm1,%zmm0
   1798d:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17994:	vfmadd132pd %zmm22,%zmm1,%zmm0
   1799a:	vmovapd %zmm0,0xc0(%rsp)
   179a2:	vpermilpd $0x55,0x40(%rax),%zmm0
   179aa:	vfmadd231pd 0x40(%rax),%zmm20,%zmm0
   179b1:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   179b8:	vfmadd132pd %zmm21,%zmm1,%zmm0
   179be:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   179c5:	vfmadd132pd %zmm22,%zmm1,%zmm0
   179cb:	vmovapd %zmm0,0x100(%rsp)
   179d3:	vpermilpd $0x55,0x80(%rax),%zmm0
   179db:	vfmadd231pd 0x80(%rax),%zmm20,%zmm0
   179e2:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   179e9:	vfmadd132pd %zmm21,%zmm1,%zmm0
   179ef:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   179f6:	vfmadd132pd %zmm22,%zmm1,%zmm0
   179fc:	vmovapd %zmm0,0x140(%rsp)
   17a04:	vpermilpd $0x55,0xc0(%rax),%zmm0
   17a0c:	vfmadd231pd 0xc0(%rax),%zmm20,%zmm0
   17a13:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17a1a:	vfmadd132pd %zmm21,%zmm1,%zmm0
   17a20:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17a27:	vfmadd132pd %zmm22,%zmm1,%zmm0
   17a2d:	vmovapd %zmm0,0x180(%rsp)
   17a35:	vpermilpd $0x55,0x100(%rax),%zmm0
   17a3d:	vfmadd231pd 0x100(%rax),%zmm20,%zmm0
   17a44:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17a4b:	vfmadd132pd %zmm21,%zmm1,%zmm0
   17a51:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17a58:	vfmadd132pd %zmm22,%zmm1,%zmm0
   17a5e:	vmovapd %zmm0,0x1c0(%rsp)
   17a66:	vpermilpd $0x55,0x140(%rax),%zmm0
   17a6e:	vfmadd231pd 0x140(%rax),%zmm20,%zmm0
   17a75:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17a7c:	vfmadd132pd %zmm21,%zmm1,%zmm0
   17a82:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17a89:	vfmadd132pd %zmm22,%zmm1,%zmm0
   17a8f:	vmovapd %zmm0,0x200(%rsp)
   17a97:	vpermilpd $0x55,0x180(%rax),%zmm0
   17a9f:	vfmadd231pd 0x180(%rax),%zmm20,%zmm0
   17aa6:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17aad:	vfmadd132pd %zmm21,%zmm1,%zmm0
   17ab3:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17aba:	vfmadd132pd %zmm22,%zmm1,%zmm0
   17ac0:	vmovapd %zmm0,0x240(%rsp)
   17ac8:	vpermilpd $0x55,0x1c0(%rax),%zmm0
   17ad0:	vfmadd231pd 0x1c0(%rax),%zmm20,%zmm0
   17ad7:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17ade:	vfmadd132pd %zmm21,%zmm1,%zmm0
   17ae4:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17aeb:	vfmadd132pd %zmm22,%zmm1,%zmm0
   17af1:	vmovapd %zmm0,0x280(%rsp)
   17af9:	vpermilpd $0x55,0x200(%rax),%zmm0
   17b01:	vfmadd231pd 0x200(%rax),%zmm20,%zmm0
   17b08:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17b0f:	vfmadd132pd %zmm21,%zmm1,%zmm0
   17b15:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17b1c:	vfmadd132pd %zmm22,%zmm1,%zmm0
   17b22:	vmovapd %zmm0,0x2c0(%rsp)
   17b2a:	vpermilpd $0x55,0x240(%rax),%zmm0
   17b32:	vfmadd231pd 0x240(%rax),%zmm20,%zmm0
   17b39:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17b40:	vfmadd132pd %zmm21,%zmm1,%zmm0
   17b46:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17b4d:	vfmadd132pd %zmm22,%zmm1,%zmm0
   17b53:	vmovapd %zmm0,0x300(%rsp)
   17b5b:	vpermilpd $0x55,0x280(%rax),%zmm0
   17b63:	vfmadd231pd 0x280(%rax),%zmm20,%zmm0
   17b6a:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17b71:	vfmadd132pd %zmm21,%zmm1,%zmm0
   17b77:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17b7e:	vfmadd132pd %zmm22,%zmm1,%zmm0
   17b84:	vmovapd %zmm0,0x340(%rsp)
   17b8c:	vpermilpd $0x55,0x2c0(%rax),%zmm0
   17b94:	vfmadd231pd 0x2c0(%rax),%zmm20,%zmm0
   17b9b:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17ba2:	vfmadd132pd %zmm21,%zmm1,%zmm0
   17ba8:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17baf:	vfmadd132pd %zmm22,%zmm1,%zmm0
   17bb5:	vmovapd %zmm0,0x380(%rsp)
   17bbd:	vpermilpd $0x55,0x300(%rax),%zmm0
   17bc5:	vfmadd231pd 0x300(%rax),%zmm20,%zmm0
   17bcc:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17bd3:	vfmadd132pd %zmm21,%zmm1,%zmm0
   17bd9:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17be0:	vfmadd132pd %zmm22,%zmm1,%zmm0
   17be6:	vmovapd %zmm0,0x3c0(%rsp)
   17bee:	vpermilpd $0x55,0x340(%rax),%zmm0
   17bf6:	vfmadd231pd 0x340(%rax),%zmm20,%zmm0
   17bfd:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17c04:	vfmadd132pd %zmm21,%zmm1,%zmm0
   17c0a:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17c11:	vfmadd132pd %zmm22,%zmm1,%zmm0
   17c17:	vmovapd %zmm0,0x400(%rsp)
   17c1f:	vpermilpd $0x55,0x380(%rax),%zmm0
   17c27:	vfmadd231pd 0x380(%rax),%zmm20,%zmm0
   17c2e:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17c35:	vfmadd132pd %zmm21,%zmm1,%zmm0
   17c3b:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17c42:	vfmadd132pd %zmm22,%zmm1,%zmm0
   17c48:	vmovapd %zmm0,0x440(%rsp)
   17c50:	vpermilpd $0x55,0x3c0(%rax),%zmm0
   17c58:	vfmadd231pd 0x3c0(%rax),%zmm20,%zmm0
   17c5f:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   17c66:	vfmadd132pd %zmm21,%zmm1,%zmm0
   17c6c:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   17c73:	vfmadd132pd %zmm22,%zmm1,%zmm0
   17c79:	vmovapd %zmm0,0x480(%rsp)
   17c81:	vzeroupper
   17c84:	call   16af0 <tb16_nat.constprop.0>
   17c89:	add    $0x1,%rdx
   17c8d:	vmovapd 0xc0(%rsp),%zmm2
   17c95:	vmovapd 0x100(%rsp),%zmm3
   17c9d:	vmovapd 0x140(%rsp),%zmm4
   17ca5:	add    $0x400,%rax
   17cab:	vmovapd 0x180(%rsp),%zmm5
   17cb3:	vmovapd 0x1c0(%rsp),%zmm6
   17cbb:	vmovupd %zmm2,-0x400(%rax)
   17cc2:	vmovapd 0x200(%rsp),%zmm7
   17cca:	vmovapd 0x240(%rsp),%zmm2
   17cd2:	vmovupd %zmm3,-0x3c0(%rax)
   17cd9:	vmovupd %zmm4,-0x380(%rax)
   17ce0:	vmovapd 0x280(%rsp),%zmm3
   17ce8:	vmovapd 0x2c0(%rsp),%zmm4
   17cf0:	vmovupd %zmm5,-0x340(%rax)
   17cf7:	vmovapd 0x300(%rsp),%zmm5
   17cff:	vmovupd %zmm6,-0x300(%rax)
   17d06:	vmovapd 0x340(%rsp),%zmm6
   17d0e:	vmovupd %zmm7,-0x2c0(%rax)
   17d15:	vmovapd 0x380(%rsp),%zmm7
   17d1d:	vmovupd %zmm2,-0x280(%rax)
   17d24:	vmovapd 0x3c0(%rsp),%zmm2
   17d2c:	vmovupd %zmm3,-0x240(%rax)
   17d33:	vmovapd 0x400(%rsp),%zmm3
   17d3b:	vmovupd %zmm4,-0x200(%rax)
   17d42:	vmovapd 0x440(%rsp),%zmm4
   17d4a:	vmovupd %zmm5,-0x1c0(%rax)
   17d51:	vmovapd 0x480(%rsp),%zmm5
   17d59:	vmovupd %zmm6,-0x180(%rax)
   17d60:	vmovupd %zmm7,-0x140(%rax)
   17d67:	vmovupd %zmm2,-0x100(%rax)
   17d6e:	vmovupd %zmm3,-0xc0(%rax)
   17d75:	vmovupd %zmm4,-0x80(%rax)
   17d7c:	vmovupd %zmm5,-0x40(%rax)
   17d83:	cmp    %rcx,%rsi
   17d86:	jne    17970 <hf0_tb16_nat+0x80>
   17d8c:	vzeroupper
   17d8f:	mov    0x4f8(%rsp),%rax
   17d97:	sub    %fs:0x28,%rax
   17da0:	jne    17da4 <hf0_tb16_nat+0x4b4>
   17da2:	leave
   17da3:	ret
   17da4:	call   4280 <__stack_chk_fail@plt>
   17da9:	nopl   0x0(%rax)

0000000000018c50 <pass_tb16_nat_1>:
   18c50:	endbr64
   18c54:	push   %rbp
   18c55:	mov    %rsp,%rbp
   18c58:	push   %r14
   18c5a:	push   %r13
   18c5c:	push   %r12
   18c5e:	push   %rbx
   18c5f:	and    $0xffffffffffffffc0,%rsp
   18c63:	sub    $0x440,%rsp
   18c6a:	vbroadcastsd 0x4434c(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   18c74:	mov    %fs:0x28,%rax
   18c7d:	mov    %rax,0x438(%rsp)
   18c85:	xor    %eax,%eax
   18c87:	test   %rsi,%rsi
   18c8a:	je     18eea <pass_tb16_nat_1+0x29a>
   18c90:	mov    %rsi,%r10
   18c93:	mov    %rsi,%r8
   18c96:	xor    %r12d,%r12d
   18c99:	mov    %rsp,%r14
   18c9c:	shl    $0x4,%r8
   18ca0:	lea    (%r10,%r10,2),%rdx
   18ca4:	lea    -0x1(%r10),%r13
   18ca8:	mov    %r10,%rbx
   18cab:	lea    0x0(,%rsi,8),%r11
   18cb3:	lea    (%rdi,%r8,1),%rsi
   18cb7:	neg    %rbx
   18cba:	shr    $0x3,%r13
   18cbe:	lea    0x0(,%rdx,8),%r9
   18cc6:	shl    $0x4,%rdx
   18cca:	neg    %r8
   18ccd:	shl    $0x5,%rbx
   18cd1:	lea    (%rsi,%r9,1),%rax
   18cd5:	add    %rax,%rdx
   18cd8:	lea    (%rdx,%r11,1),%rcx
   18cdc:	neg    %r11
   18cdf:	nop
   18ce0:	vmovupd (%rsi,%r8,1),%zmm1
   18ce7:	vmovupd (%rsi),%zmm3
   18ced:	mov    %r14,%rdi
   18cf0:	vmovupd (%rax,%rbx,1),%zmm2
   18cf7:	vmovupd (%rax,%r8,1),%zmm4
   18cfe:	vmovupd (%rax,%r11,1),%zmm5
   18d05:	vmovupd (%rax),%zmm6
   18d0b:	vmovapd %zmm1,(%rsp)
   18d12:	vmovupd (%rax,%r10,8),%zmm7
   18d19:	vmovupd (%rdx,%rbx,1),%zmm0
   18d20:	vmovapd %zmm2,0x40(%rsp)
   18d28:	vmovupd (%rax,%r9,1),%zmm1
   18d2f:	vmovupd (%rdx,%r8,1),%zmm2
   18d36:	vmovapd %zmm3,0x80(%rsp)
   18d3e:	vmovapd %zmm4,0xc0(%rsp)
   18d46:	vmovupd (%rdx,%r11,1),%zmm3
   18d4d:	vmovupd (%rdx),%zmm4
   18d53:	vmovapd %zmm5,0x100(%rsp)
   18d5b:	vmovupd (%rcx),%zmm5
   18d61:	vmovapd %zmm6,0x140(%rsp)
   18d69:	vmovupd (%rcx,%r10,8),%zmm6
   18d70:	vmovapd %zmm7,0x180(%rsp)
   18d78:	vmovupd (%rdx,%r9,1),%zmm7
   18d7f:	vmovapd %zmm0,0x1c0(%rsp)
   18d87:	vmovupd (%rcx,%r9,1),%zmm0
   18d8e:	vmovapd %zmm1,0x200(%rsp)
   18d96:	vmovapd %zmm2,0x240(%rsp)
   18d9e:	vmovapd %zmm3,0x280(%rsp)
   18da6:	vmovapd %zmm4,0x2c0(%rsp)
   18dae:	vmovapd %zmm5,0x300(%rsp)
   18db6:	vmovapd %zmm6,0x340(%rsp)
   18dbe:	vmovapd %zmm7,0x380(%rsp)
   18dc6:	vmovapd %zmm0,0x3c0(%rsp)
   18dce:	vzeroupper
   18dd1:	call   16af0 <tb16_nat.constprop.0>
   18dd6:	mov    %r12,%rdi
   18dd9:	add    $0x40,%rsi
   18ddd:	vmovapd (%rsp),%zmm1
   18de4:	add    $0x1,%r12
   18de8:	vmovapd 0x40(%rsp),%zmm2
   18df0:	add    $0x40,%rdx
   18df4:	vmovapd 0x80(%rsp),%zmm3
   18dfc:	vmovapd 0xc0(%rsp),%zmm4
   18e04:	vmovapd 0x100(%rsp),%zmm5
   18e0c:	vmovapd 0x140(%rsp),%zmm6
   18e14:	vmovupd %zmm1,-0x40(%rsi,%r8,1)
   18e1c:	vmovapd 0x180(%rsp),%zmm7
   18e24:	vmovapd 0x1c0(%rsp),%zmm0
   18e2c:	vmovupd %zmm2,(%rax,%rbx,1)
   18e33:	vmovapd 0x200(%rsp),%zmm1
   18e3b:	vmovupd %zmm3,-0x40(%rsi)
   18e42:	vmovapd 0x240(%rsp),%zmm2
   18e4a:	vmovupd %zmm4,(%rax,%r8,1)
   18e51:	vmovapd 0x280(%rsp),%zmm3
   18e59:	vmovapd 0x2c0(%rsp),%zmm4
   18e61:	vmovupd %zmm5,(%rax,%r11,1)
   18e68:	vmovapd 0x300(%rsp),%zmm5
   18e70:	vmovupd %zmm6,(%rax)
   18e76:	vmovapd 0x340(%rsp),%zmm6
   18e7e:	vmovupd %zmm7,(%rax,%r10,8)
   18e85:	add    $0x40,%rax
   18e89:	vmovapd 0x380(%rsp),%zmm7
   18e91:	vmovupd %zmm0,-0x40(%rdx,%rbx,1)
   18e99:	vmovapd 0x3c0(%rsp),%zmm0
   18ea1:	vmovupd %zmm1,-0x40(%rax,%r9,1)
   18ea9:	vmovupd %zmm2,-0x40(%rdx,%r8,1)
   18eb1:	vmovupd %zmm3,-0x40(%rdx,%r11,1)
   18eb9:	vmovupd %zmm4,-0x40(%rdx)
   18ec0:	vmovupd %zmm5,(%rcx)
   18ec6:	vmovupd %zmm6,(%rcx,%r10,8)
   18ecd:	add    $0x40,%rcx
   18ed1:	vmovupd %zmm7,-0x40(%rdx,%r9,1)
   18ed9:	vmovupd %zmm0,-0x40(%rcx,%r9,1)
   18ee1:	cmp    %rdi,%r13
   18ee4:	jne    18ce0 <pass_tb16_nat_1+0x90>
   18eea:	mov    0x438(%rsp),%rax
   18ef2:	sub    %fs:0x28,%rax
   18efb:	jne    18f0d <pass_tb16_nat_1+0x2bd>
   18efd:	vzeroupper
   18f00:	lea    -0x20(%rbp),%rsp
   18f04:	pop    %rbx
   18f05:	pop    %r12
   18f07:	pop    %r13
   18f09:	pop    %r14
   18f0b:	pop    %rbp
   18f0c:	ret
   18f0d:	vzeroupper
   18f10:	call   4280 <__stack_chk_fail@plt>
   18f15:	data16 cs nopw 0x0(%rax,%rax,1)

000000000001f210 <hs_g19_nat>:
   1f210:	endbr64
   1f214:	vbroadcastsd 0x3dda2(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   1f21e:	test   %rsi,%rsi
   1f221:	je     1f3cd <hs_g19_nat+0x1bd>
   1f227:	push   %rbp
   1f228:	mov    %rsp,%rbp
   1f22b:	push   %r15
   1f22d:	push   %r14
   1f22f:	push   %r13
   1f231:	lea    0x0(,%rdx,8),%r13
   1f239:	push   %r12
   1f23b:	push   %rbx
   1f23c:	and    $0xffffffffffffffc0,%rsp
   1f240:	test   %rdx,%rdx
   1f243:	je     1f3bb <hs_g19_nat+0x1ab>
   1f249:	lea    -0x1(%rdx),%r12
   1f24d:	lea    (%rdx,%rdx,2),%rcx
   1f251:	mov    %rsi,%r15
   1f254:	mov    %rdx,%r11
   1f257:	and    $0xfffffffffffffff8,%r12
   1f25b:	mov    %r13,%rsi
   1f25e:	mov    %rdx,%r9
   1f261:	mov    %rdi,%r14
   1f264:	mov    %r12,-0x8(%rsp)
   1f269:	lea    (%rdx,%rdx,4),%r8
   1f26d:	lea    0x40(%rdi),%rax
   1f271:	neg    %rsi
   1f274:	lea    0x0(,%rcx,8),%r10
   1f27c:	shl    $0x4,%r11
   1f280:	shl    $0x5,%r9
   1f284:	mov    %rdx,%rbx
   1f287:	shl    $0x3,%r8
   1f28b:	shl    $0x4,%rcx
   1f28f:	vmovq  %rax,%xmm11
   1f294:	vbroadcastsd 0x3db22(%rip),%zmm0        # 5cdc0 <_IO_stdin_used+0xdc0>
   1f29e:	xchg   %ax,%ax
   1f2a0:	mov    -0x8(%rsp),%rdi
   1f2a5:	vmovq  %xmm11,%r12
   1f2aa:	lea    (%r14,%rbx,8),%rax
   1f2ae:	add    %rbx,%rdi
   1f2b1:	lea    (%r12,%rdi,8),%rdi
   1f2b5:	nopl   (%rax)
   1f2b8:	vmovupd (%rax,%rsi,1),%zmm1
   1f2bf:	vmovupd (%rax),%zmm6
   1f2c5:	vmovapd %zmm0,%zmm3
   1f2cb:	vaddpd (%rax,%rcx,1),%zmm1,%zmm10
   1f2d2:	vaddpd (%rax,%r8,1),%zmm6,%zmm7
   1f2d9:	vmovupd (%rax,%rdx,8),%zmm4
   1f2e0:	vmovupd (%rax,%r11,1),%zmm5
   1f2e7:	vsubpd (%rax,%r9,1),%zmm4,%zmm1
   1f2ee:	vsubpd (%rax,%r10,1),%zmm5,%zmm6
   1f2f5:	vmovapd %zmm0,%zmm4
   1f2fb:	vsubpd %zmm7,%zmm10,%zmm8
   1f301:	vmovapd %zmm0,%zmm5
   1f307:	vaddpd %zmm6,%zmm1,%zmm9
   1f30d:	vsubpd %zmm9,%zmm8,%zmm2
   1f313:	vfnmadd132pd (%rax,%rcx,1),%zmm2,%zmm3
   1f31a:	vfnmadd231pd (%rax,%r9,1),%zmm0,%zmm2
   1f321:	vfmadd132pd (%rax,%r8,1),%zmm3,%zmm5
   1f328:	vfnmadd132pd (%rax,%r10,1),%zmm2,%zmm4
   1f32f:	vfmadd231pd (%rax),%zmm0,%zmm3
   1f335:	vfmadd231pd (%rax,%r11,1),%zmm0,%zmm2
   1f33c:	vfmadd132pd %zmm0,%zmm5,%zmm6
   1f342:	vfmadd132pd %zmm0,%zmm5,%zmm1
   1f348:	vfmadd132pd %zmm0,%zmm4,%zmm7
   1f34e:	vfmadd132pd %zmm0,%zmm3,%zmm9
   1f354:	vfmsub132pd %zmm0,%zmm2,%zmm8
   1f35a:	vfmsub132pd %zmm0,%zmm4,%zmm10
   1f360:	vmovupd %zmm10,(%rax,%rsi,1)
   1f367:	vmovupd %zmm1,(%rax)
   1f36d:	vmovupd %zmm3,(%rax,%rdx,8)
   1f374:	add    $0x40,%rax
   1f378:	vmovupd %zmm2,-0x40(%rax,%r11,1)
   1f380:	vmovupd %zmm9,-0x40(%rax,%r10,1)
   1f388:	vmovupd %zmm8,-0x40(%rax,%r9,1)
   1f390:	vmovupd %zmm7,-0x40(%rax,%r8,1)
   1f398:	vmovupd %zmm6,-0x40(%rax,%rcx,1)
   1f3a0:	cmp    %rax,%rdi
   1f3a3:	jne    1f2b8 <hs_g19_nat+0xa8>
   1f3a9:	add    %r13,%rbx
   1f3ac:	mov    %rbx,%rax
   1f3af:	sub    %rdx,%rax
   1f3b2:	cmp    %r15,%rax
   1f3b5:	jb     1f2a0 <hs_g19_nat+0x90>
   1f3bb:	vzeroupper
   1f3be:	lea    -0x28(%rbp),%rsp
   1f3c2:	pop    %rbx
   1f3c3:	pop    %r12
   1f3c5:	pop    %r13
   1f3c7:	pop    %r14
   1f3c9:	pop    %r15
   1f3cb:	pop    %rbp
   1f3cc:	ret
   1f3cd:	vzeroupper
   1f3d0:	ret
   1f3d1:	data16 cs nopw 0x0(%rax,%rax,1)
   1f3dc:	nopl   0x0(%rax)

0000000000020f50 <hs_h20_nat>:
   20f50:	endbr64
   20f54:	vbroadcastsd 0x3c062(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   20f5e:	test   %rsi,%rsi
   20f61:	je     21101 <hs_h20_nat+0x1b1>
   20f67:	push   %rbp
   20f68:	mov    %rsp,%rbp
   20f6b:	push   %r15
   20f6d:	push   %r14
   20f6f:	push   %r13
   20f71:	lea    0x0(,%rdx,8),%r13
   20f79:	push   %r12
   20f7b:	push   %rbx
   20f7c:	and    $0xffffffffffffffc0,%rsp
   20f80:	test   %rdx,%rdx
   20f83:	je     210ef <hs_h20_nat+0x19f>
   20f89:	lea    -0x1(%rdx),%r12
   20f8d:	lea    (%rdx,%rdx,2),%rcx
   20f91:	mov    %rsi,%r15
   20f94:	mov    %rdx,%r11
   20f97:	and    $0xfffffffffffffff8,%r12
   20f9b:	mov    %r13,%rsi
   20f9e:	mov    %rdx,%r9
   20fa1:	mov    %rdi,%r14
   20fa4:	mov    %r12,-0x8(%rsp)
   20fa9:	lea    (%rdx,%rdx,4),%r8
   20fad:	lea    0x40(%rdi),%rax
   20fb1:	neg    %rsi
   20fb4:	lea    0x0(,%rcx,8),%r10
   20fbc:	shl    $0x4,%r11
   20fc0:	shl    $0x5,%r9
   20fc4:	mov    %rdx,%rbx
   20fc7:	shl    $0x3,%r8
   20fcb:	shl    $0x4,%rcx
   20fcf:	vmovq  %rax,%xmm11
   20fd4:	vbroadcastsd 0x3bdda(%rip),%zmm10        # 5cdb8 <_IO_stdin_used+0xdb8>
   20fde:	xchg   %ax,%ax
   20fe0:	mov    -0x8(%rsp),%rdi
   20fe5:	vmovq  %xmm11,%r12
   20fea:	lea    (%r14,%rbx,8),%rax
   20fee:	add    %rbx,%rdi
   20ff1:	lea    (%r12,%rdi,8),%rdi
   20ff5:	nopl   (%rax)
   20ff8:	vmovupd (%rax,%rsi,1),%zmm3
   20fff:	vmovupd (%rax),%zmm4
   21005:	vaddpd (%rax,%rcx,1),%zmm3,%zmm9
   2100c:	vaddpd (%rax,%r8,1),%zmm4,%zmm6
   21013:	vmovupd (%rax,%r11,1),%zmm3
   2101a:	vmovupd (%rax,%rdx,8),%zmm2
   21021:	vsubpd (%rax,%r10,1),%zmm3,%zmm5
   21028:	vsubpd (%rax,%r9,1),%zmm2,%zmm2
   2102f:	vsubpd %zmm6,%zmm9,%zmm7
   21035:	vaddpd %zmm5,%zmm2,%zmm8
   2103b:	vsubpd %zmm8,%zmm7,%zmm0
   21041:	vmovapd %zmm0,%zmm1
   21047:	vfmsub213pd (%rax,%r9,1),%zmm10,%zmm0
   2104e:	vfmsub213pd (%rax,%rcx,1),%zmm10,%zmm1
   21055:	vsubpd (%rax,%r10,1),%zmm0,%zmm4
   2105c:	vaddpd (%rax,%r8,1),%zmm1,%zmm3
   21063:	vaddpd (%rax,%r11,1),%zmm0,%zmm0
   2106a:	vaddpd (%rax),%zmm1,%zmm1
   21070:	vsubpd %zmm4,%zmm9,%zmm9
   21076:	vaddpd %zmm4,%zmm6,%zmm6
   2107c:	vaddpd %zmm3,%zmm2,%zmm2
   21082:	vsubpd %zmm0,%zmm7,%zmm7
   21088:	vaddpd %zmm1,%zmm8,%zmm8
   2108e:	vaddpd %zmm3,%zmm5,%zmm5
   21094:	vmovupd %zmm9,(%rax,%rsi,1)
   2109b:	vmovupd %zmm2,(%rax)
   210a1:	vmovupd %zmm1,(%rax,%rdx,8)
   210a8:	add    $0x40,%rax
   210ac:	vmovupd %zmm0,-0x40(%rax,%r11,1)
   210b4:	vmovupd %zmm8,-0x40(%rax,%r10,1)
   210bc:	vmovupd %zmm7,-0x40(%rax,%r9,1)
   210c4:	vmovupd %zmm6,-0x40(%rax,%r8,1)
   210cc:	vmovupd %zmm5,-0x40(%rax,%rcx,1)
   210d4:	cmp    %rax,%rdi
   210d7:	jne    20ff8 <hs_h20_nat+0xa8>
   210dd:	add    %r13,%rbx
   210e0:	mov    %rbx,%rax
   210e3:	sub    %rdx,%rax
   210e6:	cmp    %r15,%rax
   210e9:	jb     20fe0 <hs_h20_nat+0x90>
   210ef:	vzeroupper
   210f2:	lea    -0x28(%rbp),%rsp
   210f6:	pop    %rbx
   210f7:	pop    %r12
   210f9:	pop    %r13
   210fb:	pop    %r14
   210fd:	pop    %r15
   210ff:	pop    %rbp
   21100:	ret
   21101:	vzeroupper
   21104:	ret
   21105:	data16 cs nopw 0x0(%rax,%rax,1)

0000000000021110 <hs_g20_nat>:
   21110:	endbr64
   21114:	vbroadcastsd 0x3bea2(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   2111e:	test   %rsi,%rsi
   21121:	je     212d1 <hs_g20_nat+0x1c1>
   21127:	push   %rbp
   21128:	mov    %rsp,%rbp
   2112b:	push   %r15
   2112d:	push   %r14
   2112f:	push   %r13
   21131:	lea    0x0(,%rdx,8),%r13
   21139:	push   %r12
   2113b:	push   %rbx
   2113c:	and    $0xffffffffffffffc0,%rsp
   21140:	test   %rdx,%rdx
   21143:	je     212bf <hs_g20_nat+0x1af>
   21149:	lea    -0x1(%rdx),%r12
   2114d:	lea    (%rdx,%rdx,2),%rcx
   21151:	mov    %rsi,%r15
   21154:	mov    %rdx,%r11
   21157:	and    $0xfffffffffffffff8,%r12
   2115b:	mov    %r13,%rsi
   2115e:	mov    %rdx,%r9
   21161:	mov    %rdi,%r14
   21164:	mov    %r12,-0x8(%rsp)
   21169:	lea    (%rdx,%rdx,4),%r8
   2116d:	lea    0x40(%rdi),%rax
   21171:	neg    %rsi
   21174:	lea    0x0(,%rcx,8),%r10
   2117c:	shl    $0x4,%r11
   21180:	shl    $0x5,%r9
   21184:	mov    %rdx,%rbx
   21187:	shl    $0x3,%r8
   2118b:	shl    $0x4,%rcx
   2118f:	vmovq  %rax,%xmm10
   21194:	vbroadcastsd 0x3bc22(%rip),%zmm0        # 5cdc0 <_IO_stdin_used+0xdc0>
   2119e:	xchg   %ax,%ax
   211a0:	mov    -0x8(%rsp),%rdi
   211a5:	vmovq  %xmm10,%r12
   211aa:	lea    (%r14,%rbx,8),%rax
   211ae:	add    %rbx,%rdi
   211b1:	lea    (%r12,%rdi,8),%rdi
   211b5:	nopl   (%rax)
   211b8:	vmovupd (%rax,%rdx,8),%zmm6
   211bf:	vmovupd (%rax),%zmm5
   211c5:	vmovapd %zmm0,%zmm4
   211cb:	vsubpd (%rax,%r11,1),%zmm6,%zmm7
   211d2:	vaddpd (%rax,%rsi,1),%zmm5,%zmm5
   211d9:	vmovupd (%rax,%r9,1),%zmm3
   211e0:	vsubpd %zmm7,%zmm5,%zmm1
   211e6:	vfmadd132pd %zmm6,%zmm1,%zmm4
   211ec:	vaddpd (%rax,%r10,1),%zmm3,%zmm6
   211f3:	vmovupd (%rax,%r8,1),%zmm3
   211fa:	vmovapd %zmm1,%zmm2
   21200:	vsubpd (%rax,%rcx,1),%zmm3,%zmm8
   21207:	vmovapd %zmm0,%zmm3
   2120d:	vfmsub231pd (%rax,%rsi,1),%zmm0,%zmm2
   21214:	vaddpd %zmm8,%zmm6,%zmm1
   2121a:	vfnmadd132pd (%rax,%r8,1),%zmm1,%zmm3
   21221:	vfmsub231pd (%rax,%r10,1),%zmm0,%zmm1
   21228:	vaddpd %zmm3,%zmm4,%zmm9
   2122e:	vfnmadd132pd %zmm0,%zmm9,%zmm6
   21234:	vfmsub132pd %zmm0,%zmm9,%zmm5
   2123a:	vaddpd %zmm1,%zmm2,%zmm9
   21240:	vfmadd132pd %zmm0,%zmm9,%zmm8
   21246:	vfnmadd132pd %zmm0,%zmm9,%zmm7
   2124c:	vfmsub132pd %zmm0,%zmm6,%zmm4
   21252:	vfmadd132pd %zmm0,%zmm5,%zmm3
   21258:	vfmsub132pd %zmm0,%zmm8,%zmm2
   2125e:	vfnmadd132pd %zmm0,%zmm7,%zmm1
   21264:	vmovupd %zmm4,(%rax,%rsi,1)
   2126b:	vmovupd %zmm8,(%rax)
   21271:	vmovupd %zmm3,(%rax,%rdx,8)
   21278:	add    $0x40,%rax
   2127c:	vmovupd %zmm7,-0x40(%rax,%r11,1)
   21284:	vmovupd %zmm6,-0x40(%rax,%r10,1)
   2128c:	vmovupd %zmm2,-0x40(%rax,%r9,1)
   21294:	vmovupd %zmm5,-0x40(%rax,%r8,1)
   2129c:	vmovupd %zmm1,-0x40(%rax,%rcx,1)
   212a4:	cmp    %rax,%rdi
   212a7:	jne    211b8 <hs_g20_nat+0xa8>
   212ad:	add    %r13,%rbx
   212b0:	mov    %rbx,%rax
   212b3:	sub    %rdx,%rax
   212b6:	cmp    %r15,%rax
   212b9:	jb     211a0 <hs_g20_nat+0x90>
   212bf:	vzeroupper
   212c2:	lea    -0x28(%rbp),%rsp
   212c6:	pop    %rbx
   212c7:	pop    %r12
   212c9:	pop    %r13
   212cb:	pop    %r14
   212cd:	pop    %r15
   212cf:	pop    %rbp
   212d0:	ret
   212d1:	vzeroupper
   212d4:	ret
   212d5:	data16 cs nopw 0x0(%rax,%rax,1)

0000000000022250 <hs_broken_g20>:
   22250:	endbr64
   22254:	vbroadcastsd 0x3ad62(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   2225e:	test   %rsi,%rsi
   22261:	je     22411 <hs_broken_g20+0x1c1>
   22267:	push   %rbp
   22268:	mov    %rsp,%rbp
   2226b:	push   %r15
   2226d:	push   %r14
   2226f:	push   %r13
   22271:	lea    0x0(,%rdx,8),%r13
   22279:	push   %r12
   2227b:	push   %rbx
   2227c:	and    $0xffffffffffffffc0,%rsp
   22280:	test   %rdx,%rdx
   22283:	je     223ff <hs_broken_g20+0x1af>
   22289:	lea    -0x1(%rdx),%r12
   2228d:	lea    (%rdx,%rdx,2),%rcx
   22291:	mov    %rsi,%r15
   22294:	mov    %rdx,%r11
   22297:	and    $0xfffffffffffffff8,%r12
   2229b:	mov    %r13,%rsi
   2229e:	mov    %rdx,%r9
   222a1:	mov    %rdi,%r14
   222a4:	mov    %r12,-0x8(%rsp)
   222a9:	lea    (%rdx,%rdx,4),%r8
   222ad:	lea    0x40(%rdi),%rax
   222b1:	neg    %rsi
   222b4:	lea    0x0(,%rcx,8),%r10
   222bc:	shl    $0x4,%r11
   222c0:	shl    $0x5,%r9
   222c4:	mov    %rdx,%rbx
   222c7:	shl    $0x3,%r8
   222cb:	shl    $0x4,%rcx
   222cf:	vmovq  %rax,%xmm10
   222d4:	vbroadcastsd 0x3aae2(%rip),%zmm0        # 5cdc0 <_IO_stdin_used+0xdc0>
   222de:	xchg   %ax,%ax
   222e0:	mov    -0x8(%rsp),%rdi
   222e5:	vmovq  %xmm10,%r12
   222ea:	lea    (%r14,%rbx,8),%rax
   222ee:	add    %rbx,%rdi
   222f1:	lea    (%r12,%rdi,8),%rdi
   222f5:	nopl   (%rax)
   222f8:	vmovupd (%rax,%rdx,8),%zmm6
   222ff:	vmovupd (%rax),%zmm5
   22305:	vmovapd %zmm0,%zmm4
   2230b:	vsubpd (%rax,%r11,1),%zmm6,%zmm7
   22312:	vaddpd (%rax,%rsi,1),%zmm5,%zmm5
   22319:	vmovupd (%rax,%r9,1),%zmm3
   22320:	vsubpd %zmm7,%zmm5,%zmm1
   22326:	vfmadd132pd %zmm6,%zmm1,%zmm4
   2232c:	vaddpd (%rax,%r10,1),%zmm3,%zmm6
   22333:	vmovupd (%rax,%r8,1),%zmm3
   2233a:	vmovapd %zmm1,%zmm2
   22340:	vsubpd (%rax,%rcx,1),%zmm3,%zmm8
   22347:	vmovapd %zmm0,%zmm3
   2234d:	vfmsub231pd (%rax,%rsi,1),%zmm0,%zmm2
   22354:	vaddpd %zmm8,%zmm6,%zmm1
   2235a:	vfnmadd132pd (%rax,%r8,1),%zmm1,%zmm3
   22361:	vfmsub231pd (%rax,%r10,1),%zmm0,%zmm1
   22368:	vaddpd %zmm3,%zmm4,%zmm9
   2236e:	vfnmadd132pd %zmm0,%zmm9,%zmm6
   22374:	vfmsub132pd %zmm0,%zmm9,%zmm5
   2237a:	vaddpd %zmm1,%zmm2,%zmm9
   22380:	vfmadd132pd %zmm0,%zmm9,%zmm8
   22386:	vfnmadd132pd %zmm0,%zmm9,%zmm7
   2238c:	vfmsub132pd %zmm0,%zmm6,%zmm4
   22392:	vfmadd132pd %zmm0,%zmm5,%zmm3
   22398:	vfmsub132pd %zmm0,%zmm8,%zmm2
   2239e:	vfnmadd132pd %zmm0,%zmm7,%zmm1
   223a4:	vmovupd %zmm4,(%rax,%rsi,1)
   223ab:	vmovupd %zmm8,(%rax)
   223b1:	vmovupd %zmm3,(%rax,%rdx,8)
   223b8:	add    $0x40,%rax
   223bc:	vmovupd %zmm7,-0x40(%rax,%r11,1)
   223c4:	vmovupd %zmm6,-0x40(%rax,%r10,1)
   223cc:	vmovupd %zmm5,-0x40(%rax,%r9,1)
   223d4:	vmovupd %zmm2,-0x40(%rax,%r8,1)
   223dc:	vmovupd %zmm1,-0x40(%rax,%rcx,1)
   223e4:	cmp    %rax,%rdi
   223e7:	jne    222f8 <hs_broken_g20+0xa8>
   223ed:	add    %r13,%rbx
   223f0:	mov    %rbx,%rax
   223f3:	sub    %rdx,%rax
   223f6:	cmp    %r15,%rax
   223f9:	jb     222e0 <hs_broken_g20+0x90>
   223ff:	vzeroupper
   22402:	lea    -0x28(%rbp),%rsp
   22406:	pop    %rbx
   22407:	pop    %r12
   22409:	pop    %r13
   2240b:	pop    %r14
   2240d:	pop    %r15
   2240f:	pop    %rbp
   22410:	ret
   22411:	vzeroupper
   22414:	ret
   22415:	data16 cs nopw 0x0(%rax,%rax,1)

0000000000025de0 <hs_tb8_nat>:
   25de0:	endbr64
   25de4:	vbroadcastsd 0x371d2(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   25dee:	test   %rsi,%rsi
   25df1:	je     25f9f <hs_tb8_nat+0x1bf>
   25df7:	push   %rbp
   25df8:	mov    %rsp,%rbp
   25dfb:	push   %r15
   25dfd:	push   %r14
   25dff:	push   %r13
   25e01:	lea    0x0(,%rdx,8),%r13
   25e09:	push   %r12
   25e0b:	push   %rbx
   25e0c:	and    $0xffffffffffffffc0,%rsp
   25e10:	test   %rdx,%rdx
   25e13:	je     25f8d <hs_tb8_nat+0x1ad>
   25e19:	lea    -0x1(%rdx),%r12
   25e1d:	lea    (%rdx,%rdx,2),%rcx
   25e21:	mov    %rsi,%r15
   25e24:	mov    %rdx,%r11
   25e27:	and    $0xfffffffffffffff8,%r12
   25e2b:	mov    %r13,%rsi
   25e2e:	mov    %rdx,%r9
   25e31:	mov    %rdi,%r14
   25e34:	mov    %r12,-0x8(%rsp)
   25e39:	lea    (%rdx,%rdx,4),%r8
   25e3d:	lea    0x40(%rdi),%rax
   25e41:	neg    %rsi
   25e44:	lea    0x0(,%rcx,8),%r10
   25e4c:	shl    $0x4,%r11
   25e50:	shl    $0x5,%r9
   25e54:	mov    %rdx,%rbx
   25e57:	shl    $0x3,%r8
   25e5b:	shl    $0x4,%rcx
   25e5f:	vmovq  %rax,%xmm10
   25e64:	nopl   0x0(%rax)
   25e68:	mov    -0x8(%rsp),%rdi
   25e6d:	vmovq  %xmm10,%r12
   25e72:	lea    (%r14,%rbx,8),%rax
   25e76:	add    %rbx,%rdi
   25e79:	lea    (%r12,%rdi,8),%rdi
   25e7d:	nopl   (%rax)
   25e80:	vmovupd (%rax,%rsi,1),%zmm7
   25e87:	vmovupd (%rax,%rdx,8),%zmm3
   25e8e:	vaddpd (%rax),%zmm7,%zmm2
   25e94:	vaddpd (%rax,%r11,1),%zmm3,%zmm6
   25e9b:	vsubpd (%rax,%r11,1),%zmm3,%zmm5
   25ea2:	vsubpd (%rax),%zmm7,%zmm0
   25ea8:	vmovupd (%rax,%r10,1),%zmm7
   25eaf:	vaddpd (%rax,%r9,1),%zmm7,%zmm3
   25eb6:	vsubpd (%rax,%r9,1),%zmm7,%zmm1
   25ebd:	vmovupd (%rax,%r8,1),%zmm7
   25ec4:	vaddpd (%rax,%rcx,1),%zmm7,%zmm9
   25ecb:	vsubpd (%rax,%rcx,1),%zmm7,%zmm4
   25ed2:	vaddpd %zmm6,%zmm2,%zmm7
   25ed8:	vsubpd %zmm6,%zmm2,%zmm2
   25ede:	vaddpd %zmm5,%zmm0,%zmm6
   25ee4:	vsubpd %zmm5,%zmm0,%zmm0
   25eea:	vaddpd %zmm9,%zmm3,%zmm8
   25ef0:	vaddpd %zmm4,%zmm1,%zmm5
   25ef6:	vsubpd %zmm4,%zmm1,%zmm1
   25efc:	vsubpd %zmm9,%zmm3,%zmm3
   25f02:	vaddpd %zmm8,%zmm7,%zmm4
   25f08:	vsubpd %zmm8,%zmm7,%zmm7
   25f0e:	vmovupd %zmm4,(%rax,%rsi,1)
   25f15:	vaddpd %zmm5,%zmm6,%zmm4
   25f1b:	vsubpd %zmm5,%zmm6,%zmm6
   25f21:	vmovupd %zmm4,(%rax)
   25f27:	vaddpd %zmm3,%zmm2,%zmm4
   25f2d:	vsubpd %zmm3,%zmm2,%zmm2
   25f33:	vmovupd %zmm4,(%rax,%rdx,8)
   25f3a:	vaddpd %zmm1,%zmm0,%zmm4
   25f40:	add    $0x40,%rax
   25f44:	vsubpd %zmm1,%zmm0,%zmm0
   25f4a:	vmovupd %zmm4,-0x40(%rax,%r11,1)
   25f52:	vmovupd %zmm7,-0x40(%rax,%r10,1)
   25f5a:	vmovupd %zmm6,-0x40(%rax,%r9,1)
   25f62:	vmovupd %zmm2,-0x40(%rax,%r8,1)
   25f6a:	vmovupd %zmm0,-0x40(%rax,%rcx,1)
   25f72:	cmp    %rax,%rdi
   25f75:	jne    25e80 <hs_tb8_nat+0xa0>
   25f7b:	add    %r13,%rbx
   25f7e:	mov    %rbx,%rax
   25f81:	sub    %rdx,%rax
   25f84:	cmp    %r15,%rax
   25f87:	jb     25e68 <hs_tb8_nat+0x88>
   25f8d:	vzeroupper
   25f90:	lea    -0x28(%rbp),%rsp
   25f94:	pop    %rbx
   25f95:	pop    %r12
   25f97:	pop    %r13
   25f99:	pop    %r14
   25f9b:	pop    %r15
   25f9d:	pop    %rbp
   25f9e:	ret
   25f9f:	vzeroupper
   25fa2:	ret
   25fa3:	data16 cs nopw 0x0(%rax,%rax,1)
   25fae:	xchg   %ax,%ax

0000000000025fb0 <hs_tb8_balS>:
   25fb0:	endbr64
   25fb4:	vbroadcastsd 0x37002(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   25fbe:	test   %rsi,%rsi
   25fc1:	je     261a0 <hs_tb8_balS+0x1f0>
   25fc7:	push   %rbp
   25fc8:	mov    %rsp,%rbp
   25fcb:	push   %r15
   25fcd:	push   %r14
   25fcf:	push   %r13
   25fd1:	lea    0x0(,%rdx,8),%r13
   25fd9:	push   %r12
   25fdb:	push   %rbx
   25fdc:	and    $0xffffffffffffffc0,%rsp
   25fe0:	test   %rdx,%rdx
   25fe3:	je     2618e <hs_tb8_balS+0x1de>
   25fe9:	lea    -0x1(%rdx),%r12
   25fed:	lea    (%rdx,%rdx,2),%rcx
   25ff1:	mov    %rsi,%r15
   25ff4:	mov    %rdx,%r11
   25ff7:	and    $0xfffffffffffffff8,%r12
   25ffb:	mov    %r13,%rsi
   25ffe:	mov    %rdx,%r9
   26001:	mov    %rdi,%r14
   26004:	mov    %r12,-0x8(%rsp)
   26009:	lea    (%rdx,%rdx,4),%r8
   2600d:	lea    0x40(%rdi),%rax
   26011:	neg    %rsi
   26014:	lea    0x0(,%rcx,8),%r10
   2601c:	shl    $0x4,%r11
   26020:	shl    $0x5,%r9
   26024:	mov    %rdx,%rbx
   26027:	shl    $0x3,%r8
   2602b:	shl    $0x4,%rcx
   2602f:	vmovq  %rax,%xmm13
   26034:	nopl   0x0(%rax)
   26038:	mov    -0x8(%rsp),%rdi
   2603d:	vmovq  %xmm13,%r12
   26042:	lea    (%r14,%rbx,8),%rax
   26046:	add    %rbx,%rdi
   26049:	lea    (%r12,%rdi,8),%rdi
   2604d:	nopl   (%rax)
   26050:	vmovupd (%rax,%rsi,1),%zmm7
   26057:	vmovupd (%rax),%zmm6
   2605d:	vsubpd (%rax),%zmm7,%zmm8
   26063:	vmovupd (%rax,%rdx,8),%zmm4
   2606a:	vmovupd (%rax,%r11,1),%zmm1
   26071:	vmovupd (%rax,%r9,1),%zmm5
   26078:	vfmadd132pd %zmm0,%zmm7,%zmm6
   2607e:	vmovupd (%rax,%r10,1),%zmm7
   26085:	vmovupd (%rax,%rcx,1),%zmm2
   2608c:	vfmadd132pd %zmm0,%zmm4,%zmm1
   26092:	vfmadd213pd (%rax,%r8,1),%zmm0,%zmm2
   26099:	vsubpd (%rax,%r9,1),%zmm7,%zmm9
   260a0:	vfmadd132pd %zmm0,%zmm7,%zmm5
   260a6:	vsubpd (%rax,%r11,1),%zmm4,%zmm3
   260ad:	vmovupd (%rax,%r8,1),%zmm4
   260b4:	vsubpd (%rax,%rcx,1),%zmm4,%zmm4
   260bb:	vsubpd %zmm1,%zmm6,%zmm7
   260c1:	vfmadd132pd %zmm0,%zmm6,%zmm1
   260c7:	vsubpd %zmm3,%zmm8,%zmm6
   260cd:	vfmadd132pd %zmm0,%zmm8,%zmm3
   260d3:	vsubpd %zmm2,%zmm5,%zmm8
   260d9:	vfmadd132pd %zmm0,%zmm5,%zmm2
   260df:	vsubpd %zmm4,%zmm9,%zmm5
   260e5:	vfmadd132pd %zmm0,%zmm9,%zmm4
   260eb:	vmovapd %zmm8,%zmm10
   260f1:	vmovapd %zmm5,%zmm9
   260f7:	vfmadd132pd %zmm0,%zmm7,%zmm10
   260fd:	vsubpd %zmm8,%zmm7,%zmm7
   26103:	vfmadd132pd %zmm0,%zmm6,%zmm9
   26109:	vsubpd %zmm5,%zmm6,%zmm6
   2610f:	vmovapd %zmm2,%zmm12
   26115:	vmovapd %zmm4,%zmm11
   2611b:	vfmadd132pd %zmm0,%zmm1,%zmm12
   26121:	vsubpd %zmm2,%zmm1,%zmm1
   26127:	vfmadd132pd %zmm0,%zmm3,%zmm11
   2612d:	vsubpd %zmm4,%zmm3,%zmm3
   26133:	vmovupd %zmm12,(%rax,%rsi,1)
   2613a:	vmovupd %zmm11,(%rax)
   26140:	vmovupd %zmm10,(%rax,%rdx,8)
   26147:	add    $0x40,%rax
   2614b:	vmovupd %zmm9,-0x40(%rax,%r11,1)
   26153:	vmovupd %zmm1,-0x40(%rax,%r10,1)
   2615b:	vmovupd %zmm3,-0x40(%rax,%r9,1)
   26163:	vmovupd %zmm7,-0x40(%rax,%r8,1)
   2616b:	vmovupd %zmm6,-0x40(%rax,%rcx,1)
   26173:	cmp    %rax,%rdi
   26176:	jne    26050 <hs_tb8_balS+0xa0>
   2617c:	add    %r13,%rbx
   2617f:	mov    %rbx,%rax
   26182:	sub    %rdx,%rax
   26185:	cmp    %r15,%rax
   26188:	jb     26038 <hs_tb8_balS+0x88>
   2618e:	vzeroupper
   26191:	lea    -0x28(%rbp),%rsp
   26195:	pop    %rbx
   26196:	pop    %r12
   26198:	pop    %r13
   2619a:	pop    %r14
   2619c:	pop    %r15
   2619e:	pop    %rbp
   2619f:	ret
   261a0:	vzeroupper
   261a3:	ret
   261a4:	data16 cs nopw 0x0(%rax,%rax,1)
   261af:	nop

00000000000261b0 <hs_tb8_bal>:
   261b0:	endbr64
   261b4:	vbroadcastsd 0x36e02(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   261be:	test   %rsi,%rsi
   261c1:	je     263bb <hs_tb8_bal+0x20b>
   261c7:	push   %rbp
   261c8:	mov    %rsp,%rbp
   261cb:	push   %r15
   261cd:	push   %r14
   261cf:	push   %r13
   261d1:	lea    0x0(,%rdx,8),%r13
   261d9:	push   %r12
   261db:	push   %rbx
   261dc:	and    $0xffffffffffffffc0,%rsp
   261e0:	test   %rdx,%rdx
   261e3:	je     263a9 <hs_tb8_bal+0x1f9>
   261e9:	lea    -0x1(%rdx),%r12
   261ed:	lea    (%rdx,%rdx,2),%rcx
   261f1:	mov    %rsi,%r15
   261f4:	mov    %rdx,%r11
   261f7:	and    $0xfffffffffffffff8,%r12
   261fb:	mov    %r13,%rsi
   261fe:	mov    %rdx,%r9
   26201:	mov    %rdi,%r14
   26204:	mov    %r12,-0x8(%rsp)
   26209:	lea    (%rdx,%rdx,4),%r8
   2620d:	lea    0x40(%rdi),%rax
   26211:	neg    %rsi
   26214:	lea    0x0(,%rcx,8),%r10
   2621c:	shl    $0x4,%r11
   26220:	shl    $0x5,%r9
   26224:	mov    %rdx,%rbx
   26227:	shl    $0x3,%r8
   2622b:	shl    $0x4,%rcx
   2622f:	vmovq  %rax,%xmm13
   26234:	nopl   0x0(%rax)
   26238:	mov    -0x8(%rsp),%rdi
   2623d:	vmovq  %xmm13,%r12
   26242:	lea    (%r14,%rbx,8),%rax
   26246:	add    %rbx,%rdi
   26249:	lea    (%r12,%rdi,8),%rdi
   2624d:	nopl   (%rax)
   26250:	vmovupd (%rax,%r11,1),%zmm7
   26257:	vfmadd213pd (%rax,%rdx,8),%zmm0,%zmm7
   2625e:	vmovupd (%rax),%zmm3
   26264:	vfmadd213pd (%rax,%rsi,1),%zmm0,%zmm3
   2626b:	vmovupd (%rax,%rcx,1),%zmm10
   26272:	vfmadd213pd (%rax,%r8,1),%zmm0,%zmm10
   26279:	vmovupd (%rax,%rsi,1),%zmm2
   26280:	vmovupd (%rax,%r9,1),%zmm4
   26287:	vsubpd (%rax),%zmm2,%zmm1
   2628d:	vfmadd213pd (%rax,%r10,1),%zmm0,%zmm4
   26294:	vmovupd (%rax,%rdx,8),%zmm2
   2629b:	vsubpd (%rax,%r11,1),%zmm2,%zmm6
   262a2:	vmovapd %zmm7,%zmm8
   262a8:	vmovupd (%rax,%r10,1),%zmm5
   262af:	vsubpd (%rax,%r9,1),%zmm5,%zmm2
   262b6:	vfmadd132pd %zmm0,%zmm3,%zmm8
   262bc:	vsubpd %zmm7,%zmm3,%zmm3
   262c2:	vmovupd (%rax,%r8,1),%zmm5
   262c9:	vsubpd (%rax,%rcx,1),%zmm5,%zmm5
   262d0:	vmovapd %zmm10,%zmm9
   262d6:	vmovapd %zmm6,%zmm7
   262dc:	vfmadd132pd %zmm0,%zmm1,%zmm7
   262e2:	vsubpd %zmm6,%zmm1,%zmm1
   262e8:	vmovapd %zmm5,%zmm6
   262ee:	vfmadd132pd %zmm0,%zmm4,%zmm9
   262f4:	vsubpd %zmm10,%zmm4,%zmm4
   262fa:	vfmadd132pd %zmm0,%zmm2,%zmm6
   26300:	vsubpd %zmm5,%zmm2,%zmm2
   26306:	vmovapd %zmm4,%zmm10
   2630c:	vmovapd %zmm2,%zmm5
   26312:	vfmadd132pd %zmm0,%zmm3,%zmm10
   26318:	vsubpd %zmm4,%zmm3,%zmm3
   2631e:	vmovapd %zmm9,%zmm12
   26324:	vfmadd132pd %zmm0,%zmm1,%zmm5
   2632a:	vsubpd %zmm2,%zmm1,%zmm1
   26330:	vmovapd %zmm6,%zmm11
   26336:	vfmadd132pd %zmm0,%zmm8,%zmm12
   2633c:	vsubpd %zmm9,%zmm8,%zmm8
   26342:	vfmadd132pd %zmm0,%zmm7,%zmm11
   26348:	vsubpd %zmm6,%zmm7,%zmm7
   2634e:	vmovupd %zmm12,(%rax,%rsi,1)
   26355:	vmovupd %zmm11,(%rax)
   2635b:	vmovupd %zmm10,(%rax,%rdx,8)
   26362:	add    $0x40,%rax
   26366:	vmovupd %zmm5,-0x40(%rax,%r11,1)
   2636e:	vmovupd %zmm8,-0x40(%rax,%r10,1)
   26376:	vmovupd %zmm7,-0x40(%rax,%r9,1)
   2637e:	vmovupd %zmm3,-0x40(%rax,%r8,1)
   26386:	vmovupd %zmm1,-0x40(%rax,%rcx,1)
   2638e:	cmp    %rax,%rdi
   26391:	jne    26250 <hs_tb8_bal+0xa0>
   26397:	add    %r13,%rbx
   2639a:	mov    %rbx,%rax
   2639d:	sub    %rdx,%rax
   263a0:	cmp    %r15,%rax
   263a3:	jb     26238 <hs_tb8_bal+0x88>
   263a9:	vzeroupper
   263ac:	lea    -0x28(%rbp),%rsp
   263b0:	pop    %rbx
   263b1:	pop    %r12
   263b3:	pop    %r13
   263b5:	pop    %r14
   263b7:	pop    %r15
   263b9:	pop    %rbp
   263ba:	ret
   263bb:	vzeroupper
   263be:	ret
   263bf:	nop

0000000000030310 <hs_g52_nat>:
   30310:	endbr64
   30314:	vbroadcastsd 0x2cca2(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   3031e:	test   %rsi,%rsi
   30321:	je     30640 <hs_g52_nat+0x330>
   30327:	push   %rbp
   30328:	mov    %rdx,%rcx
   3032b:	mov    %rsp,%rbp
   3032e:	push   %r15
   30330:	push   %r14
   30332:	push   %r13
   30334:	push   %r12
   30336:	mov    %rsi,%r12
   30339:	mov    %rdx,%rsi
   3033c:	push   %rbx
   3033d:	shl    $0x4,%rsi
   30341:	and    $0xffffffffffffffc0,%rsp
   30345:	test   %rdx,%rdx
   30348:	je     3062e <hs_g52_nat+0x31e>
   3034e:	lea    (%rdx,%rdx,4),%r8
   30352:	mov    %rdi,%rax
   30355:	lea    -0x1(%rdx),%rdx
   30359:	mov    %rcx,%r10
   3035c:	mov    %r8,%r14
   3035f:	lea    (%rdi,%rsi,1),%rbx
   30363:	shr    $0x3,%rdx
   30367:	add    $0x40,%rax
   3036b:	shl    $0x4,%r14
   3036f:	vmovq  %rbx,%xmm1
   30374:	lea    (%rcx,%rdx,4),%r13
   30378:	xor    %ebx,%ebx
   3037a:	add    %rdi,%r14
   3037d:	neg    %r10
   30380:	mov    %rsi,%rdi
   30383:	mov    %rcx,%r11
   30386:	lea    (%rcx,%rcx,2),%r9
   3038a:	vmovq  %rax,%xmm2
   3038f:	add    %r13,%r13
   30392:	neg    %rdi
   30395:	vmovq  %r12,%xmm16
   3039b:	shl    $0x3,%r10
   3039f:	vmovq  %xmm1,%r12
   303a4:	vbroadcastsd 0x2ca12(%rip),%zmm0        # 5cdc0 <_IO_stdin_used+0xdc0>
   303ae:	shl    $0x3,%r9
   303b2:	shl    $0x5,%r11
   303b6:	vmovdqa64 %xmm2,%xmm19
   303bc:	shl    $0x3,%r8
   303c0:	lea    0x0(,%rbx,8),%rdx
   303c8:	lea    (%rbx,%r13,1),%r15
   303cc:	lea    (%rdx,%r12,1),%rax
   303d0:	add    %r14,%rdx
   303d3:	mov    %rax,-0x8(%rsp)
   303d8:	vmovq  %xmm19,%rax
   303de:	lea    (%rax,%r15,8),%r15
   303e2:	mov    -0x8(%rsp),%rax
   303e7:	nopw   0x0(%rax,%rax,1)
   303f0:	vmovupd (%rax),%zmm4
   303f6:	vmovupd (%rax,%r10,1),%zmm3
   303fd:	vmovapd %zmm0,%zmm8
   30403:	vmovapd %zmm0,%zmm13
   30409:	vaddpd (%rax,%rdi,1),%zmm3,%zmm17
   30410:	vsubpd (%rax,%rcx,8),%zmm4,%zmm15
   30417:	vmovupd (%rax,%r11,1),%zmm6
   3041e:	vmovupd (%rax,%r9,1),%zmm5
   30425:	vsubpd (%rax,%r8,1),%zmm6,%zmm3
   3042c:	vaddpd (%rax,%rsi,1),%zmm5,%zmm12
   30433:	vmovapd %zmm0,%zmm5
   30439:	vsubpd %zmm15,%zmm17,%zmm2
   3043f:	vmovupd (%rdx,%r10,1),%zmm7
   30446:	vaddpd (%rdx,%rdi,1),%zmm7,%zmm10
   3044d:	vmovupd (%rdx,%r9,1),%zmm7
   30454:	vaddpd (%rdx,%rsi,1),%zmm7,%zmm11
   3045b:	vmovapd %zmm0,%zmm7
   30461:	vfmadd132pd %zmm4,%zmm2,%zmm8
   30467:	vmovapd %zmm2,%zmm1
   3046d:	vaddpd %zmm3,%zmm12,%zmm2
   30473:	vfmsub231pd (%rax,%rdi,1),%zmm0,%zmm1
   3047a:	vfnmadd132pd %zmm6,%zmm2,%zmm5
   30480:	vmovapd %zmm2,%zmm4
   30486:	vmovupd (%rdx),%zmm6
   3048c:	vsubpd (%rdx,%rcx,8),%zmm6,%zmm14
   30493:	vfmsub231pd (%rax,%rsi,1),%zmm0,%zmm4
   3049a:	vsubpd %zmm5,%zmm8,%zmm2
   304a0:	vfmadd132pd %zmm0,%zmm2,%zmm12
   304a6:	vfmsub132pd %zmm0,%zmm2,%zmm17
   304ac:	vaddpd %zmm4,%zmm1,%zmm2
   304b2:	vfmadd132pd %zmm0,%zmm2,%zmm3
   304b8:	vfnmadd132pd %zmm0,%zmm2,%zmm15
   304be:	vsubpd %zmm14,%zmm10,%zmm2
   304c4:	vfmadd132pd %zmm6,%zmm2,%zmm13
   304ca:	vfmsub231pd (%rdx,%rdi,1),%zmm0,%zmm2
   304d1:	vmovupd (%rdx,%r11,1),%zmm6
   304d8:	vmovapd %zmm2,%zmm9
   304de:	vsubpd (%rdx,%r8,1),%zmm6,%zmm2
   304e5:	vaddpd %zmm2,%zmm11,%zmm6
   304eb:	vfnmadd132pd (%rdx,%r11,1),%zmm6,%zmm7
   304f2:	vfmsub231pd (%rdx,%rsi,1),%zmm0,%zmm6
   304f9:	vaddpd %zmm7,%zmm13,%zmm18
   304ff:	vfnmadd132pd %zmm0,%zmm18,%zmm11
   30505:	vfmsub132pd %zmm0,%zmm18,%zmm10
   3050b:	vsubpd %zmm6,%zmm9,%zmm18
   30511:	vfnmadd132pd %zmm0,%zmm18,%zmm2
   30517:	vfnmadd132pd %zmm0,%zmm18,%zmm14
   3051d:	vaddpd %zmm11,%zmm12,%zmm18
   30523:	vfnmadd132pd %zmm0,%zmm18,%zmm13
   30529:	vfmsub132pd %zmm0,%zmm18,%zmm8
   3052f:	vaddpd %zmm2,%zmm3,%zmm18
   30535:	vfnmadd132pd %zmm0,%zmm18,%zmm9
   3053b:	vfmsub132pd %zmm0,%zmm18,%zmm1
   30541:	vaddpd %zmm10,%zmm17,%zmm18
   30547:	vfmsub132pd %zmm0,%zmm13,%zmm12
   3054d:	vfmadd132pd %zmm0,%zmm8,%zmm11
   30553:	vfmadd132pd %zmm0,%zmm18,%zmm7
   30559:	vfnmadd132pd %zmm0,%zmm18,%zmm5
   3055f:	vaddpd %zmm14,%zmm15,%zmm18
   30565:	vfmsub132pd %zmm0,%zmm9,%zmm3
   3056b:	vfmadd132pd %zmm0,%zmm1,%zmm2
   30571:	vfmadd132pd %zmm0,%zmm18,%zmm6
   30577:	vfnmadd132pd %zmm0,%zmm18,%zmm4
   3057d:	vmovupd %zmm12,(%rax,%rdi,1)
   30584:	vfmsub132pd %zmm0,%zmm7,%zmm17
   3058a:	vfnmadd132pd %zmm0,%zmm5,%zmm10
   30590:	vmovupd %zmm3,(%rax,%r10,1)
   30597:	vfmsub132pd %zmm0,%zmm6,%zmm15
   3059d:	vfnmadd132pd %zmm0,%zmm4,%zmm14
   305a3:	vmovupd %zmm7,(%rax)
   305a9:	vmovupd %zmm6,(%rax,%rcx,8)
   305b0:	add    $0x40,%rax
   305b4:	vmovupd %zmm11,-0x40(%rax,%rsi,1)
   305bc:	vmovupd %zmm2,-0x40(%rax,%r9,1)
   305c4:	vmovupd %zmm5,-0x40(%rax,%r11,1)
   305cc:	vmovupd %zmm4,-0x40(%rax,%r8,1)
   305d4:	vmovupd %zmm13,(%rdx,%rdi,1)
   305db:	vmovupd %zmm9,(%rdx,%r10,1)
   305e2:	vmovupd %zmm17,(%rdx)
   305e8:	vmovupd %zmm15,(%rdx,%rcx,8)
   305ef:	add    $0x40,%rdx
   305f3:	vmovupd %zmm8,-0x40(%rdx,%rsi,1)
   305fb:	vmovupd %zmm1,-0x40(%rdx,%r9,1)
   30603:	vmovupd %zmm10,-0x40(%rdx,%r11,1)
   3060b:	vmovupd %zmm14,-0x40(%rdx,%r8,1)
   30613:	cmp    %r15,%rax
   30616:	jne    303f0 <hs_g52_nat+0xe0>
   3061c:	add    %rsi,%rbx
   3061f:	vmovq  %xmm16,%rax
   30625:	cmp    %rax,%rbx
   30628:	jb     303c0 <hs_g52_nat+0xb0>
   3062e:	vzeroupper
   30631:	lea    -0x28(%rbp),%rsp
   30635:	pop    %rbx
   30636:	pop    %r12
   30638:	pop    %r13
   3063a:	pop    %r14
   3063c:	pop    %r15
   3063e:	pop    %rbp
   3063f:	ret
   30640:	vzeroupper
   30643:	ret
   30644:	data16 cs nopw 0x0(%rax,%rax,1)
   3064f:	nop

0000000000030650 <hs_broken_g52>:
   30650:	endbr64
   30654:	vbroadcastsd 0x2c962(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   3065e:	test   %rsi,%rsi
   30661:	je     30980 <hs_broken_g52+0x330>
   30667:	push   %rbp
   30668:	mov    %rdx,%rcx
   3066b:	mov    %rsp,%rbp
   3066e:	push   %r15
   30670:	push   %r14
   30672:	push   %r13
   30674:	push   %r12
   30676:	mov    %rsi,%r12
   30679:	mov    %rdx,%rsi
   3067c:	push   %rbx
   3067d:	shl    $0x4,%rsi
   30681:	and    $0xffffffffffffffc0,%rsp
   30685:	test   %rdx,%rdx
   30688:	je     3096e <hs_broken_g52+0x31e>
   3068e:	lea    (%rdx,%rdx,4),%r8
   30692:	mov    %rdi,%rax
   30695:	lea    -0x1(%rdx),%rdx
   30699:	mov    %rcx,%r10
   3069c:	mov    %r8,%r14
   3069f:	lea    (%rdi,%rsi,1),%rbx
   306a3:	shr    $0x3,%rdx
   306a7:	add    $0x40,%rax
   306ab:	shl    $0x4,%r14
   306af:	vmovq  %rbx,%xmm1
   306b4:	lea    (%rcx,%rdx,4),%r13
   306b8:	xor    %ebx,%ebx
   306ba:	add    %rdi,%r14
   306bd:	neg    %r10
   306c0:	mov    %rsi,%rdi
   306c3:	mov    %rcx,%r11
   306c6:	lea    (%rcx,%rcx,2),%r9
   306ca:	vmovq  %rax,%xmm2
   306cf:	add    %r13,%r13
   306d2:	neg    %rdi
   306d5:	vmovq  %r12,%xmm16
   306db:	shl    $0x3,%r10
   306df:	vmovq  %xmm1,%r12
   306e4:	vbroadcastsd 0x2c6d2(%rip),%zmm0        # 5cdc0 <_IO_stdin_used+0xdc0>
   306ee:	shl    $0x3,%r9
   306f2:	shl    $0x5,%r11
   306f6:	vmovdqa64 %xmm2,%xmm19
   306fc:	shl    $0x3,%r8
   30700:	lea    0x0(,%rbx,8),%rdx
   30708:	lea    (%rbx,%r13,1),%r15
   3070c:	lea    (%rdx,%r12,1),%rax
   30710:	add    %r14,%rdx
   30713:	mov    %rax,-0x8(%rsp)
   30718:	vmovq  %xmm19,%rax
   3071e:	lea    (%rax,%r15,8),%r15
   30722:	mov    -0x8(%rsp),%rax
   30727:	nopw   0x0(%rax,%rax,1)
   30730:	vmovupd (%rax),%zmm4
   30736:	vmovupd (%rax,%r10,1),%zmm3
   3073d:	vmovapd %zmm0,%zmm8
   30743:	vmovapd %zmm0,%zmm13
   30749:	vaddpd (%rax,%rdi,1),%zmm3,%zmm17
   30750:	vsubpd (%rax,%rcx,8),%zmm4,%zmm15
   30757:	vmovupd (%rax,%r11,1),%zmm6
   3075e:	vmovupd (%rax,%r9,1),%zmm5
   30765:	vsubpd (%rax,%r8,1),%zmm6,%zmm3
   3076c:	vaddpd (%rax,%rsi,1),%zmm5,%zmm12
   30773:	vmovapd %zmm0,%zmm5
   30779:	vsubpd %zmm15,%zmm17,%zmm2
   3077f:	vmovupd (%rdx,%r10,1),%zmm7
   30786:	vaddpd (%rdx,%rdi,1),%zmm7,%zmm10
   3078d:	vmovupd (%rdx,%r9,1),%zmm7
   30794:	vaddpd (%rdx,%rsi,1),%zmm7,%zmm11
   3079b:	vmovapd %zmm0,%zmm7
   307a1:	vfmadd132pd %zmm4,%zmm2,%zmm8
   307a7:	vmovapd %zmm2,%zmm1
   307ad:	vaddpd %zmm3,%zmm12,%zmm2
   307b3:	vfmsub231pd (%rax,%rdi,1),%zmm0,%zmm1
   307ba:	vfnmadd132pd %zmm6,%zmm2,%zmm5
   307c0:	vmovapd %zmm2,%zmm4
   307c6:	vmovupd (%rdx),%zmm6
   307cc:	vsubpd (%rdx,%rcx,8),%zmm6,%zmm14
   307d3:	vfmsub231pd (%rax,%rsi,1),%zmm0,%zmm4
   307da:	vsubpd %zmm5,%zmm8,%zmm2
   307e0:	vfmadd132pd %zmm0,%zmm2,%zmm12
   307e6:	vfmsub132pd %zmm0,%zmm2,%zmm17
   307ec:	vaddpd %zmm4,%zmm1,%zmm2
   307f2:	vfmadd132pd %zmm0,%zmm2,%zmm3
   307f8:	vfnmadd132pd %zmm0,%zmm2,%zmm15
   307fe:	vsubpd %zmm14,%zmm10,%zmm2
   30804:	vfmadd132pd %zmm6,%zmm2,%zmm13
   3080a:	vfmsub231pd (%rdx,%rdi,1),%zmm0,%zmm2
   30811:	vmovupd (%rdx,%r11,1),%zmm6
   30818:	vmovapd %zmm2,%zmm9
   3081e:	vsubpd (%rdx,%r8,1),%zmm6,%zmm2
   30825:	vaddpd %zmm2,%zmm11,%zmm6
   3082b:	vfnmadd132pd (%rdx,%r11,1),%zmm6,%zmm7
   30832:	vfmsub231pd (%rdx,%rsi,1),%zmm0,%zmm6
   30839:	vaddpd %zmm7,%zmm13,%zmm18
   3083f:	vfnmadd132pd %zmm0,%zmm18,%zmm11
   30845:	vfmsub132pd %zmm0,%zmm18,%zmm10
   3084b:	vsubpd %zmm6,%zmm9,%zmm18
   30851:	vfnmadd132pd %zmm0,%zmm18,%zmm2
   30857:	vfnmadd132pd %zmm0,%zmm18,%zmm14
   3085d:	vaddpd %zmm11,%zmm12,%zmm18
   30863:	vfnmadd132pd %zmm0,%zmm18,%zmm13
   30869:	vfmsub132pd %zmm0,%zmm18,%zmm8
   3086f:	vaddpd %zmm2,%zmm3,%zmm18
   30875:	vfnmadd132pd %zmm0,%zmm18,%zmm9
   3087b:	vfmsub132pd %zmm0,%zmm18,%zmm1
   30881:	vaddpd %zmm10,%zmm17,%zmm18
   30887:	vfmsub132pd %zmm0,%zmm13,%zmm12
   3088d:	vfmadd132pd %zmm0,%zmm8,%zmm11
   30893:	vfmadd132pd %zmm0,%zmm18,%zmm7
   30899:	vfnmadd132pd %zmm0,%zmm18,%zmm5
   3089f:	vaddpd %zmm14,%zmm15,%zmm18
   308a5:	vfmsub132pd %zmm0,%zmm9,%zmm3
   308ab:	vfmadd132pd %zmm0,%zmm1,%zmm2
   308b1:	vfmadd132pd %zmm0,%zmm18,%zmm6
   308b7:	vfnmadd132pd %zmm0,%zmm18,%zmm4
   308bd:	vmovupd %zmm12,(%rax,%rdi,1)
   308c4:	vfmsub132pd %zmm0,%zmm7,%zmm17
   308ca:	vfnmadd132pd %zmm0,%zmm5,%zmm10
   308d0:	vmovupd %zmm3,(%rax,%r10,1)
   308d7:	vfmsub132pd %zmm0,%zmm6,%zmm15
   308dd:	vfnmadd132pd %zmm0,%zmm4,%zmm14
   308e3:	vmovupd %zmm7,(%rax)
   308e9:	vmovupd %zmm6,(%rax,%rcx,8)
   308f0:	add    $0x40,%rax
   308f4:	vmovupd %zmm11,-0x40(%rax,%rsi,1)
   308fc:	vmovupd %zmm5,-0x40(%rax,%r9,1)
   30904:	vmovupd %zmm2,-0x40(%rax,%r11,1)
   3090c:	vmovupd %zmm4,-0x40(%rax,%r8,1)
   30914:	vmovupd %zmm13,(%rdx,%rdi,1)
   3091b:	vmovupd %zmm9,(%rdx,%r10,1)
   30922:	vmovupd %zmm17,(%rdx)
   30928:	vmovupd %zmm15,(%rdx,%rcx,8)
   3092f:	add    $0x40,%rdx
   30933:	vmovupd %zmm8,-0x40(%rdx,%rsi,1)
   3093b:	vmovupd %zmm1,-0x40(%rdx,%r9,1)
   30943:	vmovupd %zmm10,-0x40(%rdx,%r11,1)
   3094b:	vmovupd %zmm14,-0x40(%rdx,%r8,1)
   30953:	cmp    %r15,%rax
   30956:	jne    30730 <hs_broken_g52+0xe0>
   3095c:	add    %rsi,%rbx
   3095f:	vmovq  %xmm16,%rax
   30965:	cmp    %rax,%rbx
   30968:	jb     30700 <hs_broken_g52+0xb0>
   3096e:	vzeroupper
   30971:	lea    -0x28(%rbp),%rsp
   30975:	pop    %rbx
   30976:	pop    %r12
   30978:	pop    %r13
   3097a:	pop    %r14
   3097c:	pop    %r15
   3097e:	pop    %rbp
   3097f:	ret
   30980:	vzeroupper
   30983:	ret
   30984:	data16 cs nopw 0x0(%rax,%rax,1)
   3098f:	nop

0000000000031d10 <hs_tb16_balS>:
   31d10:	endbr64
   31d14:	vbroadcastsd 0x2b2a2(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   31d1e:	test   %rsi,%rsi
   31d21:	je     320c3 <hs_tb16_balS+0x3b3>
   31d27:	push   %rbp
   31d28:	mov    %rdx,%rcx
   31d2b:	mov    %rsp,%rbp
   31d2e:	push   %r15
   31d30:	push   %r14
   31d32:	push   %r13
   31d34:	push   %r12
   31d36:	mov    %rsi,%r12
   31d39:	mov    %rdx,%rsi
   31d3c:	push   %rbx
   31d3d:	shl    $0x4,%rsi
   31d41:	and    $0xffffffffffffffc0,%rsp
   31d45:	test   %rdx,%rdx
   31d48:	je     320b1 <hs_tb16_balS+0x3a1>
   31d4e:	lea    (%rdx,%rdx,4),%r8
   31d52:	mov    %rdi,%rax
   31d55:	lea    -0x1(%rdx),%rdx
   31d59:	mov    %rcx,%r10
   31d5c:	mov    %r8,%r14
   31d5f:	lea    (%rdi,%rsi,1),%rbx
   31d63:	shr    $0x3,%rdx
   31d67:	add    $0x40,%rax
   31d6b:	shl    $0x4,%r14
   31d6f:	vmovq  %rbx,%xmm9
   31d74:	lea    (%rcx,%rdx,4),%r13
   31d78:	xor    %ebx,%ebx
   31d7a:	add    %rdi,%r14
   31d7d:	neg    %r10
   31d80:	mov    %rsi,%rdi
   31d83:	mov    %rcx,%r11
   31d86:	lea    (%rcx,%rcx,2),%r9
   31d8a:	vmovq  %rax,%xmm2
   31d8f:	add    %r13,%r13
   31d92:	neg    %rdi
   31d95:	vmovq  %r12,%xmm11
   31d9a:	shl    $0x3,%r10
   31d9e:	vmovq  %xmm9,%r12
   31da3:	vmovdqa64 %xmm2,%xmm27
   31da9:	shl    $0x3,%r9
   31dad:	shl    $0x5,%r11
   31db1:	shl    $0x3,%r8
   31db5:	lea    0x0(,%rbx,8),%rdx
   31dbd:	lea    (%rbx,%r13,1),%r15
   31dc1:	lea    (%rdx,%r12,1),%rax
   31dc5:	add    %r14,%rdx
   31dc8:	mov    %rax,-0x8(%rsp)
   31dcd:	vmovq  %xmm27,%rax
   31dd3:	lea    (%rax,%r15,8),%r15
   31dd7:	mov    -0x8(%rsp),%rax
   31ddc:	nopl   0x0(%rax)
   31de0:	vmovupd (%rax,%rdi,1),%zmm5
   31de7:	vmovupd (%rax),%zmm2
   31ded:	vmovupd (%rax,%r10,1),%zmm10
   31df4:	vmovupd (%rax,%rcx,8),%zmm6
   31dfb:	vsubpd (%rax,%r10,1),%zmm5,%zmm12
   31e02:	vsubpd (%rax,%rcx,8),%zmm2,%zmm13
   31e09:	vmovupd (%rdx,%rdi,1),%zmm3
   31e10:	vmovupd (%rax,%r9,1),%zmm9
   31e17:	vfmadd132pd %zmm0,%zmm5,%zmm10
   31e1d:	vfmadd132pd %zmm0,%zmm2,%zmm6
   31e23:	vmovupd (%rax,%rsi,1),%zmm5
   31e2a:	vmovupd (%rax,%r11,1),%zmm2
   31e31:	vmovupd (%rax,%r8,1),%zmm1
   31e38:	vmovupd (%rdx,%r10,1),%zmm7
   31e3f:	vsubpd %zmm13,%zmm12,%zmm19
   31e45:	vfmadd132pd %zmm0,%zmm12,%zmm13
   31e4b:	vsubpd (%rax,%r9,1),%zmm5,%zmm17
   31e52:	vsubpd (%rdx,%r10,1),%zmm3,%zmm14
   31e59:	vfmadd132pd %zmm0,%zmm5,%zmm9
   31e5f:	vmovupd (%rdx),%zmm4
   31e65:	vsubpd (%rax,%r8,1),%zmm2,%zmm5
   31e6c:	vfmadd132pd %zmm0,%zmm3,%zmm7
   31e72:	vmovupd (%rdx,%rcx,8),%zmm8
   31e79:	vmovupd (%rdx,%r9,1),%zmm3
   31e80:	vfmadd132pd %zmm0,%zmm2,%zmm1
   31e86:	vsubpd %zmm6,%zmm10,%zmm18
   31e8c:	vmovupd (%rdx,%rsi,1),%zmm2
   31e93:	vsubpd (%rdx,%rcx,8),%zmm4,%zmm15
   31e9a:	vfmadd132pd %zmm0,%zmm10,%zmm6
   31ea0:	vsubpd (%rdx,%r9,1),%zmm2,%zmm16
   31ea7:	vfmadd132pd %zmm0,%zmm4,%zmm8
   31ead:	vmovupd (%rdx,%r11,1),%zmm4
   31eb4:	vmovapd %zmm13,%zmm10
   31eba:	vfmadd132pd %zmm0,%zmm2,%zmm3
   31ec0:	vsubpd (%rdx,%r8,1),%zmm4,%zmm2
   31ec7:	vmovupd (%rdx,%r8,1),%zmm4
   31ece:	vsubpd %zmm5,%zmm17,%zmm12
   31ed4:	vfmadd213pd (%rdx,%r11,1),%zmm0,%zmm4
   31edb:	vsubpd %zmm15,%zmm14,%zmm21
   31ee1:	vsubpd %zmm1,%zmm9,%zmm13
   31ee7:	vfmadd132pd %zmm0,%zmm9,%zmm1
   31eed:	vfmadd132pd %zmm0,%zmm14,%zmm15
   31ef3:	vfmadd132pd %zmm0,%zmm17,%zmm5
   31ef9:	vsubpd %zmm8,%zmm7,%zmm17
   31eff:	vfmadd132pd %zmm0,%zmm7,%zmm8
   31f05:	vmovapd %zmm13,%zmm7
   31f0b:	vsubpd %zmm4,%zmm3,%zmm14
   31f11:	vfmadd132pd %zmm0,%zmm3,%zmm4
   31f17:	vsubpd %zmm2,%zmm16,%zmm3
   31f1d:	vfmadd132pd %zmm0,%zmm16,%zmm2
   31f23:	vsubpd %zmm1,%zmm6,%zmm16
   31f29:	vfmadd132pd %zmm0,%zmm6,%zmm1
   31f2f:	vmovapd %zmm12,%zmm6
   31f35:	vsubpd %zmm5,%zmm10,%zmm20
   31f3b:	vfmadd132pd %zmm0,%zmm18,%zmm7
   31f41:	vfmadd132pd %zmm0,%zmm10,%zmm5
   31f47:	vsubpd %zmm13,%zmm18,%zmm10
   31f4d:	vfmadd132pd %zmm0,%zmm19,%zmm6
   31f53:	vsubpd %zmm12,%zmm19,%zmm13
   31f59:	vsubpd %zmm14,%zmm17,%zmm12
   31f5f:	vsubpd %zmm4,%zmm8,%zmm19
   31f65:	vfmadd132pd %zmm0,%zmm17,%zmm14
   31f6b:	vfmadd132pd %zmm0,%zmm8,%zmm4
   31f71:	vsubpd %zmm2,%zmm15,%zmm18
   31f77:	vsubpd %zmm3,%zmm21,%zmm8
   31f7d:	vfmadd132pd %zmm0,%zmm15,%zmm2
   31f83:	vfmadd132pd %zmm0,%zmm21,%zmm3
   31f89:	vmovapd %zmm12,%zmm17
   31f8f:	vmovapd %zmm19,%zmm22
   31f95:	vfmadd132pd %zmm0,%zmm10,%zmm17
   31f9b:	vmovapd %zmm18,%zmm21
   31fa1:	vmovapd %zmm8,%zmm15
   31fa7:	vmovapd %zmm14,%zmm24
   31fad:	vfmadd132pd %zmm0,%zmm16,%zmm22
   31fb3:	vmovapd %zmm4,%zmm26
   31fb9:	vfmadd132pd %zmm0,%zmm7,%zmm24
   31fbf:	vsubpd %zmm14,%zmm7,%zmm7
   31fc5:	vmovapd %zmm2,%zmm25
   31fcb:	vmovapd %zmm3,%zmm23
   31fd1:	vfmadd132pd %zmm0,%zmm1,%zmm26
   31fd7:	vfmadd132pd %zmm0,%zmm5,%zmm25
   31fdd:	vsubpd %zmm4,%zmm1,%zmm1
   31fe3:	vfmadd132pd %zmm0,%zmm6,%zmm23
   31fe9:	vfmadd132pd %zmm0,%zmm20,%zmm21
   31fef:	vsubpd %zmm2,%zmm5,%zmm5
   31ff5:	vfmadd132pd %zmm0,%zmm13,%zmm15
   31ffb:	vsubpd %zmm3,%zmm6,%zmm6
   32001:	vsubpd %zmm19,%zmm16,%zmm4
   32007:	vsubpd %zmm18,%zmm20,%zmm3
   3200d:	vsubpd %zmm12,%zmm10,%zmm2
   32013:	vmovupd %zmm26,(%rax,%rdi,1)
   3201a:	vmovupd %zmm25,(%rax,%r10,1)
   32021:	vmovupd %zmm24,(%rax)
   32027:	vmovupd %zmm23,(%rax,%rcx,8)
   3202e:	add    $0x40,%rax
   32032:	vmovupd %zmm22,-0x40(%rax,%rsi,1)
   3203a:	vmovupd %zmm21,-0x40(%rax,%r9,1)
   32042:	vmovupd %zmm17,-0x40(%rax,%r11,1)
   3204a:	vmovupd %zmm15,-0x40(%rax,%r8,1)
   32052:	vmovupd %zmm1,(%rdx,%rdi,1)
   32059:	vsubpd %zmm8,%zmm13,%zmm1
   3205f:	vmovupd %zmm5,(%rdx,%r10,1)
   32066:	vmovupd %zmm7,(%rdx)
   3206c:	vmovupd %zmm6,(%rdx,%rcx,8)
   32073:	add    $0x40,%rdx
   32077:	vmovupd %zmm4,-0x40(%rdx,%rsi,1)
   3207f:	vmovupd %zmm3,-0x40(%rdx,%r9,1)
   32087:	vmovupd %zmm2,-0x40(%rdx,%r11,1)
   3208f:	vmovupd %zmm1,-0x40(%rdx,%r8,1)
   32097:	cmp    %r15,%rax
   3209a:	jne    31de0 <hs_tb16_balS+0xd0>
   320a0:	add    %rsi,%rbx
   320a3:	vmovq  %xmm11,%rax
   320a8:	cmp    %rax,%rbx
   320ab:	jb     31db5 <hs_tb16_balS+0xa5>
   320b1:	vzeroupper
   320b4:	lea    -0x28(%rbp),%rsp
   320b8:	pop    %rbx
   320b9:	pop    %r12
   320bb:	pop    %r13
   320bd:	pop    %r14
   320bf:	pop    %r15
   320c1:	pop    %rbp
   320c2:	ret
   320c3:	vzeroupper
   320c6:	ret
   320c7:	nopw   0x0(%rax,%rax,1)

0000000000034ea0 <hf2_g19_nat>:
   34ea0:	endbr64
   34ea4:	vbroadcastsd 0x28112(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   34eae:	mov    %rdi,%rax
   34eb1:	test   %rsi,%rsi
   34eb4:	je     3519d <hf2_g19_nat+0x2fd>
   34eba:	lea    -0x8(,%rsi,8),%rdx
   34ec2:	mov    $0xffffffaa,%ecx
   34ec7:	vmovdqa64 0x27f6f(%rip),%zmm7        # 5ce40 <_IO_stdin_used+0xe40>
   34ed1:	vmovdqa64 0x27fa5(%rip),%zmm6        # 5ce80 <_IO_stdin_used+0xe80>
   34edb:	and    $0xfffffffffffffe00,%rdx
   34ee2:	kmovw  %ecx,%k3
   34ee6:	mov    $0xffffffcc,%ecx
   34eeb:	vmovdqa64 0x27fcb(%rip),%zmm5        # 5cec0 <_IO_stdin_used+0xec0>
   34ef5:	vbroadcastsd 0x27ec1(%rip),%zmm0        # 5cdc0 <_IO_stdin_used+0xdc0>
   34eff:	lea    0x200(%rdi,%rdx,1),%rdx
   34f07:	kmovw  %ecx,%k2
   34f0b:	mov    $0xfffffff0,%edi
   34f10:	kmovw  %edi,%k1
   34f14:	nopl   0x0(%rax)
   34f18:	vpermpd (%rax),%zmm7,%zmm1
   34f1e:	vaddpd (%rax),%zmm1,%zmm2
   34f24:	add    $0x200,%rax
   34f2a:	vsubpd -0x200(%rax),%zmm1,%zmm2{%k3}
   34f31:	vpermpd %zmm2,%zmm6,%zmm3
   34f37:	vaddpd %zmm2,%zmm3,%zmm1
   34f3d:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   34f43:	vpermpd %zmm1,%zmm5,%zmm2
   34f49:	vaddpd %zmm2,%zmm1,%zmm4
   34f4f:	vsubpd %zmm1,%zmm2,%zmm4{%k1}
   34f55:	vpermpd -0x1c0(%rax),%zmm7,%zmm2
   34f5c:	vaddpd -0x1c0(%rax),%zmm2,%zmm1
   34f63:	vsubpd -0x1c0(%rax),%zmm2,%zmm1{%k3}
   34f6a:	vpermpd %zmm1,%zmm6,%zmm3
   34f70:	vaddpd %zmm3,%zmm1,%zmm2
   34f76:	vsubpd %zmm1,%zmm3,%zmm2{%k2}
   34f7c:	vpermpd %zmm2,%zmm5,%zmm3
   34f82:	vaddpd %zmm3,%zmm2,%zmm1
   34f88:	vsubpd %zmm2,%zmm3,%zmm1{%k1}
   34f8e:	vmovapd %zmm1,%zmm9
   34f94:	vpermpd -0x180(%rax),%zmm7,%zmm1
   34f9b:	vaddpd -0x180(%rax),%zmm1,%zmm2
   34fa2:	vsubpd -0x180(%rax),%zmm1,%zmm2{%k3}
   34fa9:	vpermpd %zmm2,%zmm6,%zmm3
   34faf:	vaddpd %zmm3,%zmm2,%zmm1
   34fb5:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   34fbb:	vpermpd %zmm1,%zmm5,%zmm2
   34fc1:	vaddpd %zmm2,%zmm1,%zmm3
   34fc7:	vsubpd %zmm1,%zmm2,%zmm3{%k1}
   34fcd:	vpermpd -0x140(%rax),%zmm7,%zmm1
   34fd4:	vaddpd -0x140(%rax),%zmm1,%zmm2
   34fdb:	vsubpd -0x140(%rax),%zmm1,%zmm2{%k3}
   34fe2:	vpermpd %zmm2,%zmm6,%zmm8
   34fe8:	vaddpd %zmm8,%zmm2,%zmm1
   34fee:	vsubpd %zmm2,%zmm8,%zmm1{%k2}
   34ff4:	vpermpd %zmm1,%zmm5,%zmm2
   34ffa:	vaddpd %zmm2,%zmm1,%zmm8
   35000:	vsubpd %zmm1,%zmm2,%zmm8{%k1}
   35006:	vpermpd -0x100(%rax),%zmm7,%zmm1
   3500d:	vaddpd -0x100(%rax),%zmm1,%zmm2
   35014:	vsubpd -0x100(%rax),%zmm1,%zmm2{%k3}
   3501b:	vpermpd %zmm2,%zmm6,%zmm10
   35021:	vaddpd %zmm10,%zmm2,%zmm1
   35027:	vsubpd %zmm2,%zmm10,%zmm1{%k2}
   3502d:	vpermpd %zmm1,%zmm5,%zmm2
   35033:	vaddpd %zmm2,%zmm1,%zmm10
   35039:	vsubpd %zmm1,%zmm2,%zmm10{%k1}
   3503f:	vpermpd -0xc0(%rax),%zmm7,%zmm1
   35046:	vaddpd -0xc0(%rax),%zmm1,%zmm2
   3504d:	vsubpd -0xc0(%rax),%zmm1,%zmm2{%k3}
   35054:	vpermpd %zmm2,%zmm6,%zmm11
   3505a:	vaddpd %zmm11,%zmm2,%zmm1
   35060:	vsubpd %zmm2,%zmm11,%zmm1{%k2}
   35066:	vpermpd %zmm1,%zmm5,%zmm2
   3506c:	vaddpd %zmm2,%zmm1,%zmm11
   35072:	vsubpd %zmm1,%zmm2,%zmm11{%k1}
   35078:	vpermpd -0x80(%rax),%zmm7,%zmm1
   3507f:	vaddpd -0x80(%rax),%zmm1,%zmm2
   35086:	vsubpd -0x80(%rax),%zmm1,%zmm2{%k3}
   3508d:	vsubpd %zmm11,%zmm3,%zmm3
   35093:	vpermpd %zmm2,%zmm6,%zmm12
   35099:	vaddpd %zmm12,%zmm2,%zmm1
   3509f:	vsubpd %zmm2,%zmm12,%zmm1{%k2}
   350a5:	vpermpd %zmm1,%zmm5,%zmm12
   350ab:	vaddpd %zmm12,%zmm1,%zmm2
   350b1:	vsubpd %zmm1,%zmm12,%zmm2{%k1}
   350b7:	vpermpd -0x40(%rax),%zmm7,%zmm12
   350be:	vaddpd -0x40(%rax),%zmm12,%zmm1
   350c5:	vsubpd -0x40(%rax),%zmm12,%zmm1{%k3}
   350cc:	vpermpd %zmm1,%zmm6,%zmm13
   350d2:	vaddpd %zmm1,%zmm13,%zmm12
   350d8:	vsubpd %zmm1,%zmm13,%zmm12{%k2}
   350de:	vpermpd %zmm12,%zmm5,%zmm13
   350e4:	vaddpd %zmm13,%zmm12,%zmm1
   350ea:	vsubpd %zmm12,%zmm13,%zmm1{%k1}
   350f0:	vsubpd %zmm10,%zmm8,%zmm12
   350f6:	vaddpd %zmm2,%zmm9,%zmm13
   350fc:	vaddpd %zmm1,%zmm4,%zmm4
   35102:	vaddpd %zmm12,%zmm3,%zmm15
   35108:	vsubpd %zmm13,%zmm4,%zmm14
   3510e:	vsubpd %zmm15,%zmm14,%zmm16
   35114:	vfnmadd132pd %zmm0,%zmm16,%zmm1
   3511a:	vfnmadd132pd %zmm0,%zmm16,%zmm11
   35120:	vfmadd132pd %zmm0,%zmm1,%zmm2
   35126:	vfnmadd132pd %zmm0,%zmm11,%zmm10
   3512c:	vfmadd132pd %zmm0,%zmm11,%zmm8
   35132:	vfmadd231pd %zmm0,%zmm9,%zmm1
   35138:	vfmadd132pd %zmm0,%zmm2,%zmm12
   3513e:	vfmadd132pd %zmm0,%zmm2,%zmm3
   35144:	vfmsub132pd %zmm0,%zmm8,%zmm14
   3514a:	vfmadd132pd %zmm0,%zmm10,%zmm13
   35150:	vmovupd %zmm1,-0x180(%rax)
   35157:	vfmadd132pd %zmm0,%zmm1,%zmm15
   3515d:	vfmsub132pd %zmm0,%zmm10,%zmm4
   35163:	vmovupd %zmm8,-0x140(%rax)
   3516a:	vmovupd %zmm3,-0x1c0(%rax)
   35171:	vmovupd %zmm14,-0xc0(%rax)
   35178:	vmovupd %zmm4,-0x200(%rax)
   3517f:	vmovupd %zmm15,-0x100(%rax)
   35186:	vmovupd %zmm13,-0x80(%rax)
   3518d:	vmovupd %zmm12,-0x40(%rax)
   35194:	cmp    %rdx,%rax
   35197:	jne    34f18 <hf2_g19_nat+0x78>
   3519d:	vzeroupper
   351a0:	ret
   351a1:	data16 cs nopw 0x0(%rax,%rax,1)
   351ac:	nopl   0x0(%rax)

0000000000035460 <hf2_h20_nat>:
   35460:	endbr64
   35464:	vbroadcastsd 0x27b52(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   3546e:	mov    %rdi,%rax
   35471:	test   %rsi,%rsi
   35474:	je     35757 <hf2_h20_nat+0x2f7>
   3547a:	lea    -0x8(,%rsi,8),%rdx
   35482:	mov    $0xffffffaa,%ecx
   35487:	vmovdqa64 0x279af(%rip),%zmm7        # 5ce40 <_IO_stdin_used+0xe40>
   35491:	vmovdqa64 0x279e5(%rip),%zmm6        # 5ce80 <_IO_stdin_used+0xe80>
   3549b:	and    $0xfffffffffffffe00,%rdx
   354a2:	kmovw  %ecx,%k3
   354a6:	mov    $0xffffffcc,%ecx
   354ab:	vmovdqa64 0x27a0b(%rip),%zmm5        # 5cec0 <_IO_stdin_used+0xec0>
   354b5:	vbroadcastsd 0x278f9(%rip),%zmm9        # 5cdb8 <_IO_stdin_used+0xdb8>
   354bf:	lea    0x200(%rdi,%rdx,1),%rdx
   354c7:	kmovw  %ecx,%k2
   354cb:	mov    $0xfffffff0,%edi
   354d0:	kmovw  %edi,%k1
   354d4:	nopl   0x0(%rax)
   354d8:	vpermpd (%rax),%zmm7,%zmm0
   354de:	vaddpd (%rax),%zmm0,%zmm1
   354e4:	add    $0x200,%rax
   354ea:	vsubpd -0x200(%rax),%zmm0,%zmm1{%k3}
   354f1:	vpermpd %zmm1,%zmm6,%zmm2
   354f7:	vaddpd %zmm1,%zmm2,%zmm0
   354fd:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   35503:	vpermpd %zmm0,%zmm5,%zmm1
   35509:	vaddpd %zmm1,%zmm0,%zmm4
   3550f:	vsubpd %zmm0,%zmm1,%zmm4{%k1}
   35515:	vpermpd -0x1c0(%rax),%zmm7,%zmm0
   3551c:	vaddpd -0x1c0(%rax),%zmm0,%zmm1
   35523:	vsubpd -0x1c0(%rax),%zmm0,%zmm1{%k3}
   3552a:	vpermpd %zmm1,%zmm6,%zmm2
   35530:	vaddpd %zmm2,%zmm1,%zmm0
   35536:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   3553c:	vpermpd %zmm0,%zmm5,%zmm1
   35542:	vaddpd %zmm1,%zmm0,%zmm10
   35548:	vsubpd %zmm0,%zmm1,%zmm10{%k1}
   3554e:	vpermpd -0x180(%rax),%zmm7,%zmm0
   35555:	vaddpd -0x180(%rax),%zmm0,%zmm1
   3555c:	vsubpd -0x180(%rax),%zmm0,%zmm1{%k3}
   35563:	vpermpd %zmm1,%zmm6,%zmm2
   35569:	vaddpd %zmm2,%zmm1,%zmm0
   3556f:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   35575:	vpermpd %zmm0,%zmm5,%zmm1
   3557b:	vaddpd %zmm1,%zmm0,%zmm3
   35581:	vsubpd %zmm0,%zmm1,%zmm3{%k1}
   35587:	vpermpd -0x140(%rax),%zmm7,%zmm0
   3558e:	vaddpd -0x140(%rax),%zmm0,%zmm1
   35595:	vsubpd -0x140(%rax),%zmm0,%zmm1{%k3}
   3559c:	vpermpd %zmm1,%zmm6,%zmm2
   355a2:	vaddpd %zmm2,%zmm1,%zmm0
   355a8:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   355ae:	vpermpd %zmm0,%zmm5,%zmm1
   355b4:	vaddpd %zmm1,%zmm0,%zmm11
   355ba:	vsubpd %zmm0,%zmm1,%zmm11{%k1}
   355c0:	vpermpd -0x100(%rax),%zmm7,%zmm0
   355c7:	vaddpd -0x100(%rax),%zmm0,%zmm1
   355ce:	vsubpd -0x100(%rax),%zmm0,%zmm1{%k3}
   355d5:	vpermpd %zmm1,%zmm6,%zmm2
   355db:	vaddpd %zmm2,%zmm1,%zmm0
   355e1:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   355e7:	vpermpd %zmm0,%zmm5,%zmm1
   355ed:	vaddpd %zmm1,%zmm0,%zmm8
   355f3:	vsubpd %zmm0,%zmm1,%zmm8{%k1}
   355f9:	vpermpd -0xc0(%rax),%zmm7,%zmm0
   35600:	vaddpd -0xc0(%rax),%zmm0,%zmm1
   35607:	vsubpd -0xc0(%rax),%zmm0,%zmm1{%k3}
   3560e:	vpermpd %zmm1,%zmm6,%zmm2
   35614:	vaddpd %zmm2,%zmm1,%zmm0
   3561a:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   35620:	vpermpd %zmm0,%zmm5,%zmm1
   35626:	vaddpd %zmm1,%zmm0,%zmm16
   3562c:	vsubpd %zmm0,%zmm1,%zmm16{%k1}
   35632:	vpermpd -0x80(%rax),%zmm7,%zmm0
   35639:	vaddpd -0x80(%rax),%zmm0,%zmm1
   35640:	vsubpd -0x80(%rax),%zmm0,%zmm1{%k3}
   35647:	vsubpd %zmm16,%zmm3,%zmm3
   3564d:	vpermpd %zmm1,%zmm6,%zmm2
   35653:	vaddpd %zmm2,%zmm1,%zmm0
   35659:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
   3565f:	vpermpd %zmm0,%zmm5,%zmm1
   35665:	vaddpd %zmm1,%zmm0,%zmm2
   3566b:	vsubpd %zmm0,%zmm1,%zmm2{%k1}
   35671:	vpermpd -0x40(%rax),%zmm7,%zmm1
   35678:	vaddpd -0x40(%rax),%zmm1,%zmm0
   3567f:	vsubpd -0x40(%rax),%zmm1,%zmm0{%k3}
   35686:	vaddpd %zmm2,%zmm10,%zmm13
   3568c:	vpermpd %zmm0,%zmm6,%zmm12
   35692:	vaddpd %zmm0,%zmm12,%zmm1
   35698:	vsubpd %zmm0,%zmm12,%zmm1{%k2}
   3569e:	vpermpd %zmm1,%zmm5,%zmm12
   356a4:	vaddpd %zmm12,%zmm1,%zmm0
   356aa:	vsubpd %zmm1,%zmm12,%zmm0{%k1}
   356b0:	vsubpd %zmm8,%zmm11,%zmm12
   356b6:	vaddpd %zmm0,%zmm4,%zmm4
   356bc:	vaddpd %zmm12,%zmm3,%zmm15
   356c2:	vsubpd %zmm13,%zmm4,%zmm14
   356c8:	vsubpd %zmm15,%zmm14,%zmm1
   356ce:	vfmsub231pd %zmm9,%zmm1,%zmm0
   356d4:	vfmsub132pd %zmm9,%zmm16,%zmm1
   356da:	vaddpd %zmm2,%zmm0,%zmm2
   356e0:	vsubpd %zmm8,%zmm1,%zmm8
   356e6:	vaddpd %zmm10,%zmm0,%zmm0
   356ec:	vaddpd %zmm11,%zmm1,%zmm1
   356f2:	vsubpd %zmm8,%zmm4,%zmm4
   356f8:	vaddpd %zmm2,%zmm3,%zmm3
   356fe:	vaddpd %zmm0,%zmm15,%zmm15
   35704:	vsubpd %zmm1,%zmm14,%zmm14
   3570a:	vmovupd %zmm0,-0x180(%rax)
   35711:	vaddpd %zmm8,%zmm13,%zmm13
   35717:	vaddpd %zmm2,%zmm12,%zmm12
   3571d:	vmovupd %zmm1,-0x140(%rax)
   35724:	vmovupd %zmm4,-0x200(%rax)
   3572b:	vmovupd %zmm3,-0x1c0(%rax)
   35732:	vmovupd %zmm15,-0x100(%rax)
   35739:	vmovupd %zmm14,-0xc0(%rax)
   35740:	vmovupd %zmm13,-0x80(%rax)
   35747:	vmovupd %zmm12,-0x40(%rax)
   3574e:	cmp    %rdx,%rax
   35751:	jne    354d8 <hf2_h20_nat+0x78>
   35757:	vzeroupper
   3575a:	ret
   3575b:	nopl   0x0(%rax,%rax,1)

0000000000035760 <hf2_g20_nat>:
   35760:	endbr64
   35764:	vbroadcastsd 0x27852(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   3576e:	mov    %rdi,%rax
   35771:	test   %rsi,%rsi
   35774:	je     35a5d <hf2_g20_nat+0x2fd>
   3577a:	lea    -0x8(,%rsi,8),%rdx
   35782:	mov    $0xffffffaa,%ecx
   35787:	vmovdqa64 0x276af(%rip),%zmm11        # 5ce40 <_IO_stdin_used+0xe40>
   35791:	vmovdqa64 0x276e5(%rip),%zmm10        # 5ce80 <_IO_stdin_used+0xe80>
   3579b:	and    $0xfffffffffffffe00,%rdx
   357a2:	kmovw  %ecx,%k3
   357a6:	mov    $0xffffffcc,%ecx
   357ab:	vmovdqa64 0x2770b(%rip),%zmm9        # 5cec0 <_IO_stdin_used+0xec0>
   357b5:	vbroadcastsd 0x27601(%rip),%zmm0        # 5cdc0 <_IO_stdin_used+0xdc0>
   357bf:	lea    0x200(%rdi,%rdx,1),%rdx
   357c7:	kmovw  %ecx,%k2
   357cb:	mov    $0xfffffff0,%edi
   357d0:	kmovw  %edi,%k1
   357d4:	nopl   0x0(%rax)
   357d8:	vpermpd (%rax),%zmm11,%zmm1
   357de:	vaddpd (%rax),%zmm1,%zmm2
   357e4:	add    $0x200,%rax
   357ea:	vsubpd -0x200(%rax),%zmm1,%zmm2{%k3}
   357f1:	vpermpd %zmm2,%zmm10,%zmm3
   357f7:	vaddpd %zmm2,%zmm3,%zmm1
   357fd:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   35803:	vpermpd %zmm1,%zmm9,%zmm2
   35809:	vaddpd %zmm2,%zmm1,%zmm5
   3580f:	vsubpd %zmm1,%zmm2,%zmm5{%k1}
   35815:	vpermpd -0x1c0(%rax),%zmm11,%zmm1
   3581c:	vaddpd -0x1c0(%rax),%zmm1,%zmm2
   35823:	vsubpd -0x1c0(%rax),%zmm1,%zmm2{%k3}
   3582a:	vpermpd %zmm2,%zmm10,%zmm3
   35830:	vaddpd %zmm3,%zmm2,%zmm1
   35836:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   3583c:	vpermpd %zmm1,%zmm9,%zmm2
   35842:	vaddpd %zmm2,%zmm1,%zmm4
   35848:	vsubpd %zmm1,%zmm2,%zmm4{%k1}
   3584e:	vpermpd -0x180(%rax),%zmm11,%zmm1
   35855:	vaddpd -0x180(%rax),%zmm1,%zmm2
   3585c:	vsubpd -0x180(%rax),%zmm1,%zmm2{%k3}
   35863:	vaddpd %zmm4,%zmm5,%zmm4
   35869:	vpermpd %zmm2,%zmm10,%zmm3
   3586f:	vaddpd %zmm3,%zmm2,%zmm1
   35875:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   3587b:	vpermpd %zmm1,%zmm9,%zmm2
   35881:	vaddpd %zmm2,%zmm1,%zmm8
   35887:	vsubpd %zmm1,%zmm2,%zmm8{%k1}
   3588d:	vpermpd -0x140(%rax),%zmm11,%zmm1
   35894:	vaddpd -0x140(%rax),%zmm1,%zmm2
   3589b:	vsubpd -0x140(%rax),%zmm1,%zmm2{%k3}
   358a2:	vpermpd %zmm2,%zmm10,%zmm3
   358a8:	vaddpd %zmm3,%zmm2,%zmm1
   358ae:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   358b4:	vpermpd %zmm1,%zmm9,%zmm2
   358ba:	vaddpd %zmm2,%zmm1,%zmm7
   358c0:	vsubpd %zmm1,%zmm2,%zmm7{%k1}
   358c6:	vpermpd -0x100(%rax),%zmm11,%zmm1
   358cd:	vaddpd -0x100(%rax),%zmm1,%zmm2
   358d4:	vsubpd -0x100(%rax),%zmm1,%zmm2{%k3}
   358db:	vsubpd %zmm7,%zmm8,%zmm7
   358e1:	vpermpd %zmm2,%zmm10,%zmm3
   358e7:	vaddpd %zmm3,%zmm2,%zmm1
   358ed:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   358f3:	vpermpd %zmm1,%zmm9,%zmm2
   358f9:	vaddpd %zmm2,%zmm1,%zmm3
   358ff:	vsubpd %zmm1,%zmm2,%zmm3{%k1}
   35905:	vpermpd -0xc0(%rax),%zmm11,%zmm1
   3590c:	vaddpd -0xc0(%rax),%zmm1,%zmm2
   35913:	vsubpd -0xc0(%rax),%zmm1,%zmm2{%k3}
   3591a:	vpermpd %zmm2,%zmm10,%zmm6
   35920:	vaddpd %zmm6,%zmm2,%zmm1
   35926:	vsubpd %zmm2,%zmm6,%zmm1{%k2}
   3592c:	vpermpd %zmm1,%zmm9,%zmm2
   35932:	vaddpd %zmm2,%zmm1,%zmm6
   35938:	vsubpd %zmm1,%zmm2,%zmm6{%k1}
   3593e:	vpermpd -0x80(%rax),%zmm11,%zmm2
   35945:	vaddpd -0x80(%rax),%zmm2,%zmm1
   3594c:	vsubpd -0x80(%rax),%zmm2,%zmm1{%k3}
   35953:	vaddpd %zmm6,%zmm3,%zmm6
   35959:	vpermpd %zmm1,%zmm10,%zmm12
   3595f:	vaddpd %zmm12,%zmm1,%zmm2
   35965:	vsubpd %zmm1,%zmm12,%zmm2{%k2}
   3596b:	vpermpd %zmm2,%zmm9,%zmm12
   35971:	vaddpd %zmm12,%zmm2,%zmm1
   35977:	vsubpd %zmm2,%zmm12,%zmm1{%k1}
   3597d:	vpermpd -0x40(%rax),%zmm11,%zmm12
   35984:	vaddpd -0x40(%rax),%zmm12,%zmm2
   3598b:	vsubpd -0x40(%rax),%zmm12,%zmm2{%k3}
   35992:	vpermpd %zmm2,%zmm10,%zmm13
   35998:	vaddpd %zmm2,%zmm13,%zmm12
   3599e:	vsubpd %zmm2,%zmm13,%zmm12{%k2}
   359a4:	vpermpd %zmm12,%zmm9,%zmm13
   359aa:	vaddpd %zmm13,%zmm12,%zmm2
   359b0:	vsubpd %zmm12,%zmm13,%zmm2{%k1}
   359b6:	vsubpd %zmm7,%zmm4,%zmm12
   359bc:	vsubpd %zmm2,%zmm1,%zmm2
   359c2:	vfmadd132pd %zmm0,%zmm12,%zmm8
   359c8:	vfmsub132pd %zmm0,%zmm12,%zmm5
   359ce:	vaddpd %zmm2,%zmm6,%zmm12
   359d4:	vfnmadd132pd %zmm0,%zmm12,%zmm1
   359da:	vfmsub132pd %zmm0,%zmm12,%zmm3
   359e0:	vaddpd %zmm1,%zmm8,%zmm12
   359e6:	vfnmadd132pd %zmm0,%zmm12,%zmm6
   359ec:	vfmsub132pd %zmm0,%zmm12,%zmm4
   359f2:	vaddpd %zmm3,%zmm5,%zmm12
   359f8:	vfmadd132pd %zmm0,%zmm12,%zmm2
   359fe:	vfnmadd132pd %zmm0,%zmm12,%zmm7
   35a04:	vfmsub132pd %zmm0,%zmm6,%zmm8
   35a0a:	vfmadd132pd %zmm0,%zmm4,%zmm1
   35a10:	vmovupd %zmm6,-0x100(%rax)
   35a17:	vmovupd %zmm4,-0x80(%rax)
   35a1e:	vfmsub132pd %zmm0,%zmm2,%zmm5
   35a24:	vfnmadd132pd %zmm0,%zmm7,%zmm3
   35a2a:	vmovupd %zmm2,-0x1c0(%rax)
   35a31:	vmovupd %zmm7,-0x140(%rax)
   35a38:	vmovupd %zmm8,-0x200(%rax)
   35a3f:	vmovupd %zmm1,-0x180(%rax)
   35a46:	vmovupd %zmm5,-0xc0(%rax)
   35a4d:	vmovupd %zmm3,-0x40(%rax)
   35a54:	cmp    %rdx,%rax
   35a57:	jne    357d8 <hf2_g20_nat+0x78>
   35a5d:	vzeroupper
   35a60:	ret
   35a61:	data16 cs nopw 0x0(%rax,%rax,1)
   35a6c:	nopl   0x0(%rax)

0000000000037050 <hf2_broken_g20>:
   37050:	endbr64
   37054:	vbroadcastsd 0x25f62(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   3705e:	mov    %rdi,%rax
   37061:	test   %rsi,%rsi
   37064:	je     3734d <hf2_broken_g20+0x2fd>
   3706a:	lea    -0x8(,%rsi,8),%rdx
   37072:	mov    $0xffffffaa,%ecx
   37077:	vmovdqa64 0x25dbf(%rip),%zmm11        # 5ce40 <_IO_stdin_used+0xe40>
   37081:	vmovdqa64 0x25df5(%rip),%zmm10        # 5ce80 <_IO_stdin_used+0xe80>
   3708b:	and    $0xfffffffffffffe00,%rdx
   37092:	kmovw  %ecx,%k3
   37096:	mov    $0xffffffcc,%ecx
   3709b:	vmovdqa64 0x25e1b(%rip),%zmm9        # 5cec0 <_IO_stdin_used+0xec0>
   370a5:	vbroadcastsd 0x25d11(%rip),%zmm0        # 5cdc0 <_IO_stdin_used+0xdc0>
   370af:	lea    0x200(%rdi,%rdx,1),%rdx
   370b7:	kmovw  %ecx,%k2
   370bb:	mov    $0xfffffff0,%edi
   370c0:	kmovw  %edi,%k1
   370c4:	nopl   0x0(%rax)
   370c8:	vpermpd (%rax),%zmm11,%zmm1
   370ce:	vaddpd (%rax),%zmm1,%zmm2
   370d4:	add    $0x200,%rax
   370da:	vsubpd -0x200(%rax),%zmm1,%zmm2{%k3}
   370e1:	vpermpd %zmm2,%zmm10,%zmm3
   370e7:	vaddpd %zmm2,%zmm3,%zmm1
   370ed:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   370f3:	vpermpd %zmm1,%zmm9,%zmm2
   370f9:	vaddpd %zmm2,%zmm1,%zmm4
   370ff:	vsubpd %zmm1,%zmm2,%zmm4{%k1}
   37105:	vpermpd -0x1c0(%rax),%zmm11,%zmm1
   3710c:	vaddpd -0x1c0(%rax),%zmm1,%zmm2
   37113:	vsubpd -0x1c0(%rax),%zmm1,%zmm2{%k3}
   3711a:	vpermpd %zmm2,%zmm10,%zmm3
   37120:	vaddpd %zmm3,%zmm2,%zmm1
   37126:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   3712c:	vpermpd %zmm1,%zmm9,%zmm2
   37132:	vaddpd %zmm2,%zmm1,%zmm5
   37138:	vsubpd %zmm1,%zmm2,%zmm5{%k1}
   3713e:	vpermpd -0x180(%rax),%zmm11,%zmm1
   37145:	vaddpd -0x180(%rax),%zmm1,%zmm2
   3714c:	vsubpd -0x180(%rax),%zmm1,%zmm2{%k3}
   37153:	vaddpd %zmm5,%zmm4,%zmm5
   37159:	vpermpd %zmm2,%zmm10,%zmm3
   3715f:	vaddpd %zmm3,%zmm2,%zmm1
   37165:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   3716b:	vpermpd %zmm1,%zmm9,%zmm2
   37171:	vaddpd %zmm2,%zmm1,%zmm8
   37177:	vsubpd %zmm1,%zmm2,%zmm8{%k1}
   3717d:	vpermpd -0x140(%rax),%zmm11,%zmm1
   37184:	vaddpd -0x140(%rax),%zmm1,%zmm2
   3718b:	vsubpd -0x140(%rax),%zmm1,%zmm2{%k3}
   37192:	vpermpd %zmm2,%zmm10,%zmm3
   37198:	vaddpd %zmm3,%zmm2,%zmm1
   3719e:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   371a4:	vpermpd %zmm1,%zmm9,%zmm2
   371aa:	vaddpd %zmm2,%zmm1,%zmm7
   371b0:	vsubpd %zmm1,%zmm2,%zmm7{%k1}
   371b6:	vpermpd -0x100(%rax),%zmm11,%zmm1
   371bd:	vaddpd -0x100(%rax),%zmm1,%zmm2
   371c4:	vsubpd -0x100(%rax),%zmm1,%zmm2{%k3}
   371cb:	vsubpd %zmm7,%zmm8,%zmm7
   371d1:	vpermpd %zmm2,%zmm10,%zmm3
   371d7:	vaddpd %zmm3,%zmm2,%zmm1
   371dd:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   371e3:	vpermpd %zmm1,%zmm9,%zmm2
   371e9:	vaddpd %zmm2,%zmm1,%zmm3
   371ef:	vsubpd %zmm1,%zmm2,%zmm3{%k1}
   371f5:	vpermpd -0xc0(%rax),%zmm11,%zmm1
   371fc:	vaddpd -0xc0(%rax),%zmm1,%zmm2
   37203:	vsubpd -0xc0(%rax),%zmm1,%zmm2{%k3}
   3720a:	vpermpd %zmm2,%zmm10,%zmm6
   37210:	vaddpd %zmm6,%zmm2,%zmm1
   37216:	vsubpd %zmm2,%zmm6,%zmm1{%k2}
   3721c:	vpermpd %zmm1,%zmm9,%zmm2
   37222:	vaddpd %zmm2,%zmm1,%zmm6
   37228:	vsubpd %zmm1,%zmm2,%zmm6{%k1}
   3722e:	vpermpd -0x80(%rax),%zmm11,%zmm2
   37235:	vaddpd -0x80(%rax),%zmm2,%zmm1
   3723c:	vsubpd -0x80(%rax),%zmm2,%zmm1{%k3}
   37243:	vaddpd %zmm6,%zmm3,%zmm6
   37249:	vpermpd %zmm1,%zmm10,%zmm12
   3724f:	vaddpd %zmm12,%zmm1,%zmm2
   37255:	vsubpd %zmm1,%zmm12,%zmm2{%k2}
   3725b:	vpermpd %zmm2,%zmm9,%zmm12
   37261:	vaddpd %zmm12,%zmm2,%zmm1
   37267:	vsubpd %zmm2,%zmm12,%zmm1{%k1}
   3726d:	vpermpd -0x40(%rax),%zmm11,%zmm12
   37274:	vaddpd -0x40(%rax),%zmm12,%zmm2
   3727b:	vsubpd -0x40(%rax),%zmm12,%zmm2{%k3}
   37282:	vpermpd %zmm2,%zmm10,%zmm13
   37288:	vaddpd %zmm13,%zmm2,%zmm12
   3728e:	vsubpd %zmm2,%zmm13,%zmm12{%k2}
   37294:	vpermpd %zmm12,%zmm9,%zmm13
   3729a:	vaddpd %zmm13,%zmm12,%zmm2
   372a0:	vsubpd %zmm12,%zmm13,%zmm2{%k1}
   372a6:	vsubpd %zmm7,%zmm5,%zmm12
   372ac:	vsubpd %zmm2,%zmm1,%zmm2
   372b2:	vfmadd132pd %zmm0,%zmm12,%zmm8
   372b8:	vfmsub132pd %zmm0,%zmm12,%zmm4
   372be:	vaddpd %zmm2,%zmm6,%zmm12
   372c4:	vfnmadd132pd %zmm0,%zmm12,%zmm1
   372ca:	vfmsub132pd %zmm0,%zmm12,%zmm3
   372d0:	vaddpd %zmm1,%zmm8,%zmm12
   372d6:	vfnmadd132pd %zmm0,%zmm12,%zmm6
   372dc:	vfmsub132pd %zmm0,%zmm12,%zmm5
   372e2:	vaddpd %zmm3,%zmm4,%zmm12
   372e8:	vfmadd132pd %zmm0,%zmm12,%zmm2
   372ee:	vfnmadd132pd %zmm0,%zmm12,%zmm7
   372f4:	vfmsub132pd %zmm0,%zmm6,%zmm8
   372fa:	vfmadd132pd %zmm0,%zmm5,%zmm1
   37300:	vmovupd %zmm6,-0x100(%rax)
   37307:	vmovupd %zmm5,-0xc0(%rax)
   3730e:	vfmsub132pd %zmm0,%zmm2,%zmm4
   37314:	vfnmadd132pd %zmm0,%zmm7,%zmm3
   3731a:	vmovupd %zmm2,-0x1c0(%rax)
   37321:	vmovupd %zmm7,-0x140(%rax)
   37328:	vmovupd %zmm8,-0x200(%rax)
   3732f:	vmovupd %zmm1,-0x180(%rax)
   37336:	vmovupd %zmm4,-0x80(%rax)
   3733d:	vmovupd %zmm3,-0x40(%rax)
   37344:	cmp    %rdx,%rax
   37347:	jne    370c8 <hf2_broken_g20+0x78>
   3734d:	vzeroupper
   37350:	ret
   37351:	data16 cs nopw 0x0(%rax,%rax,1)
   3735c:	nopl   0x0(%rax)

0000000000037c40 <hf0_g19_nat>:
   37c40:	endbr64
   37c44:	push   %rbp
   37c45:	mov    %rdi,%rdx
   37c48:	mov    %rsp,%rbp
   37c4b:	and    $0xffffffffffffffc0,%rsp
   37c4f:	sub    $0x100,%rsp
   37c56:	vbroadcastsd 0x25360(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   37c60:	mov    %fs:0x28,%rax
   37c69:	mov    %rax,0xf8(%rsp)
   37c71:	xor    %eax,%eax
   37c73:	mov    %rsp,%rdi
   37c76:	vzeroupper
   37c79:	call   ea60 <inl_consts.constprop.1>
   37c7e:	vmovapd (%rsp),%zmm4
   37c85:	vmovapd 0x40(%rsp),%zmm5
   37c8d:	vmovapd 0x80(%rsp),%zmm6
   37c95:	test   %rsi,%rsi
   37c98:	je     37eeb <hf0_g19_nat+0x2ab>
   37c9e:	vbroadcastsd 0x25118(%rip),%zmm3        # 5cdc0 <_IO_stdin_used+0xdc0>
   37ca8:	mov    %rdx,%rax
   37cab:	lea    -0x8(,%rsi,8),%rdx
   37cb3:	and    $0xfffffffffffffe00,%rdx
   37cba:	lea    0x200(%rax,%rdx,1),%rdx
   37cc2:	nopw   0x0(%rax,%rax,1)
   37cc8:	vpermilpd $0x55,(%rax),%zmm0
   37ccf:	vfmadd231pd (%rax),%zmm4,%zmm0
   37cd5:	add    $0x200,%rax
   37cdb:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   37ce2:	vfmadd132pd %zmm5,%zmm1,%zmm0
   37ce8:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   37cef:	vfmadd132pd %zmm6,%zmm1,%zmm0
   37cf5:	vmovapd %zmm0,%zmm9
   37cfb:	vpermilpd $0x55,-0x1c0(%rax),%zmm0
   37d03:	vfmadd231pd -0x1c0(%rax),%zmm4,%zmm0
   37d0a:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   37d11:	vfmadd132pd %zmm5,%zmm1,%zmm0
   37d17:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   37d1e:	vfmadd132pd %zmm6,%zmm1,%zmm0
   37d24:	vmovapd %zmm0,%zmm8
   37d2a:	vpermilpd $0x55,-0x180(%rax),%zmm0
   37d32:	vfmadd231pd -0x180(%rax),%zmm4,%zmm0
   37d39:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   37d40:	vfmadd132pd %zmm5,%zmm1,%zmm0
   37d46:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   37d4d:	vmovapd %zmm0,%zmm7
   37d53:	vpermilpd $0x55,-0x140(%rax),%zmm0
   37d5b:	vfmadd231pd -0x140(%rax),%zmm4,%zmm0
   37d62:	vfmadd132pd %zmm6,%zmm1,%zmm7
   37d68:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   37d6f:	vfmadd132pd %zmm5,%zmm1,%zmm0
   37d75:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   37d7c:	vfmadd132pd %zmm6,%zmm1,%zmm0
   37d82:	vmovapd %zmm0,%zmm10
   37d88:	vpermilpd $0x55,-0x100(%rax),%zmm0
   37d90:	vfmadd231pd -0x100(%rax),%zmm4,%zmm0
   37d97:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   37d9e:	vfmadd132pd %zmm5,%zmm1,%zmm0
   37da4:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   37dab:	vfmadd132pd %zmm6,%zmm1,%zmm0
   37db1:	vmovapd %zmm0,%zmm11
   37db7:	vpermilpd $0x55,-0xc0(%rax),%zmm0
   37dbf:	vfmadd231pd -0xc0(%rax),%zmm4,%zmm0
   37dc6:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   37dcd:	vfmadd132pd %zmm5,%zmm1,%zmm0
   37dd3:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   37dda:	vmovapd %zmm0,%zmm2
   37de0:	vpermilpd $0x55,-0x80(%rax),%zmm0
   37de8:	vfmadd231pd -0x80(%rax),%zmm4,%zmm0
   37def:	vfmadd132pd %zmm6,%zmm1,%zmm2
   37df5:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   37dfc:	vsubpd %zmm2,%zmm7,%zmm7
   37e02:	vfmadd132pd %zmm5,%zmm1,%zmm0
   37e08:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   37e0f:	vfmadd231pd %zmm6,%zmm0,%zmm1
   37e15:	vpermilpd $0x55,-0x40(%rax),%zmm0
   37e1d:	vfmadd231pd -0x40(%rax),%zmm4,%zmm0
   37e24:	vaddpd %zmm1,%zmm8,%zmm13
   37e2a:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm12
   37e31:	vfmadd132pd %zmm5,%zmm12,%zmm0
   37e37:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm12
   37e3e:	vfmadd132pd %zmm6,%zmm12,%zmm0
   37e44:	vsubpd %zmm11,%zmm10,%zmm12
   37e4a:	vaddpd %zmm12,%zmm7,%zmm15
   37e50:	vaddpd %zmm0,%zmm9,%zmm9
   37e56:	vsubpd %zmm13,%zmm9,%zmm14
   37e5c:	vsubpd %zmm15,%zmm14,%zmm16
   37e62:	vfnmadd132pd %zmm3,%zmm16,%zmm0
   37e68:	vfnmadd132pd %zmm3,%zmm16,%zmm2
   37e6e:	vfmadd132pd %zmm3,%zmm0,%zmm1
   37e74:	vfnmadd132pd %zmm3,%zmm2,%zmm11
   37e7a:	vfmadd231pd %zmm3,%zmm8,%zmm0
   37e80:	vfmadd231pd %zmm3,%zmm10,%zmm2
   37e86:	vfmadd132pd %zmm3,%zmm1,%zmm12
   37e8c:	vfmadd132pd %zmm3,%zmm1,%zmm7
   37e92:	vfmsub132pd %zmm3,%zmm2,%zmm14
   37e98:	vfmadd132pd %zmm3,%zmm11,%zmm13
   37e9e:	vmovupd %zmm0,-0x180(%rax)
   37ea5:	vfmadd132pd %zmm3,%zmm0,%zmm15
   37eab:	vfmsub132pd %zmm3,%zmm11,%zmm9
   37eb1:	vmovupd %zmm2,-0x140(%rax)
   37eb8:	vmovupd %zmm7,-0x1c0(%rax)
   37ebf:	vmovupd %zmm14,-0xc0(%rax)
   37ec6:	vmovupd %zmm9,-0x200(%rax)
   37ecd:	vmovupd %zmm15,-0x100(%rax)
   37ed4:	vmovupd %zmm13,-0x80(%rax)
   37edb:	vmovupd %zmm12,-0x40(%rax)
   37ee2:	cmp    %rax,%rdx
   37ee5:	jne    37cc8 <hf0_g19_nat+0x88>
   37eeb:	mov    0xf8(%rsp),%rax
   37ef3:	sub    %fs:0x28,%rax
   37efc:	jne    37f03 <hf0_g19_nat+0x2c3>
   37efe:	vzeroupper
   37f01:	leave
   37f02:	ret
   37f03:	vzeroupper
   37f06:	call   4280 <__stack_chk_fail@plt>
   37f0b:	nopl   0x0(%rax,%rax,1)

0000000000038870 <pass_tb8_nat_1>:
   38870:	endbr64
   38874:	vbroadcastsd 0x24742(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   3887e:	test   %rsi,%rsi
   38881:	je     389ba <pass_tb8_nat_1+0x14a>
   38887:	lea    -0x1(%rsi),%r8
   3888b:	mov    %rsi,%rax
   3888e:	lea    0x0(,%rsi,8),%rcx
   38896:	and    $0xfffffffffffffff8,%r8
   3889a:	shl    $0x5,%rax
   3889e:	lea    (%rdi,%rcx,1),%rdx
   388a2:	neg    %rcx
   388a5:	add    %rsi,%r8
   388a8:	add    %rdi,%rax
   388ab:	lea    0x40(%rdi,%r8,8),%r9
   388b0:	mov    %rsi,%r8
   388b3:	lea    (%rsi,%rsi,2),%rdi
   388b7:	shl    $0x4,%r8
   388bb:	shl    $0x3,%rdi
   388bf:	nop
   388c0:	vmovupd (%rdx,%rcx,1),%zmm7
   388c7:	vmovupd (%rdx,%rsi,8),%zmm3
   388ce:	vaddpd (%rdx),%zmm7,%zmm2
   388d4:	vaddpd (%rax,%rcx,1),%zmm3,%zmm6
   388db:	vsubpd (%rax,%rcx,1),%zmm3,%zmm5
   388e2:	vsubpd (%rdx),%zmm7,%zmm0
   388e8:	vmovupd (%rax),%zmm7
   388ee:	vaddpd (%rax,%rsi,8),%zmm7,%zmm3
   388f5:	vsubpd (%rax,%rsi,8),%zmm7,%zmm1
   388fc:	vmovupd (%rax,%r8,1),%zmm7
   38903:	vaddpd (%rax,%rdi,1),%zmm7,%zmm9
   3890a:	vsubpd (%rax,%rdi,1),%zmm7,%zmm4
   38911:	vaddpd %zmm6,%zmm2,%zmm7
   38917:	vsubpd %zmm6,%zmm2,%zmm2
   3891d:	vaddpd %zmm5,%zmm0,%zmm6
   38923:	vsubpd %zmm5,%zmm0,%zmm0
   38929:	vaddpd %zmm9,%zmm3,%zmm8
   3892f:	vaddpd %zmm4,%zmm1,%zmm5
   38935:	vsubpd %zmm4,%zmm1,%zmm1
   3893b:	vsubpd %zmm9,%zmm3,%zmm3
   38941:	vaddpd %zmm8,%zmm7,%zmm4
   38947:	vsubpd %zmm8,%zmm7,%zmm7
   3894d:	vmovupd %zmm4,(%rdx,%rcx,1)
   38954:	vaddpd %zmm5,%zmm6,%zmm4
   3895a:	vsubpd %zmm5,%zmm6,%zmm6
   38960:	vmovupd %zmm4,(%rdx)
   38966:	vaddpd %zmm3,%zmm2,%zmm4
   3896c:	vsubpd %zmm3,%zmm2,%zmm2
   38972:	vmovupd %zmm4,(%rdx,%rsi,8)
   38979:	vaddpd %zmm1,%zmm0,%zmm4
   3897f:	add    $0x40,%rdx
   38983:	vsubpd %zmm1,%zmm0,%zmm0
   38989:	vmovupd %zmm4,(%rax,%rcx,1)
   38990:	vmovupd %zmm7,(%rax)
   38996:	vmovupd %zmm6,(%rax,%rsi,8)
   3899d:	add    $0x40,%rax
   389a1:	vmovupd %zmm2,-0x40(%rax,%r8,1)
   389a9:	vmovupd %zmm0,-0x40(%rax,%rdi,1)
   389b1:	cmp    %rdx,%r9
   389b4:	jne    388c0 <pass_tb8_nat_1+0x50>
   389ba:	vzeroupper
   389bd:	ret
   389be:	xchg   %ax,%ax

00000000000389c0 <pass_tb8_balS_1>:
   389c0:	endbr64
   389c4:	vbroadcastsd 0x245f2(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   389ce:	test   %rsi,%rsi
   389d1:	je     38b3b <pass_tb8_balS_1+0x17b>
   389d7:	lea    -0x1(%rsi),%r8
   389db:	mov    %rsi,%rax
   389de:	lea    0x0(,%rsi,8),%rcx
   389e6:	and    $0xfffffffffffffff8,%r8
   389ea:	shl    $0x5,%rax
   389ee:	lea    (%rdi,%rcx,1),%rdx
   389f2:	neg    %rcx
   389f5:	add    %rsi,%r8
   389f8:	add    %rdi,%rax
   389fb:	lea    0x40(%rdi,%r8,8),%r9
   38a00:	mov    %rsi,%r8
   38a03:	lea    (%rsi,%rsi,2),%rdi
   38a07:	shl    $0x4,%r8
   38a0b:	shl    $0x3,%rdi
   38a0f:	nop
   38a10:	vmovupd (%rdx,%rcx,1),%zmm7
   38a17:	vmovupd (%rdx),%zmm6
   38a1d:	vsubpd (%rdx),%zmm7,%zmm8
   38a23:	vmovupd (%rdx,%rsi,8),%zmm4
   38a2a:	vmovupd (%rax,%rcx,1),%zmm1
   38a31:	vmovupd (%rax,%rsi,8),%zmm5
   38a38:	vfmadd132pd %zmm0,%zmm7,%zmm6
   38a3e:	vmovupd (%rax),%zmm7
   38a44:	vmovupd (%rax,%rdi,1),%zmm2
   38a4b:	vfmadd132pd %zmm0,%zmm4,%zmm1
   38a51:	vfmadd213pd (%rax,%r8,1),%zmm0,%zmm2
   38a58:	vsubpd (%rax,%rsi,8),%zmm7,%zmm9
   38a5f:	vfmadd132pd %zmm0,%zmm7,%zmm5
   38a65:	vsubpd (%rax,%rcx,1),%zmm4,%zmm3
   38a6c:	vmovupd (%rax,%r8,1),%zmm4
   38a73:	vsubpd (%rax,%rdi,1),%zmm4,%zmm4
   38a7a:	vsubpd %zmm1,%zmm6,%zmm7
   38a80:	vfmadd132pd %zmm0,%zmm6,%zmm1
   38a86:	vsubpd %zmm3,%zmm8,%zmm6
   38a8c:	vfmadd132pd %zmm0,%zmm8,%zmm3
   38a92:	vsubpd %zmm2,%zmm5,%zmm8
   38a98:	vfmadd132pd %zmm0,%zmm5,%zmm2
   38a9e:	vsubpd %zmm4,%zmm9,%zmm5
   38aa4:	vfmadd132pd %zmm0,%zmm9,%zmm4
   38aaa:	vmovapd %zmm8,%zmm10
   38ab0:	vfmadd132pd %zmm0,%zmm7,%zmm10
   38ab6:	vmovapd %zmm5,%zmm9
   38abc:	vsubpd %zmm8,%zmm7,%zmm7
   38ac2:	vfmadd132pd %zmm0,%zmm6,%zmm9
   38ac8:	vsubpd %zmm5,%zmm6,%zmm6
   38ace:	vmovapd %zmm2,%zmm12
   38ad4:	vmovapd %zmm4,%zmm11
   38ada:	vfmadd132pd %zmm0,%zmm1,%zmm12
   38ae0:	vsubpd %zmm2,%zmm1,%zmm1
   38ae6:	vfmadd132pd %zmm0,%zmm3,%zmm11
   38aec:	vsubpd %zmm4,%zmm3,%zmm3
   38af2:	vmovupd %zmm12,(%rdx,%rcx,1)
   38af9:	vmovupd %zmm11,(%rdx)
   38aff:	vmovupd %zmm10,(%rdx,%rsi,8)
   38b06:	add    $0x40,%rdx
   38b0a:	vmovupd %zmm9,(%rax,%rcx,1)
   38b11:	vmovupd %zmm1,(%rax)
   38b17:	vmovupd %zmm3,(%rax,%rsi,8)
   38b1e:	add    $0x40,%rax
   38b22:	vmovupd %zmm7,-0x40(%rax,%r8,1)
   38b2a:	vmovupd %zmm6,-0x40(%rax,%rdi,1)
   38b32:	cmp    %rdx,%r9
   38b35:	jne    38a10 <pass_tb8_balS_1+0x50>
   38b3b:	vzeroupper
   38b3e:	ret
   38b3f:	nop

0000000000038b40 <pass_tb8_bal_1>:
   38b40:	endbr64
   38b44:	vbroadcastsd 0x24472(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   38b4e:	test   %rsi,%rsi
   38b51:	je     38cd5 <pass_tb8_bal_1+0x195>
   38b57:	lea    -0x1(%rsi),%r8
   38b5b:	mov    %rsi,%rax
   38b5e:	lea    0x0(,%rsi,8),%rcx
   38b66:	and    $0xfffffffffffffff8,%r8
   38b6a:	shl    $0x5,%rax
   38b6e:	lea    (%rdi,%rcx,1),%rdx
   38b72:	neg    %rcx
   38b75:	add    %rsi,%r8
   38b78:	add    %rdi,%rax
   38b7b:	lea    0x40(%rdi,%r8,8),%r9
   38b80:	mov    %rsi,%r8
   38b83:	lea    (%rsi,%rsi,2),%rdi
   38b87:	shl    $0x4,%r8
   38b8b:	shl    $0x3,%rdi
   38b8f:	nop
   38b90:	vmovupd (%rax,%rcx,1),%zmm7
   38b97:	vfmadd213pd (%rdx,%rsi,8),%zmm0,%zmm7
   38b9e:	vmovupd (%rdx),%zmm3
   38ba4:	vfmadd213pd (%rdx,%rcx,1),%zmm0,%zmm3
   38bab:	vmovupd (%rax,%rdi,1),%zmm10
   38bb2:	vfmadd213pd (%rax,%r8,1),%zmm0,%zmm10
   38bb9:	vmovupd (%rdx,%rcx,1),%zmm2
   38bc0:	vmovupd (%rax,%rsi,8),%zmm4
   38bc7:	vsubpd (%rdx),%zmm2,%zmm1
   38bcd:	vfmadd213pd (%rax),%zmm0,%zmm4
   38bd3:	vmovupd (%rdx,%rsi,8),%zmm2
   38bda:	vsubpd (%rax,%rcx,1),%zmm2,%zmm6
   38be1:	vmovapd %zmm7,%zmm8
   38be7:	vmovupd (%rax),%zmm5
   38bed:	vsubpd (%rax,%rsi,8),%zmm5,%zmm2
   38bf4:	vfmadd132pd %zmm0,%zmm3,%zmm8
   38bfa:	vsubpd %zmm7,%zmm3,%zmm3
   38c00:	vmovupd (%rax,%r8,1),%zmm5
   38c07:	vsubpd (%rax,%rdi,1),%zmm5,%zmm5
   38c0e:	vmovapd %zmm10,%zmm9
   38c14:	vmovapd %zmm6,%zmm7
   38c1a:	vfmadd132pd %zmm0,%zmm1,%zmm7
   38c20:	vsubpd %zmm6,%zmm1,%zmm1
   38c26:	vmovapd %zmm5,%zmm6
   38c2c:	vfmadd132pd %zmm0,%zmm4,%zmm9
   38c32:	vsubpd %zmm10,%zmm4,%zmm4
   38c38:	vfmadd132pd %zmm0,%zmm2,%zmm6
   38c3e:	vsubpd %zmm5,%zmm2,%zmm2
   38c44:	vmovapd %zmm4,%zmm10
   38c4a:	vfmadd132pd %zmm0,%zmm3,%zmm10
   38c50:	vmovapd %zmm2,%zmm5
   38c56:	vsubpd %zmm4,%zmm3,%zmm3
   38c5c:	vmovapd %zmm9,%zmm12
   38c62:	vfmadd132pd %zmm0,%zmm1,%zmm5
   38c68:	vsubpd %zmm2,%zmm1,%zmm1
   38c6e:	vmovapd %zmm6,%zmm11
   38c74:	vfmadd132pd %zmm0,%zmm8,%zmm12
   38c7a:	vsubpd %zmm9,%zmm8,%zmm8
   38c80:	vfmadd132pd %zmm0,%zmm7,%zmm11
   38c86:	vsubpd %zmm6,%zmm7,%zmm7
   38c8c:	vmovupd %zmm12,(%rdx,%rcx,1)
   38c93:	vmovupd %zmm11,(%rdx)
   38c99:	vmovupd %zmm10,(%rdx,%rsi,8)
   38ca0:	add    $0x40,%rdx
   38ca4:	vmovupd %zmm5,(%rax,%rcx,1)
   38cab:	vmovupd %zmm8,(%rax)
   38cb1:	vmovupd %zmm7,(%rax,%rsi,8)
   38cb8:	add    $0x40,%rax
   38cbc:	vmovupd %zmm3,-0x40(%rax,%r8,1)
   38cc4:	vmovupd %zmm1,-0x40(%rax,%rdi,1)
   38ccc:	cmp    %rdx,%r9
   38ccf:	jne    38b90 <pass_tb8_bal_1+0x50>
   38cd5:	vzeroupper
   38cd8:	ret
   38cd9:	nopl   0x0(%rax)

00000000000396d0 <hf0_h20_nat>:
   396d0:	endbr64
   396d4:	push   %rbp
   396d5:	mov    %rdi,%rdx
   396d8:	mov    %rsp,%rbp
   396db:	and    $0xffffffffffffffc0,%rsp
   396df:	sub    $0x100,%rsp
   396e6:	vbroadcastsd 0x238d0(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   396f0:	mov    %fs:0x28,%rax
   396f9:	mov    %rax,0xf8(%rsp)
   39701:	xor    %eax,%eax
   39703:	mov    %rsp,%rdi
   39706:	vzeroupper
   39709:	call   ea60 <inl_consts.constprop.1>
   3970e:	vmovapd (%rsp),%zmm3
   39715:	vmovapd 0x40(%rsp),%zmm4
   3971d:	vmovapd 0x80(%rsp),%zmm5
   39725:	test   %rsi,%rsi
   39728:	je     3997b <hf0_h20_nat+0x2ab>
   3972e:	vbroadcastsd 0x23680(%rip),%zmm6        # 5cdb8 <_IO_stdin_used+0xdb8>
   39738:	mov    %rdx,%rax
   3973b:	lea    -0x8(,%rsi,8),%rdx
   39743:	and    $0xfffffffffffffe00,%rdx
   3974a:	lea    0x200(%rax,%rdx,1),%rdx
   39752:	nopw   0x0(%rax,%rax,1)
   39758:	vpermilpd $0x55,(%rax),%zmm0
   3975f:	vfmadd231pd (%rax),%zmm3,%zmm0
   39765:	add    $0x200,%rax
   3976b:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   39772:	vfmadd132pd %zmm4,%zmm1,%zmm0
   39778:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   3977f:	vfmadd132pd %zmm5,%zmm1,%zmm0
   39785:	vmovapd %zmm0,%zmm10
   3978b:	vpermilpd $0x55,-0x1c0(%rax),%zmm0
   39793:	vfmadd231pd -0x1c0(%rax),%zmm3,%zmm0
   3979a:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   397a1:	vfmadd132pd %zmm4,%zmm1,%zmm0
   397a7:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   397ae:	vfmadd132pd %zmm5,%zmm1,%zmm0
   397b4:	vmovapd %zmm0,%zmm9
   397ba:	vpermilpd $0x55,-0x180(%rax),%zmm0
   397c2:	vfmadd231pd -0x180(%rax),%zmm3,%zmm0
   397c9:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   397d0:	vfmadd132pd %zmm4,%zmm1,%zmm0
   397d6:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   397dd:	vfmadd132pd %zmm5,%zmm1,%zmm0
   397e3:	vmovapd %zmm0,%zmm8
   397e9:	vpermilpd $0x55,-0x140(%rax),%zmm0
   397f1:	vfmadd231pd -0x140(%rax),%zmm3,%zmm0
   397f8:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   397ff:	vfmadd132pd %zmm4,%zmm1,%zmm0
   39805:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   3980c:	vfmadd132pd %zmm5,%zmm1,%zmm0
   39812:	vmovapd %zmm0,%zmm12
   39818:	vpermilpd $0x55,-0x100(%rax),%zmm0
   39820:	vfmadd231pd -0x100(%rax),%zmm3,%zmm0
   39827:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   3982e:	vfmadd132pd %zmm4,%zmm1,%zmm0
   39834:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   3983b:	vfmadd132pd %zmm5,%zmm1,%zmm0
   39841:	vmovapd %zmm0,%zmm11
   39847:	vpermilpd $0x55,-0xc0(%rax),%zmm0
   3984f:	vfmadd231pd -0xc0(%rax),%zmm3,%zmm0
   39856:	vsubpd %zmm11,%zmm12,%zmm13
   3985c:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   39863:	vfmadd132pd %zmm4,%zmm1,%zmm0
   39869:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   39870:	vmovapd %zmm0,%zmm2
   39876:	vpermilpd $0x55,-0x80(%rax),%zmm0
   3987e:	vfmadd231pd -0x80(%rax),%zmm3,%zmm0
   39885:	vfmadd132pd %zmm5,%zmm1,%zmm2
   3988b:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   39892:	vsubpd %zmm2,%zmm8,%zmm8
   39898:	vfmadd132pd %zmm4,%zmm1,%zmm0
   3989e:	vaddpd %zmm13,%zmm8,%zmm16
   398a4:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   398ab:	vfmadd231pd %zmm5,%zmm0,%zmm1
   398b1:	vpermilpd $0x55,-0x40(%rax),%zmm0
   398b9:	vfmadd231pd -0x40(%rax),%zmm3,%zmm0
   398c0:	vaddpd %zmm1,%zmm9,%zmm14
   398c6:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm7
   398cd:	vfmadd132pd %zmm4,%zmm7,%zmm0
   398d3:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm7
   398da:	vfmadd132pd %zmm5,%zmm7,%zmm0
   398e0:	vaddpd %zmm0,%zmm10,%zmm10
   398e6:	vsubpd %zmm14,%zmm10,%zmm15
   398ec:	vsubpd %zmm16,%zmm15,%zmm7
   398f2:	vfmsub231pd %zmm6,%zmm7,%zmm0
   398f8:	vfmsub231pd %zmm6,%zmm7,%zmm2
   398fe:	vaddpd %zmm1,%zmm0,%zmm1
   39904:	vsubpd %zmm11,%zmm2,%zmm7
   3990a:	vaddpd %zmm9,%zmm0,%zmm0
   39910:	vaddpd %zmm12,%zmm2,%zmm2
   39916:	vsubpd %zmm7,%zmm10,%zmm10
   3991c:	vaddpd %zmm1,%zmm8,%zmm8
   39922:	vaddpd %zmm0,%zmm16,%zmm16
   39928:	vsubpd %zmm2,%zmm15,%zmm15
   3992e:	vmovupd %zmm0,-0x180(%rax)
   39935:	vaddpd %zmm7,%zmm14,%zmm14
   3993b:	vaddpd %zmm1,%zmm13,%zmm13
   39941:	vmovupd %zmm2,-0x140(%rax)
   39948:	vmovupd %zmm10,-0x200(%rax)
   3994f:	vmovupd %zmm8,-0x1c0(%rax)
   39956:	vmovupd %zmm16,-0x100(%rax)
   3995d:	vmovupd %zmm15,-0xc0(%rax)
   39964:	vmovupd %zmm14,-0x80(%rax)
   3996b:	vmovupd %zmm13,-0x40(%rax)
   39972:	cmp    %rax,%rdx
   39975:	jne    39758 <hf0_h20_nat+0x88>
   3997b:	mov    0xf8(%rsp),%rax
   39983:	sub    %fs:0x28,%rax
   3998c:	jne    39993 <hf0_h20_nat+0x2c3>
   3998e:	vzeroupper
   39991:	leave
   39992:	ret
   39993:	vzeroupper
   39996:	call   4280 <__stack_chk_fail@plt>
   3999b:	nopl   0x0(%rax,%rax,1)

00000000000399a0 <hf0_g20_nat>:
   399a0:	endbr64
   399a4:	push   %rbp
   399a5:	mov    %rdi,%rdx
   399a8:	mov    %rsp,%rbp
   399ab:	and    $0xffffffffffffffc0,%rsp
   399af:	sub    $0x100,%rsp
   399b6:	vbroadcastsd 0x23600(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   399c0:	mov    %fs:0x28,%rax
   399c9:	mov    %rax,0xf8(%rsp)
   399d1:	xor    %eax,%eax
   399d3:	mov    %rsp,%rdi
   399d6:	vzeroupper
   399d9:	call   ea60 <inl_consts.constprop.1>
   399de:	vmovapd (%rsp),%zmm4
   399e5:	vmovapd 0x40(%rsp),%zmm5
   399ed:	vmovapd 0x80(%rsp),%zmm6
   399f5:	test   %rsi,%rsi
   399f8:	je     39c4b <hf0_g20_nat+0x2ab>
   399fe:	vbroadcastsd 0x233b8(%rip),%zmm3        # 5cdc0 <_IO_stdin_used+0xdc0>
   39a08:	mov    %rdx,%rax
   39a0b:	lea    -0x8(,%rsi,8),%rdx
   39a13:	and    $0xfffffffffffffe00,%rdx
   39a1a:	lea    0x200(%rax,%rdx,1),%rdx
   39a22:	nopw   0x0(%rax,%rax,1)
   39a28:	vpermilpd $0x55,(%rax),%zmm0
   39a2f:	vfmadd231pd (%rax),%zmm4,%zmm0
   39a35:	add    $0x200,%rax
   39a3b:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   39a42:	vfmadd132pd %zmm5,%zmm1,%zmm0
   39a48:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   39a4f:	vfmadd132pd %zmm6,%zmm1,%zmm0
   39a55:	vmovapd %zmm0,%zmm9
   39a5b:	vpermilpd $0x55,-0x1c0(%rax),%zmm0
   39a63:	vfmadd231pd -0x1c0(%rax),%zmm4,%zmm0
   39a6a:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   39a71:	vfmadd132pd %zmm5,%zmm1,%zmm0
   39a77:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   39a7e:	vfmadd132pd %zmm6,%zmm1,%zmm0
   39a84:	vmovapd %zmm0,%zmm8
   39a8a:	vpermilpd $0x55,-0x180(%rax),%zmm0
   39a92:	vfmadd231pd -0x180(%rax),%zmm4,%zmm0
   39a99:	vaddpd %zmm8,%zmm9,%zmm8
   39a9f:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   39aa6:	vfmadd132pd %zmm5,%zmm1,%zmm0
   39aac:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   39ab3:	vfmadd132pd %zmm6,%zmm1,%zmm0
   39ab9:	vmovapd %zmm0,%zmm11
   39abf:	vpermilpd $0x55,-0x140(%rax),%zmm0
   39ac7:	vfmadd231pd -0x140(%rax),%zmm4,%zmm0
   39ace:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   39ad5:	vfmadd132pd %zmm5,%zmm1,%zmm0
   39adb:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   39ae2:	vfmadd132pd %zmm6,%zmm1,%zmm0
   39ae8:	vmovapd %zmm0,%zmm10
   39aee:	vpermilpd $0x55,-0x100(%rax),%zmm0
   39af6:	vfmadd231pd -0x100(%rax),%zmm4,%zmm0
   39afd:	vsubpd %zmm10,%zmm11,%zmm10
   39b03:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   39b0a:	vfmadd132pd %zmm5,%zmm1,%zmm0
   39b10:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   39b17:	vmovapd %zmm0,%zmm7
   39b1d:	vpermilpd $0x55,-0xc0(%rax),%zmm0
   39b25:	vfmadd231pd -0xc0(%rax),%zmm4,%zmm0
   39b2c:	vfmadd132pd %zmm6,%zmm1,%zmm7
   39b32:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   39b39:	vfmadd132pd %zmm5,%zmm1,%zmm0
   39b3f:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   39b46:	vfmadd132pd %zmm6,%zmm1,%zmm0
   39b4c:	vpermilpd $0x55,-0x80(%rax),%zmm1
   39b54:	vfmadd231pd -0x80(%rax),%zmm4,%zmm1
   39b5b:	vaddpd %zmm0,%zmm7,%zmm0
   39b61:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm2
   39b68:	vfmadd132pd %zmm5,%zmm2,%zmm1
   39b6e:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm2
   39b75:	vfmadd132pd %zmm6,%zmm2,%zmm1
   39b7b:	vpermilpd $0x55,-0x40(%rax),%zmm2
   39b83:	vfmadd231pd -0x40(%rax),%zmm4,%zmm2
   39b8a:	vshuff64x2 $0xb1,%zmm2,%zmm2,%zmm12
   39b91:	vfmadd132pd %zmm5,%zmm12,%zmm2
   39b97:	vshuff64x2 $0x4e,%zmm2,%zmm2,%zmm12
   39b9e:	vfmadd132pd %zmm6,%zmm12,%zmm2
   39ba4:	vsubpd %zmm10,%zmm8,%zmm12
   39baa:	vfmadd132pd %zmm3,%zmm12,%zmm11
   39bb0:	vfmsub132pd %zmm3,%zmm12,%zmm9
   39bb6:	vsubpd %zmm2,%zmm1,%zmm2
   39bbc:	vaddpd %zmm2,%zmm0,%zmm12
   39bc2:	vfnmadd132pd %zmm3,%zmm12,%zmm1
   39bc8:	vfmsub132pd %zmm3,%zmm12,%zmm7
   39bce:	vaddpd %zmm1,%zmm11,%zmm12
   39bd4:	vfnmadd132pd %zmm3,%zmm12,%zmm0
   39bda:	vfmsub132pd %zmm3,%zmm12,%zmm8
   39be0:	vaddpd %zmm7,%zmm9,%zmm12
   39be6:	vfmadd132pd %zmm3,%zmm12,%zmm2
   39bec:	vfnmadd132pd %zmm3,%zmm12,%zmm10
   39bf2:	vfmsub132pd %zmm3,%zmm0,%zmm11
   39bf8:	vfmadd132pd %zmm3,%zmm8,%zmm1
   39bfe:	vmovupd %zmm0,-0x100(%rax)
   39c05:	vmovupd %zmm8,-0x80(%rax)
   39c0c:	vfmsub132pd %zmm3,%zmm2,%zmm9
   39c12:	vfnmadd132pd %zmm3,%zmm10,%zmm7
   39c18:	vmovupd %zmm2,-0x1c0(%rax)
   39c1f:	vmovupd %zmm10,-0x140(%rax)
   39c26:	vmovupd %zmm11,-0x200(%rax)
   39c2d:	vmovupd %zmm1,-0x180(%rax)
   39c34:	vmovupd %zmm9,-0xc0(%rax)
   39c3b:	vmovupd %zmm7,-0x40(%rax)
   39c42:	cmp    %rax,%rdx
   39c45:	jne    39a28 <hf0_g20_nat+0x88>
   39c4b:	mov    0xf8(%rsp),%rax
   39c53:	sub    %fs:0x28,%rax
   39c5c:	jne    39c63 <hf0_g20_nat+0x2c3>
   39c5e:	vzeroupper
   39c61:	leave
   39c62:	ret
   39c63:	vzeroupper
   39c66:	call   4280 <__stack_chk_fail@plt>
   39c6b:	nopl   0x0(%rax,%rax,1)

0000000000039c70 <hf1_g20_nat>:
   39c70:	endbr64
   39c74:	push   %rbp
   39c75:	mov    %rdi,%rdx
   39c78:	mov    %rsp,%rbp
   39c7b:	and    $0xffffffffffffffc0,%rsp
   39c7f:	sub    $0x100,%rsp
   39c86:	vbroadcastsd 0x23330(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   39c90:	mov    %fs:0x28,%rax
   39c99:	mov    %rax,0xf8(%rsp)
   39ca1:	xor    %eax,%eax
   39ca3:	mov    %rsp,%rdi
   39ca6:	vzeroupper
   39ca9:	call   df20 <inl_consts.constprop.0>
   39cae:	vmovapd (%rsp),%zmm5
   39cb5:	vmovapd 0x40(%rsp),%zmm4
   39cbd:	vmovapd 0x80(%rsp),%zmm3
   39cc5:	test   %rsi,%rsi
   39cc8:	je     39f8d <hf1_g20_nat+0x31d>
   39cce:	vbroadcastsd 0x230e8(%rip),%zmm0        # 5cdc0 <_IO_stdin_used+0xdc0>
   39cd8:	mov    %rdx,%rax
   39cdb:	lea    -0x8(,%rsi,8),%rdx
   39ce3:	and    $0xfffffffffffffe00,%rdx
   39cea:	lea    0x200(%rax,%rdx,1),%rdx
   39cf2:	nopw   0x0(%rax,%rax,1)
   39cf8:	vpxord (%rax),%zmm5,%zmm2
   39cfe:	vpermilpd $0x55,(%rax),%zmm1
   39d05:	add    $0x200,%rax
   39d0b:	vpxord -0x180(%rax),%zmm5,%zmm6
   39d12:	vaddpd %zmm2,%zmm1,%zmm1
   39d18:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm2
   39d1f:	vpxord %zmm1,%zmm4,%zmm1
   39d25:	vaddpd %zmm1,%zmm2,%zmm1
   39d2b:	vpxord -0x1c0(%rax),%zmm5,%zmm2
   39d32:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm9
   39d39:	vpxord %zmm1,%zmm3,%zmm1
   39d3f:	vaddpd %zmm1,%zmm9,%zmm9
   39d45:	vpermilpd $0x55,-0x1c0(%rax),%zmm1
   39d4d:	vaddpd %zmm2,%zmm1,%zmm1
   39d53:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm14
   39d5a:	vpxord %zmm1,%zmm4,%zmm1
   39d60:	vaddpd %zmm1,%zmm14,%zmm14
   39d66:	vpermilpd $0x55,-0x180(%rax),%zmm1
   39d6e:	vaddpd %zmm6,%zmm1,%zmm1
   39d74:	vshuff64x2 $0x4e,%zmm14,%zmm14,%zmm2
   39d7b:	vpxord %zmm14,%zmm3,%zmm14
   39d81:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm6
   39d88:	vpxord %zmm1,%zmm4,%zmm1
   39d8e:	vaddpd %zmm1,%zmm6,%zmm1
   39d94:	vpxord -0x140(%rax),%zmm5,%zmm6
   39d9b:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm12
   39da2:	vpxord %zmm1,%zmm3,%zmm1
   39da8:	vaddpd %zmm1,%zmm12,%zmm12
   39dae:	vpermilpd $0x55,-0x140(%rax),%zmm1
   39db6:	vaddpd %zmm6,%zmm1,%zmm1
   39dbc:	vpxord -0x100(%rax),%zmm5,%zmm6
   39dc3:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm15
   39dca:	vpxord %zmm1,%zmm4,%zmm1
   39dd0:	vaddpd %zmm1,%zmm15,%zmm15
   39dd6:	vpermilpd $0x55,-0x100(%rax),%zmm1
   39dde:	vaddpd %zmm6,%zmm1,%zmm1
   39de4:	vshuff64x2 $0x4e,%zmm15,%zmm15,%zmm7
   39deb:	vpxord %zmm15,%zmm3,%zmm15
   39df1:	vaddpd %zmm15,%zmm7,%zmm7
   39df7:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm6
   39dfe:	vpxord %zmm1,%zmm4,%zmm1
   39e04:	vaddpd %zmm1,%zmm6,%zmm1
   39e0a:	vpxord -0xc0(%rax),%zmm5,%zmm6
   39e11:	vsubpd %zmm7,%zmm12,%zmm7
   39e17:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm8
   39e1e:	vpxord %zmm1,%zmm3,%zmm1
   39e24:	vaddpd %zmm1,%zmm8,%zmm10
   39e2a:	vpxord -0x80(%rax),%zmm5,%zmm8
   39e31:	vpermilpd $0x55,-0xc0(%rax),%zmm1
   39e39:	vaddpd %zmm6,%zmm1,%zmm1
   39e3f:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm16
   39e46:	vpxord %zmm1,%zmm4,%zmm1
   39e4c:	vaddpd %zmm1,%zmm16,%zmm16
   39e52:	vpermilpd $0x55,-0x80(%rax),%zmm1
   39e5a:	vaddpd %zmm8,%zmm1,%zmm1
   39e60:	vshuff64x2 $0x4e,%zmm16,%zmm16,%zmm6
   39e67:	vpxord %zmm16,%zmm3,%zmm16
   39e6d:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm8
   39e74:	vpxord %zmm1,%zmm4,%zmm1
   39e7a:	vaddpd %zmm1,%zmm8,%zmm1
   39e80:	vpxord -0x40(%rax),%zmm5,%zmm8
   39e87:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm11
   39e8e:	vpxord %zmm1,%zmm3,%zmm1
   39e94:	vaddpd %zmm1,%zmm11,%zmm11
   39e9a:	vpermilpd $0x55,-0x40(%rax),%zmm1
   39ea2:	vaddpd %zmm8,%zmm1,%zmm1
   39ea8:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm13
   39eaf:	vpxord %zmm1,%zmm4,%zmm1
   39eb5:	vaddpd %zmm1,%zmm13,%zmm13
   39ebb:	vaddpd %zmm14,%zmm2,%zmm1
   39ec1:	vaddpd %zmm9,%zmm1,%zmm1
   39ec7:	vshuff64x2 $0x4e,%zmm13,%zmm13,%zmm8
   39ece:	vpxord %zmm13,%zmm3,%zmm13
   39ed4:	vsubpd %zmm7,%zmm1,%zmm2
   39eda:	vfmadd132pd %zmm0,%zmm2,%zmm12
   39ee0:	vfmsub132pd %zmm0,%zmm2,%zmm9
   39ee6:	vaddpd %zmm16,%zmm6,%zmm2
   39eec:	vaddpd %zmm13,%zmm8,%zmm6
   39ef2:	vaddpd %zmm10,%zmm2,%zmm2
   39ef8:	vsubpd %zmm6,%zmm11,%zmm6
   39efe:	vaddpd %zmm6,%zmm2,%zmm8
   39f04:	vfnmadd132pd %zmm0,%zmm8,%zmm11
   39f0a:	vfmsub231pd %zmm0,%zmm10,%zmm8
   39f10:	vaddpd %zmm11,%zmm12,%zmm10
   39f16:	vfnmadd132pd %zmm0,%zmm10,%zmm2
   39f1c:	vfmsub132pd %zmm0,%zmm10,%zmm1
   39f22:	vaddpd %zmm8,%zmm9,%zmm10
   39f28:	vfmadd132pd %zmm0,%zmm10,%zmm6
   39f2e:	vfnmadd132pd %zmm0,%zmm10,%zmm7
   39f34:	vfmsub132pd %zmm0,%zmm2,%zmm12
   39f3a:	vfmadd132pd %zmm0,%zmm1,%zmm11
   39f40:	vmovupd %zmm2,-0x100(%rax)
   39f47:	vmovupd %zmm1,-0x80(%rax)
   39f4e:	vfmsub132pd %zmm0,%zmm6,%zmm9
   39f54:	vfnmadd132pd %zmm0,%zmm7,%zmm8
   39f5a:	vmovupd %zmm6,-0x1c0(%rax)
   39f61:	vmovupd %zmm7,-0x140(%rax)
   39f68:	vmovupd %zmm12,-0x200(%rax)
   39f6f:	vmovupd %zmm11,-0x180(%rax)
   39f76:	vmovupd %zmm9,-0xc0(%rax)
   39f7d:	vmovupd %zmm8,-0x40(%rax)
   39f84:	cmp    %rax,%rdx
   39f87:	jne    39cf8 <hf1_g20_nat+0x88>
   39f8d:	mov    0xf8(%rsp),%rax
   39f95:	sub    %fs:0x28,%rax
   39f9e:	jne    39fa5 <hf1_g20_nat+0x335>
   39fa0:	vzeroupper
   39fa3:	leave
   39fa4:	ret
   39fa5:	vzeroupper
   39fa8:	call   4280 <__stack_chk_fail@plt>
   39fad:	nopl   (%rax)

0000000000039fb0 <hf2_tb8_nat>:
   39fb0:	endbr64
   39fb4:	vbroadcastsd 0x23002(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   39fbe:	mov    %rdi,%rax
   39fc1:	test   %rsi,%rsi
   39fc4:	je     3a2bd <hf2_tb8_nat+0x30d>
   39fca:	lea    -0x8(,%rsi,8),%rdx
   39fd2:	mov    $0xffffffaa,%ecx
   39fd7:	vmovdqa64 0x22e5f(%rip),%zmm4        # 5ce40 <_IO_stdin_used+0xe40>
   39fe1:	vmovdqa64 0x22e95(%rip),%zmm3        # 5ce80 <_IO_stdin_used+0xe80>
   39feb:	and    $0xfffffffffffffe00,%rdx
   39ff2:	kmovw  %ecx,%k3
   39ff6:	mov    $0xffffffcc,%ecx
   39ffb:	vmovdqa64 0x22ebb(%rip),%zmm2        # 5cec0 <_IO_stdin_used+0xec0>
   3a005:	lea    0x200(%rdi,%rdx,1),%rdx
   3a00d:	mov    $0xfffffff0,%edi
   3a012:	kmovw  %ecx,%k2
   3a016:	kmovw  %edi,%k1
   3a01a:	nopw   0x0(%rax,%rax,1)
   3a020:	vpermpd (%rax),%zmm4,%zmm1
   3a026:	vaddpd (%rax),%zmm1,%zmm0
   3a02c:	add    $0x200,%rax
   3a032:	vsubpd -0x200(%rax),%zmm1,%zmm0{%k3}
   3a039:	vpermpd %zmm0,%zmm3,%zmm5
   3a03f:	vaddpd %zmm0,%zmm5,%zmm1
   3a045:	vsubpd %zmm0,%zmm5,%zmm1{%k2}
   3a04b:	vpermpd %zmm1,%zmm2,%zmm5
   3a051:	vaddpd %zmm5,%zmm1,%zmm0
   3a057:	vsubpd %zmm1,%zmm5,%zmm0{%k1}
   3a05d:	vpermpd -0x1c0(%rax),%zmm4,%zmm1
   3a064:	vaddpd -0x1c0(%rax),%zmm1,%zmm5
   3a06b:	vsubpd -0x1c0(%rax),%zmm1,%zmm5{%k3}
   3a072:	vpermpd %zmm5,%zmm3,%zmm6
   3a078:	vaddpd %zmm6,%zmm5,%zmm1
   3a07e:	vsubpd %zmm5,%zmm6,%zmm1{%k2}
   3a084:	vpermpd %zmm1,%zmm2,%zmm5
   3a08a:	vaddpd %zmm5,%zmm1,%zmm9
   3a090:	vsubpd %zmm1,%zmm5,%zmm9{%k1}
   3a096:	vpermpd -0x180(%rax),%zmm4,%zmm1
   3a09d:	vaddpd -0x180(%rax),%zmm1,%zmm5
   3a0a4:	vsubpd -0x180(%rax),%zmm1,%zmm5{%k3}
   3a0ab:	vpermpd %zmm5,%zmm3,%zmm6
   3a0b1:	vaddpd %zmm6,%zmm5,%zmm1
   3a0b7:	vsubpd %zmm5,%zmm6,%zmm1{%k2}
   3a0bd:	vpermpd %zmm1,%zmm2,%zmm5
   3a0c3:	vaddpd %zmm5,%zmm1,%zmm8
   3a0c9:	vsubpd %zmm1,%zmm5,%zmm8{%k1}
   3a0cf:	vpermpd -0x140(%rax),%zmm4,%zmm1
   3a0d6:	vaddpd -0x140(%rax),%zmm1,%zmm5
   3a0dd:	vsubpd -0x140(%rax),%zmm1,%zmm5{%k3}
   3a0e4:	vpermpd %zmm5,%zmm3,%zmm6
   3a0ea:	vaddpd %zmm6,%zmm5,%zmm1
   3a0f0:	vsubpd %zmm5,%zmm6,%zmm1{%k2}
   3a0f6:	vpermpd %zmm1,%zmm2,%zmm5
   3a0fc:	vaddpd %zmm5,%zmm1,%zmm12
   3a102:	vsubpd %zmm1,%zmm5,%zmm12{%k1}
   3a108:	vpermpd -0x100(%rax),%zmm4,%zmm5
   3a10f:	vaddpd -0x100(%rax),%zmm5,%zmm1
   3a116:	vsubpd -0x100(%rax),%zmm5,%zmm1{%k3}
   3a11d:	vpermpd %zmm1,%zmm3,%zmm6
   3a123:	vaddpd %zmm6,%zmm1,%zmm5
   3a129:	vsubpd %zmm1,%zmm6,%zmm5{%k2}
   3a12f:	vpermpd %zmm5,%zmm2,%zmm6
   3a135:	vaddpd %zmm6,%zmm5,%zmm1
   3a13b:	vsubpd %zmm5,%zmm6,%zmm1{%k1}
   3a141:	vpermpd -0xc0(%rax),%zmm4,%zmm5
   3a148:	vaddpd -0xc0(%rax),%zmm5,%zmm6
   3a14f:	vsubpd -0xc0(%rax),%zmm5,%zmm6{%k3}
   3a156:	vpermpd %zmm6,%zmm3,%zmm7
   3a15c:	vaddpd %zmm7,%zmm6,%zmm5
   3a162:	vsubpd %zmm6,%zmm7,%zmm5{%k2}
   3a168:	vpermpd %zmm5,%zmm2,%zmm6
   3a16e:	vaddpd %zmm6,%zmm5,%zmm11
   3a174:	vsubpd %zmm5,%zmm6,%zmm11{%k1}
   3a17a:	vpermpd -0x80(%rax),%zmm4,%zmm5
   3a181:	vaddpd -0x80(%rax),%zmm5,%zmm6
   3a188:	vsubpd -0x80(%rax),%zmm5,%zmm6{%k3}
   3a18f:	vpermpd %zmm6,%zmm3,%zmm7
   3a195:	vaddpd %zmm7,%zmm6,%zmm5
   3a19b:	vsubpd %zmm6,%zmm7,%zmm5{%k2}
   3a1a1:	vpermpd %zmm5,%zmm2,%zmm7
   3a1a7:	vaddpd %zmm7,%zmm5,%zmm6
   3a1ad:	vsubpd %zmm5,%zmm7,%zmm6{%k1}
   3a1b3:	vpermpd -0x40(%rax),%zmm4,%zmm5
   3a1ba:	vaddpd -0x40(%rax),%zmm5,%zmm7
   3a1c1:	vsubpd -0x40(%rax),%zmm5,%zmm7{%k3}
   3a1c8:	vpermpd %zmm7,%zmm3,%zmm10
   3a1ce:	vaddpd %zmm7,%zmm10,%zmm5
   3a1d4:	vsubpd %zmm7,%zmm10,%zmm5{%k2}
   3a1da:	vpermpd %zmm5,%zmm2,%zmm7
   3a1e0:	vaddpd %zmm7,%zmm5,%zmm10
   3a1e6:	vsubpd %zmm5,%zmm7,%zmm10{%k1}
   3a1ec:	vaddpd %zmm9,%zmm0,%zmm5
   3a1f2:	vaddpd %zmm11,%zmm1,%zmm7
   3a1f8:	vsubpd %zmm9,%zmm0,%zmm0
   3a1fe:	vaddpd %zmm12,%zmm8,%zmm9
   3a204:	vsubpd %zmm12,%zmm8,%zmm8
   3a20a:	vaddpd %zmm6,%zmm10,%zmm12
   3a210:	vsubpd %zmm11,%zmm1,%zmm1
   3a216:	vsubpd %zmm10,%zmm6,%zmm6
   3a21c:	vaddpd %zmm9,%zmm5,%zmm10
   3a222:	vsubpd %zmm9,%zmm5,%zmm5
   3a228:	vaddpd %zmm12,%zmm7,%zmm11
   3a22e:	vaddpd %zmm8,%zmm0,%zmm9
   3a234:	vsubpd %zmm8,%zmm0,%zmm0
   3a23a:	vaddpd %zmm6,%zmm1,%zmm8
   3a240:	vsubpd %zmm6,%zmm1,%zmm1
   3a246:	vsubpd %zmm12,%zmm7,%zmm7
   3a24c:	vaddpd %zmm11,%zmm10,%zmm6
   3a252:	vsubpd %zmm11,%zmm10,%zmm10
   3a258:	vmovupd %zmm6,-0x200(%rax)
   3a25f:	vaddpd %zmm8,%zmm9,%zmm6
   3a265:	vsubpd %zmm8,%zmm9,%zmm9
   3a26b:	vmovupd %zmm10,-0x100(%rax)
   3a272:	vmovupd %zmm6,-0x1c0(%rax)
   3a279:	vaddpd %zmm7,%zmm5,%zmm6
   3a27f:	vsubpd %zmm7,%zmm5,%zmm5
   3a285:	vmovupd %zmm9,-0xc0(%rax)
   3a28c:	vmovupd %zmm6,-0x180(%rax)
   3a293:	vaddpd %zmm1,%zmm0,%zmm6
   3a299:	vsubpd %zmm1,%zmm0,%zmm0
   3a29f:	vmovupd %zmm5,-0x80(%rax)
   3a2a6:	vmovupd %zmm6,-0x140(%rax)
   3a2ad:	vmovupd %zmm0,-0x40(%rax)
   3a2b4:	cmp    %rdx,%rax
   3a2b7:	jne    3a020 <hf2_tb8_nat+0x70>
   3a2bd:	vzeroupper
   3a2c0:	ret
   3a2c1:	data16 cs nopw 0x0(%rax,%rax,1)
   3a2cc:	nopl   0x0(%rax)

000000000003a2d0 <hf2_tb8_bal>:
   3a2d0:	endbr64
   3a2d4:	vbroadcastsd 0x22ce2(%rip),%zmm1        # 5cfc0 <_IO_stdin_used+0xfc0>
   3a2de:	mov    %rdi,%rax
   3a2e1:	test   %rsi,%rsi
   3a2e4:	je     3a625 <hf2_tb8_bal+0x355>
   3a2ea:	lea    -0x8(,%rsi,8),%rdx
   3a2f2:	mov    $0xffffffaa,%ecx
   3a2f7:	vmovdqa64 0x22b3f(%rip),%zmm5        # 5ce40 <_IO_stdin_used+0xe40>
   3a301:	vmovdqa64 0x22b75(%rip),%zmm4        # 5ce80 <_IO_stdin_used+0xe80>
   3a30b:	and    $0xfffffffffffffe00,%rdx
   3a312:	kmovw  %ecx,%k3
   3a316:	mov    $0xffffffcc,%ecx
   3a31b:	vmovdqa64 0x22b9b(%rip),%zmm3        # 5cec0 <_IO_stdin_used+0xec0>
   3a325:	lea    0x200(%rdi,%rdx,1),%rdx
   3a32d:	mov    $0xfffffff0,%edi
   3a332:	kmovw  %ecx,%k2
   3a336:	kmovw  %edi,%k1
   3a33a:	nopw   0x0(%rax,%rax,1)
   3a340:	vpermpd (%rax),%zmm5,%zmm2
   3a346:	vaddpd (%rax),%zmm2,%zmm0
   3a34c:	add    $0x200,%rax
   3a352:	vsubpd -0x200(%rax),%zmm2,%zmm0{%k3}
   3a359:	vpermpd %zmm0,%zmm4,%zmm6
   3a35f:	vaddpd %zmm0,%zmm6,%zmm2
   3a365:	vsubpd %zmm0,%zmm6,%zmm2{%k2}
   3a36b:	vpermpd %zmm2,%zmm3,%zmm6
   3a371:	vaddpd %zmm6,%zmm2,%zmm0
   3a377:	vsubpd %zmm2,%zmm6,%zmm0{%k1}
   3a37d:	vpermpd -0x1c0(%rax),%zmm5,%zmm2
   3a384:	vaddpd -0x1c0(%rax),%zmm2,%zmm6
   3a38b:	vsubpd -0x1c0(%rax),%zmm2,%zmm6{%k3}
   3a392:	vpermpd %zmm6,%zmm4,%zmm7
   3a398:	vaddpd %zmm7,%zmm6,%zmm2
   3a39e:	vsubpd %zmm6,%zmm7,%zmm2{%k2}
   3a3a4:	vpermpd %zmm2,%zmm3,%zmm6
   3a3aa:	vaddpd %zmm6,%zmm2,%zmm10
   3a3b0:	vsubpd %zmm2,%zmm6,%zmm10{%k1}
   3a3b6:	vpermpd -0x180(%rax),%zmm5,%zmm2
   3a3bd:	vaddpd -0x180(%rax),%zmm2,%zmm6
   3a3c4:	vsubpd -0x180(%rax),%zmm2,%zmm6{%k3}
   3a3cb:	vpermpd %zmm6,%zmm4,%zmm7
   3a3d1:	vaddpd %zmm7,%zmm6,%zmm2
   3a3d7:	vsubpd %zmm6,%zmm7,%zmm2{%k2}
   3a3dd:	vpermpd %zmm2,%zmm3,%zmm6
   3a3e3:	vaddpd %zmm6,%zmm2,%zmm9
   3a3e9:	vsubpd %zmm2,%zmm6,%zmm9{%k1}
   3a3ef:	vpermpd -0x140(%rax),%zmm5,%zmm2
   3a3f6:	vaddpd -0x140(%rax),%zmm2,%zmm6
   3a3fd:	vsubpd -0x140(%rax),%zmm2,%zmm6{%k3}
   3a404:	vpermpd %zmm6,%zmm4,%zmm7
   3a40a:	vaddpd %zmm7,%zmm6,%zmm2
   3a410:	vsubpd %zmm6,%zmm7,%zmm2{%k2}
   3a416:	vpermpd %zmm2,%zmm3,%zmm6
   3a41c:	vaddpd %zmm6,%zmm2,%zmm12
   3a422:	vsubpd %zmm2,%zmm6,%zmm12{%k1}
   3a428:	vpermpd -0x100(%rax),%zmm5,%zmm6
   3a42f:	vaddpd -0x100(%rax),%zmm6,%zmm2
   3a436:	vsubpd -0x100(%rax),%zmm6,%zmm2{%k3}
   3a43d:	vpermpd %zmm2,%zmm4,%zmm7
   3a443:	vaddpd %zmm7,%zmm2,%zmm6
   3a449:	vsubpd %zmm2,%zmm7,%zmm6{%k2}
   3a44f:	vpermpd %zmm6,%zmm3,%zmm7
   3a455:	vaddpd %zmm7,%zmm6,%zmm2
   3a45b:	vsubpd %zmm6,%zmm7,%zmm2{%k1}
   3a461:	vpermpd -0xc0(%rax),%zmm5,%zmm6
   3a468:	vaddpd -0xc0(%rax),%zmm6,%zmm7
   3a46f:	vsubpd -0xc0(%rax),%zmm6,%zmm7{%k3}
   3a476:	vpermpd %zmm7,%zmm4,%zmm8
   3a47c:	vaddpd %zmm8,%zmm7,%zmm6
   3a482:	vsubpd %zmm7,%zmm8,%zmm6{%k2}
   3a488:	vpermpd %zmm6,%zmm3,%zmm7
   3a48e:	vaddpd %zmm7,%zmm6,%zmm13
   3a494:	vsubpd %zmm6,%zmm7,%zmm13{%k1}
   3a49a:	vpermpd -0x80(%rax),%zmm5,%zmm6
   3a4a1:	vaddpd -0x80(%rax),%zmm6,%zmm7
   3a4a8:	vsubpd -0x80(%rax),%zmm6,%zmm7{%k3}
   3a4af:	vpermpd %zmm7,%zmm4,%zmm8
   3a4b5:	vaddpd %zmm8,%zmm7,%zmm6
   3a4bb:	vsubpd %zmm7,%zmm8,%zmm6{%k2}
   3a4c1:	vpermpd %zmm6,%zmm3,%zmm8
   3a4c7:	vaddpd %zmm8,%zmm6,%zmm7
   3a4cd:	vsubpd %zmm6,%zmm8,%zmm7{%k1}
   3a4d3:	vpermpd -0x40(%rax),%zmm5,%zmm6
   3a4da:	vaddpd -0x40(%rax),%zmm6,%zmm8
   3a4e1:	vsubpd -0x40(%rax),%zmm6,%zmm8{%k3}
   3a4e8:	vpermpd %zmm8,%zmm4,%zmm11
   3a4ee:	vaddpd %zmm8,%zmm11,%zmm6
   3a4f4:	vsubpd %zmm8,%zmm11,%zmm6{%k2}
   3a4fa:	vpermpd %zmm6,%zmm3,%zmm8
   3a500:	vaddpd %zmm8,%zmm6,%zmm11
   3a506:	vsubpd %zmm6,%zmm8,%zmm11{%k1}
   3a50c:	vmovapd %zmm10,%zmm6
   3a512:	vmovapd %zmm13,%zmm8
   3a518:	vfmadd132pd %zmm1,%zmm0,%zmm6
   3a51e:	vsubpd %zmm10,%zmm0,%zmm0
   3a524:	vmovapd %zmm12,%zmm10
   3a52a:	vfmadd132pd %zmm1,%zmm9,%zmm10
   3a530:	vfmadd132pd %zmm1,%zmm2,%zmm8
   3a536:	vsubpd %zmm13,%zmm2,%zmm2
   3a53c:	vmovapd %zmm11,%zmm13
   3a542:	vsubpd %zmm12,%zmm9,%zmm9
   3a548:	vfmadd132pd %zmm1,%zmm7,%zmm13
   3a54e:	vsubpd %zmm11,%zmm7,%zmm7
   3a554:	vmovapd %zmm10,%zmm11
   3a55a:	vfmadd132pd %zmm1,%zmm6,%zmm11
   3a560:	vsubpd %zmm10,%zmm6,%zmm6
   3a566:	vmovapd %zmm9,%zmm10
   3a56c:	vfmadd132pd %zmm1,%zmm0,%zmm10
   3a572:	vmovapd %zmm13,%zmm12
   3a578:	vsubpd %zmm9,%zmm0,%zmm0
   3a57e:	vmovapd %zmm7,%zmm9
   3a584:	vfmadd132pd %zmm1,%zmm8,%zmm12
   3a58a:	vsubpd %zmm13,%zmm8,%zmm8
   3a590:	vfmadd132pd %zmm1,%zmm2,%zmm9
   3a596:	vsubpd %zmm7,%zmm2,%zmm2
   3a59c:	vmovapd %zmm8,%zmm13
   3a5a2:	vmovapd %zmm2,%zmm7
   3a5a8:	vfmadd132pd %zmm1,%zmm6,%zmm13
   3a5ae:	vsubpd %zmm8,%zmm6,%zmm6
   3a5b4:	vmovapd %zmm12,%zmm15
   3a5ba:	vfmadd132pd %zmm1,%zmm0,%zmm7
   3a5c0:	vsubpd %zmm2,%zmm0,%zmm0
   3a5c6:	vmovapd %zmm9,%zmm14
   3a5cc:	vfmadd132pd %zmm1,%zmm11,%zmm15
   3a5d2:	vsubpd %zmm12,%zmm11,%zmm11
   3a5d8:	vfmadd132pd %zmm1,%zmm10,%zmm14
   3a5de:	vsubpd %zmm9,%zmm10,%zmm10
   3a5e4:	vmovupd %zmm6,-0x80(%rax)
   3a5eb:	vmovupd %zmm0,-0x40(%rax)
   3a5f2:	vmovupd %zmm13,-0x180(%rax)
   3a5f9:	vmovupd %zmm7,-0x140(%rax)
   3a600:	vmovupd %zmm15,-0x200(%rax)
   3a607:	vmovupd %zmm14,-0x1c0(%rax)
   3a60e:	vmovupd %zmm11,-0x100(%rax)
   3a615:	vmovupd %zmm10,-0xc0(%rax)
   3a61c:	cmp    %rdx,%rax
   3a61f:	jne    3a340 <hf2_tb8_bal+0x70>
   3a625:	vzeroupper
   3a628:	ret
   3a629:	nopl   0x0(%rax)

000000000003a630 <hf2_tb8_balS>:
   3a630:	endbr64
   3a634:	vbroadcastsd 0x22982(%rip),%zmm1        # 5cfc0 <_IO_stdin_used+0xfc0>
   3a63e:	mov    %rdi,%rax
   3a641:	test   %rsi,%rsi
   3a644:	je     3a955 <hf2_tb8_balS+0x325>
   3a64a:	lea    -0x8(,%rsi,8),%rdx
   3a652:	mov    $0xffffffaa,%ecx
   3a657:	vmovdqa64 0x227df(%rip),%zmm5        # 5ce40 <_IO_stdin_used+0xe40>
   3a661:	vmovdqa64 0x22815(%rip),%zmm4        # 5ce80 <_IO_stdin_used+0xe80>
   3a66b:	and    $0xfffffffffffffe00,%rdx
   3a672:	kmovw  %ecx,%k3
   3a676:	mov    $0xffffffcc,%ecx
   3a67b:	vmovdqa64 0x2283b(%rip),%zmm3        # 5cec0 <_IO_stdin_used+0xec0>
   3a685:	lea    0x200(%rdi,%rdx,1),%rdx
   3a68d:	mov    $0xfffffff0,%edi
   3a692:	kmovw  %ecx,%k2
   3a696:	kmovw  %edi,%k1
   3a69a:	nopw   0x0(%rax,%rax,1)
   3a6a0:	vpermpd (%rax),%zmm5,%zmm0
   3a6a6:	vaddpd (%rax),%zmm0,%zmm2
   3a6ac:	add    $0x200,%rax
   3a6b2:	vsubpd -0x200(%rax),%zmm0,%zmm2{%k3}
   3a6b9:	vpermpd %zmm2,%zmm4,%zmm6
   3a6bf:	vaddpd %zmm2,%zmm6,%zmm0
   3a6c5:	vsubpd %zmm2,%zmm6,%zmm0{%k2}
   3a6cb:	vpermpd %zmm0,%zmm3,%zmm2
   3a6d1:	vaddpd %zmm2,%zmm0,%zmm10
   3a6d7:	vsubpd %zmm0,%zmm2,%zmm10{%k1}
   3a6dd:	vpermpd -0x1c0(%rax),%zmm5,%zmm0
   3a6e4:	vaddpd -0x1c0(%rax),%zmm0,%zmm2
   3a6eb:	vsubpd -0x1c0(%rax),%zmm0,%zmm2{%k3}
   3a6f2:	vpermpd %zmm2,%zmm4,%zmm6
   3a6f8:	vaddpd %zmm6,%zmm2,%zmm0
   3a6fe:	vsubpd %zmm2,%zmm6,%zmm0{%k2}
   3a704:	vpermpd %zmm0,%zmm3,%zmm2
   3a70a:	vaddpd %zmm2,%zmm0,%zmm9
   3a710:	vsubpd %zmm0,%zmm2,%zmm9{%k1}
   3a716:	vpermpd -0x180(%rax),%zmm5,%zmm0
   3a71d:	vaddpd -0x180(%rax),%zmm0,%zmm2
   3a724:	vsubpd -0x180(%rax),%zmm0,%zmm2{%k3}
   3a72b:	vsubpd %zmm9,%zmm10,%zmm14
   3a731:	vfmadd132pd %zmm1,%zmm10,%zmm9
   3a737:	vpermpd %zmm2,%zmm4,%zmm6
   3a73d:	vaddpd %zmm6,%zmm2,%zmm0
   3a743:	vsubpd %zmm2,%zmm6,%zmm0{%k2}
   3a749:	vpermpd %zmm0,%zmm3,%zmm2
   3a74f:	vaddpd %zmm2,%zmm0,%zmm7
   3a755:	vsubpd %zmm0,%zmm2,%zmm7{%k1}
   3a75b:	vpermpd -0x140(%rax),%zmm5,%zmm2
   3a762:	vaddpd -0x140(%rax),%zmm2,%zmm0
   3a769:	vsubpd -0x140(%rax),%zmm2,%zmm0{%k3}
   3a770:	vpermpd %zmm0,%zmm4,%zmm6
   3a776:	vaddpd %zmm6,%zmm0,%zmm2
   3a77c:	vsubpd %zmm0,%zmm6,%zmm2{%k2}
   3a782:	vpermpd %zmm2,%zmm3,%zmm6
   3a788:	vaddpd %zmm6,%zmm2,%zmm0
   3a78e:	vsubpd %zmm2,%zmm6,%zmm0{%k1}
   3a794:	vpermpd -0x100(%rax),%zmm5,%zmm2
   3a79b:	vaddpd -0x100(%rax),%zmm2,%zmm6
   3a7a2:	vsubpd -0x100(%rax),%zmm2,%zmm6{%k3}
   3a7a9:	vpermpd %zmm6,%zmm4,%zmm8
   3a7af:	vaddpd %zmm8,%zmm6,%zmm2
   3a7b5:	vsubpd %zmm6,%zmm8,%zmm2{%k2}
   3a7bb:	vpermpd %zmm2,%zmm3,%zmm6
   3a7c1:	vaddpd %zmm6,%zmm2,%zmm12
   3a7c7:	vsubpd %zmm2,%zmm6,%zmm12{%k1}
   3a7cd:	vpermpd -0xc0(%rax),%zmm5,%zmm2
   3a7d4:	vaddpd -0xc0(%rax),%zmm2,%zmm6
   3a7db:	vsubpd -0xc0(%rax),%zmm2,%zmm6{%k3}
   3a7e2:	vpermpd %zmm6,%zmm4,%zmm8
   3a7e8:	vaddpd %zmm8,%zmm6,%zmm2
   3a7ee:	vsubpd %zmm6,%zmm8,%zmm2{%k2}
   3a7f4:	vpermpd %zmm2,%zmm3,%zmm6
   3a7fa:	vaddpd %zmm6,%zmm2,%zmm8
   3a800:	vsubpd %zmm2,%zmm6,%zmm8{%k1}
   3a806:	vpermpd -0x80(%rax),%zmm5,%zmm2
   3a80d:	vaddpd -0x80(%rax),%zmm2,%zmm6
   3a814:	vsubpd -0x80(%rax),%zmm2,%zmm6{%k3}
   3a81b:	vpermpd %zmm6,%zmm4,%zmm11
   3a821:	vaddpd %zmm11,%zmm6,%zmm2
   3a827:	vsubpd %zmm6,%zmm11,%zmm2{%k2}
   3a82d:	vpermpd %zmm2,%zmm3,%zmm6
   3a833:	vaddpd %zmm6,%zmm2,%zmm11
   3a839:	vsubpd %zmm2,%zmm6,%zmm11{%k1}
   3a83f:	vpermpd -0x40(%rax),%zmm5,%zmm6
   3a846:	vaddpd -0x40(%rax),%zmm6,%zmm2
   3a84d:	vsubpd -0x40(%rax),%zmm6,%zmm2{%k3}
   3a854:	vpermpd %zmm2,%zmm4,%zmm13
   3a85a:	vaddpd %zmm2,%zmm13,%zmm6
   3a860:	vsubpd %zmm2,%zmm13,%zmm6{%k2}
   3a866:	vpermpd %zmm6,%zmm3,%zmm13
   3a86c:	vaddpd %zmm13,%zmm6,%zmm2
   3a872:	vsubpd %zmm6,%zmm13,%zmm2{%k1}
   3a878:	vsubpd %zmm8,%zmm12,%zmm13
   3a87e:	vfmadd132pd %zmm1,%zmm12,%zmm8
   3a884:	vsubpd %zmm0,%zmm7,%zmm6
   3a88a:	vfmadd132pd %zmm1,%zmm7,%zmm0
   3a890:	vsubpd %zmm2,%zmm11,%zmm7
   3a896:	vfmadd132pd %zmm1,%zmm11,%zmm2
   3a89c:	vsubpd %zmm0,%zmm9,%zmm10
   3a8a2:	vfmadd132pd %zmm1,%zmm9,%zmm0
   3a8a8:	vsubpd %zmm6,%zmm14,%zmm9
   3a8ae:	vfmadd132pd %zmm1,%zmm14,%zmm6
   3a8b4:	vsubpd %zmm2,%zmm8,%zmm11
   3a8ba:	vfmadd132pd %zmm1,%zmm8,%zmm2
   3a8c0:	vsubpd %zmm7,%zmm13,%zmm8
   3a8c6:	vfmadd132pd %zmm1,%zmm13,%zmm7
   3a8cc:	vmovapd %zmm8,%zmm12
   3a8d2:	vmovapd %zmm11,%zmm13
   3a8d8:	vfmadd132pd %zmm1,%zmm10,%zmm13
   3a8de:	vfmadd132pd %zmm1,%zmm9,%zmm12
   3a8e4:	vsubpd %zmm11,%zmm10,%zmm10
   3a8ea:	vmovapd %zmm2,%zmm15
   3a8f0:	vsubpd %zmm8,%zmm9,%zmm9
   3a8f6:	vmovapd %zmm7,%zmm14
   3a8fc:	vfmadd132pd %zmm1,%zmm0,%zmm15
   3a902:	vsubpd %zmm2,%zmm0,%zmm0
   3a908:	vfmadd132pd %zmm1,%zmm6,%zmm14
   3a90e:	vsubpd %zmm7,%zmm6,%zmm6
   3a914:	vmovupd %zmm10,-0x80(%rax)
   3a91b:	vmovupd %zmm9,-0x40(%rax)
   3a922:	vmovupd %zmm13,-0x180(%rax)
   3a929:	vmovupd %zmm12,-0x140(%rax)
   3a930:	vmovupd %zmm15,-0x200(%rax)
   3a937:	vmovupd %zmm14,-0x1c0(%rax)
   3a93e:	vmovupd %zmm0,-0x100(%rax)
   3a945:	vmovupd %zmm6,-0xc0(%rax)
   3a94c:	cmp    %rdx,%rax
   3a94f:	jne    3a6a0 <hf2_tb8_balS+0x70>
   3a955:	vzeroupper
   3a958:	ret
   3a959:	nopl   0x0(%rax)

000000000003a960 <hf0_broken_g20>:
   3a960:	endbr64
   3a964:	push   %rbp
   3a965:	mov    %rdi,%rdx
   3a968:	mov    %rsp,%rbp
   3a96b:	and    $0xffffffffffffffc0,%rsp
   3a96f:	sub    $0x100,%rsp
   3a976:	vbroadcastsd 0x22640(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   3a980:	mov    %fs:0x28,%rax
   3a989:	mov    %rax,0xf8(%rsp)
   3a991:	xor    %eax,%eax
   3a993:	mov    %rsp,%rdi
   3a996:	vzeroupper
   3a999:	call   ea60 <inl_consts.constprop.1>
   3a99e:	vmovapd (%rsp),%zmm4
   3a9a5:	vmovapd 0x40(%rsp),%zmm5
   3a9ad:	vmovapd 0x80(%rsp),%zmm6
   3a9b5:	test   %rsi,%rsi
   3a9b8:	je     3ac0b <hf0_broken_g20+0x2ab>
   3a9be:	vbroadcastsd 0x223f8(%rip),%zmm3        # 5cdc0 <_IO_stdin_used+0xdc0>
   3a9c8:	mov    %rdx,%rax
   3a9cb:	lea    -0x8(,%rsi,8),%rdx
   3a9d3:	and    $0xfffffffffffffe00,%rdx
   3a9da:	lea    0x200(%rax,%rdx,1),%rdx
   3a9e2:	nopw   0x0(%rax,%rax,1)
   3a9e8:	vpermilpd $0x55,(%rax),%zmm0
   3a9ef:	vfmadd231pd (%rax),%zmm4,%zmm0
   3a9f5:	add    $0x200,%rax
   3a9fb:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   3aa02:	vfmadd132pd %zmm5,%zmm1,%zmm0
   3aa08:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   3aa0f:	vfmadd132pd %zmm6,%zmm1,%zmm0
   3aa15:	vmovapd %zmm0,%zmm8
   3aa1b:	vpermilpd $0x55,-0x1c0(%rax),%zmm0
   3aa23:	vfmadd231pd -0x1c0(%rax),%zmm4,%zmm0
   3aa2a:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   3aa31:	vfmadd132pd %zmm5,%zmm1,%zmm0
   3aa37:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   3aa3e:	vfmadd132pd %zmm6,%zmm1,%zmm0
   3aa44:	vmovapd %zmm0,%zmm9
   3aa4a:	vpermilpd $0x55,-0x180(%rax),%zmm0
   3aa52:	vfmadd231pd -0x180(%rax),%zmm4,%zmm0
   3aa59:	vaddpd %zmm9,%zmm8,%zmm9
   3aa5f:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   3aa66:	vfmadd132pd %zmm5,%zmm1,%zmm0
   3aa6c:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   3aa73:	vfmadd132pd %zmm6,%zmm1,%zmm0
   3aa79:	vmovapd %zmm0,%zmm11
   3aa7f:	vpermilpd $0x55,-0x140(%rax),%zmm0
   3aa87:	vfmadd231pd -0x140(%rax),%zmm4,%zmm0
   3aa8e:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   3aa95:	vfmadd132pd %zmm5,%zmm1,%zmm0
   3aa9b:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   3aaa2:	vfmadd132pd %zmm6,%zmm1,%zmm0
   3aaa8:	vmovapd %zmm0,%zmm10
   3aaae:	vpermilpd $0x55,-0x100(%rax),%zmm0
   3aab6:	vfmadd231pd -0x100(%rax),%zmm4,%zmm0
   3aabd:	vsubpd %zmm10,%zmm11,%zmm10
   3aac3:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   3aaca:	vfmadd132pd %zmm5,%zmm1,%zmm0
   3aad0:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   3aad7:	vmovapd %zmm0,%zmm7
   3aadd:	vpermilpd $0x55,-0xc0(%rax),%zmm0
   3aae5:	vfmadd231pd -0xc0(%rax),%zmm4,%zmm0
   3aaec:	vfmadd132pd %zmm6,%zmm1,%zmm7
   3aaf2:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   3aaf9:	vfmadd132pd %zmm5,%zmm1,%zmm0
   3aaff:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   3ab06:	vfmadd132pd %zmm6,%zmm1,%zmm0
   3ab0c:	vpermilpd $0x55,-0x80(%rax),%zmm1
   3ab14:	vfmadd231pd -0x80(%rax),%zmm4,%zmm1
   3ab1b:	vaddpd %zmm0,%zmm7,%zmm0
   3ab21:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm2
   3ab28:	vfmadd132pd %zmm5,%zmm2,%zmm1
   3ab2e:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm2
   3ab35:	vfmadd132pd %zmm6,%zmm2,%zmm1
   3ab3b:	vpermilpd $0x55,-0x40(%rax),%zmm2
   3ab43:	vfmadd231pd -0x40(%rax),%zmm4,%zmm2
   3ab4a:	vshuff64x2 $0xb1,%zmm2,%zmm2,%zmm12
   3ab51:	vfmadd132pd %zmm5,%zmm12,%zmm2
   3ab57:	vshuff64x2 $0x4e,%zmm2,%zmm2,%zmm12
   3ab5e:	vfmadd132pd %zmm6,%zmm12,%zmm2
   3ab64:	vsubpd %zmm10,%zmm9,%zmm12
   3ab6a:	vfmadd132pd %zmm3,%zmm12,%zmm11
   3ab70:	vfmsub132pd %zmm3,%zmm12,%zmm8
   3ab76:	vsubpd %zmm2,%zmm1,%zmm2
   3ab7c:	vaddpd %zmm2,%zmm0,%zmm12
   3ab82:	vfnmadd132pd %zmm3,%zmm12,%zmm1
   3ab88:	vfmsub132pd %zmm3,%zmm12,%zmm7
   3ab8e:	vaddpd %zmm1,%zmm11,%zmm12
   3ab94:	vfnmadd132pd %zmm3,%zmm12,%zmm0
   3ab9a:	vfmsub132pd %zmm3,%zmm12,%zmm9
   3aba0:	vaddpd %zmm7,%zmm8,%zmm12
   3aba6:	vfmadd132pd %zmm3,%zmm12,%zmm2
   3abac:	vfnmadd132pd %zmm3,%zmm12,%zmm10
   3abb2:	vfmsub132pd %zmm3,%zmm0,%zmm11
   3abb8:	vfmadd132pd %zmm3,%zmm9,%zmm1
   3abbe:	vmovupd %zmm0,-0x100(%rax)
   3abc5:	vmovupd %zmm9,-0xc0(%rax)
   3abcc:	vfmsub132pd %zmm3,%zmm2,%zmm8
   3abd2:	vfnmadd132pd %zmm3,%zmm10,%zmm7
   3abd8:	vmovupd %zmm2,-0x1c0(%rax)
   3abdf:	vmovupd %zmm10,-0x140(%rax)
   3abe6:	vmovupd %zmm11,-0x200(%rax)
   3abed:	vmovupd %zmm1,-0x180(%rax)
   3abf4:	vmovupd %zmm8,-0x80(%rax)
   3abfb:	vmovupd %zmm7,-0x40(%rax)
   3ac02:	cmp    %rax,%rdx
   3ac05:	jne    3a9e8 <hf0_broken_g20+0x88>
   3ac0b:	mov    0xf8(%rsp),%rax
   3ac13:	sub    %fs:0x28,%rax
   3ac1c:	jne    3ac23 <hf0_broken_g20+0x2c3>
   3ac1e:	vzeroupper
   3ac21:	leave
   3ac22:	ret
   3ac23:	vzeroupper
   3ac26:	call   4280 <__stack_chk_fail@plt>
   3ac2b:	nopl   0x0(%rax,%rax,1)

000000000003ac30 <hf1_broken_g20>:
   3ac30:	endbr64
   3ac34:	push   %rbp
   3ac35:	mov    %rdi,%rdx
   3ac38:	mov    %rsp,%rbp
   3ac3b:	and    $0xffffffffffffffc0,%rsp
   3ac3f:	sub    $0x100,%rsp
   3ac46:	vbroadcastsd 0x22370(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   3ac50:	mov    %fs:0x28,%rax
   3ac59:	mov    %rax,0xf8(%rsp)
   3ac61:	xor    %eax,%eax
   3ac63:	mov    %rsp,%rdi
   3ac66:	vzeroupper
   3ac69:	call   df20 <inl_consts.constprop.0>
   3ac6e:	vmovapd (%rsp),%zmm5
   3ac75:	vmovapd 0x40(%rsp),%zmm4
   3ac7d:	vmovapd 0x80(%rsp),%zmm3
   3ac85:	test   %rsi,%rsi
   3ac88:	je     3af4d <hf1_broken_g20+0x31d>
   3ac8e:	vbroadcastsd 0x22128(%rip),%zmm0        # 5cdc0 <_IO_stdin_used+0xdc0>
   3ac98:	mov    %rdx,%rax
   3ac9b:	lea    -0x8(,%rsi,8),%rdx
   3aca3:	and    $0xfffffffffffffe00,%rdx
   3acaa:	lea    0x200(%rax,%rdx,1),%rdx
   3acb2:	nopw   0x0(%rax,%rax,1)
   3acb8:	vpxord (%rax),%zmm5,%zmm2
   3acbe:	vpermilpd $0x55,(%rax),%zmm1
   3acc5:	add    $0x200,%rax
   3accb:	vpxord -0x180(%rax),%zmm5,%zmm6
   3acd2:	vaddpd %zmm2,%zmm1,%zmm1
   3acd8:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm2
   3acdf:	vpxord %zmm1,%zmm4,%zmm1
   3ace5:	vaddpd %zmm1,%zmm2,%zmm1
   3aceb:	vpxord -0x1c0(%rax),%zmm5,%zmm2
   3acf2:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm9
   3acf9:	vpxord %zmm1,%zmm3,%zmm1
   3acff:	vaddpd %zmm1,%zmm9,%zmm9
   3ad05:	vpermilpd $0x55,-0x1c0(%rax),%zmm1
   3ad0d:	vaddpd %zmm2,%zmm1,%zmm1
   3ad13:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm14
   3ad1a:	vpxord %zmm1,%zmm4,%zmm1
   3ad20:	vaddpd %zmm1,%zmm14,%zmm14
   3ad26:	vpermilpd $0x55,-0x180(%rax),%zmm1
   3ad2e:	vaddpd %zmm6,%zmm1,%zmm1
   3ad34:	vshuff64x2 $0x4e,%zmm14,%zmm14,%zmm2
   3ad3b:	vpxord %zmm14,%zmm3,%zmm14
   3ad41:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm6
   3ad48:	vpxord %zmm1,%zmm4,%zmm1
   3ad4e:	vaddpd %zmm1,%zmm6,%zmm1
   3ad54:	vpxord -0x140(%rax),%zmm5,%zmm6
   3ad5b:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm12
   3ad62:	vpxord %zmm1,%zmm3,%zmm1
   3ad68:	vaddpd %zmm1,%zmm12,%zmm12
   3ad6e:	vpermilpd $0x55,-0x140(%rax),%zmm1
   3ad76:	vaddpd %zmm6,%zmm1,%zmm1
   3ad7c:	vpxord -0x100(%rax),%zmm5,%zmm6
   3ad83:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm15
   3ad8a:	vpxord %zmm1,%zmm4,%zmm1
   3ad90:	vaddpd %zmm1,%zmm15,%zmm15
   3ad96:	vpermilpd $0x55,-0x100(%rax),%zmm1
   3ad9e:	vaddpd %zmm6,%zmm1,%zmm1
   3ada4:	vshuff64x2 $0x4e,%zmm15,%zmm15,%zmm7
   3adab:	vpxord %zmm15,%zmm3,%zmm15
   3adb1:	vaddpd %zmm15,%zmm7,%zmm7
   3adb7:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm6
   3adbe:	vpxord %zmm1,%zmm4,%zmm1
   3adc4:	vaddpd %zmm1,%zmm6,%zmm1
   3adca:	vpxord -0xc0(%rax),%zmm5,%zmm6
   3add1:	vsubpd %zmm7,%zmm12,%zmm7
   3add7:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm8
   3adde:	vpxord %zmm1,%zmm3,%zmm1
   3ade4:	vaddpd %zmm1,%zmm8,%zmm10
   3adea:	vpxord -0x80(%rax),%zmm5,%zmm8
   3adf1:	vpermilpd $0x55,-0xc0(%rax),%zmm1
   3adf9:	vaddpd %zmm6,%zmm1,%zmm1
   3adff:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm16
   3ae06:	vpxord %zmm1,%zmm4,%zmm1
   3ae0c:	vaddpd %zmm1,%zmm16,%zmm16
   3ae12:	vpermilpd $0x55,-0x80(%rax),%zmm1
   3ae1a:	vaddpd %zmm8,%zmm1,%zmm1
   3ae20:	vshuff64x2 $0x4e,%zmm16,%zmm16,%zmm6
   3ae27:	vpxord %zmm16,%zmm3,%zmm16
   3ae2d:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm8
   3ae34:	vpxord %zmm1,%zmm4,%zmm1
   3ae3a:	vaddpd %zmm1,%zmm8,%zmm1
   3ae40:	vpxord -0x40(%rax),%zmm5,%zmm8
   3ae47:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm11
   3ae4e:	vpxord %zmm1,%zmm3,%zmm1
   3ae54:	vaddpd %zmm1,%zmm11,%zmm11
   3ae5a:	vpermilpd $0x55,-0x40(%rax),%zmm1
   3ae62:	vaddpd %zmm8,%zmm1,%zmm1
   3ae68:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm13
   3ae6f:	vpxord %zmm1,%zmm4,%zmm1
   3ae75:	vaddpd %zmm1,%zmm13,%zmm13
   3ae7b:	vaddpd %zmm14,%zmm2,%zmm1
   3ae81:	vaddpd %zmm9,%zmm1,%zmm1
   3ae87:	vshuff64x2 $0x4e,%zmm13,%zmm13,%zmm8
   3ae8e:	vpxord %zmm13,%zmm3,%zmm13
   3ae94:	vsubpd %zmm7,%zmm1,%zmm2
   3ae9a:	vfmadd132pd %zmm0,%zmm2,%zmm12
   3aea0:	vfmsub132pd %zmm0,%zmm2,%zmm9
   3aea6:	vaddpd %zmm16,%zmm6,%zmm2
   3aeac:	vaddpd %zmm13,%zmm8,%zmm6
   3aeb2:	vaddpd %zmm10,%zmm2,%zmm2
   3aeb8:	vsubpd %zmm6,%zmm11,%zmm6
   3aebe:	vaddpd %zmm6,%zmm2,%zmm8
   3aec4:	vfnmadd132pd %zmm0,%zmm8,%zmm11
   3aeca:	vfmsub231pd %zmm0,%zmm10,%zmm8
   3aed0:	vaddpd %zmm11,%zmm12,%zmm10
   3aed6:	vfnmadd132pd %zmm0,%zmm10,%zmm2
   3aedc:	vfmsub132pd %zmm0,%zmm10,%zmm1
   3aee2:	vaddpd %zmm8,%zmm9,%zmm10
   3aee8:	vfmadd132pd %zmm0,%zmm10,%zmm6
   3aeee:	vfnmadd132pd %zmm0,%zmm10,%zmm7
   3aef4:	vfmsub132pd %zmm0,%zmm2,%zmm12
   3aefa:	vfmadd132pd %zmm0,%zmm1,%zmm11
   3af00:	vmovupd %zmm2,-0x100(%rax)
   3af07:	vmovupd %zmm1,-0xc0(%rax)
   3af0e:	vfmsub132pd %zmm0,%zmm6,%zmm9
   3af14:	vfnmadd132pd %zmm0,%zmm7,%zmm8
   3af1a:	vmovupd %zmm6,-0x1c0(%rax)
   3af21:	vmovupd %zmm7,-0x140(%rax)
   3af28:	vmovupd %zmm12,-0x200(%rax)
   3af2f:	vmovupd %zmm11,-0x180(%rax)
   3af36:	vmovupd %zmm9,-0x80(%rax)
   3af3d:	vmovupd %zmm8,-0x40(%rax)
   3af44:	cmp    %rax,%rdx
   3af47:	jne    3acb8 <hf1_broken_g20+0x88>
   3af4d:	mov    0xf8(%rsp),%rax
   3af55:	sub    %fs:0x28,%rax
   3af5e:	jne    3af65 <hf1_broken_g20+0x335>
   3af60:	vzeroupper
   3af63:	leave
   3af64:	ret
   3af65:	vzeroupper
   3af68:	call   4280 <__stack_chk_fail@plt>
   3af6d:	nopl   (%rax)

000000000003c900 <hf0_tb8_nat>:
   3c900:	endbr64
   3c904:	push   %rbp
   3c905:	mov    %rdi,%rdx
   3c908:	mov    %rsp,%rbp
   3c90b:	and    $0xffffffffffffffc0,%rsp
   3c90f:	sub    $0x100,%rsp
   3c916:	vbroadcastsd 0x206a0(%rip),%zmm0        # 5cfc0 <_IO_stdin_used+0xfc0>
   3c920:	mov    %fs:0x28,%rax
   3c929:	mov    %rax,0xf8(%rsp)
   3c931:	xor    %eax,%eax
   3c933:	mov    %rsp,%rdi
   3c936:	vzeroupper
   3c939:	call   ea60 <inl_consts.constprop.1>
   3c93e:	vmovapd (%rsp),%zmm6
   3c945:	vmovapd 0x40(%rsp),%zmm7
   3c94d:	vmovapd 0x80(%rsp),%zmm8
   3c955:	test   %rsi,%rsi
   3c958:	je     3cbbb <hf0_tb8_nat+0x2bb>
   3c95e:	mov    %rdx,%rax
   3c961:	lea    -0x8(,%rsi,8),%rdx
   3c969:	and    $0xfffffffffffffe00,%rdx
   3c970:	lea    0x200(%rax,%rdx,1),%rdx
   3c978:	nopl   0x0(%rax,%rax,1)
   3c980:	vpermilpd $0x55,(%rax),%zmm2
   3c987:	vfmadd231pd (%rax),%zmm6,%zmm2
   3c98d:	add    $0x200,%rax
   3c993:	vshuff64x2 $0xb1,%zmm2,%zmm2,%zmm0
   3c99a:	vfmadd132pd %zmm7,%zmm0,%zmm2
   3c9a0:	vshuff64x2 $0x4e,%zmm2,%zmm2,%zmm0
   3c9a7:	vmovapd %zmm2,%zmm4
   3c9ad:	vfmadd132pd %zmm8,%zmm0,%zmm4
   3c9b3:	vpermilpd $0x55,-0x1c0(%rax),%zmm0
   3c9bb:	vfmadd231pd -0x1c0(%rax),%zmm6,%zmm0
   3c9c2:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   3c9c9:	vfmadd132pd %zmm7,%zmm1,%zmm0
   3c9cf:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   3c9d6:	vfmadd132pd %zmm8,%zmm1,%zmm0
   3c9dc:	vmovapd %zmm0,%zmm11
   3c9e2:	vpermilpd $0x55,-0x180(%rax),%zmm0
   3c9ea:	vfmadd231pd -0x180(%rax),%zmm6,%zmm0
   3c9f1:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   3c9f8:	vfmadd132pd %zmm7,%zmm1,%zmm0
   3c9fe:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   3ca05:	vfmadd132pd %zmm8,%zmm1,%zmm0
   3ca0b:	vmovapd %zmm0,%zmm10
   3ca11:	vpermilpd $0x55,-0x140(%rax),%zmm0
   3ca19:	vfmadd231pd -0x140(%rax),%zmm6,%zmm0
   3ca20:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   3ca27:	vfmadd132pd %zmm7,%zmm1,%zmm0
   3ca2d:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   3ca34:	vmovapd %zmm0,%zmm5
   3ca3a:	vpermilpd $0x55,-0x100(%rax),%zmm0
   3ca42:	vfmadd231pd -0x100(%rax),%zmm6,%zmm0
   3ca49:	vfmadd132pd %zmm8,%zmm1,%zmm5
   3ca4f:	vshuff64x2 $0xb1,%zmm0,%zmm0,%zmm1
   3ca56:	vaddpd %zmm5,%zmm10,%zmm13
   3ca5c:	vsubpd %zmm5,%zmm10,%zmm10
   3ca62:	vfmadd132pd %zmm7,%zmm1,%zmm0
   3ca68:	vshuff64x2 $0x4e,%zmm0,%zmm0,%zmm1
   3ca6f:	vfmadd132pd %zmm8,%zmm1,%zmm0
   3ca75:	vpermilpd $0x55,-0xc0(%rax),%zmm1
   3ca7d:	vfmadd231pd -0xc0(%rax),%zmm6,%zmm1
   3ca84:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm2
   3ca8b:	vfmadd132pd %zmm7,%zmm2,%zmm1
   3ca91:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm2
   3ca98:	vmovapd %zmm1,%zmm3
   3ca9e:	vpermilpd $0x55,-0x80(%rax),%zmm1
   3caa6:	vfmadd231pd -0x80(%rax),%zmm6,%zmm1
   3caad:	vfmadd132pd %zmm8,%zmm2,%zmm3
   3cab3:	vshuff64x2 $0xb1,%zmm1,%zmm1,%zmm2
   3caba:	vaddpd %zmm3,%zmm0,%zmm5
   3cac0:	vsubpd %zmm3,%zmm0,%zmm0
   3cac6:	vfmadd132pd %zmm7,%zmm2,%zmm1
   3cacc:	vshuff64x2 $0x4e,%zmm1,%zmm1,%zmm2
   3cad3:	vfmadd132pd %zmm8,%zmm2,%zmm1
   3cad9:	vpermilpd $0x55,-0x40(%rax),%zmm2
   3cae1:	vfmadd231pd -0x40(%rax),%zmm6,%zmm2
   3cae8:	vshuff64x2 $0xb1,%zmm2,%zmm2,%zmm9
   3caef:	vfmadd132pd %zmm7,%zmm9,%zmm2
   3caf5:	vshuff64x2 $0x4e,%zmm2,%zmm2,%zmm9
   3cafc:	vfmadd132pd %zmm8,%zmm9,%zmm2
   3cb02:	vaddpd %zmm11,%zmm4,%zmm9
   3cb08:	vsubpd %zmm11,%zmm4,%zmm4
   3cb0e:	vsubpd %zmm13,%zmm9,%zmm3
   3cb14:	vaddpd %zmm13,%zmm9,%zmm11
   3cb1a:	vaddpd %zmm10,%zmm4,%zmm9
   3cb20:	vaddpd %zmm2,%zmm1,%zmm12
   3cb26:	vsubpd %zmm2,%zmm1,%zmm1
   3cb2c:	vsubpd %zmm10,%zmm4,%zmm2
   3cb32:	vaddpd %zmm12,%zmm5,%zmm10
   3cb38:	vsubpd %zmm12,%zmm5,%zmm4
   3cb3e:	vaddpd %zmm1,%zmm0,%zmm5
   3cb44:	vsubpd %zmm1,%zmm0,%zmm0
   3cb4a:	vaddpd %zmm10,%zmm11,%zmm1
   3cb50:	vsubpd %zmm10,%zmm11,%zmm11
   3cb56:	vmovupd %zmm1,-0x200(%rax)
   3cb5d:	vaddpd %zmm5,%zmm9,%zmm1
   3cb63:	vsubpd %zmm5,%zmm9,%zmm9
   3cb69:	vmovupd %zmm11,-0x100(%rax)
   3cb70:	vmovupd %zmm1,-0x1c0(%rax)
   3cb77:	vaddpd %zmm4,%zmm3,%zmm1
   3cb7d:	vsubpd %zmm4,%zmm3,%zmm3
   3cb83:	vmovupd %zmm9,-0xc0(%rax)
   3cb8a:	vmovupd %zmm1,-0x180(%rax)
   3cb91:	vaddpd %zmm0,%zmm2,%zmm1
   3cb97:	vsubpd %zmm0,%zmm2,%zmm2
   3cb9d:	vmovupd %zmm3,-0x80(%rax)
   3cba4:	vmovupd %zmm1,-0x140(%rax)
   3cbab:	vmovupd %zmm2,-0x40(%rax)
   3cbb2:	cmp    %rax,%rdx
   3cbb5:	jne    3c980 <hf0_tb8_nat+0x80>
   3cbbb:	mov    0xf8(%rsp),%rax
   3cbc3:	sub    %fs:0x28,%rax
   3cbcc:	jne    3cbd3 <hf0_tb8_nat+0x2d3>
   3cbce:	vzeroupper
   3cbd1:	leave
   3cbd2:	ret
   3cbd3:	vzeroupper
   3cbd6:	call   4280 <__stack_chk_fail@plt>
   3cbdb:	nopl   0x0(%rax,%rax,1)

