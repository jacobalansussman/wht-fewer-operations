000000000000b770 <hs_tb2_nat>:
    b770:	endbr64
    b774:	vbroadcastss 0x52882(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
    b77e:	test   %rsi,%rsi
    b781:	je     b7e7 <hs_tb2_nat+0x77>
    b783:	lea    (%rdx,%rdx,1),%r11
    b787:	test   %rdx,%rdx
    b78a:	je     b7e7 <hs_tb2_nat+0x77>
    b78c:	lea    -0x1(%rdx),%r9
    b790:	xor    %r8d,%r8d
    b793:	lea    0x40(%rdi),%r10
    b797:	and    $0xfffffffffffffff0,%r9
    b79b:	nopl   0x0(%rax,%rax,1)
    b7a0:	lea    (%r9,%r8,1),%rcx
    b7a4:	lea    (%rdi,%r8,4),%rax
    b7a8:	lea    (%r10,%rcx,4),%rcx
    b7ac:	nopl   0x0(%rax)
    b7b0:	vmovups (%rax),%zmm0
    b7b6:	vmovups (%rax,%rdx,4),%zmm1
    b7bd:	vaddps %zmm1,%zmm0,%zmm2
    b7c3:	vsubps %zmm1,%zmm0,%zmm0
    b7c9:	vmovups %zmm2,(%rax)
    b7cf:	vmovups %zmm0,(%rax,%rdx,4)
    b7d6:	add    $0x40,%rax
    b7da:	cmp    %rax,%rcx
    b7dd:	jne    b7b0 <hs_tb2_nat+0x40>
    b7df:	add    %r11,%r8
    b7e2:	cmp    %rsi,%r8
    b7e5:	jb     b7a0 <hs_tb2_nat+0x30>
    b7e7:	vzeroupper
    b7ea:	ret
    b7eb:	nopl   0x0(%rax,%rax,1)

000000000000b7f0 <hs_tb4_nat>:
    b7f0:	endbr64
    b7f4:	vbroadcastss 0x52802(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
    b7fe:	test   %rsi,%rsi
    b801:	je     b8bf <hs_tb4_nat+0xcf>
    b807:	push   %rbp
    b808:	mov    %rsp,%rbp
    b80b:	push   %rbx
    b80c:	lea    0x0(,%rdx,4),%rbx
    b814:	test   %rdx,%rdx
    b817:	je     b8b6 <hs_tb4_nat+0xc6>
    b81d:	lea    -0x1(%rdx),%r10
    b821:	lea    (%rdx,%rdx,2),%rcx
    b825:	xor    %r9d,%r9d
    b828:	and    $0xfffffffffffffff0,%r10
    b82c:	shl    $0x2,%rcx
    b830:	lea    0x40(%rdi),%r11
    b834:	nopl   0x0(%rax)
    b838:	lea    (%r9,%r10,1),%r8
    b83c:	lea    (%rdi,%r9,4),%rax
    b840:	lea    (%r11,%r8,4),%r8
    b844:	nopl   0x0(%rax)
    b848:	vmovups (%rax),%zmm5
    b84e:	vmovups (%rax,%rdx,8),%zmm7
    b855:	vaddps (%rax,%rdx,4),%zmm5,%zmm2
    b85c:	vaddps (%rax,%rcx,1),%zmm7,%zmm3
    b863:	vsubps (%rax,%rdx,4),%zmm5,%zmm0
    b86a:	vsubps (%rax,%rcx,1),%zmm7,%zmm1
    b871:	vaddps %zmm3,%zmm2,%zmm4
    b877:	vsubps %zmm3,%zmm2,%zmm2
    b87d:	vmovups %zmm4,(%rax)
    b883:	vaddps %zmm1,%zmm0,%zmm4
    b889:	vsubps %zmm1,%zmm0,%zmm0
    b88f:	vmovups %zmm4,(%rax,%rdx,4)
    b896:	vmovups %zmm2,(%rax,%rdx,8)
    b89d:	add    $0x40,%rax
    b8a1:	vmovups %zmm0,-0x40(%rax,%rcx,1)
    b8a9:	cmp    %rax,%r8
    b8ac:	jne    b848 <hs_tb4_nat+0x58>
    b8ae:	add    %rbx,%r9
    b8b1:	cmp    %rsi,%r9
    b8b4:	jb     b838 <hs_tb4_nat+0x48>
    b8b6:	vzeroupper
    b8b9:	mov    -0x8(%rbp),%rbx
    b8bd:	leave
    b8be:	ret
    b8bf:	vzeroupper
    b8c2:	ret
    b8c3:	data16 cs nopw 0x0(%rax,%rax,1)
    b8ce:	xchg   %ax,%ax

000000000000bca0 <hf2_kid_nat>:
    bca0:	endbr64
    bca4:	vbroadcastss 0x52352(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
    bcae:	test   %rsi,%rsi
    bcb1:	je     bd71 <hf2_kid_nat+0xd1>
    bcb7:	lea    -0x4(,%rsi,4),%rax
    bcbf:	mov    $0xffffaaaa,%edx
    bcc4:	mov    $0xffffcccc,%ecx
    bcc9:	vmovdqa32 0x5212d(%rip),%zmm6        # 5de00 <_IO_stdin_used+0xe00>
    bcd3:	and    $0xffffffffffffffc0,%rax
    bcd7:	kmovw  %edx,%k4
    bcdb:	vmovdqa32 0x5215b(%rip),%zmm5        # 5de40 <_IO_stdin_used+0xe40>
    bce5:	vmovdqa32 0x52191(%rip),%zmm4        # 5de80 <_IO_stdin_used+0xe80>
    bcef:	mov    $0xfffff0f0,%edx
    bcf4:	kmovw  %ecx,%k3
    bcf8:	lea    0x40(%rdi,%rax,1),%rax
    bcfd:	vmovdqa32 0x521b9(%rip),%zmm3        # 5dec0 <_IO_stdin_used+0xec0>
    bd07:	mov    $0xffffff00,%ecx
    bd0c:	kmovw  %edx,%k2
    bd10:	kmovw  %ecx,%k1
    bd14:	nopl   0x0(%rax)
    bd18:	vpermps (%rdi),%zmm6,%zmm1
    bd1e:	vaddps (%rdi),%zmm1,%zmm0
    bd24:	add    $0x40,%rdi
    bd28:	vsubps -0x40(%rdi),%zmm1,%zmm0{%k4}
    bd2f:	vpermps %zmm0,%zmm5,%zmm2
    bd35:	vaddps %zmm2,%zmm0,%zmm1
    bd3b:	vsubps %zmm0,%zmm2,%zmm1{%k3}
    bd41:	vpermps %zmm1,%zmm4,%zmm2
    bd47:	vaddps %zmm2,%zmm1,%zmm0
    bd4d:	vsubps %zmm1,%zmm2,%zmm0{%k2}
    bd53:	vpermps %zmm0,%zmm3,%zmm2
    bd59:	vaddps %zmm0,%zmm2,%zmm1
    bd5f:	vsubps %zmm0,%zmm2,%zmm1{%k1}
    bd65:	vmovups %zmm1,-0x40(%rdi)
    bd6c:	cmp    %rdi,%rax
    bd6f:	jne    bd18 <hf2_kid_nat+0x78>
    bd71:	vzeroupper
    bd74:	ret
    bd75:	data16 cs nopw 0x0(%rax,%rax,1)

000000000000bd80 <hf2_tb2_nat>:
    bd80:	endbr64
    bd84:	vbroadcastss 0x52272(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
    bd8e:	test   %rsi,%rsi
    bd91:	je     bebb <hf2_tb2_nat+0x13b>
    bd97:	lea    -0x4(,%rsi,4),%rax
    bd9f:	mov    $0xffffaaaa,%edx
    bda4:	mov    $0xffffcccc,%ecx
    bda9:	vmovdqa32 0x5204d(%rip),%zmm7        # 5de00 <_IO_stdin_used+0xe00>
    bdb3:	and    $0xffffffffffffff80,%rax
    bdb7:	kmovw  %edx,%k4
    bdbb:	vmovdqa32 0x5207b(%rip),%zmm6        # 5de40 <_IO_stdin_used+0xe40>
    bdc5:	vmovdqa32 0x520b1(%rip),%zmm5        # 5de80 <_IO_stdin_used+0xe80>
    bdcf:	vmovdqa32 0x520e7(%rip),%zmm4        # 5dec0 <_IO_stdin_used+0xec0>
    bdd9:	mov    $0xfffff0f0,%edx
    bdde:	kmovw  %ecx,%k3
    bde2:	lea    0x80(%rdi,%rax,1),%rax
    bdea:	mov    $0xffffff00,%ecx
    bdef:	kmovw  %edx,%k2
    bdf3:	kmovw  %ecx,%k1
    bdf7:	nopw   0x0(%rax,%rax,1)
    be00:	vpermps (%rdi),%zmm7,%zmm0
    be06:	vaddps (%rdi),%zmm0,%zmm1
    be0c:	sub    $0xffffffffffffff80,%rdi
    be10:	vsubps -0x80(%rdi),%zmm0,%zmm1{%k4}
    be17:	vpermps %zmm1,%zmm6,%zmm2
    be1d:	vaddps %zmm2,%zmm1,%zmm0
    be23:	vsubps %zmm1,%zmm2,%zmm0{%k3}
    be29:	vpermps %zmm0,%zmm5,%zmm2
    be2f:	vaddps %zmm2,%zmm0,%zmm1
    be35:	vsubps %zmm0,%zmm2,%zmm1{%k2}
    be3b:	vpermps %zmm1,%zmm4,%zmm2
    be41:	vaddps %zmm2,%zmm1,%zmm0
    be47:	vsubps %zmm1,%zmm2,%zmm0{%k1}
    be4d:	vpermps -0x40(%rdi),%zmm7,%zmm2
    be54:	vaddps -0x40(%rdi),%zmm2,%zmm1
    be5b:	vsubps -0x40(%rdi),%zmm2,%zmm1{%k4}
    be62:	vpermps %zmm1,%zmm6,%zmm3
    be68:	vaddps %zmm3,%zmm1,%zmm2
    be6e:	vsubps %zmm1,%zmm3,%zmm2{%k3}
    be74:	vpermps %zmm2,%zmm5,%zmm3
    be7a:	vaddps %zmm3,%zmm2,%zmm1
    be80:	vsubps %zmm2,%zmm3,%zmm1{%k2}
    be86:	vpermps %zmm1,%zmm4,%zmm3
    be8c:	vaddps %zmm1,%zmm3,%zmm2
    be92:	vsubps %zmm1,%zmm3,%zmm2{%k1}
    be98:	vaddps %zmm0,%zmm2,%zmm1
    be9e:	vsubps %zmm2,%zmm0,%zmm0
    bea4:	vmovups %zmm1,-0x80(%rdi)
    beab:	vmovups %zmm0,-0x40(%rdi)
    beb2:	cmp    %rax,%rdi
    beb5:	jne    be00 <hf2_tb2_nat+0x80>
    bebb:	vzeroupper
    bebe:	ret
    bebf:	nop

000000000000bec0 <hf2_tb4_nat>:
    bec0:	endbr64
    bec4:	vbroadcastss 0x52132(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
    bece:	test   %rsi,%rsi
    bed1:	je     c0c5 <hf2_tb4_nat+0x205>
    bed7:	mov    $0xffffaaaa,%ecx
    bedc:	mov    %rdi,%rax
    bedf:	lea    -0x4(,%rsi,4),%rdx
    bee7:	vmovdqa32 0x51f0f(%rip),%zmm7        # 5de00 <_IO_stdin_used+0xe00>
    bef1:	vmovdqa32 0x51f45(%rip),%zmm6        # 5de40 <_IO_stdin_used+0xe40>
    befb:	xor    %dl,%dl
    befd:	kmovw  %ecx,%k4
    bf01:	vmovdqa32 0x51f75(%rip),%zmm5        # 5de80 <_IO_stdin_used+0xe80>
    bf0b:	mov    $0xffffcccc,%ecx
    bf10:	lea    0x100(%rdi,%rdx,1),%rdx
    bf18:	vmovdqa32 0x51f9e(%rip),%zmm4        # 5dec0 <_IO_stdin_used+0xec0>
    bf22:	mov    $0xffffff00,%edi
    bf27:	kmovw  %ecx,%k3
    bf2b:	mov    $0xfffff0f0,%ecx
    bf30:	kmovw  %edi,%k1
    bf34:	kmovw  %ecx,%k2
    bf38:	nopl   0x0(%rax,%rax,1)
    bf40:	vpermps (%rax),%zmm7,%zmm0
    bf46:	vaddps (%rax),%zmm0,%zmm1
    bf4c:	add    $0x100,%rax
    bf52:	vsubps -0x100(%rax),%zmm0,%zmm1{%k4}
    bf59:	vpermps %zmm1,%zmm6,%zmm2
    bf5f:	vaddps %zmm2,%zmm1,%zmm0
    bf65:	vsubps %zmm1,%zmm2,%zmm0{%k3}
    bf6b:	vpermps %zmm0,%zmm5,%zmm2
    bf71:	vaddps %zmm2,%zmm0,%zmm1
    bf77:	vsubps %zmm0,%zmm2,%zmm1{%k2}
    bf7d:	vpermps %zmm1,%zmm4,%zmm2
    bf83:	vaddps %zmm2,%zmm1,%zmm0
    bf89:	vsubps %zmm1,%zmm2,%zmm0{%k1}
    bf8f:	vpermps -0xc0(%rax),%zmm7,%zmm2
    bf96:	vaddps -0xc0(%rax),%zmm2,%zmm1
    bf9d:	vsubps -0xc0(%rax),%zmm2,%zmm1{%k4}
    bfa4:	vpermps %zmm1,%zmm6,%zmm3
    bfaa:	vaddps %zmm3,%zmm1,%zmm2
    bfb0:	vsubps %zmm1,%zmm3,%zmm2{%k3}
    bfb6:	vpermps %zmm2,%zmm5,%zmm3
    bfbc:	vaddps %zmm3,%zmm2,%zmm1
    bfc2:	vsubps %zmm2,%zmm3,%zmm1{%k2}
    bfc8:	vpermps %zmm1,%zmm4,%zmm2
    bfce:	vaddps %zmm2,%zmm1,%zmm8
    bfd4:	vsubps %zmm1,%zmm2,%zmm8{%k1}
    bfda:	vpermps -0x80(%rax),%zmm7,%zmm1
    bfe1:	vaddps -0x80(%rax),%zmm1,%zmm2
    bfe8:	vsubps -0x80(%rax),%zmm1,%zmm2{%k4}
    bfef:	vpermps %zmm2,%zmm6,%zmm3
    bff5:	vaddps %zmm3,%zmm2,%zmm1
    bffb:	vsubps %zmm2,%zmm3,%zmm1{%k3}
    c001:	vpermps %zmm1,%zmm5,%zmm3
    c007:	vaddps %zmm3,%zmm1,%zmm2
    c00d:	vsubps %zmm1,%zmm3,%zmm2{%k2}
    c013:	vpermps %zmm2,%zmm4,%zmm3
    c019:	vaddps %zmm3,%zmm2,%zmm1
    c01f:	vsubps %zmm2,%zmm3,%zmm1{%k1}
    c025:	vpermps -0x40(%rax),%zmm7,%zmm3
    c02c:	vaddps -0x40(%rax),%zmm3,%zmm2
    c033:	vsubps -0x40(%rax),%zmm3,%zmm2{%k4}
    c03a:	vpermps %zmm2,%zmm6,%zmm9
    c040:	vaddps %zmm9,%zmm2,%zmm3
    c046:	vsubps %zmm2,%zmm9,%zmm3{%k3}
    c04c:	vpermps %zmm3,%zmm5,%zmm9
    c052:	vaddps %zmm9,%zmm3,%zmm2
    c058:	vsubps %zmm3,%zmm9,%zmm2{%k2}
    c05e:	vpermps %zmm2,%zmm4,%zmm9
    c064:	vaddps %zmm2,%zmm9,%zmm3
    c06a:	vsubps %zmm2,%zmm9,%zmm3{%k1}
    c070:	vaddps %zmm8,%zmm0,%zmm2
    c076:	vsubps %zmm8,%zmm0,%zmm0
    c07c:	vaddps %zmm1,%zmm3,%zmm8
    c082:	vsubps %zmm3,%zmm1,%zmm1
    c088:	vaddps %zmm8,%zmm2,%zmm3
    c08e:	vsubps %zmm8,%zmm2,%zmm2
    c094:	vmovups %zmm3,-0x100(%rax)
    c09b:	vaddps %zmm1,%zmm0,%zmm3
    c0a1:	vsubps %zmm1,%zmm0,%zmm0
    c0a7:	vmovups %zmm2,-0x80(%rax)
    c0ae:	vmovups %zmm3,-0xc0(%rax)
    c0b5:	vmovups %zmm0,-0x40(%rax)
    c0bc:	cmp    %rdx,%rax
    c0bf:	jne    bf40 <hf2_tb4_nat+0x80>
    c0c5:	vzeroupper
    c0c8:	ret
    c0c9:	nopl   0x0(%rax)

000000000000c3d0 <pass_tb16_bal_1>:
    c3d0:	endbr64
    c3d4:	lea    0x8(%rsp),%r10
    c3d9:	and    $0xffffffffffffffc0,%rsp
    c3dd:	push   -0x8(%r10)
    c3e1:	push   %rbp
    c3e2:	mov    %rsp,%rbp
    c3e5:	push   %r14
    c3e7:	push   %r13
    c3e9:	push   %r12
    c3eb:	push   %r10
    c3ed:	push   %rbx
    c3ee:	sub    $0x448,%rsp
    c3f5:	vbroadcastss 0x51c01(%rip),%zmm24        # 5e000 <_IO_stdin_used+0x1000>
    c3ff:	mov    %fs:0x28,%rax
    c408:	mov    %rax,-0x38(%rbp)
    c40c:	xor    %eax,%eax
    c40e:	test   %rsi,%rsi
    c411:	je     c6c7 <pass_tb16_bal_1+0x2f7>
    c417:	lea    (%rsi,%rsi,2),%rdx
    c41b:	mov    %rsi,%r10
    c41e:	xor    %r12d,%r12d
    c421:	lea    0x0(,%rsi,8),%r8
    c429:	lea    0x0(,%rsi,4),%r11
    c431:	mov    %r10,%rbx
    c434:	lea    0x0(,%rdx,4),%r9
    c43c:	lea    (%rdi,%r8,1),%rsi
    c440:	neg    %rbx
    c443:	neg    %r8
    c446:	lea    (%rsi,%r9,1),%rax
    c44a:	lea    -0x1(%r10),%r13
    c44e:	shl    $0x4,%rbx
    c452:	lea    (%rax,%rdx,8),%rdx
    c456:	shr    $0x4,%r13
    c45a:	lea    -0x470(%rbp),%r14
    c461:	lea    (%rdx,%r11,1),%rcx
    c465:	neg    %r11
    c468:	nopl   0x0(%rax,%rax,1)
    c470:	vmovups (%rdx,%rbx,1),%zmm0
    c477:	vmovups (%rsi,%r8,1),%zmm1
    c47e:	mov    %r14,%rdi
    c481:	add    $0x40,%rsi
    c485:	vmovups (%rax,%rbx,1),%zmm2
    c48c:	vmovups (%rax),%zmm6
    c492:	add    $0x40,%rdx
    c496:	vmovups (%rax,%r8,1),%zmm4
    c49d:	vmovups (%rax,%r11,1),%zmm5
    c4a4:	vmovaps %zmm0,-0x2b0(%rbp)
    c4ae:	vmovups (%rax,%r10,4),%zmm7
    c4b5:	vmovups -0x40(%rsi),%zmm3
    c4bc:	vmovaps %zmm1,-0x470(%rbp)
    c4c6:	vmovups (%rcx,%r9,1),%zmm0
    c4cd:	vmovups (%rax,%r9,1),%zmm1
    c4d4:	vmovaps %zmm2,-0x430(%rbp)
    c4de:	vmovaps %zmm3,-0x3f0(%rbp)
    c4e8:	vmovups -0x40(%rdx,%r8,1),%zmm2
    c4f0:	vmovups -0x40(%rdx,%r11,1),%zmm3
    c4f8:	vmovaps %zmm4,-0x3b0(%rbp)
    c502:	vmovups -0x40(%rdx),%zmm4
    c509:	vmovaps %zmm5,-0x370(%rbp)
    c513:	vmovups (%rcx),%zmm5
    c519:	vmovaps %zmm6,-0x330(%rbp)
    c523:	vmovups (%rcx,%r10,4),%zmm6
    c52a:	vmovaps %zmm7,-0x2f0(%rbp)
    c534:	vmovups -0x40(%rdx,%r9,1),%zmm7
    c53c:	vmovaps %zmm0,-0xb0(%rbp)
    c546:	vmovaps %zmm24,%zmm0
    c54c:	vmovaps %zmm1,-0x270(%rbp)
    c556:	vmovaps %zmm2,-0x230(%rbp)
    c560:	vmovaps %zmm3,-0x1f0(%rbp)
    c56a:	vmovaps %zmm4,-0x1b0(%rbp)
    c574:	vmovaps %zmm5,-0x170(%rbp)
    c57e:	vmovaps %zmm6,-0x130(%rbp)
    c588:	vmovaps %zmm7,-0xf0(%rbp)
    c592:	call   c0d0 <tb16_bal>
    c597:	mov    %r12,%rdi
    c59a:	add    $0x1,%r12
    c59e:	vmovaps -0x470(%rbp),%zmm1
    c5a8:	vmovaps -0x430(%rbp),%zmm2
    c5b2:	vmovaps -0x3f0(%rbp),%zmm3
    c5bc:	vmovaps -0x3b0(%rbp),%zmm4
    c5c6:	vmovaps -0x370(%rbp),%zmm5
    c5d0:	vmovups %zmm1,-0x40(%rsi,%r8,1)
    c5d8:	vmovaps -0x330(%rbp),%zmm6
    c5e2:	vmovups %zmm2,(%rax,%rbx,1)
    c5e9:	vmovaps -0x2f0(%rbp),%zmm7
    c5f3:	vmovaps -0x2b0(%rbp),%zmm0
    c5fd:	vmovups %zmm3,-0x40(%rsi)
    c604:	vmovaps -0x270(%rbp),%zmm1
    c60e:	vmovups %zmm4,(%rax,%r8,1)
    c615:	vmovaps -0x230(%rbp),%zmm2
    c61f:	vmovaps -0x1f0(%rbp),%zmm3
    c629:	vmovups %zmm5,(%rax,%r11,1)
    c630:	vmovaps -0x1b0(%rbp),%zmm4
    c63a:	vmovaps -0x170(%rbp),%zmm5
    c644:	vmovups %zmm6,(%rax)
    c64a:	vmovaps -0x130(%rbp),%zmm6
    c654:	vmovups %zmm7,(%rax,%r10,4)
    c65b:	add    $0x40,%rax
    c65f:	vmovaps -0xf0(%rbp),%zmm7
    c669:	vmovups %zmm0,-0x40(%rdx,%rbx,1)
    c671:	vmovaps -0xb0(%rbp),%zmm0
    c67b:	vmovups %zmm1,-0x40(%rax,%r9,1)
    c683:	vmovups %zmm2,-0x40(%rdx,%r8,1)
    c68b:	vmovups %zmm3,-0x40(%rdx,%r11,1)
    c693:	vmovups %zmm4,-0x40(%rdx)
    c69a:	vmovups %zmm5,(%rcx)
    c6a0:	vmovups %zmm6,(%rcx,%r10,4)
    c6a7:	add    $0x40,%rcx
    c6ab:	vmovups %zmm7,-0x40(%rdx,%r9,1)
    c6b3:	vmovups %zmm0,-0x40(%rcx,%r9,1)
    c6bb:	cmp    %rdi,%r13
    c6be:	jne    c470 <pass_tb16_bal_1+0xa0>
    c6c4:	vzeroupper
    c6c7:	mov    -0x38(%rbp),%rax
    c6cb:	sub    %fs:0x28,%rax
    c6d4:	jne    c6ec <pass_tb16_bal_1+0x31c>
    c6d6:	add    $0x448,%rsp
    c6dd:	pop    %rbx
    c6de:	pop    %r10
    c6e0:	pop    %r12
    c6e2:	pop    %r13
    c6e4:	pop    %r14
    c6e6:	pop    %rbp
    c6e7:	lea    -0x8(%r10),%rsp
    c6eb:	ret
    c6ec:	call   4280 <__stack_chk_fail@plt>
    c6f1:	data16 cs nopw 0x0(%rax,%rax,1)
    c6fc:	nopl   0x0(%rax)

000000000000dfa0 <pass_tb16_balS_1>:
    dfa0:	endbr64
    dfa4:	lea    0x8(%rsp),%r10
    dfa9:	and    $0xffffffffffffffc0,%rsp
    dfad:	push   -0x8(%r10)
    dfb1:	push   %rbp
    dfb2:	mov    %rsp,%rbp
    dfb5:	push   %r14
    dfb7:	push   %r13
    dfb9:	push   %r12
    dfbb:	push   %r10
    dfbd:	push   %rbx
    dfbe:	sub    $0x448,%rsp
    dfc5:	vbroadcastss 0x50031(%rip),%zmm24        # 5e000 <_IO_stdin_used+0x1000>
    dfcf:	mov    %fs:0x28,%rax
    dfd8:	mov    %rax,-0x38(%rbp)
    dfdc:	xor    %eax,%eax
    dfde:	test   %rsi,%rsi
    dfe1:	je     e297 <pass_tb16_balS_1+0x2f7>
    dfe7:	lea    (%rsi,%rsi,2),%rdx
    dfeb:	mov    %rsi,%r10
    dfee:	xor    %r12d,%r12d
    dff1:	lea    0x0(,%rsi,8),%r8
    dff9:	lea    0x0(,%rsi,4),%r11
    e001:	mov    %r10,%rbx
    e004:	lea    0x0(,%rdx,4),%r9
    e00c:	lea    (%rdi,%r8,1),%rsi
    e010:	neg    %rbx
    e013:	neg    %r8
    e016:	lea    (%rsi,%r9,1),%rax
    e01a:	lea    -0x1(%r10),%r13
    e01e:	shl    $0x4,%rbx
    e022:	lea    (%rax,%rdx,8),%rdx
    e026:	shr    $0x4,%r13
    e02a:	lea    -0x470(%rbp),%r14
    e031:	lea    (%rdx,%r11,1),%rcx
    e035:	neg    %r11
    e038:	nopl   0x0(%rax,%rax,1)
    e040:	vmovups (%rdx,%rbx,1),%zmm0
    e047:	vmovups (%rsi,%r8,1),%zmm1
    e04e:	mov    %r14,%rdi
    e051:	add    $0x40,%rsi
    e055:	vmovups (%rax,%rbx,1),%zmm2
    e05c:	vmovups (%rax),%zmm6
    e062:	add    $0x40,%rdx
    e066:	vmovups (%rax,%r8,1),%zmm4
    e06d:	vmovups (%rax,%r11,1),%zmm5
    e074:	vmovaps %zmm0,-0x2b0(%rbp)
    e07e:	vmovups (%rax,%r10,4),%zmm7
    e085:	vmovups -0x40(%rsi),%zmm3
    e08c:	vmovaps %zmm1,-0x470(%rbp)
    e096:	vmovups (%rcx,%r9,1),%zmm0
    e09d:	vmovups (%rax,%r9,1),%zmm1
    e0a4:	vmovaps %zmm2,-0x430(%rbp)
    e0ae:	vmovaps %zmm3,-0x3f0(%rbp)
    e0b8:	vmovups -0x40(%rdx,%r8,1),%zmm2
    e0c0:	vmovups -0x40(%rdx,%r11,1),%zmm3
    e0c8:	vmovaps %zmm4,-0x3b0(%rbp)
    e0d2:	vmovups -0x40(%rdx),%zmm4
    e0d9:	vmovaps %zmm5,-0x370(%rbp)
    e0e3:	vmovups (%rcx),%zmm5
    e0e9:	vmovaps %zmm6,-0x330(%rbp)
    e0f3:	vmovups (%rcx,%r10,4),%zmm6
    e0fa:	vmovaps %zmm7,-0x2f0(%rbp)
    e104:	vmovups -0x40(%rdx,%r9,1),%zmm7
    e10c:	vmovaps %zmm0,-0xb0(%rbp)
    e116:	vmovaps %zmm24,%zmm0
    e11c:	vmovaps %zmm1,-0x270(%rbp)
    e126:	vmovaps %zmm2,-0x230(%rbp)
    e130:	vmovaps %zmm3,-0x1f0(%rbp)
    e13a:	vmovaps %zmm4,-0x1b0(%rbp)
    e144:	vmovaps %zmm5,-0x170(%rbp)
    e14e:	vmovaps %zmm6,-0x130(%rbp)
    e158:	vmovaps %zmm7,-0xf0(%rbp)
    e162:	call   dd00 <tb16_balS>
    e167:	mov    %r12,%rdi
    e16a:	add    $0x1,%r12
    e16e:	vmovaps -0x470(%rbp),%zmm1
    e178:	vmovaps -0x430(%rbp),%zmm2
    e182:	vmovaps -0x3f0(%rbp),%zmm3
    e18c:	vmovaps -0x3b0(%rbp),%zmm4
    e196:	vmovaps -0x370(%rbp),%zmm5
    e1a0:	vmovups %zmm1,-0x40(%rsi,%r8,1)
    e1a8:	vmovaps -0x330(%rbp),%zmm6
    e1b2:	vmovups %zmm2,(%rax,%rbx,1)
    e1b9:	vmovaps -0x2f0(%rbp),%zmm7
    e1c3:	vmovaps -0x2b0(%rbp),%zmm0
    e1cd:	vmovups %zmm3,-0x40(%rsi)
    e1d4:	vmovaps -0x270(%rbp),%zmm1
    e1de:	vmovups %zmm4,(%rax,%r8,1)
    e1e5:	vmovaps -0x230(%rbp),%zmm2
    e1ef:	vmovaps -0x1f0(%rbp),%zmm3
    e1f9:	vmovups %zmm5,(%rax,%r11,1)
    e200:	vmovaps -0x1b0(%rbp),%zmm4
    e20a:	vmovaps -0x170(%rbp),%zmm5
    e214:	vmovups %zmm6,(%rax)
    e21a:	vmovaps -0x130(%rbp),%zmm6
    e224:	vmovups %zmm7,(%rax,%r10,4)
    e22b:	add    $0x40,%rax
    e22f:	vmovaps -0xf0(%rbp),%zmm7
    e239:	vmovups %zmm0,-0x40(%rdx,%rbx,1)
    e241:	vmovaps -0xb0(%rbp),%zmm0
    e24b:	vmovups %zmm1,-0x40(%rax,%r9,1)
    e253:	vmovups %zmm2,-0x40(%rdx,%r8,1)
    e25b:	vmovups %zmm3,-0x40(%rdx,%r11,1)
    e263:	vmovups %zmm4,-0x40(%rdx)
    e26a:	vmovups %zmm5,(%rcx)
    e270:	vmovups %zmm6,(%rcx,%r10,4)
    e277:	add    $0x40,%rcx
    e27b:	vmovups %zmm7,-0x40(%rdx,%r9,1)
    e283:	vmovups %zmm0,-0x40(%rcx,%r9,1)
    e28b:	cmp    %rdi,%r13
    e28e:	jne    e040 <pass_tb16_balS_1+0xa0>
    e294:	vzeroupper
    e297:	mov    -0x38(%rbp),%rax
    e29b:	sub    %fs:0x28,%rax
    e2a4:	jne    e2bc <pass_tb16_balS_1+0x31c>
    e2a6:	add    $0x448,%rsp
    e2ad:	pop    %rbx
    e2ae:	pop    %r10
    e2b0:	pop    %r12
    e2b2:	pop    %r13
    e2b4:	pop    %r14
    e2b6:	pop    %rbp
    e2b7:	lea    -0x8(%r10),%rsp
    e2bb:	ret
    e2bc:	call   4280 <__stack_chk_fail@plt>
    e2c1:	data16 cs nopw 0x0(%rax,%rax,1)
    e2cc:	nopl   0x0(%rax)

00000000000101c0 <hf0_kid_nat>:
   101c0:	endbr64
   101c4:	push   %rbp
   101c5:	mov    %rdi,%rdx
   101c8:	mov    %rsp,%rbp
   101cb:	and    $0xffffffffffffffc0,%rsp
   101cf:	sub    $0x140,%rsp
   101d6:	vbroadcastss 0x4de20(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   101e0:	mov    %fs:0x28,%rax
   101e9:	mov    %rax,0x138(%rsp)
   101f1:	xor    %eax,%eax
   101f3:	mov    %rsp,%rdi
   101f6:	vzeroupper
   101f9:	call   10170 <inl_consts.constprop.1>
   101fe:	vmovaps (%rsp),%zmm2
   10205:	vmovaps 0x40(%rsp),%zmm3
   1020d:	vmovaps 0x80(%rsp),%zmm4
   10215:	vmovaps 0xc0(%rsp),%zmm5
   1021d:	test   %rsi,%rsi
   10220:	je     10284 <hf0_kid_nat+0xc4>
   10222:	lea    -0x4(,%rsi,4),%rax
   1022a:	mov    %rdx,%rdi
   1022d:	and    $0xffffffffffffffc0,%rax
   10231:	lea    0x40(%rdx,%rax,1),%rax
   10236:	cs nopw 0x0(%rax,%rax,1)
   10240:	vpermilps $0xb1,(%rdi),%zmm0
   10247:	vfmadd231ps (%rdi),%zmm2,%zmm0
   1024d:	add    $0x40,%rdi
   10251:	vpermilps $0x4e,%zmm0,%zmm1
   10258:	vfmadd132ps %zmm3,%zmm1,%zmm0
   1025e:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   10265:	vfmadd132ps %zmm4,%zmm1,%zmm0
   1026b:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   10272:	vfmadd132ps %zmm5,%zmm1,%zmm0
   10278:	vmovups %zmm0,-0x40(%rdi)
   1027f:	cmp    %rdi,%rax
   10282:	jne    10240 <hf0_kid_nat+0x80>
   10284:	mov    0x138(%rsp),%rax
   1028c:	sub    %fs:0x28,%rax
   10295:	jne    1029c <hf0_kid_nat+0xdc>
   10297:	vzeroupper
   1029a:	leave
   1029b:	ret
   1029c:	vzeroupper
   1029f:	call   4280 <__stack_chk_fail@plt>
   102a4:	data16 cs nopw 0x0(%rax,%rax,1)
   102af:	nop

00000000000102b0 <hf0_tb2_nat>:
   102b0:	endbr64
   102b4:	push   %rbp
   102b5:	mov    %rdi,%rdx
   102b8:	mov    %rsp,%rbp
   102bb:	and    $0xffffffffffffffc0,%rsp
   102bf:	sub    $0x140,%rsp
   102c6:	vbroadcastss 0x4dd30(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   102d0:	mov    %fs:0x28,%rax
   102d9:	mov    %rax,0x138(%rsp)
   102e1:	xor    %eax,%eax
   102e3:	mov    %rsp,%rdi
   102e6:	vzeroupper
   102e9:	call   10170 <inl_consts.constprop.1>
   102ee:	vmovaps (%rsp),%zmm2
   102f5:	vmovaps 0x40(%rsp),%zmm3
   102fd:	vmovaps 0x80(%rsp),%zmm4
   10305:	vmovaps 0xc0(%rsp),%zmm5
   1030d:	test   %rsi,%rsi
   10310:	je     103c1 <hf0_tb2_nat+0x111>
   10316:	lea    -0x4(,%rsi,4),%rax
   1031e:	mov    %rdx,%rdi
   10321:	and    $0xffffffffffffff80,%rax
   10325:	lea    0x80(%rdx,%rax,1),%rax
   1032d:	nopl   (%rax)
   10330:	vpermilps $0xb1,(%rdi),%zmm0
   10337:	vfmadd231ps (%rdi),%zmm2,%zmm0
   1033d:	sub    $0xffffffffffffff80,%rdi
   10341:	vpermilps $0x4e,%zmm0,%zmm1
   10348:	vfmadd132ps %zmm3,%zmm1,%zmm0
   1034e:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   10355:	vfmadd132ps %zmm4,%zmm1,%zmm0
   1035b:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   10362:	vfmadd132ps %zmm5,%zmm1,%zmm0
   10368:	vpermilps $0xb1,-0x40(%rdi),%zmm1
   10370:	vfmadd231ps -0x40(%rdi),%zmm2,%zmm1
   10377:	vpermilps $0x4e,%zmm1,%zmm6
   1037e:	vfmadd132ps %zmm3,%zmm6,%zmm1
   10384:	vshuff32x4 $0xb1,%zmm1,%zmm1,%zmm6
   1038b:	vfmadd132ps %zmm4,%zmm6,%zmm1
   10391:	vshuff32x4 $0x4e,%zmm1,%zmm1,%zmm6
   10398:	vfmadd132ps %zmm5,%zmm6,%zmm1
   1039e:	vaddps %zmm1,%zmm0,%zmm6
   103a4:	vsubps %zmm1,%zmm0,%zmm0
   103aa:	vmovups %zmm6,-0x80(%rdi)
   103b1:	vmovups %zmm0,-0x40(%rdi)
   103b8:	cmp    %rdi,%rax
   103bb:	jne    10330 <hf0_tb2_nat+0x80>
   103c1:	mov    0x138(%rsp),%rax
   103c9:	sub    %fs:0x28,%rax
   103d2:	jne    103d9 <hf0_tb2_nat+0x129>
   103d4:	vzeroupper
   103d7:	leave
   103d8:	ret
   103d9:	vzeroupper
   103dc:	call   4280 <__stack_chk_fail@plt>
   103e1:	data16 cs nopw 0x0(%rax,%rax,1)
   103ec:	nopl   0x0(%rax)

00000000000103f0 <hf0_tb4_nat>:
   103f0:	endbr64
   103f4:	push   %rbp
   103f5:	mov    %rdi,%rdx
   103f8:	mov    %rsp,%rbp
   103fb:	and    $0xffffffffffffffc0,%rsp
   103ff:	sub    $0x140,%rsp
   10406:	vbroadcastss 0x4dbf0(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   10410:	mov    %fs:0x28,%rax
   10419:	mov    %rax,0x138(%rsp)
   10421:	xor    %eax,%eax
   10423:	mov    %rsp,%rdi
   10426:	vzeroupper
   10429:	call   10170 <inl_consts.constprop.1>
   1042e:	vmovaps (%rsp),%zmm5
   10435:	vmovaps 0x40(%rsp),%zmm6
   1043d:	vmovaps 0x80(%rsp),%zmm7
   10445:	vmovaps 0xc0(%rsp),%zmm8
   1044d:	test   %rsi,%rsi
   10450:	je     105a7 <hf0_tb4_nat+0x1b7>
   10456:	mov    %rdx,%rax
   10459:	lea    -0x4(,%rsi,4),%rdx
   10461:	xor    %dl,%dl
   10463:	lea    0x100(%rax,%rdx,1),%rdx
   1046b:	nopl   0x0(%rax,%rax,1)
   10470:	vpermilps $0xb1,(%rax),%zmm0
   10477:	vfmadd231ps (%rax),%zmm5,%zmm0
   1047d:	add    $0x100,%rax
   10483:	vpermilps $0x4e,%zmm0,%zmm1
   1048a:	vfmadd132ps %zmm6,%zmm1,%zmm0
   10490:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   10497:	vfmadd132ps %zmm7,%zmm1,%zmm0
   1049d:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   104a4:	vfmadd132ps %zmm8,%zmm1,%zmm0
   104aa:	vpermilps $0xb1,-0xc0(%rax),%zmm1
   104b2:	vfmadd231ps -0xc0(%rax),%zmm5,%zmm1
   104b9:	vpermilps $0x4e,%zmm1,%zmm2
   104c0:	vfmadd132ps %zmm6,%zmm2,%zmm1
   104c6:	vshuff32x4 $0xb1,%zmm1,%zmm1,%zmm2
   104cd:	vfmadd132ps %zmm7,%zmm2,%zmm1
   104d3:	vshuff32x4 $0x4e,%zmm1,%zmm1,%zmm2
   104da:	vmovaps %zmm1,%zmm3
   104e0:	vpermilps $0xb1,-0x80(%rax),%zmm1
   104e8:	vfmadd231ps -0x80(%rax),%zmm5,%zmm1
   104ef:	vfmadd132ps %zmm8,%zmm2,%zmm3
   104f5:	vpermilps $0x4e,%zmm1,%zmm2
   104fc:	vfmadd132ps %zmm6,%zmm2,%zmm1
   10502:	vshuff32x4 $0xb1,%zmm1,%zmm1,%zmm2
   10509:	vfmadd132ps %zmm7,%zmm2,%zmm1
   1050f:	vshuff32x4 $0x4e,%zmm1,%zmm1,%zmm2
   10516:	vfmadd132ps %zmm8,%zmm2,%zmm1
   1051c:	vpermilps $0xb1,-0x40(%rax),%zmm2
   10524:	vfmadd231ps -0x40(%rax),%zmm5,%zmm2
   1052b:	vpermilps $0x4e,%zmm2,%zmm4
   10532:	vfmadd132ps %zmm6,%zmm4,%zmm2
   10538:	vshuff32x4 $0xb1,%zmm2,%zmm2,%zmm4
   1053f:	vfmadd132ps %zmm7,%zmm4,%zmm2
   10545:	vshuff32x4 $0x4e,%zmm2,%zmm2,%zmm4
   1054c:	vfmadd132ps %zmm8,%zmm4,%zmm2
   10552:	vaddps %zmm3,%zmm0,%zmm4
   10558:	vsubps %zmm3,%zmm0,%zmm0
   1055e:	vaddps %zmm2,%zmm1,%zmm3
   10564:	vsubps %zmm2,%zmm1,%zmm1
   1056a:	vaddps %zmm3,%zmm4,%zmm2
   10570:	vsubps %zmm3,%zmm4,%zmm4
   10576:	vmovups %zmm2,-0x100(%rax)
   1057d:	vaddps %zmm1,%zmm0,%zmm2
   10583:	vsubps %zmm1,%zmm0,%zmm0
   10589:	vmovups %zmm4,-0x80(%rax)
   10590:	vmovups %zmm2,-0xc0(%rax)
   10597:	vmovups %zmm0,-0x40(%rax)
   1059e:	cmp    %rax,%rdx
   105a1:	jne    10470 <hf0_tb4_nat+0x80>
   105a7:	mov    0x138(%rsp),%rax
   105af:	sub    %fs:0x28,%rax
   105b8:	jne    105bf <hf0_tb4_nat+0x1cf>
   105ba:	vzeroupper
   105bd:	leave
   105be:	ret
   105bf:	vzeroupper
   105c2:	call   4280 <__stack_chk_fail@plt>
   105c7:	nopw   0x0(%rax,%rax,1)

00000000000105d0 <hf0_tb8_bal>:
   105d0:	endbr64
   105d4:	lea    0x8(%rsp),%r10
   105d9:	and    $0xffffffffffffffc0,%rsp
   105dd:	mov    %rdi,%rdx
   105e0:	push   -0x8(%r10)
   105e4:	push   %rbp
   105e5:	mov    %rsp,%rbp
   105e8:	push   %r10
   105ea:	sub    $0x368,%rsp
   105f1:	vbroadcastss 0x4da05(%rip),%zmm16        # 5e000 <_IO_stdin_used+0x1000>
   105fb:	mov    %fs:0x28,%rax
   10604:	mov    %rax,-0x38(%rbp)
   10608:	xor    %eax,%eax
   1060a:	lea    -0x370(%rbp),%rdi
   10611:	call   10170 <inl_consts.constprop.1>
   10616:	vmovaps -0x370(%rbp),%zmm12
   10620:	vmovaps -0x330(%rbp),%zmm13
   1062a:	vmovaps -0x2f0(%rbp),%zmm14
   10634:	vmovaps -0x2b0(%rbp),%zmm15
   1063e:	test   %rsi,%rsi
   10641:	je     10907 <hf0_tb8_bal+0x337>
   10647:	sub    $0x1,%rsi
   1064b:	mov    %rdx,%rax
   1064e:	lea    -0x270(%rbp),%rdi
   10655:	xor    %edx,%edx
   10657:	shr    $0x7,%rsi
   1065b:	nopl   0x0(%rax,%rax,1)
   10660:	vpermilps $0xb1,(%rax),%zmm0
   10667:	vfmadd231ps (%rax),%zmm12,%zmm0
   1066d:	mov    %rdx,%rcx
   10670:	add    $0x200,%rax
   10676:	add    $0x1,%rdx
   1067a:	vpermilps $0x4e,%zmm0,%zmm1
   10681:	vfmadd132ps %zmm13,%zmm1,%zmm0
   10687:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1068e:	vfmadd132ps %zmm14,%zmm1,%zmm0
   10694:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1069b:	vfmadd132ps %zmm15,%zmm1,%zmm0
   106a1:	vmovaps %zmm0,-0x270(%rbp)
   106ab:	vpermilps $0xb1,-0x1c0(%rax),%zmm0
   106b3:	vfmadd231ps -0x1c0(%rax),%zmm12,%zmm0
   106ba:	vpermilps $0x4e,%zmm0,%zmm1
   106c1:	vfmadd132ps %zmm13,%zmm1,%zmm0
   106c7:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   106ce:	vfmadd132ps %zmm14,%zmm1,%zmm0
   106d4:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   106db:	vfmadd132ps %zmm15,%zmm1,%zmm0
   106e1:	vmovaps %zmm0,-0x230(%rbp)
   106eb:	vpermilps $0xb1,-0x180(%rax),%zmm0
   106f3:	vfmadd231ps -0x180(%rax),%zmm12,%zmm0
   106fa:	vpermilps $0x4e,%zmm0,%zmm1
   10701:	vfmadd132ps %zmm13,%zmm1,%zmm0
   10707:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1070e:	vfmadd132ps %zmm14,%zmm1,%zmm0
   10714:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1071b:	vfmadd132ps %zmm15,%zmm1,%zmm0
   10721:	vmovaps %zmm0,-0x1f0(%rbp)
   1072b:	vpermilps $0xb1,-0x140(%rax),%zmm0
   10733:	vfmadd231ps -0x140(%rax),%zmm12,%zmm0
   1073a:	vpermilps $0x4e,%zmm0,%zmm1
   10741:	vfmadd132ps %zmm13,%zmm1,%zmm0
   10747:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1074e:	vfmadd132ps %zmm14,%zmm1,%zmm0
   10754:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1075b:	vfmadd132ps %zmm15,%zmm1,%zmm0
   10761:	vmovaps %zmm0,-0x1b0(%rbp)
   1076b:	vpermilps $0xb1,-0x100(%rax),%zmm0
   10773:	vfmadd231ps -0x100(%rax),%zmm12,%zmm0
   1077a:	vpermilps $0x4e,%zmm0,%zmm1
   10781:	vfmadd132ps %zmm13,%zmm1,%zmm0
   10787:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1078e:	vfmadd132ps %zmm14,%zmm1,%zmm0
   10794:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1079b:	vfmadd132ps %zmm15,%zmm1,%zmm0
   107a1:	vmovaps %zmm0,-0x170(%rbp)
   107ab:	vpermilps $0xb1,-0xc0(%rax),%zmm0
   107b3:	vfmadd231ps -0xc0(%rax),%zmm12,%zmm0
   107ba:	vpermilps $0x4e,%zmm0,%zmm1
   107c1:	vfmadd132ps %zmm13,%zmm1,%zmm0
   107c7:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   107ce:	vfmadd132ps %zmm14,%zmm1,%zmm0
   107d4:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   107db:	vfmadd132ps %zmm15,%zmm1,%zmm0
   107e1:	vmovaps %zmm0,-0x130(%rbp)
   107eb:	vpermilps $0xb1,-0x80(%rax),%zmm0
   107f3:	vfmadd231ps -0x80(%rax),%zmm12,%zmm0
   107fa:	vpermilps $0x4e,%zmm0,%zmm1
   10801:	vfmadd132ps %zmm13,%zmm1,%zmm0
   10807:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1080e:	vfmadd132ps %zmm14,%zmm1,%zmm0
   10814:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1081b:	vfmadd132ps %zmm15,%zmm1,%zmm0
   10821:	vmovaps %zmm0,-0xf0(%rbp)
   1082b:	vpermilps $0xb1,-0x40(%rax),%zmm0
   10833:	vfmadd231ps -0x40(%rax),%zmm12,%zmm0
   1083a:	vpermilps $0x4e,%zmm0,%zmm1
   10841:	vfmadd132ps %zmm13,%zmm1,%zmm0
   10847:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1084e:	vfmadd132ps %zmm14,%zmm1,%zmm0
   10854:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1085b:	vfmadd132ps %zmm15,%zmm1,%zmm0
   10861:	vmovaps %zmm0,-0xb0(%rbp)
   1086b:	vmovaps %zmm16,%zmm0
   10871:	call   d9a0 <tb8_bal>
   10876:	vmovaps -0x270(%rbp),%zmm2
   10880:	vmovaps -0x230(%rbp),%zmm3
   1088a:	vmovaps -0x1f0(%rbp),%zmm4
   10894:	vmovaps -0x1b0(%rbp),%zmm5
   1089e:	vmovups %zmm2,-0x200(%rax)
   108a5:	vmovaps -0x170(%rbp),%zmm6
   108af:	vmovaps -0x130(%rbp),%zmm7
   108b9:	vmovups %zmm3,-0x1c0(%rax)
   108c0:	vmovaps -0xf0(%rbp),%zmm2
   108ca:	vmovaps -0xb0(%rbp),%zmm3
   108d4:	vmovups %zmm4,-0x180(%rax)
   108db:	vmovups %zmm5,-0x140(%rax)
   108e2:	vmovups %zmm6,-0x100(%rax)
   108e9:	vmovups %zmm7,-0xc0(%rax)
   108f0:	vmovups %zmm2,-0x80(%rax)
   108f7:	vmovups %zmm3,-0x40(%rax)
   108fe:	cmp    %rcx,%rsi
   10901:	jne    10660 <hf0_tb8_bal+0x90>
   10907:	mov    -0x38(%rbp),%rax
   1090b:	sub    %fs:0x28,%rax
   10914:	jne    10923 <hf0_tb8_bal+0x353>
   10916:	vzeroupper
   10919:	mov    -0x8(%rbp),%r10
   1091d:	leave
   1091e:	lea    -0x8(%r10),%rsp
   10922:	ret
   10923:	vzeroupper
   10926:	call   4280 <__stack_chk_fail@plt>
   1092b:	nopl   0x0(%rax,%rax,1)

0000000000010930 <hf0_tb8_balS>:
   10930:	endbr64
   10934:	lea    0x8(%rsp),%r10
   10939:	and    $0xffffffffffffffc0,%rsp
   1093d:	mov    %rdi,%rdx
   10940:	push   -0x8(%r10)
   10944:	push   %rbp
   10945:	mov    %rsp,%rbp
   10948:	push   %r10
   1094a:	sub    $0x368,%rsp
   10951:	vbroadcastss 0x4d6a5(%rip),%zmm16        # 5e000 <_IO_stdin_used+0x1000>
   1095b:	mov    %fs:0x28,%rax
   10964:	mov    %rax,-0x38(%rbp)
   10968:	xor    %eax,%eax
   1096a:	lea    -0x370(%rbp),%rdi
   10971:	call   10170 <inl_consts.constprop.1>
   10976:	vmovaps -0x370(%rbp),%zmm12
   10980:	vmovaps -0x330(%rbp),%zmm13
   1098a:	vmovaps -0x2f0(%rbp),%zmm14
   10994:	vmovaps -0x2b0(%rbp),%zmm15
   1099e:	test   %rsi,%rsi
   109a1:	je     10c67 <hf0_tb8_balS+0x337>
   109a7:	sub    $0x1,%rsi
   109ab:	mov    %rdx,%rax
   109ae:	lea    -0x270(%rbp),%rdi
   109b5:	xor    %edx,%edx
   109b7:	shr    $0x7,%rsi
   109bb:	nopl   0x0(%rax,%rax,1)
   109c0:	vpermilps $0xb1,(%rax),%zmm0
   109c7:	vfmadd231ps (%rax),%zmm12,%zmm0
   109cd:	mov    %rdx,%rcx
   109d0:	add    $0x200,%rax
   109d6:	add    $0x1,%rdx
   109da:	vpermilps $0x4e,%zmm0,%zmm1
   109e1:	vfmadd132ps %zmm13,%zmm1,%zmm0
   109e7:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   109ee:	vfmadd132ps %zmm14,%zmm1,%zmm0
   109f4:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   109fb:	vfmadd132ps %zmm15,%zmm1,%zmm0
   10a01:	vmovaps %zmm0,-0x270(%rbp)
   10a0b:	vpermilps $0xb1,-0x1c0(%rax),%zmm0
   10a13:	vfmadd231ps -0x1c0(%rax),%zmm12,%zmm0
   10a1a:	vpermilps $0x4e,%zmm0,%zmm1
   10a21:	vfmadd132ps %zmm13,%zmm1,%zmm0
   10a27:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   10a2e:	vfmadd132ps %zmm14,%zmm1,%zmm0
   10a34:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   10a3b:	vfmadd132ps %zmm15,%zmm1,%zmm0
   10a41:	vmovaps %zmm0,-0x230(%rbp)
   10a4b:	vpermilps $0xb1,-0x180(%rax),%zmm0
   10a53:	vfmadd231ps -0x180(%rax),%zmm12,%zmm0
   10a5a:	vpermilps $0x4e,%zmm0,%zmm1
   10a61:	vfmadd132ps %zmm13,%zmm1,%zmm0
   10a67:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   10a6e:	vfmadd132ps %zmm14,%zmm1,%zmm0
   10a74:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   10a7b:	vfmadd132ps %zmm15,%zmm1,%zmm0
   10a81:	vmovaps %zmm0,-0x1f0(%rbp)
   10a8b:	vpermilps $0xb1,-0x140(%rax),%zmm0
   10a93:	vfmadd231ps -0x140(%rax),%zmm12,%zmm0
   10a9a:	vpermilps $0x4e,%zmm0,%zmm1
   10aa1:	vfmadd132ps %zmm13,%zmm1,%zmm0
   10aa7:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   10aae:	vfmadd132ps %zmm14,%zmm1,%zmm0
   10ab4:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   10abb:	vfmadd132ps %zmm15,%zmm1,%zmm0
   10ac1:	vmovaps %zmm0,-0x1b0(%rbp)
   10acb:	vpermilps $0xb1,-0x100(%rax),%zmm0
   10ad3:	vfmadd231ps -0x100(%rax),%zmm12,%zmm0
   10ada:	vpermilps $0x4e,%zmm0,%zmm1
   10ae1:	vfmadd132ps %zmm13,%zmm1,%zmm0
   10ae7:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   10aee:	vfmadd132ps %zmm14,%zmm1,%zmm0
   10af4:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   10afb:	vfmadd132ps %zmm15,%zmm1,%zmm0
   10b01:	vmovaps %zmm0,-0x170(%rbp)
   10b0b:	vpermilps $0xb1,-0xc0(%rax),%zmm0
   10b13:	vfmadd231ps -0xc0(%rax),%zmm12,%zmm0
   10b1a:	vpermilps $0x4e,%zmm0,%zmm1
   10b21:	vfmadd132ps %zmm13,%zmm1,%zmm0
   10b27:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   10b2e:	vfmadd132ps %zmm14,%zmm1,%zmm0
   10b34:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   10b3b:	vfmadd132ps %zmm15,%zmm1,%zmm0
   10b41:	vmovaps %zmm0,-0x130(%rbp)
   10b4b:	vpermilps $0xb1,-0x80(%rax),%zmm0
   10b53:	vfmadd231ps -0x80(%rax),%zmm12,%zmm0
   10b5a:	vpermilps $0x4e,%zmm0,%zmm1
   10b61:	vfmadd132ps %zmm13,%zmm1,%zmm0
   10b67:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   10b6e:	vfmadd132ps %zmm14,%zmm1,%zmm0
   10b74:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   10b7b:	vfmadd132ps %zmm15,%zmm1,%zmm0
   10b81:	vmovaps %zmm0,-0xf0(%rbp)
   10b8b:	vpermilps $0xb1,-0x40(%rax),%zmm0
   10b93:	vfmadd231ps -0x40(%rax),%zmm12,%zmm0
   10b9a:	vpermilps $0x4e,%zmm0,%zmm1
   10ba1:	vfmadd132ps %zmm13,%zmm1,%zmm0
   10ba7:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   10bae:	vfmadd132ps %zmm14,%zmm1,%zmm0
   10bb4:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   10bbb:	vfmadd132ps %zmm15,%zmm1,%zmm0
   10bc1:	vmovaps %zmm0,-0xb0(%rbp)
   10bcb:	vmovaps %zmm16,%zmm0
   10bd1:	call   dbe0 <tb8_balS>
   10bd6:	vmovaps -0x270(%rbp),%zmm2
   10be0:	vmovaps -0x230(%rbp),%zmm3
   10bea:	vmovaps -0x1f0(%rbp),%zmm4
   10bf4:	vmovaps -0x1b0(%rbp),%zmm5
   10bfe:	vmovups %zmm2,-0x200(%rax)
   10c05:	vmovaps -0x170(%rbp),%zmm6
   10c0f:	vmovaps -0x130(%rbp),%zmm7
   10c19:	vmovups %zmm3,-0x1c0(%rax)
   10c20:	vmovaps -0xf0(%rbp),%zmm2
   10c2a:	vmovaps -0xb0(%rbp),%zmm3
   10c34:	vmovups %zmm4,-0x180(%rax)
   10c3b:	vmovups %zmm5,-0x140(%rax)
   10c42:	vmovups %zmm6,-0x100(%rax)
   10c49:	vmovups %zmm7,-0xc0(%rax)
   10c50:	vmovups %zmm2,-0x80(%rax)
   10c57:	vmovups %zmm3,-0x40(%rax)
   10c5e:	cmp    %rcx,%rsi
   10c61:	jne    109c0 <hf0_tb8_balS+0x90>
   10c67:	mov    -0x38(%rbp),%rax
   10c6b:	sub    %fs:0x28,%rax
   10c74:	jne    10c83 <hf0_tb8_balS+0x353>
   10c76:	vzeroupper
   10c79:	mov    -0x8(%rbp),%r10
   10c7d:	leave
   10c7e:	lea    -0x8(%r10),%rsp
   10c82:	ret
   10c83:	vzeroupper
   10c86:	call   4280 <__stack_chk_fail@plt>
   10c8b:	nopl   0x0(%rax,%rax,1)

0000000000013220 <hf0_tb8_nat>:
   13220:	endbr64
   13224:	push   %rbp
   13225:	mov    %rdi,%rdx
   13228:	mov    %rsp,%rbp
   1322b:	and    $0xffffffffffffffc0,%rsp
   1322f:	sub    $0x340,%rsp
   13236:	vbroadcastss 0x4adc0(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   13240:	mov    %fs:0x28,%rax
   13249:	mov    %rax,0x338(%rsp)
   13251:	xor    %eax,%eax
   13253:	mov    %rsp,%rdi
   13256:	vzeroupper
   13259:	call   10170 <inl_consts.constprop.1>
   1325e:	vmovaps (%rsp),%zmm16
   13265:	vmovaps 0x40(%rsp),%zmm17
   1326d:	vmovaps 0x80(%rsp),%zmm18
   13275:	vmovaps 0xc0(%rsp),%zmm19
   1327d:	test   %rsi,%rsi
   13280:	je     13527 <hf0_tb8_nat+0x307>
   13286:	sub    $0x1,%rsi
   1328a:	mov    %rdx,%rax
   1328d:	lea    0x100(%rsp),%rdi
   13295:	xor    %edx,%edx
   13297:	shr    $0x7,%rsi
   1329b:	nopl   0x0(%rax,%rax,1)
   132a0:	vpermilps $0xb1,(%rax),%zmm0
   132a7:	vfmadd231ps (%rax),%zmm16,%zmm0
   132ad:	mov    %rdx,%rcx
   132b0:	vpermilps $0x4e,%zmm0,%zmm1
   132b7:	vfmadd132ps %zmm17,%zmm1,%zmm0
   132bd:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   132c4:	vfmadd132ps %zmm18,%zmm1,%zmm0
   132ca:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   132d1:	vfmadd132ps %zmm19,%zmm1,%zmm0
   132d7:	vmovaps %zmm0,0x100(%rsp)
   132df:	vpermilps $0xb1,0x40(%rax),%zmm0
   132e7:	vfmadd231ps 0x40(%rax),%zmm16,%zmm0
   132ee:	vpermilps $0x4e,%zmm0,%zmm1
   132f5:	vfmadd132ps %zmm17,%zmm1,%zmm0
   132fb:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   13302:	vfmadd132ps %zmm18,%zmm1,%zmm0
   13308:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1330f:	vfmadd132ps %zmm19,%zmm1,%zmm0
   13315:	vmovaps %zmm0,0x140(%rsp)
   1331d:	vpermilps $0xb1,0x80(%rax),%zmm0
   13325:	vfmadd231ps 0x80(%rax),%zmm16,%zmm0
   1332c:	vpermilps $0x4e,%zmm0,%zmm1
   13333:	vfmadd132ps %zmm17,%zmm1,%zmm0
   13339:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   13340:	vfmadd132ps %zmm18,%zmm1,%zmm0
   13346:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1334d:	vfmadd132ps %zmm19,%zmm1,%zmm0
   13353:	vmovaps %zmm0,0x180(%rsp)
   1335b:	vpermilps $0xb1,0xc0(%rax),%zmm0
   13363:	vfmadd231ps 0xc0(%rax),%zmm16,%zmm0
   1336a:	vpermilps $0x4e,%zmm0,%zmm1
   13371:	vfmadd132ps %zmm17,%zmm1,%zmm0
   13377:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1337e:	vfmadd132ps %zmm18,%zmm1,%zmm0
   13384:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1338b:	vfmadd132ps %zmm19,%zmm1,%zmm0
   13391:	vmovaps %zmm0,0x1c0(%rsp)
   13399:	vpermilps $0xb1,0x100(%rax),%zmm0
   133a1:	vfmadd231ps 0x100(%rax),%zmm16,%zmm0
   133a8:	vpermilps $0x4e,%zmm0,%zmm1
   133af:	vfmadd132ps %zmm17,%zmm1,%zmm0
   133b5:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   133bc:	vfmadd132ps %zmm18,%zmm1,%zmm0
   133c2:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   133c9:	vfmadd132ps %zmm19,%zmm1,%zmm0
   133cf:	vmovaps %zmm0,0x200(%rsp)
   133d7:	vpermilps $0xb1,0x140(%rax),%zmm0
   133df:	vfmadd231ps 0x140(%rax),%zmm16,%zmm0
   133e6:	vpermilps $0x4e,%zmm0,%zmm1
   133ed:	vfmadd132ps %zmm17,%zmm1,%zmm0
   133f3:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   133fa:	vfmadd132ps %zmm18,%zmm1,%zmm0
   13400:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   13407:	vfmadd132ps %zmm19,%zmm1,%zmm0
   1340d:	vmovaps %zmm0,0x240(%rsp)
   13415:	vpermilps $0xb1,0x180(%rax),%zmm0
   1341d:	vfmadd231ps 0x180(%rax),%zmm16,%zmm0
   13424:	vpermilps $0x4e,%zmm0,%zmm1
   1342b:	vfmadd132ps %zmm17,%zmm1,%zmm0
   13431:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   13438:	vfmadd132ps %zmm18,%zmm1,%zmm0
   1343e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   13445:	vfmadd132ps %zmm19,%zmm1,%zmm0
   1344b:	vmovaps %zmm0,0x280(%rsp)
   13453:	vpermilps $0xb1,0x1c0(%rax),%zmm0
   1345b:	vfmadd231ps 0x1c0(%rax),%zmm16,%zmm0
   13462:	vpermilps $0x4e,%zmm0,%zmm1
   13469:	vfmadd132ps %zmm17,%zmm1,%zmm0
   1346f:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   13476:	vfmadd132ps %zmm18,%zmm1,%zmm0
   1347c:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   13483:	vfmadd132ps %zmm19,%zmm1,%zmm0
   13489:	vmovaps %zmm0,0x2c0(%rsp)
   13491:	vzeroupper
   13494:	call   13130 <tb8_nat.constprop.0>
   13499:	add    $0x1,%rdx
   1349d:	vmovaps 0x100(%rsp),%zmm2
   134a5:	vmovaps 0x140(%rsp),%zmm3
   134ad:	vmovaps 0x180(%rsp),%zmm4
   134b5:	add    $0x200,%rax
   134bb:	vmovups %zmm2,-0x200(%rax)
   134c2:	vmovaps 0x1c0(%rsp),%zmm5
   134ca:	vmovaps 0x200(%rsp),%zmm6
   134d2:	vmovups %zmm3,-0x1c0(%rax)
   134d9:	vmovaps 0x240(%rsp),%zmm7
   134e1:	vmovaps 0x280(%rsp),%zmm2
   134e9:	vmovaps 0x2c0(%rsp),%zmm3
   134f1:	vmovups %zmm4,-0x180(%rax)
   134f8:	vmovups %zmm5,-0x140(%rax)
   134ff:	vmovups %zmm6,-0x100(%rax)
   13506:	vmovups %zmm7,-0xc0(%rax)
   1350d:	vmovups %zmm2,-0x80(%rax)
   13514:	vmovups %zmm3,-0x40(%rax)
   1351b:	cmp    %rcx,%rsi
   1351e:	jne    132a0 <hf0_tb8_nat+0x80>
   13524:	vzeroupper
   13527:	mov    0x338(%rsp),%rax
   1352f:	sub    %fs:0x28,%rax
   13538:	jne    1353c <hf0_tb8_nat+0x31c>
   1353a:	leave
   1353b:	ret
   1353c:	call   4280 <__stack_chk_fail@plt>
   13541:	data16 cs nopw 0x0(%rax,%rax,1)
   1354c:	nopl   0x0(%rax)

0000000000015130 <hf2_broken_g52>:
   15130:	endbr64
   15134:	push   %rbp
   15135:	mov    %rsp,%rbp
   15138:	and    $0xffffffffffffffc0,%rsp
   1513c:	sub    $0x440,%rsp
   15143:	vbroadcastss 0x48eb3(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   1514d:	mov    %fs:0x28,%rax
   15156:	mov    %rax,0x438(%rsp)
   1515e:	xor    %eax,%eax
   15160:	test   %rsi,%rsi
   15163:	je     15337 <hf2_broken_g52+0x207>
   15169:	vmovdqa32 0x48c8d(%rip),%zmm21        # 5de00 <_IO_stdin_used+0xe00>
   15173:	mov    %rdi,%rdx
   15176:	xor    %r8d,%r8d
   15179:	vmovdqa32 0x48cbd(%rip),%zmm20        # 5de40 <_IO_stdin_used+0xe40>
   15183:	vmovdqa32 0x48cf3(%rip),%zmm19        # 5de80 <_IO_stdin_used+0xe80>
   1518d:	mov    $0xffffaaaa,%eax
   15192:	mov    %rsp,%rcx
   15195:	vmovdqa32 0x48d21(%rip),%zmm18        # 5dec0 <_IO_stdin_used+0xec0>
   1519f:	kmovw  %eax,%k4
   151a3:	nopl   0x0(%rax,%rax,1)
   151a8:	mov    $0xffffcccc,%edi
   151ad:	xor    %eax,%eax
   151af:	kmovw  %edi,%k3
   151b3:	mov    $0xfffff0f0,%edi
   151b8:	kmovw  %edi,%k2
   151bc:	mov    $0xffffff00,%edi
   151c1:	kmovw  %edi,%k1
   151c5:	nopl   (%rax)
   151c8:	vpermps (%rdx,%rax,1),%zmm21,%zmm1
   151cf:	vaddps (%rdx,%rax,1),%zmm1,%zmm0
   151d6:	vsubps (%rdx,%rax,1),%zmm1,%zmm0{%k4}
   151dd:	vpermps %zmm0,%zmm20,%zmm2
   151e3:	vaddps %zmm0,%zmm2,%zmm1
   151e9:	vsubps %zmm0,%zmm2,%zmm1{%k3}
   151ef:	vpermps %zmm1,%zmm19,%zmm2
   151f5:	vaddps %zmm1,%zmm2,%zmm0
   151fb:	vsubps %zmm1,%zmm2,%zmm0{%k2}
   15201:	vpermps %zmm0,%zmm18,%zmm2
   15207:	vaddps %zmm0,%zmm2,%zmm1
   1520d:	vsubps %zmm0,%zmm2,%zmm1{%k1}
   15213:	vmovaps %zmm1,(%rcx,%rax,1)
   1521a:	add    $0x40,%rax
   1521e:	cmp    $0x400,%rax
   15224:	jne    151c8 <hf2_broken_g52+0x98>
   15226:	mov    %rcx,%rdi
   15229:	vzeroupper
   1522c:	add    $0x100,%r8
   15233:	add    $0x400,%rdx
   1523a:	call   14f10 <g52_nat.constprop.0>
   1523f:	vmovaps (%rsp),%zmm3
   15246:	vmovaps 0x40(%rsp),%zmm4
   1524e:	vmovaps 0x80(%rsp),%zmm5
   15256:	vmovaps 0xc0(%rsp),%zmm6
   1525e:	vmovaps 0x100(%rsp),%zmm7
   15266:	vmovups %zmm3,-0x400(%rdx)
   1526d:	vmovaps 0x180(%rsp),%zmm3
   15275:	vmovups %zmm4,-0x3c0(%rdx)
   1527c:	vmovaps 0x140(%rsp),%zmm4
   15284:	vmovups %zmm5,-0x380(%rdx)
   1528b:	vmovaps 0x1c0(%rsp),%zmm5
   15293:	vmovups %zmm6,-0x340(%rdx)
   1529a:	vmovaps 0x200(%rsp),%zmm6
   152a2:	vmovups %zmm7,-0x300(%rdx)
   152a9:	vmovaps 0x240(%rsp),%zmm7
   152b1:	vmovups %zmm3,-0x2c0(%rdx)
   152b8:	vmovaps 0x280(%rsp),%zmm3
   152c0:	vmovups %zmm4,-0x280(%rdx)
   152c7:	vmovaps 0x2c0(%rsp),%zmm4
   152cf:	vmovups %zmm5,-0x240(%rdx)
   152d6:	vmovaps 0x300(%rsp),%zmm5
   152de:	vmovups %zmm6,-0x200(%rdx)
   152e5:	vmovaps 0x340(%rsp),%zmm6
   152ed:	vmovups %zmm7,-0x1c0(%rdx)
   152f4:	vmovaps 0x380(%rsp),%zmm7
   152fc:	vmovups %zmm3,-0x180(%rdx)
   15303:	vmovaps 0x3c0(%rsp),%zmm3
   1530b:	vmovups %zmm4,-0x140(%rdx)
   15312:	vmovups %zmm5,-0x100(%rdx)
   15319:	vmovups %zmm6,-0xc0(%rdx)
   15320:	vmovups %zmm7,-0x80(%rdx)
   15327:	vmovups %zmm3,-0x40(%rdx)
   1532e:	cmp    %rsi,%r8
   15331:	jb     151a8 <hf2_broken_g52+0x78>
   15337:	mov    0x438(%rsp),%rax
   1533f:	sub    %fs:0x28,%rax
   15348:	jne    1534f <hf2_broken_g52+0x21f>
   1534a:	vzeroupper
   1534d:	leave
   1534e:	ret
   1534f:	vzeroupper
   15352:	call   4280 <__stack_chk_fail@plt>
   15357:	nopw   0x0(%rax,%rax,1)

0000000000015360 <hf0_broken_g52>:
   15360:	endbr64
   15364:	push   %rbp
   15365:	mov    %rdi,%rdx
   15368:	mov    %rsp,%rbp
   1536b:	and    $0xffffffffffffffc0,%rsp
   1536f:	sub    $0x540,%rsp
   15376:	vbroadcastss 0x48c80(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   15380:	mov    %fs:0x28,%rax
   15389:	mov    %rax,0x538(%rsp)
   15391:	xor    %eax,%eax
   15393:	mov    %rsp,%rdi
   15396:	vzeroupper
   15399:	call   10170 <inl_consts.constprop.1>
   1539e:	vmovaps (%rsp),%zmm18
   153a5:	vmovaps 0x40(%rsp),%zmm19
   153ad:	vmovaps 0x80(%rsp),%zmm20
   153b5:	vmovaps 0xc0(%rsp),%zmm21
   153bd:	test   %rsi,%rsi
   153c0:	je     158d7 <hf0_broken_g52+0x577>
   153c6:	mov    %rsi,%rcx
   153c9:	mov    %rdx,%rax
   153cc:	lea    0x100(%rsp),%rdi
   153d4:	xor    %edx,%edx
   153d6:	sub    $0x1,%rcx
   153da:	mov    %rcx,%rsi
   153dd:	shr    $0x8,%rsi
   153e1:	nopl   0x0(%rax)
   153e8:	vpermilps $0xb1,(%rax),%zmm0
   153ef:	vfmadd231ps (%rax),%zmm18,%zmm0
   153f5:	mov    %rdx,%rcx
   153f8:	vpermilps $0x4e,%zmm0,%zmm1
   153ff:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15405:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1540c:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15412:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15419:	vfmadd132ps %zmm21,%zmm1,%zmm0
   1541f:	vmovaps %zmm0,0x100(%rsp)
   15427:	vpermilps $0xb1,0x40(%rax),%zmm0
   1542f:	vfmadd231ps 0x40(%rax),%zmm18,%zmm0
   15436:	vpermilps $0x4e,%zmm0,%zmm1
   1543d:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15443:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1544a:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15450:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15457:	vfmadd132ps %zmm21,%zmm1,%zmm0
   1545d:	vmovaps %zmm0,0x140(%rsp)
   15465:	vpermilps $0xb1,0x80(%rax),%zmm0
   1546d:	vfmadd231ps 0x80(%rax),%zmm18,%zmm0
   15474:	vpermilps $0x4e,%zmm0,%zmm1
   1547b:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15481:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15488:	vfmadd132ps %zmm20,%zmm1,%zmm0
   1548e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15495:	vfmadd132ps %zmm21,%zmm1,%zmm0
   1549b:	vmovaps %zmm0,0x180(%rsp)
   154a3:	vpermilps $0xb1,0xc0(%rax),%zmm0
   154ab:	vfmadd231ps 0xc0(%rax),%zmm18,%zmm0
   154b2:	vpermilps $0x4e,%zmm0,%zmm1
   154b9:	vfmadd132ps %zmm19,%zmm1,%zmm0
   154bf:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   154c6:	vfmadd132ps %zmm20,%zmm1,%zmm0
   154cc:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   154d3:	vfmadd132ps %zmm21,%zmm1,%zmm0
   154d9:	vmovaps %zmm0,0x1c0(%rsp)
   154e1:	vpermilps $0xb1,0x100(%rax),%zmm0
   154e9:	vfmadd231ps 0x100(%rax),%zmm18,%zmm0
   154f0:	vpermilps $0x4e,%zmm0,%zmm1
   154f7:	vfmadd132ps %zmm19,%zmm1,%zmm0
   154fd:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15504:	vfmadd132ps %zmm20,%zmm1,%zmm0
   1550a:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15511:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15517:	vmovaps %zmm0,0x200(%rsp)
   1551f:	vpermilps $0xb1,0x140(%rax),%zmm0
   15527:	vfmadd231ps 0x140(%rax),%zmm18,%zmm0
   1552e:	vpermilps $0x4e,%zmm0,%zmm1
   15535:	vfmadd132ps %zmm19,%zmm1,%zmm0
   1553b:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15542:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15548:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1554f:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15555:	vmovaps %zmm0,0x240(%rsp)
   1555d:	vpermilps $0xb1,0x180(%rax),%zmm0
   15565:	vfmadd231ps 0x180(%rax),%zmm18,%zmm0
   1556c:	vpermilps $0x4e,%zmm0,%zmm1
   15573:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15579:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15580:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15586:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1558d:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15593:	vmovaps %zmm0,0x280(%rsp)
   1559b:	vpermilps $0xb1,0x1c0(%rax),%zmm0
   155a3:	vfmadd231ps 0x1c0(%rax),%zmm18,%zmm0
   155aa:	vpermilps $0x4e,%zmm0,%zmm1
   155b1:	vfmadd132ps %zmm19,%zmm1,%zmm0
   155b7:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   155be:	vfmadd132ps %zmm20,%zmm1,%zmm0
   155c4:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   155cb:	vfmadd132ps %zmm21,%zmm1,%zmm0
   155d1:	vmovaps %zmm0,0x2c0(%rsp)
   155d9:	vpermilps $0xb1,0x200(%rax),%zmm0
   155e1:	vfmadd231ps 0x200(%rax),%zmm18,%zmm0
   155e8:	vpermilps $0x4e,%zmm0,%zmm1
   155ef:	vfmadd132ps %zmm19,%zmm1,%zmm0
   155f5:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   155fc:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15602:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15609:	vfmadd132ps %zmm21,%zmm1,%zmm0
   1560f:	vmovaps %zmm0,0x300(%rsp)
   15617:	vpermilps $0xb1,0x240(%rax),%zmm0
   1561f:	vfmadd231ps 0x240(%rax),%zmm18,%zmm0
   15626:	vpermilps $0x4e,%zmm0,%zmm1
   1562d:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15633:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1563a:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15640:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15647:	vfmadd132ps %zmm21,%zmm1,%zmm0
   1564d:	vmovaps %zmm0,0x340(%rsp)
   15655:	vpermilps $0xb1,0x280(%rax),%zmm0
   1565d:	vfmadd231ps 0x280(%rax),%zmm18,%zmm0
   15664:	vpermilps $0x4e,%zmm0,%zmm1
   1566b:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15671:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15678:	vfmadd132ps %zmm20,%zmm1,%zmm0
   1567e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15685:	vfmadd132ps %zmm21,%zmm1,%zmm0
   1568b:	vmovaps %zmm0,0x380(%rsp)
   15693:	vpermilps $0xb1,0x2c0(%rax),%zmm0
   1569b:	vfmadd231ps 0x2c0(%rax),%zmm18,%zmm0
   156a2:	vpermilps $0x4e,%zmm0,%zmm1
   156a9:	vfmadd132ps %zmm19,%zmm1,%zmm0
   156af:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   156b6:	vfmadd132ps %zmm20,%zmm1,%zmm0
   156bc:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   156c3:	vfmadd132ps %zmm21,%zmm1,%zmm0
   156c9:	vmovaps %zmm0,0x3c0(%rsp)
   156d1:	vpermilps $0xb1,0x300(%rax),%zmm0
   156d9:	vfmadd231ps 0x300(%rax),%zmm18,%zmm0
   156e0:	vpermilps $0x4e,%zmm0,%zmm1
   156e7:	vfmadd132ps %zmm19,%zmm1,%zmm0
   156ed:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   156f4:	vfmadd132ps %zmm20,%zmm1,%zmm0
   156fa:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15701:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15707:	vmovaps %zmm0,0x400(%rsp)
   1570f:	vpermilps $0xb1,0x340(%rax),%zmm0
   15717:	vfmadd231ps 0x340(%rax),%zmm18,%zmm0
   1571e:	vpermilps $0x4e,%zmm0,%zmm1
   15725:	vfmadd132ps %zmm19,%zmm1,%zmm0
   1572b:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15732:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15738:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1573f:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15745:	vmovaps %zmm0,0x440(%rsp)
   1574d:	vpermilps $0xb1,0x380(%rax),%zmm0
   15755:	vfmadd231ps 0x380(%rax),%zmm18,%zmm0
   1575c:	vpermilps $0x4e,%zmm0,%zmm1
   15763:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15769:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15770:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15776:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1577d:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15783:	vmovaps %zmm0,0x480(%rsp)
   1578b:	vpermilps $0xb1,0x3c0(%rax),%zmm0
   15793:	vfmadd231ps 0x3c0(%rax),%zmm18,%zmm0
   1579a:	vpermilps $0x4e,%zmm0,%zmm1
   157a1:	vfmadd132ps %zmm19,%zmm1,%zmm0
   157a7:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   157ae:	vfmadd132ps %zmm20,%zmm1,%zmm0
   157b4:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   157bb:	vfmadd132ps %zmm21,%zmm1,%zmm0
   157c1:	vmovaps %zmm0,0x4c0(%rsp)
   157c9:	vzeroupper
   157cc:	call   14f10 <g52_nat.constprop.0>
   157d1:	add    $0x1,%rdx
   157d5:	vmovaps 0x100(%rsp),%zmm2
   157dd:	vmovaps 0x140(%rsp),%zmm3
   157e5:	vmovaps 0x180(%rsp),%zmm4
   157ed:	add    $0x400,%rax
   157f3:	vmovaps 0x1c0(%rsp),%zmm5
   157fb:	vmovaps 0x200(%rsp),%zmm6
   15803:	vmovups %zmm2,-0x400(%rax)
   1580a:	vmovaps 0x280(%rsp),%zmm7
   15812:	vmovaps 0x240(%rsp),%zmm2
   1581a:	vmovups %zmm3,-0x3c0(%rax)
   15821:	vmovups %zmm4,-0x380(%rax)
   15828:	vmovaps 0x2c0(%rsp),%zmm3
   15830:	vmovaps 0x300(%rsp),%zmm4
   15838:	vmovups %zmm5,-0x340(%rax)
   1583f:	vmovaps 0x340(%rsp),%zmm5
   15847:	vmovups %zmm6,-0x300(%rax)
   1584e:	vmovaps 0x380(%rsp),%zmm6
   15856:	vmovups %zmm7,-0x2c0(%rax)
   1585d:	vmovaps 0x3c0(%rsp),%zmm7
   15865:	vmovups %zmm2,-0x280(%rax)
   1586c:	vmovaps 0x400(%rsp),%zmm2
   15874:	vmovups %zmm3,-0x240(%rax)
   1587b:	vmovaps 0x440(%rsp),%zmm3
   15883:	vmovups %zmm4,-0x200(%rax)
   1588a:	vmovaps 0x480(%rsp),%zmm4
   15892:	vmovups %zmm5,-0x1c0(%rax)
   15899:	vmovaps 0x4c0(%rsp),%zmm5
   158a1:	vmovups %zmm6,-0x180(%rax)
   158a8:	vmovups %zmm7,-0x140(%rax)
   158af:	vmovups %zmm2,-0x100(%rax)
   158b6:	vmovups %zmm3,-0xc0(%rax)
   158bd:	vmovups %zmm4,-0x80(%rax)
   158c4:	vmovups %zmm5,-0x40(%rax)
   158cb:	cmp    %rcx,%rsi
   158ce:	jne    153e8 <hf0_broken_g52+0x88>
   158d4:	vzeroupper
   158d7:	mov    0x538(%rsp),%rax
   158df:	sub    %fs:0x28,%rax
   158e8:	jne    158ec <hf0_broken_g52+0x58c>
   158ea:	leave
   158eb:	ret
   158ec:	call   4280 <__stack_chk_fail@plt>
   158f1:	data16 cs nopw 0x0(%rax,%rax,1)
   158fc:	nopl   0x0(%rax)

0000000000015900 <hf2_g52_nat>:
   15900:	endbr64
   15904:	push   %rbp
   15905:	mov    %rsp,%rbp
   15908:	and    $0xffffffffffffffc0,%rsp
   1590c:	sub    $0x440,%rsp
   15913:	vbroadcastss 0x486e3(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   1591d:	mov    %fs:0x28,%rax
   15926:	mov    %rax,0x438(%rsp)
   1592e:	xor    %eax,%eax
   15930:	test   %rsi,%rsi
   15933:	je     15b07 <hf2_g52_nat+0x207>
   15939:	vmovdqa32 0x484bd(%rip),%zmm21        # 5de00 <_IO_stdin_used+0xe00>
   15943:	mov    %rdi,%rdx
   15946:	xor    %r8d,%r8d
   15949:	vmovdqa32 0x484ed(%rip),%zmm20        # 5de40 <_IO_stdin_used+0xe40>
   15953:	vmovdqa32 0x48523(%rip),%zmm19        # 5de80 <_IO_stdin_used+0xe80>
   1595d:	mov    $0xffffaaaa,%eax
   15962:	mov    %rsp,%rcx
   15965:	vmovdqa32 0x48551(%rip),%zmm18        # 5dec0 <_IO_stdin_used+0xec0>
   1596f:	kmovw  %eax,%k4
   15973:	nopl   0x0(%rax,%rax,1)
   15978:	mov    $0xffffcccc,%edi
   1597d:	xor    %eax,%eax
   1597f:	kmovw  %edi,%k3
   15983:	mov    $0xfffff0f0,%edi
   15988:	kmovw  %edi,%k2
   1598c:	mov    $0xffffff00,%edi
   15991:	kmovw  %edi,%k1
   15995:	nopl   (%rax)
   15998:	vpermps (%rdx,%rax,1),%zmm21,%zmm1
   1599f:	vaddps (%rdx,%rax,1),%zmm1,%zmm0
   159a6:	vsubps (%rdx,%rax,1),%zmm1,%zmm0{%k4}
   159ad:	vpermps %zmm0,%zmm20,%zmm2
   159b3:	vaddps %zmm0,%zmm2,%zmm1
   159b9:	vsubps %zmm0,%zmm2,%zmm1{%k3}
   159bf:	vpermps %zmm1,%zmm19,%zmm2
   159c5:	vaddps %zmm1,%zmm2,%zmm0
   159cb:	vsubps %zmm1,%zmm2,%zmm0{%k2}
   159d1:	vpermps %zmm0,%zmm18,%zmm2
   159d7:	vaddps %zmm0,%zmm2,%zmm1
   159dd:	vsubps %zmm0,%zmm2,%zmm1{%k1}
   159e3:	vmovaps %zmm1,(%rcx,%rax,1)
   159ea:	add    $0x40,%rax
   159ee:	cmp    $0x400,%rax
   159f4:	jne    15998 <hf2_g52_nat+0x98>
   159f6:	mov    %rcx,%rdi
   159f9:	vzeroupper
   159fc:	add    $0x100,%r8
   15a03:	add    $0x400,%rdx
   15a0a:	call   14f10 <g52_nat.constprop.0>
   15a0f:	vmovaps (%rsp),%zmm3
   15a16:	vmovaps 0x40(%rsp),%zmm4
   15a1e:	vmovaps 0x80(%rsp),%zmm5
   15a26:	vmovaps 0xc0(%rsp),%zmm6
   15a2e:	vmovaps 0x100(%rsp),%zmm7
   15a36:	vmovups %zmm3,-0x400(%rdx)
   15a3d:	vmovaps 0x140(%rsp),%zmm3
   15a45:	vmovups %zmm4,-0x3c0(%rdx)
   15a4c:	vmovaps 0x180(%rsp),%zmm4
   15a54:	vmovups %zmm5,-0x380(%rdx)
   15a5b:	vmovaps 0x1c0(%rsp),%zmm5
   15a63:	vmovups %zmm6,-0x340(%rdx)
   15a6a:	vmovaps 0x200(%rsp),%zmm6
   15a72:	vmovups %zmm7,-0x300(%rdx)
   15a79:	vmovaps 0x240(%rsp),%zmm7
   15a81:	vmovups %zmm3,-0x2c0(%rdx)
   15a88:	vmovaps 0x280(%rsp),%zmm3
   15a90:	vmovups %zmm4,-0x280(%rdx)
   15a97:	vmovaps 0x2c0(%rsp),%zmm4
   15a9f:	vmovups %zmm5,-0x240(%rdx)
   15aa6:	vmovaps 0x300(%rsp),%zmm5
   15aae:	vmovups %zmm6,-0x200(%rdx)
   15ab5:	vmovaps 0x340(%rsp),%zmm6
   15abd:	vmovups %zmm7,-0x1c0(%rdx)
   15ac4:	vmovaps 0x380(%rsp),%zmm7
   15acc:	vmovups %zmm3,-0x180(%rdx)
   15ad3:	vmovaps 0x3c0(%rsp),%zmm3
   15adb:	vmovups %zmm4,-0x140(%rdx)
   15ae2:	vmovups %zmm5,-0x100(%rdx)
   15ae9:	vmovups %zmm6,-0xc0(%rdx)
   15af0:	vmovups %zmm7,-0x80(%rdx)
   15af7:	vmovups %zmm3,-0x40(%rdx)
   15afe:	cmp    %rsi,%r8
   15b01:	jb     15978 <hf2_g52_nat+0x78>
   15b07:	mov    0x438(%rsp),%rax
   15b0f:	sub    %fs:0x28,%rax
   15b18:	jne    15b1f <hf2_g52_nat+0x21f>
   15b1a:	vzeroupper
   15b1d:	leave
   15b1e:	ret
   15b1f:	vzeroupper
   15b22:	call   4280 <__stack_chk_fail@plt>
   15b27:	nopw   0x0(%rax,%rax,1)

0000000000015b30 <hf0_g52_nat>:
   15b30:	endbr64
   15b34:	push   %rbp
   15b35:	mov    %rdi,%rdx
   15b38:	mov    %rsp,%rbp
   15b3b:	and    $0xffffffffffffffc0,%rsp
   15b3f:	sub    $0x540,%rsp
   15b46:	vbroadcastss 0x484b0(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   15b50:	mov    %fs:0x28,%rax
   15b59:	mov    %rax,0x538(%rsp)
   15b61:	xor    %eax,%eax
   15b63:	mov    %rsp,%rdi
   15b66:	vzeroupper
   15b69:	call   10170 <inl_consts.constprop.1>
   15b6e:	vmovaps (%rsp),%zmm18
   15b75:	vmovaps 0x40(%rsp),%zmm19
   15b7d:	vmovaps 0x80(%rsp),%zmm20
   15b85:	vmovaps 0xc0(%rsp),%zmm21
   15b8d:	test   %rsi,%rsi
   15b90:	je     160a7 <hf0_g52_nat+0x577>
   15b96:	mov    %rsi,%rcx
   15b99:	mov    %rdx,%rax
   15b9c:	lea    0x100(%rsp),%rdi
   15ba4:	xor    %edx,%edx
   15ba6:	sub    $0x1,%rcx
   15baa:	mov    %rcx,%rsi
   15bad:	shr    $0x8,%rsi
   15bb1:	nopl   0x0(%rax)
   15bb8:	vpermilps $0xb1,(%rax),%zmm0
   15bbf:	vfmadd231ps (%rax),%zmm18,%zmm0
   15bc5:	mov    %rdx,%rcx
   15bc8:	vpermilps $0x4e,%zmm0,%zmm1
   15bcf:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15bd5:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15bdc:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15be2:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15be9:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15bef:	vmovaps %zmm0,0x100(%rsp)
   15bf7:	vpermilps $0xb1,0x40(%rax),%zmm0
   15bff:	vfmadd231ps 0x40(%rax),%zmm18,%zmm0
   15c06:	vpermilps $0x4e,%zmm0,%zmm1
   15c0d:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15c13:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15c1a:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15c20:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15c27:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15c2d:	vmovaps %zmm0,0x140(%rsp)
   15c35:	vpermilps $0xb1,0x80(%rax),%zmm0
   15c3d:	vfmadd231ps 0x80(%rax),%zmm18,%zmm0
   15c44:	vpermilps $0x4e,%zmm0,%zmm1
   15c4b:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15c51:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15c58:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15c5e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15c65:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15c6b:	vmovaps %zmm0,0x180(%rsp)
   15c73:	vpermilps $0xb1,0xc0(%rax),%zmm0
   15c7b:	vfmadd231ps 0xc0(%rax),%zmm18,%zmm0
   15c82:	vpermilps $0x4e,%zmm0,%zmm1
   15c89:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15c8f:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15c96:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15c9c:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15ca3:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15ca9:	vmovaps %zmm0,0x1c0(%rsp)
   15cb1:	vpermilps $0xb1,0x100(%rax),%zmm0
   15cb9:	vfmadd231ps 0x100(%rax),%zmm18,%zmm0
   15cc0:	vpermilps $0x4e,%zmm0,%zmm1
   15cc7:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15ccd:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15cd4:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15cda:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15ce1:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15ce7:	vmovaps %zmm0,0x200(%rsp)
   15cef:	vpermilps $0xb1,0x140(%rax),%zmm0
   15cf7:	vfmadd231ps 0x140(%rax),%zmm18,%zmm0
   15cfe:	vpermilps $0x4e,%zmm0,%zmm1
   15d05:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15d0b:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15d12:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15d18:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15d1f:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15d25:	vmovaps %zmm0,0x240(%rsp)
   15d2d:	vpermilps $0xb1,0x180(%rax),%zmm0
   15d35:	vfmadd231ps 0x180(%rax),%zmm18,%zmm0
   15d3c:	vpermilps $0x4e,%zmm0,%zmm1
   15d43:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15d49:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15d50:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15d56:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15d5d:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15d63:	vmovaps %zmm0,0x280(%rsp)
   15d6b:	vpermilps $0xb1,0x1c0(%rax),%zmm0
   15d73:	vfmadd231ps 0x1c0(%rax),%zmm18,%zmm0
   15d7a:	vpermilps $0x4e,%zmm0,%zmm1
   15d81:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15d87:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15d8e:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15d94:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15d9b:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15da1:	vmovaps %zmm0,0x2c0(%rsp)
   15da9:	vpermilps $0xb1,0x200(%rax),%zmm0
   15db1:	vfmadd231ps 0x200(%rax),%zmm18,%zmm0
   15db8:	vpermilps $0x4e,%zmm0,%zmm1
   15dbf:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15dc5:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15dcc:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15dd2:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15dd9:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15ddf:	vmovaps %zmm0,0x300(%rsp)
   15de7:	vpermilps $0xb1,0x240(%rax),%zmm0
   15def:	vfmadd231ps 0x240(%rax),%zmm18,%zmm0
   15df6:	vpermilps $0x4e,%zmm0,%zmm1
   15dfd:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15e03:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15e0a:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15e10:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15e17:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15e1d:	vmovaps %zmm0,0x340(%rsp)
   15e25:	vpermilps $0xb1,0x280(%rax),%zmm0
   15e2d:	vfmadd231ps 0x280(%rax),%zmm18,%zmm0
   15e34:	vpermilps $0x4e,%zmm0,%zmm1
   15e3b:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15e41:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15e48:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15e4e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15e55:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15e5b:	vmovaps %zmm0,0x380(%rsp)
   15e63:	vpermilps $0xb1,0x2c0(%rax),%zmm0
   15e6b:	vfmadd231ps 0x2c0(%rax),%zmm18,%zmm0
   15e72:	vpermilps $0x4e,%zmm0,%zmm1
   15e79:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15e7f:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15e86:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15e8c:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15e93:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15e99:	vmovaps %zmm0,0x3c0(%rsp)
   15ea1:	vpermilps $0xb1,0x300(%rax),%zmm0
   15ea9:	vfmadd231ps 0x300(%rax),%zmm18,%zmm0
   15eb0:	vpermilps $0x4e,%zmm0,%zmm1
   15eb7:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15ebd:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15ec4:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15eca:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15ed1:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15ed7:	vmovaps %zmm0,0x400(%rsp)
   15edf:	vpermilps $0xb1,0x340(%rax),%zmm0
   15ee7:	vfmadd231ps 0x340(%rax),%zmm18,%zmm0
   15eee:	vpermilps $0x4e,%zmm0,%zmm1
   15ef5:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15efb:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15f02:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15f08:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15f0f:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15f15:	vmovaps %zmm0,0x440(%rsp)
   15f1d:	vpermilps $0xb1,0x380(%rax),%zmm0
   15f25:	vfmadd231ps 0x380(%rax),%zmm18,%zmm0
   15f2c:	vpermilps $0x4e,%zmm0,%zmm1
   15f33:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15f39:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15f40:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15f46:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15f4d:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15f53:	vmovaps %zmm0,0x480(%rsp)
   15f5b:	vpermilps $0xb1,0x3c0(%rax),%zmm0
   15f63:	vfmadd231ps 0x3c0(%rax),%zmm18,%zmm0
   15f6a:	vpermilps $0x4e,%zmm0,%zmm1
   15f71:	vfmadd132ps %zmm19,%zmm1,%zmm0
   15f77:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   15f7e:	vfmadd132ps %zmm20,%zmm1,%zmm0
   15f84:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   15f8b:	vfmadd132ps %zmm21,%zmm1,%zmm0
   15f91:	vmovaps %zmm0,0x4c0(%rsp)
   15f99:	vzeroupper
   15f9c:	call   14f10 <g52_nat.constprop.0>
   15fa1:	add    $0x1,%rdx
   15fa5:	vmovaps 0x100(%rsp),%zmm2
   15fad:	vmovaps 0x140(%rsp),%zmm3
   15fb5:	vmovaps 0x180(%rsp),%zmm4
   15fbd:	add    $0x400,%rax
   15fc3:	vmovaps 0x1c0(%rsp),%zmm5
   15fcb:	vmovaps 0x200(%rsp),%zmm6
   15fd3:	vmovups %zmm2,-0x400(%rax)
   15fda:	vmovaps 0x240(%rsp),%zmm7
   15fe2:	vmovaps 0x280(%rsp),%zmm2
   15fea:	vmovups %zmm3,-0x3c0(%rax)
   15ff1:	vmovups %zmm4,-0x380(%rax)
   15ff8:	vmovaps 0x2c0(%rsp),%zmm3
   16000:	vmovaps 0x300(%rsp),%zmm4
   16008:	vmovups %zmm5,-0x340(%rax)
   1600f:	vmovaps 0x340(%rsp),%zmm5
   16017:	vmovups %zmm6,-0x300(%rax)
   1601e:	vmovaps 0x380(%rsp),%zmm6
   16026:	vmovups %zmm7,-0x2c0(%rax)
   1602d:	vmovaps 0x3c0(%rsp),%zmm7
   16035:	vmovups %zmm2,-0x280(%rax)
   1603c:	vmovaps 0x400(%rsp),%zmm2
   16044:	vmovups %zmm3,-0x240(%rax)
   1604b:	vmovaps 0x440(%rsp),%zmm3
   16053:	vmovups %zmm4,-0x200(%rax)
   1605a:	vmovaps 0x480(%rsp),%zmm4
   16062:	vmovups %zmm5,-0x1c0(%rax)
   16069:	vmovaps 0x4c0(%rsp),%zmm5
   16071:	vmovups %zmm6,-0x180(%rax)
   16078:	vmovups %zmm7,-0x140(%rax)
   1607f:	vmovups %zmm2,-0x100(%rax)
   16086:	vmovups %zmm3,-0xc0(%rax)
   1608d:	vmovups %zmm4,-0x80(%rax)
   16094:	vmovups %zmm5,-0x40(%rax)
   1609b:	cmp    %rcx,%rsi
   1609e:	jne    15bb8 <hf0_g52_nat+0x88>
   160a4:	vzeroupper
   160a7:	mov    0x538(%rsp),%rax
   160af:	sub    %fs:0x28,%rax
   160b8:	jne    160bc <hf0_g52_nat+0x58c>
   160ba:	leave
   160bb:	ret
   160bc:	call   4280 <__stack_chk_fail@plt>
   160c1:	data16 cs nopw 0x0(%rax,%rax,1)
   160cc:	nopl   0x0(%rax)

0000000000016da0 <hf2_tb16_nat>:
   16da0:	endbr64
   16da4:	push   %rbp
   16da5:	mov    %rsp,%rbp
   16da8:	and    $0xffffffffffffffc0,%rsp
   16dac:	sub    $0x440,%rsp
   16db3:	vbroadcastss 0x47243(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   16dbd:	mov    %fs:0x28,%rax
   16dc6:	mov    %rax,0x438(%rsp)
   16dce:	xor    %eax,%eax
   16dd0:	test   %rsi,%rsi
   16dd3:	je     16fa7 <hf2_tb16_nat+0x207>
   16dd9:	vmovdqa32 0x4701d(%rip),%zmm23        # 5de00 <_IO_stdin_used+0xe00>
   16de3:	mov    %rdi,%rdx
   16de6:	xor    %r8d,%r8d
   16de9:	vmovdqa32 0x4704d(%rip),%zmm22        # 5de40 <_IO_stdin_used+0xe40>
   16df3:	vmovdqa32 0x47083(%rip),%zmm21        # 5de80 <_IO_stdin_used+0xe80>
   16dfd:	mov    $0xffffaaaa,%eax
   16e02:	mov    %rsp,%rcx
   16e05:	vmovdqa32 0x470b1(%rip),%zmm20        # 5dec0 <_IO_stdin_used+0xec0>
   16e0f:	kmovw  %eax,%k4
   16e13:	nopl   0x0(%rax,%rax,1)
   16e18:	mov    $0xffffcccc,%edi
   16e1d:	xor    %eax,%eax
   16e1f:	kmovw  %edi,%k3
   16e23:	mov    $0xfffff0f0,%edi
   16e28:	kmovw  %edi,%k2
   16e2c:	mov    $0xffffff00,%edi
   16e31:	kmovw  %edi,%k1
   16e35:	nopl   (%rax)
   16e38:	vpermps (%rdx,%rax,1),%zmm23,%zmm1
   16e3f:	vaddps (%rdx,%rax,1),%zmm1,%zmm0
   16e46:	vsubps (%rdx,%rax,1),%zmm1,%zmm0{%k4}
   16e4d:	vpermps %zmm0,%zmm22,%zmm2
   16e53:	vaddps %zmm0,%zmm2,%zmm1
   16e59:	vsubps %zmm0,%zmm2,%zmm1{%k3}
   16e5f:	vpermps %zmm1,%zmm21,%zmm2
   16e65:	vaddps %zmm1,%zmm2,%zmm0
   16e6b:	vsubps %zmm1,%zmm2,%zmm0{%k2}
   16e71:	vpermps %zmm0,%zmm20,%zmm2
   16e77:	vaddps %zmm0,%zmm2,%zmm1
   16e7d:	vsubps %zmm0,%zmm2,%zmm1{%k1}
   16e83:	vmovaps %zmm1,(%rcx,%rax,1)
   16e8a:	add    $0x40,%rax
   16e8e:	cmp    $0x400,%rax
   16e94:	jne    16e38 <hf2_tb16_nat+0x98>
   16e96:	mov    %rcx,%rdi
   16e99:	vzeroupper
   16e9c:	add    $0x100,%r8
   16ea3:	add    $0x400,%rdx
   16eaa:	call   16b50 <tb16_nat.constprop.0>
   16eaf:	vmovaps (%rsp),%zmm3
   16eb6:	vmovaps 0x40(%rsp),%zmm4
   16ebe:	vmovaps 0x80(%rsp),%zmm5
   16ec6:	vmovaps 0xc0(%rsp),%zmm6
   16ece:	vmovaps 0x100(%rsp),%zmm7
   16ed6:	vmovups %zmm3,-0x400(%rdx)
   16edd:	vmovaps 0x140(%rsp),%zmm3
   16ee5:	vmovups %zmm4,-0x3c0(%rdx)
   16eec:	vmovaps 0x180(%rsp),%zmm4
   16ef4:	vmovups %zmm5,-0x380(%rdx)
   16efb:	vmovaps 0x1c0(%rsp),%zmm5
   16f03:	vmovups %zmm6,-0x340(%rdx)
   16f0a:	vmovaps 0x200(%rsp),%zmm6
   16f12:	vmovups %zmm7,-0x300(%rdx)
   16f19:	vmovaps 0x240(%rsp),%zmm7
   16f21:	vmovups %zmm3,-0x2c0(%rdx)
   16f28:	vmovaps 0x280(%rsp),%zmm3
   16f30:	vmovups %zmm4,-0x280(%rdx)
   16f37:	vmovaps 0x2c0(%rsp),%zmm4
   16f3f:	vmovups %zmm5,-0x240(%rdx)
   16f46:	vmovaps 0x300(%rsp),%zmm5
   16f4e:	vmovups %zmm6,-0x200(%rdx)
   16f55:	vmovaps 0x340(%rsp),%zmm6
   16f5d:	vmovups %zmm7,-0x1c0(%rdx)
   16f64:	vmovaps 0x380(%rsp),%zmm7
   16f6c:	vmovups %zmm3,-0x180(%rdx)
   16f73:	vmovaps 0x3c0(%rsp),%zmm3
   16f7b:	vmovups %zmm4,-0x140(%rdx)
   16f82:	vmovups %zmm5,-0x100(%rdx)
   16f89:	vmovups %zmm6,-0xc0(%rdx)
   16f90:	vmovups %zmm7,-0x80(%rdx)
   16f97:	vmovups %zmm3,-0x40(%rdx)
   16f9e:	cmp    %rsi,%r8
   16fa1:	jb     16e18 <hf2_tb16_nat+0x78>
   16fa7:	mov    0x438(%rsp),%rax
   16faf:	sub    %fs:0x28,%rax
   16fb8:	jne    16fbf <hf2_tb16_nat+0x21f>
   16fba:	vzeroupper
   16fbd:	leave
   16fbe:	ret
   16fbf:	vzeroupper
   16fc2:	call   4280 <__stack_chk_fail@plt>
   16fc7:	nopw   0x0(%rax,%rax,1)

0000000000016fd0 <hf0_tb16_nat>:
   16fd0:	endbr64
   16fd4:	push   %rbp
   16fd5:	mov    %rdi,%rdx
   16fd8:	mov    %rsp,%rbp
   16fdb:	and    $0xffffffffffffffc0,%rsp
   16fdf:	sub    $0x540,%rsp
   16fe6:	vbroadcastss 0x47010(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   16ff0:	mov    %fs:0x28,%rax
   16ff9:	mov    %rax,0x538(%rsp)
   17001:	xor    %eax,%eax
   17003:	mov    %rsp,%rdi
   17006:	vzeroupper
   17009:	call   10170 <inl_consts.constprop.1>
   1700e:	vmovaps (%rsp),%zmm20
   17015:	vmovaps 0x40(%rsp),%zmm21
   1701d:	vmovaps 0x80(%rsp),%zmm22
   17025:	vmovaps 0xc0(%rsp),%zmm23
   1702d:	test   %rsi,%rsi
   17030:	je     17547 <hf0_tb16_nat+0x577>
   17036:	mov    %rsi,%rcx
   17039:	mov    %rdx,%rax
   1703c:	lea    0x100(%rsp),%rdi
   17044:	xor    %edx,%edx
   17046:	sub    $0x1,%rcx
   1704a:	mov    %rcx,%rsi
   1704d:	shr    $0x8,%rsi
   17051:	nopl   0x0(%rax)
   17058:	vpermilps $0xb1,(%rax),%zmm0
   1705f:	vfmadd231ps (%rax),%zmm20,%zmm0
   17065:	mov    %rdx,%rcx
   17068:	vpermilps $0x4e,%zmm0,%zmm1
   1706f:	vfmadd132ps %zmm21,%zmm1,%zmm0
   17075:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1707c:	vfmadd132ps %zmm22,%zmm1,%zmm0
   17082:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   17089:	vfmadd132ps %zmm23,%zmm1,%zmm0
   1708f:	vmovaps %zmm0,0x100(%rsp)
   17097:	vpermilps $0xb1,0x40(%rax),%zmm0
   1709f:	vfmadd231ps 0x40(%rax),%zmm20,%zmm0
   170a6:	vpermilps $0x4e,%zmm0,%zmm1
   170ad:	vfmadd132ps %zmm21,%zmm1,%zmm0
   170b3:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   170ba:	vfmadd132ps %zmm22,%zmm1,%zmm0
   170c0:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   170c7:	vfmadd132ps %zmm23,%zmm1,%zmm0
   170cd:	vmovaps %zmm0,0x140(%rsp)
   170d5:	vpermilps $0xb1,0x80(%rax),%zmm0
   170dd:	vfmadd231ps 0x80(%rax),%zmm20,%zmm0
   170e4:	vpermilps $0x4e,%zmm0,%zmm1
   170eb:	vfmadd132ps %zmm21,%zmm1,%zmm0
   170f1:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   170f8:	vfmadd132ps %zmm22,%zmm1,%zmm0
   170fe:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   17105:	vfmadd132ps %zmm23,%zmm1,%zmm0
   1710b:	vmovaps %zmm0,0x180(%rsp)
   17113:	vpermilps $0xb1,0xc0(%rax),%zmm0
   1711b:	vfmadd231ps 0xc0(%rax),%zmm20,%zmm0
   17122:	vpermilps $0x4e,%zmm0,%zmm1
   17129:	vfmadd132ps %zmm21,%zmm1,%zmm0
   1712f:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   17136:	vfmadd132ps %zmm22,%zmm1,%zmm0
   1713c:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   17143:	vfmadd132ps %zmm23,%zmm1,%zmm0
   17149:	vmovaps %zmm0,0x1c0(%rsp)
   17151:	vpermilps $0xb1,0x100(%rax),%zmm0
   17159:	vfmadd231ps 0x100(%rax),%zmm20,%zmm0
   17160:	vpermilps $0x4e,%zmm0,%zmm1
   17167:	vfmadd132ps %zmm21,%zmm1,%zmm0
   1716d:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   17174:	vfmadd132ps %zmm22,%zmm1,%zmm0
   1717a:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   17181:	vfmadd132ps %zmm23,%zmm1,%zmm0
   17187:	vmovaps %zmm0,0x200(%rsp)
   1718f:	vpermilps $0xb1,0x140(%rax),%zmm0
   17197:	vfmadd231ps 0x140(%rax),%zmm20,%zmm0
   1719e:	vpermilps $0x4e,%zmm0,%zmm1
   171a5:	vfmadd132ps %zmm21,%zmm1,%zmm0
   171ab:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   171b2:	vfmadd132ps %zmm22,%zmm1,%zmm0
   171b8:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   171bf:	vfmadd132ps %zmm23,%zmm1,%zmm0
   171c5:	vmovaps %zmm0,0x240(%rsp)
   171cd:	vpermilps $0xb1,0x180(%rax),%zmm0
   171d5:	vfmadd231ps 0x180(%rax),%zmm20,%zmm0
   171dc:	vpermilps $0x4e,%zmm0,%zmm1
   171e3:	vfmadd132ps %zmm21,%zmm1,%zmm0
   171e9:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   171f0:	vfmadd132ps %zmm22,%zmm1,%zmm0
   171f6:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   171fd:	vfmadd132ps %zmm23,%zmm1,%zmm0
   17203:	vmovaps %zmm0,0x280(%rsp)
   1720b:	vpermilps $0xb1,0x1c0(%rax),%zmm0
   17213:	vfmadd231ps 0x1c0(%rax),%zmm20,%zmm0
   1721a:	vpermilps $0x4e,%zmm0,%zmm1
   17221:	vfmadd132ps %zmm21,%zmm1,%zmm0
   17227:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1722e:	vfmadd132ps %zmm22,%zmm1,%zmm0
   17234:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1723b:	vfmadd132ps %zmm23,%zmm1,%zmm0
   17241:	vmovaps %zmm0,0x2c0(%rsp)
   17249:	vpermilps $0xb1,0x200(%rax),%zmm0
   17251:	vfmadd231ps 0x200(%rax),%zmm20,%zmm0
   17258:	vpermilps $0x4e,%zmm0,%zmm1
   1725f:	vfmadd132ps %zmm21,%zmm1,%zmm0
   17265:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1726c:	vfmadd132ps %zmm22,%zmm1,%zmm0
   17272:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   17279:	vfmadd132ps %zmm23,%zmm1,%zmm0
   1727f:	vmovaps %zmm0,0x300(%rsp)
   17287:	vpermilps $0xb1,0x240(%rax),%zmm0
   1728f:	vfmadd231ps 0x240(%rax),%zmm20,%zmm0
   17296:	vpermilps $0x4e,%zmm0,%zmm1
   1729d:	vfmadd132ps %zmm21,%zmm1,%zmm0
   172a3:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   172aa:	vfmadd132ps %zmm22,%zmm1,%zmm0
   172b0:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   172b7:	vfmadd132ps %zmm23,%zmm1,%zmm0
   172bd:	vmovaps %zmm0,0x340(%rsp)
   172c5:	vpermilps $0xb1,0x280(%rax),%zmm0
   172cd:	vfmadd231ps 0x280(%rax),%zmm20,%zmm0
   172d4:	vpermilps $0x4e,%zmm0,%zmm1
   172db:	vfmadd132ps %zmm21,%zmm1,%zmm0
   172e1:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   172e8:	vfmadd132ps %zmm22,%zmm1,%zmm0
   172ee:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   172f5:	vfmadd132ps %zmm23,%zmm1,%zmm0
   172fb:	vmovaps %zmm0,0x380(%rsp)
   17303:	vpermilps $0xb1,0x2c0(%rax),%zmm0
   1730b:	vfmadd231ps 0x2c0(%rax),%zmm20,%zmm0
   17312:	vpermilps $0x4e,%zmm0,%zmm1
   17319:	vfmadd132ps %zmm21,%zmm1,%zmm0
   1731f:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   17326:	vfmadd132ps %zmm22,%zmm1,%zmm0
   1732c:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   17333:	vfmadd132ps %zmm23,%zmm1,%zmm0
   17339:	vmovaps %zmm0,0x3c0(%rsp)
   17341:	vpermilps $0xb1,0x300(%rax),%zmm0
   17349:	vfmadd231ps 0x300(%rax),%zmm20,%zmm0
   17350:	vpermilps $0x4e,%zmm0,%zmm1
   17357:	vfmadd132ps %zmm21,%zmm1,%zmm0
   1735d:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   17364:	vfmadd132ps %zmm22,%zmm1,%zmm0
   1736a:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   17371:	vfmadd132ps %zmm23,%zmm1,%zmm0
   17377:	vmovaps %zmm0,0x400(%rsp)
   1737f:	vpermilps $0xb1,0x340(%rax),%zmm0
   17387:	vfmadd231ps 0x340(%rax),%zmm20,%zmm0
   1738e:	vpermilps $0x4e,%zmm0,%zmm1
   17395:	vfmadd132ps %zmm21,%zmm1,%zmm0
   1739b:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   173a2:	vfmadd132ps %zmm22,%zmm1,%zmm0
   173a8:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   173af:	vfmadd132ps %zmm23,%zmm1,%zmm0
   173b5:	vmovaps %zmm0,0x440(%rsp)
   173bd:	vpermilps $0xb1,0x380(%rax),%zmm0
   173c5:	vfmadd231ps 0x380(%rax),%zmm20,%zmm0
   173cc:	vpermilps $0x4e,%zmm0,%zmm1
   173d3:	vfmadd132ps %zmm21,%zmm1,%zmm0
   173d9:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   173e0:	vfmadd132ps %zmm22,%zmm1,%zmm0
   173e6:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   173ed:	vfmadd132ps %zmm23,%zmm1,%zmm0
   173f3:	vmovaps %zmm0,0x480(%rsp)
   173fb:	vpermilps $0xb1,0x3c0(%rax),%zmm0
   17403:	vfmadd231ps 0x3c0(%rax),%zmm20,%zmm0
   1740a:	vpermilps $0x4e,%zmm0,%zmm1
   17411:	vfmadd132ps %zmm21,%zmm1,%zmm0
   17417:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1741e:	vfmadd132ps %zmm22,%zmm1,%zmm0
   17424:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1742b:	vfmadd132ps %zmm23,%zmm1,%zmm0
   17431:	vmovaps %zmm0,0x4c0(%rsp)
   17439:	vzeroupper
   1743c:	call   16b50 <tb16_nat.constprop.0>
   17441:	add    $0x1,%rdx
   17445:	vmovaps 0x100(%rsp),%zmm2
   1744d:	vmovaps 0x140(%rsp),%zmm3
   17455:	vmovaps 0x180(%rsp),%zmm4
   1745d:	add    $0x400,%rax
   17463:	vmovaps 0x1c0(%rsp),%zmm5
   1746b:	vmovaps 0x200(%rsp),%zmm6
   17473:	vmovups %zmm2,-0x400(%rax)
   1747a:	vmovaps 0x240(%rsp),%zmm7
   17482:	vmovaps 0x280(%rsp),%zmm2
   1748a:	vmovups %zmm3,-0x3c0(%rax)
   17491:	vmovups %zmm4,-0x380(%rax)
   17498:	vmovaps 0x2c0(%rsp),%zmm3
   174a0:	vmovaps 0x300(%rsp),%zmm4
   174a8:	vmovups %zmm5,-0x340(%rax)
   174af:	vmovaps 0x340(%rsp),%zmm5
   174b7:	vmovups %zmm6,-0x300(%rax)
   174be:	vmovaps 0x380(%rsp),%zmm6
   174c6:	vmovups %zmm7,-0x2c0(%rax)
   174cd:	vmovaps 0x3c0(%rsp),%zmm7
   174d5:	vmovups %zmm2,-0x280(%rax)
   174dc:	vmovaps 0x400(%rsp),%zmm2
   174e4:	vmovups %zmm3,-0x240(%rax)
   174eb:	vmovaps 0x440(%rsp),%zmm3
   174f3:	vmovups %zmm4,-0x200(%rax)
   174fa:	vmovaps 0x480(%rsp),%zmm4
   17502:	vmovups %zmm5,-0x1c0(%rax)
   17509:	vmovaps 0x4c0(%rsp),%zmm5
   17511:	vmovups %zmm6,-0x180(%rax)
   17518:	vmovups %zmm7,-0x140(%rax)
   1751f:	vmovups %zmm2,-0x100(%rax)
   17526:	vmovups %zmm3,-0xc0(%rax)
   1752d:	vmovups %zmm4,-0x80(%rax)
   17534:	vmovups %zmm5,-0x40(%rax)
   1753b:	cmp    %rcx,%rsi
   1753e:	jne    17058 <hf0_tb16_nat+0x88>
   17544:	vzeroupper
   17547:	mov    0x538(%rsp),%rax
   1754f:	sub    %fs:0x28,%rax
   17558:	jne    1755c <hf0_tb16_nat+0x58c>
   1755a:	leave
   1755b:	ret
   1755c:	call   4280 <__stack_chk_fail@plt>
   17561:	data16 cs nopw 0x0(%rax,%rax,1)
   1756c:	nopl   0x0(%rax)

0000000000018420 <pass_tb16_nat_1>:
   18420:	endbr64
   18424:	push   %rbp
   18425:	mov    %rsp,%rbp
   18428:	push   %r14
   1842a:	push   %r13
   1842c:	push   %r12
   1842e:	push   %rbx
   1842f:	and    $0xffffffffffffffc0,%rsp
   18433:	sub    $0x440,%rsp
   1843a:	vbroadcastss 0x45bbc(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   18444:	mov    %fs:0x28,%rax
   1844d:	mov    %rax,0x438(%rsp)
   18455:	xor    %eax,%eax
   18457:	test   %rsi,%rsi
   1845a:	je     186ba <pass_tb16_nat_1+0x29a>
   18460:	lea    (%rsi,%rsi,2),%rdx
   18464:	mov    %rsi,%r10
   18467:	xor    %r12d,%r12d
   1846a:	mov    %rsp,%r14
   1846d:	lea    0x0(,%rsi,8),%r8
   18475:	lea    0x0(,%rsi,4),%r11
   1847d:	mov    %r10,%rbx
   18480:	lea    0x0(,%rdx,4),%r9
   18488:	lea    (%rdi,%r8,1),%rsi
   1848c:	neg    %rbx
   1848f:	neg    %r8
   18492:	lea    (%rsi,%r9,1),%rax
   18496:	lea    -0x1(%r10),%r13
   1849a:	shl    $0x4,%rbx
   1849e:	lea    (%rax,%rdx,8),%rdx
   184a2:	shr    $0x4,%r13
   184a6:	lea    (%rdx,%r11,1),%rcx
   184aa:	neg    %r11
   184ad:	nopl   (%rax)
   184b0:	vmovups (%rsi,%r8,1),%zmm1
   184b7:	vmovups (%rsi),%zmm3
   184bd:	mov    %r14,%rdi
   184c0:	vmovups (%rax,%rbx,1),%zmm2
   184c7:	vmovups (%rax,%r8,1),%zmm4
   184ce:	vmovups (%rax,%r11,1),%zmm5
   184d5:	vmovups (%rax),%zmm6
   184db:	vmovaps %zmm1,(%rsp)
   184e2:	vmovups (%rax,%r10,4),%zmm7
   184e9:	vmovups (%rdx,%rbx,1),%zmm0
   184f0:	vmovaps %zmm2,0x40(%rsp)
   184f8:	vmovups (%rax,%r9,1),%zmm1
   184ff:	vmovups (%rdx,%r8,1),%zmm2
   18506:	vmovaps %zmm3,0x80(%rsp)
   1850e:	vmovaps %zmm4,0xc0(%rsp)
   18516:	vmovups (%rdx,%r11,1),%zmm3
   1851d:	vmovups (%rdx),%zmm4
   18523:	vmovaps %zmm5,0x100(%rsp)
   1852b:	vmovups (%rcx),%zmm5
   18531:	vmovaps %zmm6,0x140(%rsp)
   18539:	vmovups (%rcx,%r10,4),%zmm6
   18540:	vmovaps %zmm7,0x180(%rsp)
   18548:	vmovups (%rdx,%r9,1),%zmm7
   1854f:	vmovaps %zmm0,0x1c0(%rsp)
   18557:	vmovups (%rcx,%r9,1),%zmm0
   1855e:	vmovaps %zmm1,0x200(%rsp)
   18566:	vmovaps %zmm2,0x240(%rsp)
   1856e:	vmovaps %zmm3,0x280(%rsp)
   18576:	vmovaps %zmm4,0x2c0(%rsp)
   1857e:	vmovaps %zmm5,0x300(%rsp)
   18586:	vmovaps %zmm6,0x340(%rsp)
   1858e:	vmovaps %zmm7,0x380(%rsp)
   18596:	vmovaps %zmm0,0x3c0(%rsp)
   1859e:	vzeroupper
   185a1:	call   16b50 <tb16_nat.constprop.0>
   185a6:	mov    %r12,%rdi
   185a9:	add    $0x40,%rsi
   185ad:	vmovaps (%rsp),%zmm1
   185b4:	add    $0x1,%r12
   185b8:	vmovaps 0x40(%rsp),%zmm2
   185c0:	add    $0x40,%rdx
   185c4:	vmovaps 0x80(%rsp),%zmm3
   185cc:	vmovaps 0xc0(%rsp),%zmm4
   185d4:	vmovaps 0x100(%rsp),%zmm5
   185dc:	vmovaps 0x140(%rsp),%zmm6
   185e4:	vmovups %zmm1,-0x40(%rsi,%r8,1)
   185ec:	vmovaps 0x180(%rsp),%zmm7
   185f4:	vmovaps 0x1c0(%rsp),%zmm0
   185fc:	vmovups %zmm2,(%rax,%rbx,1)
   18603:	vmovaps 0x200(%rsp),%zmm1
   1860b:	vmovups %zmm3,-0x40(%rsi)
   18612:	vmovaps 0x240(%rsp),%zmm2
   1861a:	vmovups %zmm4,(%rax,%r8,1)
   18621:	vmovaps 0x280(%rsp),%zmm3
   18629:	vmovaps 0x2c0(%rsp),%zmm4
   18631:	vmovups %zmm5,(%rax,%r11,1)
   18638:	vmovaps 0x300(%rsp),%zmm5
   18640:	vmovups %zmm6,(%rax)
   18646:	vmovaps 0x340(%rsp),%zmm6
   1864e:	vmovups %zmm7,(%rax,%r10,4)
   18655:	add    $0x40,%rax
   18659:	vmovaps 0x380(%rsp),%zmm7
   18661:	vmovups %zmm0,-0x40(%rdx,%rbx,1)
   18669:	vmovaps 0x3c0(%rsp),%zmm0
   18671:	vmovups %zmm1,-0x40(%rax,%r9,1)
   18679:	vmovups %zmm2,-0x40(%rdx,%r8,1)
   18681:	vmovups %zmm3,-0x40(%rdx,%r11,1)
   18689:	vmovups %zmm4,-0x40(%rdx)
   18690:	vmovups %zmm5,(%rcx)
   18696:	vmovups %zmm6,(%rcx,%r10,4)
   1869d:	add    $0x40,%rcx
   186a1:	vmovups %zmm7,-0x40(%rdx,%r9,1)
   186a9:	vmovups %zmm0,-0x40(%rcx,%r9,1)
   186b1:	cmp    %rdi,%r13
   186b4:	jne    184b0 <pass_tb16_nat_1+0x90>
   186ba:	mov    0x438(%rsp),%rax
   186c2:	sub    %fs:0x28,%rax
   186cb:	jne    186dd <pass_tb16_nat_1+0x2bd>
   186cd:	vzeroupper
   186d0:	lea    -0x20(%rbp),%rsp
   186d4:	pop    %rbx
   186d5:	pop    %r12
   186d7:	pop    %r13
   186d9:	pop    %r14
   186db:	pop    %rbp
   186dc:	ret
   186dd:	vzeroupper
   186e0:	call   4280 <__stack_chk_fail@plt>
   186e5:	data16 cs nopw 0x0(%rax,%rax,1)

0000000000019510 <hf1_tb16_nat>:
   19510:	endbr64
   19514:	push   %rbp
   19515:	mov    %rdi,%rdx
   19518:	mov    %rsp,%rbp
   1951b:	and    $0xffffffffffffffc0,%rsp
   1951f:	sub    $0x540,%rsp
   19526:	vbroadcastss 0x44ad0(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   19530:	mov    %fs:0x28,%rax
   19539:	mov    %rax,0x538(%rsp)
   19541:	xor    %eax,%eax
   19543:	mov    %rsp,%rdi
   19546:	vzeroupper
   19549:	call   10120 <inl_consts.constprop.0>
   1954e:	vmovaps (%rsp),%zmm23
   19555:	vmovaps 0x40(%rsp),%zmm22
   1955d:	vmovaps 0x80(%rsp),%zmm21
   19565:	vmovaps 0xc0(%rsp),%zmm20
   1956d:	test   %rsi,%rsi
   19570:	je     19c07 <hf1_tb16_nat+0x6f7>
   19576:	mov    %rsi,%rcx
   19579:	mov    %rdx,%rax
   1957c:	lea    0x100(%rsp),%rdi
   19584:	xor    %edx,%edx
   19586:	sub    $0x1,%rcx
   1958a:	mov    %rcx,%rsi
   1958d:	shr    $0x8,%rsi
   19591:	nopl   0x0(%rax)
   19598:	vpxord (%rax),%zmm23,%zmm1
   1959e:	vpermilps $0xb1,(%rax),%zmm0
   195a5:	mov    %rdx,%rcx
   195a8:	vaddps %zmm1,%zmm0,%zmm0
   195ae:	vpermilps $0x4e,%zmm0,%zmm1
   195b5:	vpxord %zmm0,%zmm22,%zmm0
   195bb:	vaddps %zmm0,%zmm1,%zmm1
   195c1:	vshuff32x4 $0xb1,%zmm1,%zmm1,%zmm0
   195c8:	vpxord %zmm1,%zmm21,%zmm1
   195ce:	vaddps %zmm1,%zmm0,%zmm0
   195d4:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   195db:	vpxord %zmm0,%zmm20,%zmm0
   195e1:	vaddps %zmm0,%zmm1,%zmm0
   195e7:	vpxord 0x40(%rax),%zmm23,%zmm1
   195ee:	vmovaps %zmm0,0x100(%rsp)
   195f6:	vpermilps $0xb1,0x40(%rax),%zmm0
   195fe:	vaddps %zmm1,%zmm0,%zmm0
   19604:	vpermilps $0x4e,%zmm0,%zmm1
   1960b:	vpxord %zmm0,%zmm22,%zmm0
   19611:	vaddps %zmm0,%zmm1,%zmm1
   19617:	vshuff32x4 $0xb1,%zmm1,%zmm1,%zmm0
   1961e:	vpxord %zmm1,%zmm21,%zmm1
   19624:	vaddps %zmm1,%zmm0,%zmm0
   1962a:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19631:	vpxord %zmm0,%zmm20,%zmm0
   19637:	vaddps %zmm0,%zmm1,%zmm0
   1963d:	vpxord 0x80(%rax),%zmm23,%zmm1
   19644:	vmovaps %zmm0,0x140(%rsp)
   1964c:	vpermilps $0xb1,0x80(%rax),%zmm0
   19654:	vaddps %zmm1,%zmm0,%zmm0
   1965a:	vpermilps $0x4e,%zmm0,%zmm1
   19661:	vpxord %zmm0,%zmm22,%zmm0
   19667:	vaddps %zmm0,%zmm1,%zmm1
   1966d:	vshuff32x4 $0xb1,%zmm1,%zmm1,%zmm0
   19674:	vpxord %zmm1,%zmm21,%zmm1
   1967a:	vaddps %zmm1,%zmm0,%zmm0
   19680:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19687:	vpxord %zmm0,%zmm20,%zmm0
   1968d:	vaddps %zmm0,%zmm1,%zmm0
   19693:	vpxord 0xc0(%rax),%zmm23,%zmm1
   1969a:	vmovaps %zmm0,0x180(%rsp)
   196a2:	vpermilps $0xb1,0xc0(%rax),%zmm0
   196aa:	vaddps %zmm1,%zmm0,%zmm0
   196b0:	vpxord %zmm0,%zmm22,%zmm1
   196b6:	vpermilps $0x4e,%zmm0,%zmm0
   196bd:	vaddps %zmm1,%zmm0,%zmm0
   196c3:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   196ca:	vpxord %zmm0,%zmm21,%zmm0
   196d0:	vaddps %zmm0,%zmm1,%zmm0
   196d6:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   196dd:	vpxord %zmm0,%zmm20,%zmm0
   196e3:	vaddps %zmm0,%zmm1,%zmm0
   196e9:	vpxord 0x100(%rax),%zmm23,%zmm1
   196f0:	vmovaps %zmm0,0x1c0(%rsp)
   196f8:	vpermilps $0xb1,0x100(%rax),%zmm0
   19700:	vaddps %zmm1,%zmm0,%zmm0
   19706:	vpxord %zmm0,%zmm22,%zmm1
   1970c:	vpermilps $0x4e,%zmm0,%zmm0
   19713:	vaddps %zmm1,%zmm0,%zmm0
   19719:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19720:	vpxord %zmm0,%zmm21,%zmm0
   19726:	vaddps %zmm0,%zmm1,%zmm0
   1972c:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19733:	vpxord %zmm0,%zmm20,%zmm0
   19739:	vaddps %zmm0,%zmm1,%zmm0
   1973f:	vpxord 0x140(%rax),%zmm23,%zmm1
   19746:	vmovaps %zmm0,0x200(%rsp)
   1974e:	vpermilps $0xb1,0x140(%rax),%zmm0
   19756:	vaddps %zmm1,%zmm0,%zmm0
   1975c:	vpxord %zmm0,%zmm22,%zmm1
   19762:	vpermilps $0x4e,%zmm0,%zmm0
   19769:	vaddps %zmm1,%zmm0,%zmm0
   1976f:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19776:	vpxord %zmm0,%zmm21,%zmm0
   1977c:	vaddps %zmm0,%zmm1,%zmm0
   19782:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19789:	vpxord %zmm0,%zmm20,%zmm0
   1978f:	vaddps %zmm0,%zmm1,%zmm0
   19795:	vpxord 0x180(%rax),%zmm23,%zmm1
   1979c:	vmovaps %zmm0,0x240(%rsp)
   197a4:	vpermilps $0xb1,0x180(%rax),%zmm0
   197ac:	vaddps %zmm1,%zmm0,%zmm0
   197b2:	vpxord %zmm0,%zmm22,%zmm1
   197b8:	vpermilps $0x4e,%zmm0,%zmm0
   197bf:	vaddps %zmm1,%zmm0,%zmm0
   197c5:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   197cc:	vpxord %zmm0,%zmm21,%zmm0
   197d2:	vaddps %zmm0,%zmm1,%zmm0
   197d8:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   197df:	vpxord %zmm0,%zmm20,%zmm0
   197e5:	vaddps %zmm0,%zmm1,%zmm0
   197eb:	vpxord 0x1c0(%rax),%zmm23,%zmm1
   197f2:	vmovaps %zmm0,0x280(%rsp)
   197fa:	vpermilps $0xb1,0x1c0(%rax),%zmm0
   19802:	vaddps %zmm1,%zmm0,%zmm0
   19808:	vpxord %zmm0,%zmm22,%zmm1
   1980e:	vpermilps $0x4e,%zmm0,%zmm0
   19815:	vaddps %zmm1,%zmm0,%zmm0
   1981b:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19822:	vpxord %zmm0,%zmm21,%zmm0
   19828:	vaddps %zmm0,%zmm1,%zmm0
   1982e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19835:	vpxord %zmm0,%zmm20,%zmm0
   1983b:	vaddps %zmm0,%zmm1,%zmm0
   19841:	vpxord 0x200(%rax),%zmm23,%zmm1
   19848:	vmovaps %zmm0,0x2c0(%rsp)
   19850:	vpermilps $0xb1,0x200(%rax),%zmm0
   19858:	vaddps %zmm1,%zmm0,%zmm0
   1985e:	vpxord %zmm0,%zmm22,%zmm1
   19864:	vpermilps $0x4e,%zmm0,%zmm0
   1986b:	vaddps %zmm1,%zmm0,%zmm0
   19871:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19878:	vpxord %zmm0,%zmm21,%zmm0
   1987e:	vaddps %zmm0,%zmm1,%zmm0
   19884:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1988b:	vpxord %zmm0,%zmm20,%zmm0
   19891:	vaddps %zmm0,%zmm1,%zmm0
   19897:	vpxord 0x240(%rax),%zmm23,%zmm1
   1989e:	vmovaps %zmm0,0x300(%rsp)
   198a6:	vpermilps $0xb1,0x240(%rax),%zmm0
   198ae:	vaddps %zmm1,%zmm0,%zmm0
   198b4:	vpxord %zmm0,%zmm22,%zmm1
   198ba:	vpermilps $0x4e,%zmm0,%zmm0
   198c1:	vaddps %zmm1,%zmm0,%zmm0
   198c7:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   198ce:	vpxord %zmm0,%zmm21,%zmm0
   198d4:	vaddps %zmm0,%zmm1,%zmm0
   198da:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   198e1:	vpxord %zmm0,%zmm20,%zmm0
   198e7:	vaddps %zmm0,%zmm1,%zmm0
   198ed:	vpxord 0x280(%rax),%zmm23,%zmm1
   198f4:	vmovaps %zmm0,0x340(%rsp)
   198fc:	vpermilps $0xb1,0x280(%rax),%zmm0
   19904:	vaddps %zmm1,%zmm0,%zmm0
   1990a:	vpxord %zmm0,%zmm22,%zmm1
   19910:	vpermilps $0x4e,%zmm0,%zmm0
   19917:	vaddps %zmm1,%zmm0,%zmm0
   1991d:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19924:	vpxord %zmm0,%zmm21,%zmm0
   1992a:	vaddps %zmm0,%zmm1,%zmm0
   19930:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19937:	vpxord %zmm0,%zmm20,%zmm0
   1993d:	vaddps %zmm0,%zmm1,%zmm0
   19943:	vmovaps %zmm0,0x380(%rsp)
   1994b:	vpxord 0x2c0(%rax),%zmm23,%zmm1
   19952:	vpermilps $0xb1,0x2c0(%rax),%zmm0
   1995a:	vaddps %zmm1,%zmm0,%zmm0
   19960:	vpxord %zmm0,%zmm22,%zmm1
   19966:	vpermilps $0x4e,%zmm0,%zmm0
   1996d:	vaddps %zmm1,%zmm0,%zmm0
   19973:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1997a:	vpxord %zmm0,%zmm21,%zmm0
   19980:	vaddps %zmm0,%zmm1,%zmm0
   19986:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1998d:	vpxord %zmm0,%zmm20,%zmm0
   19993:	vaddps %zmm0,%zmm1,%zmm0
   19999:	vpxord 0x300(%rax),%zmm23,%zmm1
   199a0:	vmovaps %zmm0,0x3c0(%rsp)
   199a8:	vpermilps $0xb1,0x300(%rax),%zmm0
   199b0:	vaddps %zmm1,%zmm0,%zmm0
   199b6:	vpxord %zmm0,%zmm22,%zmm1
   199bc:	vpermilps $0x4e,%zmm0,%zmm0
   199c3:	vaddps %zmm1,%zmm0,%zmm0
   199c9:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   199d0:	vpxord %zmm0,%zmm21,%zmm0
   199d6:	vaddps %zmm0,%zmm1,%zmm0
   199dc:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   199e3:	vpxord %zmm0,%zmm20,%zmm0
   199e9:	vaddps %zmm0,%zmm1,%zmm0
   199ef:	vpxord 0x340(%rax),%zmm23,%zmm1
   199f6:	vmovaps %zmm0,0x400(%rsp)
   199fe:	vpermilps $0xb1,0x340(%rax),%zmm0
   19a06:	vaddps %zmm1,%zmm0,%zmm0
   19a0c:	vpxord %zmm0,%zmm22,%zmm1
   19a12:	vpermilps $0x4e,%zmm0,%zmm0
   19a19:	vaddps %zmm1,%zmm0,%zmm0
   19a1f:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19a26:	vpxord %zmm0,%zmm21,%zmm0
   19a2c:	vaddps %zmm0,%zmm1,%zmm0
   19a32:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19a39:	vpxord %zmm0,%zmm20,%zmm0
   19a3f:	vaddps %zmm0,%zmm1,%zmm0
   19a45:	vpxord 0x380(%rax),%zmm23,%zmm1
   19a4c:	vmovaps %zmm0,0x440(%rsp)
   19a54:	vpermilps $0xb1,0x380(%rax),%zmm0
   19a5c:	vaddps %zmm1,%zmm0,%zmm0
   19a62:	vpxord %zmm0,%zmm22,%zmm1
   19a68:	vpermilps $0x4e,%zmm0,%zmm0
   19a6f:	vaddps %zmm1,%zmm0,%zmm0
   19a75:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19a7c:	vpxord %zmm0,%zmm21,%zmm0
   19a82:	vaddps %zmm0,%zmm1,%zmm0
   19a88:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19a8f:	vpxord %zmm0,%zmm20,%zmm0
   19a95:	vaddps %zmm0,%zmm1,%zmm0
   19a9b:	vpxord 0x3c0(%rax),%zmm23,%zmm1
   19aa2:	vmovaps %zmm0,0x480(%rsp)
   19aaa:	vpermilps $0xb1,0x3c0(%rax),%zmm0
   19ab2:	vaddps %zmm1,%zmm0,%zmm0
   19ab8:	vpxord %zmm0,%zmm22,%zmm1
   19abe:	vpermilps $0x4e,%zmm0,%zmm0
   19ac5:	vaddps %zmm1,%zmm0,%zmm0
   19acb:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19ad2:	vpxord %zmm0,%zmm21,%zmm0
   19ad8:	vaddps %zmm0,%zmm1,%zmm0
   19ade:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19ae5:	vpxord %zmm0,%zmm20,%zmm0
   19aeb:	vaddps %zmm0,%zmm1,%zmm0
   19af1:	vmovaps %zmm0,0x4c0(%rsp)
   19af9:	vzeroupper
   19afc:	call   16b50 <tb16_nat.constprop.0>
   19b01:	add    $0x1,%rdx
   19b05:	vmovaps 0x100(%rsp),%zmm2
   19b0d:	vmovaps 0x140(%rsp),%zmm3
   19b15:	vmovaps 0x180(%rsp),%zmm4
   19b1d:	add    $0x400,%rax
   19b23:	vmovaps 0x1c0(%rsp),%zmm5
   19b2b:	vmovaps 0x200(%rsp),%zmm6
   19b33:	vmovups %zmm2,-0x400(%rax)
   19b3a:	vmovaps 0x240(%rsp),%zmm7
   19b42:	vmovaps 0x280(%rsp),%zmm2
   19b4a:	vmovups %zmm3,-0x3c0(%rax)
   19b51:	vmovups %zmm4,-0x380(%rax)
   19b58:	vmovaps 0x2c0(%rsp),%zmm3
   19b60:	vmovaps 0x300(%rsp),%zmm4
   19b68:	vmovups %zmm5,-0x340(%rax)
   19b6f:	vmovaps 0x340(%rsp),%zmm5
   19b77:	vmovups %zmm6,-0x300(%rax)
   19b7e:	vmovaps 0x380(%rsp),%zmm6
   19b86:	vmovups %zmm7,-0x2c0(%rax)
   19b8d:	vmovaps 0x3c0(%rsp),%zmm7
   19b95:	vmovups %zmm2,-0x280(%rax)
   19b9c:	vmovaps 0x400(%rsp),%zmm2
   19ba4:	vmovups %zmm3,-0x240(%rax)
   19bab:	vmovaps 0x440(%rsp),%zmm3
   19bb3:	vmovups %zmm4,-0x200(%rax)
   19bba:	vmovaps 0x480(%rsp),%zmm4
   19bc2:	vmovups %zmm5,-0x1c0(%rax)
   19bc9:	vmovaps 0x4c0(%rsp),%zmm5
   19bd1:	vmovups %zmm6,-0x180(%rax)
   19bd8:	vmovups %zmm7,-0x140(%rax)
   19bdf:	vmovups %zmm2,-0x100(%rax)
   19be6:	vmovups %zmm3,-0xc0(%rax)
   19bed:	vmovups %zmm4,-0x80(%rax)
   19bf4:	vmovups %zmm5,-0x40(%rax)
   19bfb:	cmp    %rcx,%rsi
   19bfe:	jne    19598 <hf1_tb16_nat+0x88>
   19c04:	vzeroupper
   19c07:	mov    0x538(%rsp),%rax
   19c0f:	sub    %fs:0x28,%rax
   19c18:	jne    19c1c <hf1_tb16_nat+0x70c>
   19c1a:	leave
   19c1b:	ret
   19c1c:	call   4280 <__stack_chk_fail@plt>
   19c21:	data16 cs nopw 0x0(%rax,%rax,1)
   19c2c:	nopl   0x0(%rax)

0000000000019c30 <hf1_g52_nat>:
   19c30:	endbr64
   19c34:	push   %rbp
   19c35:	mov    %rdi,%rdx
   19c38:	mov    %rsp,%rbp
   19c3b:	and    $0xffffffffffffffc0,%rsp
   19c3f:	sub    $0x540,%rsp
   19c46:	vbroadcastss 0x443b0(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   19c50:	mov    %fs:0x28,%rax
   19c59:	mov    %rax,0x538(%rsp)
   19c61:	xor    %eax,%eax
   19c63:	mov    %rsp,%rdi
   19c66:	vzeroupper
   19c69:	call   10120 <inl_consts.constprop.0>
   19c6e:	vmovaps (%rsp),%zmm21
   19c75:	vmovaps 0x40(%rsp),%zmm20
   19c7d:	vmovaps 0x80(%rsp),%zmm19
   19c85:	vmovaps 0xc0(%rsp),%zmm18
   19c8d:	test   %rsi,%rsi
   19c90:	je     1a327 <hf1_g52_nat+0x6f7>
   19c96:	mov    %rsi,%rcx
   19c99:	mov    %rdx,%rax
   19c9c:	lea    0x100(%rsp),%rdi
   19ca4:	xor    %edx,%edx
   19ca6:	sub    $0x1,%rcx
   19caa:	mov    %rcx,%rsi
   19cad:	shr    $0x8,%rsi
   19cb1:	nopl   0x0(%rax)
   19cb8:	vpxord (%rax),%zmm21,%zmm1
   19cbe:	vpermilps $0xb1,(%rax),%zmm0
   19cc5:	mov    %rdx,%rcx
   19cc8:	vaddps %zmm1,%zmm0,%zmm0
   19cce:	vpermilps $0x4e,%zmm0,%zmm1
   19cd5:	vpxord %zmm0,%zmm20,%zmm0
   19cdb:	vaddps %zmm0,%zmm1,%zmm1
   19ce1:	vshuff32x4 $0xb1,%zmm1,%zmm1,%zmm0
   19ce8:	vpxord %zmm1,%zmm19,%zmm1
   19cee:	vaddps %zmm1,%zmm0,%zmm0
   19cf4:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19cfb:	vpxord %zmm0,%zmm18,%zmm0
   19d01:	vaddps %zmm0,%zmm1,%zmm0
   19d07:	vpxord 0x40(%rax),%zmm21,%zmm1
   19d0e:	vmovaps %zmm0,0x100(%rsp)
   19d16:	vpermilps $0xb1,0x40(%rax),%zmm0
   19d1e:	vaddps %zmm1,%zmm0,%zmm0
   19d24:	vpermilps $0x4e,%zmm0,%zmm1
   19d2b:	vpxord %zmm0,%zmm20,%zmm0
   19d31:	vaddps %zmm0,%zmm1,%zmm1
   19d37:	vshuff32x4 $0xb1,%zmm1,%zmm1,%zmm0
   19d3e:	vpxord %zmm1,%zmm19,%zmm1
   19d44:	vaddps %zmm1,%zmm0,%zmm0
   19d4a:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19d51:	vpxord %zmm0,%zmm18,%zmm0
   19d57:	vaddps %zmm0,%zmm1,%zmm0
   19d5d:	vpxord 0x80(%rax),%zmm21,%zmm1
   19d64:	vmovaps %zmm0,0x140(%rsp)
   19d6c:	vpermilps $0xb1,0x80(%rax),%zmm0
   19d74:	vaddps %zmm1,%zmm0,%zmm0
   19d7a:	vpermilps $0x4e,%zmm0,%zmm1
   19d81:	vpxord %zmm0,%zmm20,%zmm0
   19d87:	vaddps %zmm0,%zmm1,%zmm1
   19d8d:	vshuff32x4 $0xb1,%zmm1,%zmm1,%zmm0
   19d94:	vpxord %zmm1,%zmm19,%zmm1
   19d9a:	vaddps %zmm1,%zmm0,%zmm0
   19da0:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19da7:	vpxord %zmm0,%zmm18,%zmm0
   19dad:	vaddps %zmm0,%zmm1,%zmm0
   19db3:	vpxord 0xc0(%rax),%zmm21,%zmm1
   19dba:	vmovaps %zmm0,0x180(%rsp)
   19dc2:	vpermilps $0xb1,0xc0(%rax),%zmm0
   19dca:	vaddps %zmm1,%zmm0,%zmm0
   19dd0:	vpxord %zmm0,%zmm20,%zmm1
   19dd6:	vpermilps $0x4e,%zmm0,%zmm0
   19ddd:	vaddps %zmm1,%zmm0,%zmm0
   19de3:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19dea:	vpxord %zmm0,%zmm19,%zmm0
   19df0:	vaddps %zmm0,%zmm1,%zmm0
   19df6:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19dfd:	vpxord %zmm0,%zmm18,%zmm0
   19e03:	vaddps %zmm0,%zmm1,%zmm0
   19e09:	vpxord 0x100(%rax),%zmm21,%zmm1
   19e10:	vmovaps %zmm0,0x1c0(%rsp)
   19e18:	vpermilps $0xb1,0x100(%rax),%zmm0
   19e20:	vaddps %zmm1,%zmm0,%zmm0
   19e26:	vpxord %zmm0,%zmm20,%zmm1
   19e2c:	vpermilps $0x4e,%zmm0,%zmm0
   19e33:	vaddps %zmm1,%zmm0,%zmm0
   19e39:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19e40:	vpxord %zmm0,%zmm19,%zmm0
   19e46:	vaddps %zmm0,%zmm1,%zmm0
   19e4c:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19e53:	vpxord %zmm0,%zmm18,%zmm0
   19e59:	vaddps %zmm0,%zmm1,%zmm0
   19e5f:	vpxord 0x140(%rax),%zmm21,%zmm1
   19e66:	vmovaps %zmm0,0x200(%rsp)
   19e6e:	vpermilps $0xb1,0x140(%rax),%zmm0
   19e76:	vaddps %zmm1,%zmm0,%zmm0
   19e7c:	vpxord %zmm0,%zmm20,%zmm1
   19e82:	vpermilps $0x4e,%zmm0,%zmm0
   19e89:	vaddps %zmm1,%zmm0,%zmm0
   19e8f:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19e96:	vpxord %zmm0,%zmm19,%zmm0
   19e9c:	vaddps %zmm0,%zmm1,%zmm0
   19ea2:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19ea9:	vpxord %zmm0,%zmm18,%zmm0
   19eaf:	vaddps %zmm0,%zmm1,%zmm0
   19eb5:	vpxord 0x180(%rax),%zmm21,%zmm1
   19ebc:	vmovaps %zmm0,0x240(%rsp)
   19ec4:	vpermilps $0xb1,0x180(%rax),%zmm0
   19ecc:	vaddps %zmm1,%zmm0,%zmm0
   19ed2:	vpxord %zmm0,%zmm20,%zmm1
   19ed8:	vpermilps $0x4e,%zmm0,%zmm0
   19edf:	vaddps %zmm1,%zmm0,%zmm0
   19ee5:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19eec:	vpxord %zmm0,%zmm19,%zmm0
   19ef2:	vaddps %zmm0,%zmm1,%zmm0
   19ef8:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19eff:	vpxord %zmm0,%zmm18,%zmm0
   19f05:	vaddps %zmm0,%zmm1,%zmm0
   19f0b:	vpxord 0x1c0(%rax),%zmm21,%zmm1
   19f12:	vmovaps %zmm0,0x280(%rsp)
   19f1a:	vpermilps $0xb1,0x1c0(%rax),%zmm0
   19f22:	vaddps %zmm1,%zmm0,%zmm0
   19f28:	vpxord %zmm0,%zmm20,%zmm1
   19f2e:	vpermilps $0x4e,%zmm0,%zmm0
   19f35:	vaddps %zmm1,%zmm0,%zmm0
   19f3b:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19f42:	vpxord %zmm0,%zmm19,%zmm0
   19f48:	vaddps %zmm0,%zmm1,%zmm0
   19f4e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19f55:	vpxord %zmm0,%zmm18,%zmm0
   19f5b:	vaddps %zmm0,%zmm1,%zmm0
   19f61:	vpxord 0x200(%rax),%zmm21,%zmm1
   19f68:	vmovaps %zmm0,0x2c0(%rsp)
   19f70:	vpermilps $0xb1,0x200(%rax),%zmm0
   19f78:	vaddps %zmm1,%zmm0,%zmm0
   19f7e:	vpxord %zmm0,%zmm20,%zmm1
   19f84:	vpermilps $0x4e,%zmm0,%zmm0
   19f8b:	vaddps %zmm1,%zmm0,%zmm0
   19f91:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19f98:	vpxord %zmm0,%zmm19,%zmm0
   19f9e:	vaddps %zmm0,%zmm1,%zmm0
   19fa4:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   19fab:	vpxord %zmm0,%zmm18,%zmm0
   19fb1:	vaddps %zmm0,%zmm1,%zmm0
   19fb7:	vpxord 0x240(%rax),%zmm21,%zmm1
   19fbe:	vmovaps %zmm0,0x300(%rsp)
   19fc6:	vpermilps $0xb1,0x240(%rax),%zmm0
   19fce:	vaddps %zmm1,%zmm0,%zmm0
   19fd4:	vpxord %zmm0,%zmm20,%zmm1
   19fda:	vpermilps $0x4e,%zmm0,%zmm0
   19fe1:	vaddps %zmm1,%zmm0,%zmm0
   19fe7:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   19fee:	vpxord %zmm0,%zmm19,%zmm0
   19ff4:	vaddps %zmm0,%zmm1,%zmm0
   19ffa:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a001:	vpxord %zmm0,%zmm18,%zmm0
   1a007:	vaddps %zmm0,%zmm1,%zmm0
   1a00d:	vpxord 0x280(%rax),%zmm21,%zmm1
   1a014:	vmovaps %zmm0,0x340(%rsp)
   1a01c:	vpermilps $0xb1,0x280(%rax),%zmm0
   1a024:	vaddps %zmm1,%zmm0,%zmm0
   1a02a:	vpxord %zmm0,%zmm20,%zmm1
   1a030:	vpermilps $0x4e,%zmm0,%zmm0
   1a037:	vaddps %zmm1,%zmm0,%zmm0
   1a03d:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a044:	vpxord %zmm0,%zmm19,%zmm0
   1a04a:	vaddps %zmm0,%zmm1,%zmm0
   1a050:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a057:	vpxord %zmm0,%zmm18,%zmm0
   1a05d:	vaddps %zmm0,%zmm1,%zmm0
   1a063:	vmovaps %zmm0,0x380(%rsp)
   1a06b:	vpxord 0x2c0(%rax),%zmm21,%zmm1
   1a072:	vpermilps $0xb1,0x2c0(%rax),%zmm0
   1a07a:	vaddps %zmm1,%zmm0,%zmm0
   1a080:	vpxord %zmm0,%zmm20,%zmm1
   1a086:	vpermilps $0x4e,%zmm0,%zmm0
   1a08d:	vaddps %zmm1,%zmm0,%zmm0
   1a093:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a09a:	vpxord %zmm0,%zmm19,%zmm0
   1a0a0:	vaddps %zmm0,%zmm1,%zmm0
   1a0a6:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a0ad:	vpxord %zmm0,%zmm18,%zmm0
   1a0b3:	vaddps %zmm0,%zmm1,%zmm0
   1a0b9:	vpxord 0x300(%rax),%zmm21,%zmm1
   1a0c0:	vmovaps %zmm0,0x3c0(%rsp)
   1a0c8:	vpermilps $0xb1,0x300(%rax),%zmm0
   1a0d0:	vaddps %zmm1,%zmm0,%zmm0
   1a0d6:	vpxord %zmm0,%zmm20,%zmm1
   1a0dc:	vpermilps $0x4e,%zmm0,%zmm0
   1a0e3:	vaddps %zmm1,%zmm0,%zmm0
   1a0e9:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a0f0:	vpxord %zmm0,%zmm19,%zmm0
   1a0f6:	vaddps %zmm0,%zmm1,%zmm0
   1a0fc:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a103:	vpxord %zmm0,%zmm18,%zmm0
   1a109:	vaddps %zmm0,%zmm1,%zmm0
   1a10f:	vpxord 0x340(%rax),%zmm21,%zmm1
   1a116:	vmovaps %zmm0,0x400(%rsp)
   1a11e:	vpermilps $0xb1,0x340(%rax),%zmm0
   1a126:	vaddps %zmm1,%zmm0,%zmm0
   1a12c:	vpxord %zmm0,%zmm20,%zmm1
   1a132:	vpermilps $0x4e,%zmm0,%zmm0
   1a139:	vaddps %zmm1,%zmm0,%zmm0
   1a13f:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a146:	vpxord %zmm0,%zmm19,%zmm0
   1a14c:	vaddps %zmm0,%zmm1,%zmm0
   1a152:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a159:	vpxord %zmm0,%zmm18,%zmm0
   1a15f:	vaddps %zmm0,%zmm1,%zmm0
   1a165:	vpxord 0x380(%rax),%zmm21,%zmm1
   1a16c:	vmovaps %zmm0,0x440(%rsp)
   1a174:	vpermilps $0xb1,0x380(%rax),%zmm0
   1a17c:	vaddps %zmm1,%zmm0,%zmm0
   1a182:	vpxord %zmm0,%zmm20,%zmm1
   1a188:	vpermilps $0x4e,%zmm0,%zmm0
   1a18f:	vaddps %zmm1,%zmm0,%zmm0
   1a195:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a19c:	vpxord %zmm0,%zmm19,%zmm0
   1a1a2:	vaddps %zmm0,%zmm1,%zmm0
   1a1a8:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a1af:	vpxord %zmm0,%zmm18,%zmm0
   1a1b5:	vaddps %zmm0,%zmm1,%zmm0
   1a1bb:	vpxord 0x3c0(%rax),%zmm21,%zmm1
   1a1c2:	vmovaps %zmm0,0x480(%rsp)
   1a1ca:	vpermilps $0xb1,0x3c0(%rax),%zmm0
   1a1d2:	vaddps %zmm1,%zmm0,%zmm0
   1a1d8:	vpxord %zmm0,%zmm20,%zmm1
   1a1de:	vpermilps $0x4e,%zmm0,%zmm0
   1a1e5:	vaddps %zmm1,%zmm0,%zmm0
   1a1eb:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a1f2:	vpxord %zmm0,%zmm19,%zmm0
   1a1f8:	vaddps %zmm0,%zmm1,%zmm0
   1a1fe:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a205:	vpxord %zmm0,%zmm18,%zmm0
   1a20b:	vaddps %zmm0,%zmm1,%zmm0
   1a211:	vmovaps %zmm0,0x4c0(%rsp)
   1a219:	vzeroupper
   1a21c:	call   14f10 <g52_nat.constprop.0>
   1a221:	add    $0x1,%rdx
   1a225:	vmovaps 0x100(%rsp),%zmm2
   1a22d:	vmovaps 0x140(%rsp),%zmm3
   1a235:	vmovaps 0x180(%rsp),%zmm4
   1a23d:	add    $0x400,%rax
   1a243:	vmovaps 0x1c0(%rsp),%zmm5
   1a24b:	vmovaps 0x200(%rsp),%zmm6
   1a253:	vmovups %zmm2,-0x400(%rax)
   1a25a:	vmovaps 0x240(%rsp),%zmm7
   1a262:	vmovaps 0x280(%rsp),%zmm2
   1a26a:	vmovups %zmm3,-0x3c0(%rax)
   1a271:	vmovups %zmm4,-0x380(%rax)
   1a278:	vmovaps 0x2c0(%rsp),%zmm3
   1a280:	vmovaps 0x300(%rsp),%zmm4
   1a288:	vmovups %zmm5,-0x340(%rax)
   1a28f:	vmovaps 0x340(%rsp),%zmm5
   1a297:	vmovups %zmm6,-0x300(%rax)
   1a29e:	vmovaps 0x380(%rsp),%zmm6
   1a2a6:	vmovups %zmm7,-0x2c0(%rax)
   1a2ad:	vmovaps 0x3c0(%rsp),%zmm7
   1a2b5:	vmovups %zmm2,-0x280(%rax)
   1a2bc:	vmovaps 0x400(%rsp),%zmm2
   1a2c4:	vmovups %zmm3,-0x240(%rax)
   1a2cb:	vmovaps 0x440(%rsp),%zmm3
   1a2d3:	vmovups %zmm4,-0x200(%rax)
   1a2da:	vmovaps 0x480(%rsp),%zmm4
   1a2e2:	vmovups %zmm5,-0x1c0(%rax)
   1a2e9:	vmovaps 0x4c0(%rsp),%zmm5
   1a2f1:	vmovups %zmm6,-0x180(%rax)
   1a2f8:	vmovups %zmm7,-0x140(%rax)
   1a2ff:	vmovups %zmm2,-0x100(%rax)
   1a306:	vmovups %zmm3,-0xc0(%rax)
   1a30d:	vmovups %zmm4,-0x80(%rax)
   1a314:	vmovups %zmm5,-0x40(%rax)
   1a31b:	cmp    %rcx,%rsi
   1a31e:	jne    19cb8 <hf1_g52_nat+0x88>
   1a324:	vzeroupper
   1a327:	mov    0x538(%rsp),%rax
   1a32f:	sub    %fs:0x28,%rax
   1a338:	jne    1a33c <hf1_g52_nat+0x70c>
   1a33a:	leave
   1a33b:	ret
   1a33c:	call   4280 <__stack_chk_fail@plt>
   1a341:	data16 cs nopw 0x0(%rax,%rax,1)
   1a34c:	nopl   0x0(%rax)

000000000001a350 <hf1_broken_g52>:
   1a350:	endbr64
   1a354:	push   %rbp
   1a355:	mov    %rdi,%rdx
   1a358:	mov    %rsp,%rbp
   1a35b:	and    $0xffffffffffffffc0,%rsp
   1a35f:	sub    $0x540,%rsp
   1a366:	vbroadcastss 0x43c90(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   1a370:	mov    %fs:0x28,%rax
   1a379:	mov    %rax,0x538(%rsp)
   1a381:	xor    %eax,%eax
   1a383:	mov    %rsp,%rdi
   1a386:	vzeroupper
   1a389:	call   10120 <inl_consts.constprop.0>
   1a38e:	vmovaps (%rsp),%zmm21
   1a395:	vmovaps 0x40(%rsp),%zmm20
   1a39d:	vmovaps 0x80(%rsp),%zmm19
   1a3a5:	vmovaps 0xc0(%rsp),%zmm18
   1a3ad:	test   %rsi,%rsi
   1a3b0:	je     1aa47 <hf1_broken_g52+0x6f7>
   1a3b6:	mov    %rsi,%rcx
   1a3b9:	mov    %rdx,%rax
   1a3bc:	lea    0x100(%rsp),%rdi
   1a3c4:	xor    %edx,%edx
   1a3c6:	sub    $0x1,%rcx
   1a3ca:	mov    %rcx,%rsi
   1a3cd:	shr    $0x8,%rsi
   1a3d1:	nopl   0x0(%rax)
   1a3d8:	vpxord (%rax),%zmm21,%zmm1
   1a3de:	vpermilps $0xb1,(%rax),%zmm0
   1a3e5:	mov    %rdx,%rcx
   1a3e8:	vaddps %zmm1,%zmm0,%zmm0
   1a3ee:	vpermilps $0x4e,%zmm0,%zmm1
   1a3f5:	vpxord %zmm0,%zmm20,%zmm0
   1a3fb:	vaddps %zmm0,%zmm1,%zmm1
   1a401:	vshuff32x4 $0xb1,%zmm1,%zmm1,%zmm0
   1a408:	vpxord %zmm1,%zmm19,%zmm1
   1a40e:	vaddps %zmm1,%zmm0,%zmm0
   1a414:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a41b:	vpxord %zmm0,%zmm18,%zmm0
   1a421:	vaddps %zmm0,%zmm1,%zmm0
   1a427:	vpxord 0x40(%rax),%zmm21,%zmm1
   1a42e:	vmovaps %zmm0,0x100(%rsp)
   1a436:	vpermilps $0xb1,0x40(%rax),%zmm0
   1a43e:	vaddps %zmm1,%zmm0,%zmm0
   1a444:	vpermilps $0x4e,%zmm0,%zmm1
   1a44b:	vpxord %zmm0,%zmm20,%zmm0
   1a451:	vaddps %zmm0,%zmm1,%zmm1
   1a457:	vshuff32x4 $0xb1,%zmm1,%zmm1,%zmm0
   1a45e:	vpxord %zmm1,%zmm19,%zmm1
   1a464:	vaddps %zmm1,%zmm0,%zmm0
   1a46a:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a471:	vpxord %zmm0,%zmm18,%zmm0
   1a477:	vaddps %zmm0,%zmm1,%zmm0
   1a47d:	vpxord 0x80(%rax),%zmm21,%zmm1
   1a484:	vmovaps %zmm0,0x140(%rsp)
   1a48c:	vpermilps $0xb1,0x80(%rax),%zmm0
   1a494:	vaddps %zmm1,%zmm0,%zmm0
   1a49a:	vpermilps $0x4e,%zmm0,%zmm1
   1a4a1:	vpxord %zmm0,%zmm20,%zmm0
   1a4a7:	vaddps %zmm0,%zmm1,%zmm1
   1a4ad:	vshuff32x4 $0xb1,%zmm1,%zmm1,%zmm0
   1a4b4:	vpxord %zmm1,%zmm19,%zmm1
   1a4ba:	vaddps %zmm1,%zmm0,%zmm0
   1a4c0:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a4c7:	vpxord %zmm0,%zmm18,%zmm0
   1a4cd:	vaddps %zmm0,%zmm1,%zmm0
   1a4d3:	vpxord 0xc0(%rax),%zmm21,%zmm1
   1a4da:	vmovaps %zmm0,0x180(%rsp)
   1a4e2:	vpermilps $0xb1,0xc0(%rax),%zmm0
   1a4ea:	vaddps %zmm1,%zmm0,%zmm0
   1a4f0:	vpxord %zmm0,%zmm20,%zmm1
   1a4f6:	vpermilps $0x4e,%zmm0,%zmm0
   1a4fd:	vaddps %zmm1,%zmm0,%zmm0
   1a503:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a50a:	vpxord %zmm0,%zmm19,%zmm0
   1a510:	vaddps %zmm0,%zmm1,%zmm0
   1a516:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a51d:	vpxord %zmm0,%zmm18,%zmm0
   1a523:	vaddps %zmm0,%zmm1,%zmm0
   1a529:	vpxord 0x100(%rax),%zmm21,%zmm1
   1a530:	vmovaps %zmm0,0x1c0(%rsp)
   1a538:	vpermilps $0xb1,0x100(%rax),%zmm0
   1a540:	vaddps %zmm1,%zmm0,%zmm0
   1a546:	vpxord %zmm0,%zmm20,%zmm1
   1a54c:	vpermilps $0x4e,%zmm0,%zmm0
   1a553:	vaddps %zmm1,%zmm0,%zmm0
   1a559:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a560:	vpxord %zmm0,%zmm19,%zmm0
   1a566:	vaddps %zmm0,%zmm1,%zmm0
   1a56c:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a573:	vpxord %zmm0,%zmm18,%zmm0
   1a579:	vaddps %zmm0,%zmm1,%zmm0
   1a57f:	vpxord 0x140(%rax),%zmm21,%zmm1
   1a586:	vmovaps %zmm0,0x200(%rsp)
   1a58e:	vpermilps $0xb1,0x140(%rax),%zmm0
   1a596:	vaddps %zmm1,%zmm0,%zmm0
   1a59c:	vpxord %zmm0,%zmm20,%zmm1
   1a5a2:	vpermilps $0x4e,%zmm0,%zmm0
   1a5a9:	vaddps %zmm1,%zmm0,%zmm0
   1a5af:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a5b6:	vpxord %zmm0,%zmm19,%zmm0
   1a5bc:	vaddps %zmm0,%zmm1,%zmm0
   1a5c2:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a5c9:	vpxord %zmm0,%zmm18,%zmm0
   1a5cf:	vaddps %zmm0,%zmm1,%zmm0
   1a5d5:	vpxord 0x180(%rax),%zmm21,%zmm1
   1a5dc:	vmovaps %zmm0,0x240(%rsp)
   1a5e4:	vpermilps $0xb1,0x180(%rax),%zmm0
   1a5ec:	vaddps %zmm1,%zmm0,%zmm0
   1a5f2:	vpxord %zmm0,%zmm20,%zmm1
   1a5f8:	vpermilps $0x4e,%zmm0,%zmm0
   1a5ff:	vaddps %zmm1,%zmm0,%zmm0
   1a605:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a60c:	vpxord %zmm0,%zmm19,%zmm0
   1a612:	vaddps %zmm0,%zmm1,%zmm0
   1a618:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a61f:	vpxord %zmm0,%zmm18,%zmm0
   1a625:	vaddps %zmm0,%zmm1,%zmm0
   1a62b:	vpxord 0x1c0(%rax),%zmm21,%zmm1
   1a632:	vmovaps %zmm0,0x280(%rsp)
   1a63a:	vpermilps $0xb1,0x1c0(%rax),%zmm0
   1a642:	vaddps %zmm1,%zmm0,%zmm0
   1a648:	vpxord %zmm0,%zmm20,%zmm1
   1a64e:	vpermilps $0x4e,%zmm0,%zmm0
   1a655:	vaddps %zmm1,%zmm0,%zmm0
   1a65b:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a662:	vpxord %zmm0,%zmm19,%zmm0
   1a668:	vaddps %zmm0,%zmm1,%zmm0
   1a66e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a675:	vpxord %zmm0,%zmm18,%zmm0
   1a67b:	vaddps %zmm0,%zmm1,%zmm0
   1a681:	vpxord 0x200(%rax),%zmm21,%zmm1
   1a688:	vmovaps %zmm0,0x2c0(%rsp)
   1a690:	vpermilps $0xb1,0x200(%rax),%zmm0
   1a698:	vaddps %zmm1,%zmm0,%zmm0
   1a69e:	vpxord %zmm0,%zmm20,%zmm1
   1a6a4:	vpermilps $0x4e,%zmm0,%zmm0
   1a6ab:	vaddps %zmm1,%zmm0,%zmm0
   1a6b1:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a6b8:	vpxord %zmm0,%zmm19,%zmm0
   1a6be:	vaddps %zmm0,%zmm1,%zmm0
   1a6c4:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a6cb:	vpxord %zmm0,%zmm18,%zmm0
   1a6d1:	vaddps %zmm0,%zmm1,%zmm0
   1a6d7:	vpxord 0x240(%rax),%zmm21,%zmm1
   1a6de:	vmovaps %zmm0,0x300(%rsp)
   1a6e6:	vpermilps $0xb1,0x240(%rax),%zmm0
   1a6ee:	vaddps %zmm1,%zmm0,%zmm0
   1a6f4:	vpxord %zmm0,%zmm20,%zmm1
   1a6fa:	vpermilps $0x4e,%zmm0,%zmm0
   1a701:	vaddps %zmm1,%zmm0,%zmm0
   1a707:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a70e:	vpxord %zmm0,%zmm19,%zmm0
   1a714:	vaddps %zmm0,%zmm1,%zmm0
   1a71a:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a721:	vpxord %zmm0,%zmm18,%zmm0
   1a727:	vaddps %zmm0,%zmm1,%zmm0
   1a72d:	vpxord 0x280(%rax),%zmm21,%zmm1
   1a734:	vmovaps %zmm0,0x340(%rsp)
   1a73c:	vpermilps $0xb1,0x280(%rax),%zmm0
   1a744:	vaddps %zmm1,%zmm0,%zmm0
   1a74a:	vpxord %zmm0,%zmm20,%zmm1
   1a750:	vpermilps $0x4e,%zmm0,%zmm0
   1a757:	vaddps %zmm1,%zmm0,%zmm0
   1a75d:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a764:	vpxord %zmm0,%zmm19,%zmm0
   1a76a:	vaddps %zmm0,%zmm1,%zmm0
   1a770:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a777:	vpxord %zmm0,%zmm18,%zmm0
   1a77d:	vaddps %zmm0,%zmm1,%zmm0
   1a783:	vmovaps %zmm0,0x380(%rsp)
   1a78b:	vpxord 0x2c0(%rax),%zmm21,%zmm1
   1a792:	vpermilps $0xb1,0x2c0(%rax),%zmm0
   1a79a:	vaddps %zmm1,%zmm0,%zmm0
   1a7a0:	vpxord %zmm0,%zmm20,%zmm1
   1a7a6:	vpermilps $0x4e,%zmm0,%zmm0
   1a7ad:	vaddps %zmm1,%zmm0,%zmm0
   1a7b3:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a7ba:	vpxord %zmm0,%zmm19,%zmm0
   1a7c0:	vaddps %zmm0,%zmm1,%zmm0
   1a7c6:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a7cd:	vpxord %zmm0,%zmm18,%zmm0
   1a7d3:	vaddps %zmm0,%zmm1,%zmm0
   1a7d9:	vpxord 0x300(%rax),%zmm21,%zmm1
   1a7e0:	vmovaps %zmm0,0x3c0(%rsp)
   1a7e8:	vpermilps $0xb1,0x300(%rax),%zmm0
   1a7f0:	vaddps %zmm1,%zmm0,%zmm0
   1a7f6:	vpxord %zmm0,%zmm20,%zmm1
   1a7fc:	vpermilps $0x4e,%zmm0,%zmm0
   1a803:	vaddps %zmm1,%zmm0,%zmm0
   1a809:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a810:	vpxord %zmm0,%zmm19,%zmm0
   1a816:	vaddps %zmm0,%zmm1,%zmm0
   1a81c:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a823:	vpxord %zmm0,%zmm18,%zmm0
   1a829:	vaddps %zmm0,%zmm1,%zmm0
   1a82f:	vpxord 0x340(%rax),%zmm21,%zmm1
   1a836:	vmovaps %zmm0,0x400(%rsp)
   1a83e:	vpermilps $0xb1,0x340(%rax),%zmm0
   1a846:	vaddps %zmm1,%zmm0,%zmm0
   1a84c:	vpxord %zmm0,%zmm20,%zmm1
   1a852:	vpermilps $0x4e,%zmm0,%zmm0
   1a859:	vaddps %zmm1,%zmm0,%zmm0
   1a85f:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a866:	vpxord %zmm0,%zmm19,%zmm0
   1a86c:	vaddps %zmm0,%zmm1,%zmm0
   1a872:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a879:	vpxord %zmm0,%zmm18,%zmm0
   1a87f:	vaddps %zmm0,%zmm1,%zmm0
   1a885:	vpxord 0x380(%rax),%zmm21,%zmm1
   1a88c:	vmovaps %zmm0,0x440(%rsp)
   1a894:	vpermilps $0xb1,0x380(%rax),%zmm0
   1a89c:	vaddps %zmm1,%zmm0,%zmm0
   1a8a2:	vpxord %zmm0,%zmm20,%zmm1
   1a8a8:	vpermilps $0x4e,%zmm0,%zmm0
   1a8af:	vaddps %zmm1,%zmm0,%zmm0
   1a8b5:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a8bc:	vpxord %zmm0,%zmm19,%zmm0
   1a8c2:	vaddps %zmm0,%zmm1,%zmm0
   1a8c8:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a8cf:	vpxord %zmm0,%zmm18,%zmm0
   1a8d5:	vaddps %zmm0,%zmm1,%zmm0
   1a8db:	vpxord 0x3c0(%rax),%zmm21,%zmm1
   1a8e2:	vmovaps %zmm0,0x480(%rsp)
   1a8ea:	vpermilps $0xb1,0x3c0(%rax),%zmm0
   1a8f2:	vaddps %zmm1,%zmm0,%zmm0
   1a8f8:	vpxord %zmm0,%zmm20,%zmm1
   1a8fe:	vpermilps $0x4e,%zmm0,%zmm0
   1a905:	vaddps %zmm1,%zmm0,%zmm0
   1a90b:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1a912:	vpxord %zmm0,%zmm19,%zmm0
   1a918:	vaddps %zmm0,%zmm1,%zmm0
   1a91e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1a925:	vpxord %zmm0,%zmm18,%zmm0
   1a92b:	vaddps %zmm0,%zmm1,%zmm0
   1a931:	vmovaps %zmm0,0x4c0(%rsp)
   1a939:	vzeroupper
   1a93c:	call   14f10 <g52_nat.constprop.0>
   1a941:	add    $0x1,%rdx
   1a945:	vmovaps 0x100(%rsp),%zmm2
   1a94d:	vmovaps 0x140(%rsp),%zmm3
   1a955:	vmovaps 0x180(%rsp),%zmm4
   1a95d:	add    $0x400,%rax
   1a963:	vmovaps 0x1c0(%rsp),%zmm5
   1a96b:	vmovaps 0x200(%rsp),%zmm6
   1a973:	vmovups %zmm2,-0x400(%rax)
   1a97a:	vmovaps 0x280(%rsp),%zmm7
   1a982:	vmovaps 0x240(%rsp),%zmm2
   1a98a:	vmovups %zmm3,-0x3c0(%rax)
   1a991:	vmovups %zmm4,-0x380(%rax)
   1a998:	vmovaps 0x2c0(%rsp),%zmm3
   1a9a0:	vmovaps 0x300(%rsp),%zmm4
   1a9a8:	vmovups %zmm5,-0x340(%rax)
   1a9af:	vmovaps 0x340(%rsp),%zmm5
   1a9b7:	vmovups %zmm6,-0x300(%rax)
   1a9be:	vmovaps 0x380(%rsp),%zmm6
   1a9c6:	vmovups %zmm7,-0x2c0(%rax)
   1a9cd:	vmovaps 0x3c0(%rsp),%zmm7
   1a9d5:	vmovups %zmm2,-0x280(%rax)
   1a9dc:	vmovaps 0x400(%rsp),%zmm2
   1a9e4:	vmovups %zmm3,-0x240(%rax)
   1a9eb:	vmovaps 0x440(%rsp),%zmm3
   1a9f3:	vmovups %zmm4,-0x200(%rax)
   1a9fa:	vmovaps 0x480(%rsp),%zmm4
   1aa02:	vmovups %zmm5,-0x1c0(%rax)
   1aa09:	vmovaps 0x4c0(%rsp),%zmm5
   1aa11:	vmovups %zmm6,-0x180(%rax)
   1aa18:	vmovups %zmm7,-0x140(%rax)
   1aa1f:	vmovups %zmm2,-0x100(%rax)
   1aa26:	vmovups %zmm3,-0xc0(%rax)
   1aa2d:	vmovups %zmm4,-0x80(%rax)
   1aa34:	vmovups %zmm5,-0x40(%rax)
   1aa3b:	cmp    %rcx,%rsi
   1aa3e:	jne    1a3d8 <hf1_broken_g52+0x88>
   1aa44:	vzeroupper
   1aa47:	mov    0x538(%rsp),%rax
   1aa4f:	sub    %fs:0x28,%rax
   1aa58:	jne    1aa5c <hf1_broken_g52+0x70c>
   1aa5a:	leave
   1aa5b:	ret
   1aa5c:	call   4280 <__stack_chk_fail@plt>
   1aa61:	data16 cs nopw 0x0(%rax,%rax,1)
   1aa6c:	nopl   0x0(%rax)

000000000001e0d0 <hf1_tb8_nat>:
   1e0d0:	endbr64
   1e0d4:	push   %rbp
   1e0d5:	mov    %rdi,%rdx
   1e0d8:	mov    %rsp,%rbp
   1e0db:	and    $0xffffffffffffffc0,%rsp
   1e0df:	sub    $0x340,%rsp
   1e0e6:	vbroadcastss 0x3ff10(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   1e0f0:	mov    %fs:0x28,%rax
   1e0f9:	mov    %rax,0x338(%rsp)
   1e101:	xor    %eax,%eax
   1e103:	mov    %rsp,%rdi
   1e106:	vzeroupper
   1e109:	call   10120 <inl_consts.constprop.0>
   1e10e:	vmovaps (%rsp),%zmm19
   1e115:	vmovaps 0x40(%rsp),%zmm18
   1e11d:	vmovaps 0x80(%rsp),%zmm17
   1e125:	vmovaps 0xc0(%rsp),%zmm16
   1e12d:	test   %rsi,%rsi
   1e130:	je     1e497 <hf1_tb8_nat+0x3c7>
   1e136:	sub    $0x1,%rsi
   1e13a:	mov    %rdx,%rax
   1e13d:	lea    0x100(%rsp),%rdi
   1e145:	xor    %edx,%edx
   1e147:	shr    $0x7,%rsi
   1e14b:	nopl   0x0(%rax,%rax,1)
   1e150:	vpxord (%rax),%zmm19,%zmm1
   1e156:	vpermilps $0xb1,(%rax),%zmm0
   1e15d:	mov    %rdx,%rcx
   1e160:	vaddps %zmm1,%zmm0,%zmm0
   1e166:	vpxord %zmm0,%zmm18,%zmm1
   1e16c:	vpermilps $0x4e,%zmm0,%zmm0
   1e173:	vaddps %zmm1,%zmm0,%zmm0
   1e179:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e180:	vpxord %zmm0,%zmm17,%zmm0
   1e186:	vaddps %zmm0,%zmm1,%zmm0
   1e18c:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e193:	vpxord %zmm0,%zmm16,%zmm0
   1e199:	vaddps %zmm0,%zmm1,%zmm0
   1e19f:	vpxord 0x40(%rax),%zmm19,%zmm1
   1e1a6:	vmovaps %zmm0,0x100(%rsp)
   1e1ae:	vpermilps $0xb1,0x40(%rax),%zmm0
   1e1b6:	vaddps %zmm1,%zmm0,%zmm0
   1e1bc:	vpxord %zmm0,%zmm18,%zmm1
   1e1c2:	vpermilps $0x4e,%zmm0,%zmm0
   1e1c9:	vaddps %zmm1,%zmm0,%zmm0
   1e1cf:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e1d6:	vpxord %zmm0,%zmm17,%zmm0
   1e1dc:	vaddps %zmm0,%zmm1,%zmm0
   1e1e2:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e1e9:	vpxord %zmm0,%zmm16,%zmm0
   1e1ef:	vaddps %zmm0,%zmm1,%zmm0
   1e1f5:	vpxord 0x80(%rax),%zmm19,%zmm1
   1e1fc:	vmovaps %zmm0,0x140(%rsp)
   1e204:	vpermilps $0xb1,0x80(%rax),%zmm0
   1e20c:	vaddps %zmm1,%zmm0,%zmm0
   1e212:	vpxord %zmm0,%zmm18,%zmm1
   1e218:	vpermilps $0x4e,%zmm0,%zmm0
   1e21f:	vaddps %zmm1,%zmm0,%zmm0
   1e225:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e22c:	vpxord %zmm0,%zmm17,%zmm0
   1e232:	vaddps %zmm0,%zmm1,%zmm0
   1e238:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e23f:	vpxord %zmm0,%zmm16,%zmm0
   1e245:	vaddps %zmm0,%zmm1,%zmm0
   1e24b:	vpxord 0xc0(%rax),%zmm19,%zmm1
   1e252:	vmovaps %zmm0,0x180(%rsp)
   1e25a:	vpermilps $0xb1,0xc0(%rax),%zmm0
   1e262:	vaddps %zmm1,%zmm0,%zmm0
   1e268:	vpxord %zmm0,%zmm18,%zmm1
   1e26e:	vpermilps $0x4e,%zmm0,%zmm0
   1e275:	vaddps %zmm1,%zmm0,%zmm0
   1e27b:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e282:	vpxord %zmm0,%zmm17,%zmm0
   1e288:	vaddps %zmm0,%zmm1,%zmm0
   1e28e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e295:	vpxord %zmm0,%zmm16,%zmm0
   1e29b:	vaddps %zmm0,%zmm1,%zmm0
   1e2a1:	vpxord 0x100(%rax),%zmm19,%zmm1
   1e2a8:	vmovaps %zmm0,0x1c0(%rsp)
   1e2b0:	vpermilps $0xb1,0x100(%rax),%zmm0
   1e2b8:	vaddps %zmm1,%zmm0,%zmm0
   1e2be:	vpxord %zmm0,%zmm18,%zmm1
   1e2c4:	vpermilps $0x4e,%zmm0,%zmm0
   1e2cb:	vaddps %zmm1,%zmm0,%zmm0
   1e2d1:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e2d8:	vpxord %zmm0,%zmm17,%zmm0
   1e2de:	vaddps %zmm0,%zmm1,%zmm0
   1e2e4:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e2eb:	vpxord %zmm0,%zmm16,%zmm0
   1e2f1:	vaddps %zmm0,%zmm1,%zmm0
   1e2f7:	vpxord 0x140(%rax),%zmm19,%zmm1
   1e2fe:	vmovaps %zmm0,0x200(%rsp)
   1e306:	vpermilps $0xb1,0x140(%rax),%zmm0
   1e30e:	vaddps %zmm1,%zmm0,%zmm0
   1e314:	vpxord %zmm0,%zmm18,%zmm1
   1e31a:	vpermilps $0x4e,%zmm0,%zmm0
   1e321:	vaddps %zmm1,%zmm0,%zmm0
   1e327:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e32e:	vpxord %zmm0,%zmm17,%zmm0
   1e334:	vaddps %zmm0,%zmm1,%zmm0
   1e33a:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e341:	vpxord %zmm0,%zmm16,%zmm0
   1e347:	vaddps %zmm0,%zmm1,%zmm0
   1e34d:	vpxord 0x180(%rax),%zmm19,%zmm1
   1e354:	vmovaps %zmm0,0x240(%rsp)
   1e35c:	vpermilps $0xb1,0x180(%rax),%zmm0
   1e364:	vaddps %zmm1,%zmm0,%zmm0
   1e36a:	vpxord %zmm0,%zmm18,%zmm1
   1e370:	vpermilps $0x4e,%zmm0,%zmm0
   1e377:	vaddps %zmm1,%zmm0,%zmm0
   1e37d:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e384:	vpxord %zmm0,%zmm17,%zmm0
   1e38a:	vaddps %zmm0,%zmm1,%zmm0
   1e390:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e397:	vpxord %zmm0,%zmm16,%zmm0
   1e39d:	vaddps %zmm0,%zmm1,%zmm0
   1e3a3:	vpxord 0x1c0(%rax),%zmm19,%zmm1
   1e3aa:	vmovaps %zmm0,0x280(%rsp)
   1e3b2:	vpermilps $0xb1,0x1c0(%rax),%zmm0
   1e3ba:	vaddps %zmm1,%zmm0,%zmm0
   1e3c0:	vpxord %zmm0,%zmm18,%zmm1
   1e3c6:	vpermilps $0x4e,%zmm0,%zmm0
   1e3cd:	vaddps %zmm1,%zmm0,%zmm0
   1e3d3:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e3da:	vpxord %zmm0,%zmm17,%zmm0
   1e3e0:	vaddps %zmm0,%zmm1,%zmm0
   1e3e6:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e3ed:	vpxord %zmm0,%zmm16,%zmm0
   1e3f3:	vaddps %zmm0,%zmm1,%zmm0
   1e3f9:	vmovaps %zmm0,0x2c0(%rsp)
   1e401:	vzeroupper
   1e404:	call   13130 <tb8_nat.constprop.0>
   1e409:	add    $0x1,%rdx
   1e40d:	vmovaps 0x100(%rsp),%zmm2
   1e415:	vmovaps 0x140(%rsp),%zmm3
   1e41d:	vmovaps 0x180(%rsp),%zmm4
   1e425:	add    $0x200,%rax
   1e42b:	vmovups %zmm2,-0x200(%rax)
   1e432:	vmovaps 0x1c0(%rsp),%zmm5
   1e43a:	vmovaps 0x200(%rsp),%zmm6
   1e442:	vmovups %zmm3,-0x1c0(%rax)
   1e449:	vmovaps 0x240(%rsp),%zmm7
   1e451:	vmovaps 0x280(%rsp),%zmm2
   1e459:	vmovaps 0x2c0(%rsp),%zmm3
   1e461:	vmovups %zmm4,-0x180(%rax)
   1e468:	vmovups %zmm5,-0x140(%rax)
   1e46f:	vmovups %zmm6,-0x100(%rax)
   1e476:	vmovups %zmm7,-0xc0(%rax)
   1e47d:	vmovups %zmm2,-0x80(%rax)
   1e484:	vmovups %zmm3,-0x40(%rax)
   1e48b:	cmp    %rcx,%rsi
   1e48e:	jne    1e150 <hf1_tb8_nat+0x80>
   1e494:	vzeroupper
   1e497:	mov    0x338(%rsp),%rax
   1e49f:	sub    %fs:0x28,%rax
   1e4a8:	jne    1e4ac <hf1_tb8_nat+0x3dc>
   1e4aa:	leave
   1e4ab:	ret
   1e4ac:	call   4280 <__stack_chk_fail@plt>
   1e4b1:	data16 cs nopw 0x0(%rax,%rax,1)
   1e4bc:	nopl   0x0(%rax)

000000000001e4c0 <hf1_tb8_bal>:
   1e4c0:	endbr64
   1e4c4:	lea    0x8(%rsp),%r10
   1e4c9:	and    $0xffffffffffffffc0,%rsp
   1e4cd:	mov    %rdi,%rdx
   1e4d0:	push   -0x8(%r10)
   1e4d4:	push   %rbp
   1e4d5:	mov    %rsp,%rbp
   1e4d8:	push   %r10
   1e4da:	sub    $0x368,%rsp
   1e4e1:	vbroadcastss 0x3fb15(%rip),%zmm16        # 5e000 <_IO_stdin_used+0x1000>
   1e4eb:	mov    %fs:0x28,%rax
   1e4f4:	mov    %rax,-0x38(%rbp)
   1e4f8:	xor    %eax,%eax
   1e4fa:	lea    -0x370(%rbp),%rdi
   1e501:	call   10120 <inl_consts.constprop.0>
   1e506:	vmovaps -0x370(%rbp),%zmm15
   1e510:	vmovaps -0x330(%rbp),%zmm14
   1e51a:	vmovaps -0x2f0(%rbp),%zmm13
   1e524:	vmovaps -0x2b0(%rbp),%zmm12
   1e52e:	test   %rsi,%rsi
   1e531:	je     1e8b7 <hf1_tb8_bal+0x3f7>
   1e537:	sub    $0x1,%rsi
   1e53b:	mov    %rdx,%rax
   1e53e:	lea    -0x270(%rbp),%rdi
   1e545:	xor    %edx,%edx
   1e547:	shr    $0x7,%rsi
   1e54b:	nopl   0x0(%rax,%rax,1)
   1e550:	vpxord (%rax),%zmm15,%zmm1
   1e556:	vpermilps $0xb1,(%rax),%zmm0
   1e55d:	mov    %rdx,%rcx
   1e560:	add    $0x200,%rax
   1e566:	add    $0x1,%rdx
   1e56a:	vaddps %zmm1,%zmm0,%zmm0
   1e570:	vpxord %zmm0,%zmm14,%zmm1
   1e576:	vpermilps $0x4e,%zmm0,%zmm0
   1e57d:	vaddps %zmm1,%zmm0,%zmm0
   1e583:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e58a:	vpxord %zmm0,%zmm13,%zmm0
   1e590:	vaddps %zmm0,%zmm1,%zmm0
   1e596:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e59d:	vpxord %zmm0,%zmm12,%zmm0
   1e5a3:	vaddps %zmm0,%zmm1,%zmm0
   1e5a9:	vpxord -0x1c0(%rax),%zmm15,%zmm1
   1e5b0:	vmovaps %zmm0,-0x270(%rbp)
   1e5ba:	vpermilps $0xb1,-0x1c0(%rax),%zmm0
   1e5c2:	vaddps %zmm1,%zmm0,%zmm0
   1e5c8:	vpxord %zmm0,%zmm14,%zmm1
   1e5ce:	vpermilps $0x4e,%zmm0,%zmm0
   1e5d5:	vaddps %zmm1,%zmm0,%zmm0
   1e5db:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e5e2:	vpxord %zmm0,%zmm13,%zmm0
   1e5e8:	vaddps %zmm0,%zmm1,%zmm0
   1e5ee:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e5f5:	vpxord %zmm0,%zmm12,%zmm0
   1e5fb:	vaddps %zmm0,%zmm1,%zmm0
   1e601:	vpxord -0x180(%rax),%zmm15,%zmm1
   1e608:	vmovaps %zmm0,-0x230(%rbp)
   1e612:	vpermilps $0xb1,-0x180(%rax),%zmm0
   1e61a:	vaddps %zmm1,%zmm0,%zmm0
   1e620:	vpxord %zmm0,%zmm14,%zmm1
   1e626:	vpermilps $0x4e,%zmm0,%zmm0
   1e62d:	vaddps %zmm1,%zmm0,%zmm0
   1e633:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e63a:	vpxord %zmm0,%zmm13,%zmm0
   1e640:	vaddps %zmm0,%zmm1,%zmm0
   1e646:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e64d:	vpxord %zmm0,%zmm12,%zmm0
   1e653:	vaddps %zmm0,%zmm1,%zmm0
   1e659:	vpxord -0x140(%rax),%zmm15,%zmm1
   1e660:	vmovaps %zmm0,-0x1f0(%rbp)
   1e66a:	vpermilps $0xb1,-0x140(%rax),%zmm0
   1e672:	vaddps %zmm1,%zmm0,%zmm0
   1e678:	vpxord %zmm0,%zmm14,%zmm1
   1e67e:	vpermilps $0x4e,%zmm0,%zmm0
   1e685:	vaddps %zmm1,%zmm0,%zmm0
   1e68b:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e692:	vpxord %zmm0,%zmm13,%zmm0
   1e698:	vaddps %zmm0,%zmm1,%zmm0
   1e69e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e6a5:	vpxord %zmm0,%zmm12,%zmm0
   1e6ab:	vaddps %zmm0,%zmm1,%zmm0
   1e6b1:	vpxord -0x100(%rax),%zmm15,%zmm1
   1e6b8:	vmovaps %zmm0,-0x1b0(%rbp)
   1e6c2:	vpermilps $0xb1,-0x100(%rax),%zmm0
   1e6ca:	vaddps %zmm1,%zmm0,%zmm0
   1e6d0:	vpxord %zmm0,%zmm14,%zmm1
   1e6d6:	vpermilps $0x4e,%zmm0,%zmm0
   1e6dd:	vaddps %zmm1,%zmm0,%zmm0
   1e6e3:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e6ea:	vpxord %zmm0,%zmm13,%zmm0
   1e6f0:	vaddps %zmm0,%zmm1,%zmm0
   1e6f6:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e6fd:	vpxord %zmm0,%zmm12,%zmm0
   1e703:	vaddps %zmm0,%zmm1,%zmm0
   1e709:	vpxord -0xc0(%rax),%zmm15,%zmm1
   1e710:	vmovaps %zmm0,-0x170(%rbp)
   1e71a:	vpermilps $0xb1,-0xc0(%rax),%zmm0
   1e722:	vaddps %zmm1,%zmm0,%zmm0
   1e728:	vpxord %zmm0,%zmm14,%zmm1
   1e72e:	vpermilps $0x4e,%zmm0,%zmm0
   1e735:	vaddps %zmm1,%zmm0,%zmm0
   1e73b:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e742:	vpxord %zmm0,%zmm13,%zmm0
   1e748:	vaddps %zmm0,%zmm1,%zmm0
   1e74e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e755:	vpxord %zmm0,%zmm12,%zmm0
   1e75b:	vaddps %zmm0,%zmm1,%zmm0
   1e761:	vpxord -0x80(%rax),%zmm15,%zmm1
   1e768:	vmovaps %zmm0,-0x130(%rbp)
   1e772:	vpermilps $0xb1,-0x80(%rax),%zmm0
   1e77a:	vaddps %zmm1,%zmm0,%zmm0
   1e780:	vpxord %zmm0,%zmm14,%zmm1
   1e786:	vpermilps $0x4e,%zmm0,%zmm0
   1e78d:	vaddps %zmm1,%zmm0,%zmm0
   1e793:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e79a:	vpxord %zmm0,%zmm13,%zmm0
   1e7a0:	vaddps %zmm0,%zmm1,%zmm0
   1e7a6:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e7ad:	vpxord %zmm0,%zmm12,%zmm0
   1e7b3:	vaddps %zmm0,%zmm1,%zmm0
   1e7b9:	vpxord -0x40(%rax),%zmm15,%zmm1
   1e7c0:	vmovaps %zmm0,-0xf0(%rbp)
   1e7ca:	vpermilps $0xb1,-0x40(%rax),%zmm0
   1e7d2:	vaddps %zmm1,%zmm0,%zmm0
   1e7d8:	vpxord %zmm0,%zmm14,%zmm1
   1e7de:	vpermilps $0x4e,%zmm0,%zmm0
   1e7e5:	vaddps %zmm1,%zmm0,%zmm0
   1e7eb:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e7f2:	vpxord %zmm0,%zmm13,%zmm0
   1e7f8:	vaddps %zmm0,%zmm1,%zmm0
   1e7fe:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e805:	vpxord %zmm0,%zmm12,%zmm0
   1e80b:	vaddps %zmm0,%zmm1,%zmm0
   1e811:	vmovaps %zmm0,-0xb0(%rbp)
   1e81b:	vmovaps %zmm16,%zmm0
   1e821:	call   d9a0 <tb8_bal>
   1e826:	vmovaps -0x270(%rbp),%zmm2
   1e830:	vmovaps -0x230(%rbp),%zmm3
   1e83a:	vmovaps -0x1f0(%rbp),%zmm4
   1e844:	vmovaps -0x1b0(%rbp),%zmm5
   1e84e:	vmovups %zmm2,-0x200(%rax)
   1e855:	vmovaps -0x170(%rbp),%zmm6
   1e85f:	vmovaps -0x130(%rbp),%zmm7
   1e869:	vmovups %zmm3,-0x1c0(%rax)
   1e870:	vmovaps -0xf0(%rbp),%zmm2
   1e87a:	vmovaps -0xb0(%rbp),%zmm3
   1e884:	vmovups %zmm4,-0x180(%rax)
   1e88b:	vmovups %zmm5,-0x140(%rax)
   1e892:	vmovups %zmm6,-0x100(%rax)
   1e899:	vmovups %zmm7,-0xc0(%rax)
   1e8a0:	vmovups %zmm2,-0x80(%rax)
   1e8a7:	vmovups %zmm3,-0x40(%rax)
   1e8ae:	cmp    %rcx,%rsi
   1e8b1:	jne    1e550 <hf1_tb8_bal+0x90>
   1e8b7:	mov    -0x38(%rbp),%rax
   1e8bb:	sub    %fs:0x28,%rax
   1e8c4:	jne    1e8d3 <hf1_tb8_bal+0x413>
   1e8c6:	vzeroupper
   1e8c9:	mov    -0x8(%rbp),%r10
   1e8cd:	leave
   1e8ce:	lea    -0x8(%r10),%rsp
   1e8d2:	ret
   1e8d3:	vzeroupper
   1e8d6:	call   4280 <__stack_chk_fail@plt>
   1e8db:	nopl   0x0(%rax,%rax,1)

000000000001e8e0 <hf1_tb8_balS>:
   1e8e0:	endbr64
   1e8e4:	lea    0x8(%rsp),%r10
   1e8e9:	and    $0xffffffffffffffc0,%rsp
   1e8ed:	mov    %rdi,%rdx
   1e8f0:	push   -0x8(%r10)
   1e8f4:	push   %rbp
   1e8f5:	mov    %rsp,%rbp
   1e8f8:	push   %r10
   1e8fa:	sub    $0x368,%rsp
   1e901:	vbroadcastss 0x3f6f5(%rip),%zmm16        # 5e000 <_IO_stdin_used+0x1000>
   1e90b:	mov    %fs:0x28,%rax
   1e914:	mov    %rax,-0x38(%rbp)
   1e918:	xor    %eax,%eax
   1e91a:	lea    -0x370(%rbp),%rdi
   1e921:	call   10120 <inl_consts.constprop.0>
   1e926:	vmovaps -0x370(%rbp),%zmm15
   1e930:	vmovaps -0x330(%rbp),%zmm14
   1e93a:	vmovaps -0x2f0(%rbp),%zmm13
   1e944:	vmovaps -0x2b0(%rbp),%zmm12
   1e94e:	test   %rsi,%rsi
   1e951:	je     1ecd7 <hf1_tb8_balS+0x3f7>
   1e957:	sub    $0x1,%rsi
   1e95b:	mov    %rdx,%rax
   1e95e:	lea    -0x270(%rbp),%rdi
   1e965:	xor    %edx,%edx
   1e967:	shr    $0x7,%rsi
   1e96b:	nopl   0x0(%rax,%rax,1)
   1e970:	vpxord (%rax),%zmm15,%zmm1
   1e976:	vpermilps $0xb1,(%rax),%zmm0
   1e97d:	mov    %rdx,%rcx
   1e980:	add    $0x200,%rax
   1e986:	add    $0x1,%rdx
   1e98a:	vaddps %zmm1,%zmm0,%zmm0
   1e990:	vpxord %zmm0,%zmm14,%zmm1
   1e996:	vpermilps $0x4e,%zmm0,%zmm0
   1e99d:	vaddps %zmm1,%zmm0,%zmm0
   1e9a3:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1e9aa:	vpxord %zmm0,%zmm13,%zmm0
   1e9b0:	vaddps %zmm0,%zmm1,%zmm0
   1e9b6:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1e9bd:	vpxord %zmm0,%zmm12,%zmm0
   1e9c3:	vaddps %zmm0,%zmm1,%zmm0
   1e9c9:	vpxord -0x1c0(%rax),%zmm15,%zmm1
   1e9d0:	vmovaps %zmm0,-0x270(%rbp)
   1e9da:	vpermilps $0xb1,-0x1c0(%rax),%zmm0
   1e9e2:	vaddps %zmm1,%zmm0,%zmm0
   1e9e8:	vpxord %zmm0,%zmm14,%zmm1
   1e9ee:	vpermilps $0x4e,%zmm0,%zmm0
   1e9f5:	vaddps %zmm1,%zmm0,%zmm0
   1e9fb:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1ea02:	vpxord %zmm0,%zmm13,%zmm0
   1ea08:	vaddps %zmm0,%zmm1,%zmm0
   1ea0e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1ea15:	vpxord %zmm0,%zmm12,%zmm0
   1ea1b:	vaddps %zmm0,%zmm1,%zmm0
   1ea21:	vpxord -0x180(%rax),%zmm15,%zmm1
   1ea28:	vmovaps %zmm0,-0x230(%rbp)
   1ea32:	vpermilps $0xb1,-0x180(%rax),%zmm0
   1ea3a:	vaddps %zmm1,%zmm0,%zmm0
   1ea40:	vpxord %zmm0,%zmm14,%zmm1
   1ea46:	vpermilps $0x4e,%zmm0,%zmm0
   1ea4d:	vaddps %zmm1,%zmm0,%zmm0
   1ea53:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1ea5a:	vpxord %zmm0,%zmm13,%zmm0
   1ea60:	vaddps %zmm0,%zmm1,%zmm0
   1ea66:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1ea6d:	vpxord %zmm0,%zmm12,%zmm0
   1ea73:	vaddps %zmm0,%zmm1,%zmm0
   1ea79:	vpxord -0x140(%rax),%zmm15,%zmm1
   1ea80:	vmovaps %zmm0,-0x1f0(%rbp)
   1ea8a:	vpermilps $0xb1,-0x140(%rax),%zmm0
   1ea92:	vaddps %zmm1,%zmm0,%zmm0
   1ea98:	vpxord %zmm0,%zmm14,%zmm1
   1ea9e:	vpermilps $0x4e,%zmm0,%zmm0
   1eaa5:	vaddps %zmm1,%zmm0,%zmm0
   1eaab:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1eab2:	vpxord %zmm0,%zmm13,%zmm0
   1eab8:	vaddps %zmm0,%zmm1,%zmm0
   1eabe:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1eac5:	vpxord %zmm0,%zmm12,%zmm0
   1eacb:	vaddps %zmm0,%zmm1,%zmm0
   1ead1:	vpxord -0x100(%rax),%zmm15,%zmm1
   1ead8:	vmovaps %zmm0,-0x1b0(%rbp)
   1eae2:	vpermilps $0xb1,-0x100(%rax),%zmm0
   1eaea:	vaddps %zmm1,%zmm0,%zmm0
   1eaf0:	vpxord %zmm0,%zmm14,%zmm1
   1eaf6:	vpermilps $0x4e,%zmm0,%zmm0
   1eafd:	vaddps %zmm1,%zmm0,%zmm0
   1eb03:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1eb0a:	vpxord %zmm0,%zmm13,%zmm0
   1eb10:	vaddps %zmm0,%zmm1,%zmm0
   1eb16:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1eb1d:	vpxord %zmm0,%zmm12,%zmm0
   1eb23:	vaddps %zmm0,%zmm1,%zmm0
   1eb29:	vpxord -0xc0(%rax),%zmm15,%zmm1
   1eb30:	vmovaps %zmm0,-0x170(%rbp)
   1eb3a:	vpermilps $0xb1,-0xc0(%rax),%zmm0
   1eb42:	vaddps %zmm1,%zmm0,%zmm0
   1eb48:	vpxord %zmm0,%zmm14,%zmm1
   1eb4e:	vpermilps $0x4e,%zmm0,%zmm0
   1eb55:	vaddps %zmm1,%zmm0,%zmm0
   1eb5b:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1eb62:	vpxord %zmm0,%zmm13,%zmm0
   1eb68:	vaddps %zmm0,%zmm1,%zmm0
   1eb6e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1eb75:	vpxord %zmm0,%zmm12,%zmm0
   1eb7b:	vaddps %zmm0,%zmm1,%zmm0
   1eb81:	vpxord -0x80(%rax),%zmm15,%zmm1
   1eb88:	vmovaps %zmm0,-0x130(%rbp)
   1eb92:	vpermilps $0xb1,-0x80(%rax),%zmm0
   1eb9a:	vaddps %zmm1,%zmm0,%zmm0
   1eba0:	vpxord %zmm0,%zmm14,%zmm1
   1eba6:	vpermilps $0x4e,%zmm0,%zmm0
   1ebad:	vaddps %zmm1,%zmm0,%zmm0
   1ebb3:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1ebba:	vpxord %zmm0,%zmm13,%zmm0
   1ebc0:	vaddps %zmm0,%zmm1,%zmm0
   1ebc6:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1ebcd:	vpxord %zmm0,%zmm12,%zmm0
   1ebd3:	vaddps %zmm0,%zmm1,%zmm0
   1ebd9:	vpxord -0x40(%rax),%zmm15,%zmm1
   1ebe0:	vmovaps %zmm0,-0xf0(%rbp)
   1ebea:	vpermilps $0xb1,-0x40(%rax),%zmm0
   1ebf2:	vaddps %zmm1,%zmm0,%zmm0
   1ebf8:	vpxord %zmm0,%zmm14,%zmm1
   1ebfe:	vpermilps $0x4e,%zmm0,%zmm0
   1ec05:	vaddps %zmm1,%zmm0,%zmm0
   1ec0b:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1ec12:	vpxord %zmm0,%zmm13,%zmm0
   1ec18:	vaddps %zmm0,%zmm1,%zmm0
   1ec1e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1ec25:	vpxord %zmm0,%zmm12,%zmm0
   1ec2b:	vaddps %zmm0,%zmm1,%zmm0
   1ec31:	vmovaps %zmm0,-0xb0(%rbp)
   1ec3b:	vmovaps %zmm16,%zmm0
   1ec41:	call   dbe0 <tb8_balS>
   1ec46:	vmovaps -0x270(%rbp),%zmm2
   1ec50:	vmovaps -0x230(%rbp),%zmm3
   1ec5a:	vmovaps -0x1f0(%rbp),%zmm4
   1ec64:	vmovaps -0x1b0(%rbp),%zmm5
   1ec6e:	vmovups %zmm2,-0x200(%rax)
   1ec75:	vmovaps -0x170(%rbp),%zmm6
   1ec7f:	vmovaps -0x130(%rbp),%zmm7
   1ec89:	vmovups %zmm3,-0x1c0(%rax)
   1ec90:	vmovaps -0xf0(%rbp),%zmm2
   1ec9a:	vmovaps -0xb0(%rbp),%zmm3
   1eca4:	vmovups %zmm4,-0x180(%rax)
   1ecab:	vmovups %zmm5,-0x140(%rax)
   1ecb2:	vmovups %zmm6,-0x100(%rax)
   1ecb9:	vmovups %zmm7,-0xc0(%rax)
   1ecc0:	vmovups %zmm2,-0x80(%rax)
   1ecc7:	vmovups %zmm3,-0x40(%rax)
   1ecce:	cmp    %rcx,%rsi
   1ecd1:	jne    1e970 <hf1_tb8_balS+0x90>
   1ecd7:	mov    -0x38(%rbp),%rax
   1ecdb:	sub    %fs:0x28,%rax
   1ece4:	jne    1ecf3 <hf1_tb8_balS+0x413>
   1ece6:	vzeroupper
   1ece9:	mov    -0x8(%rbp),%r10
   1eced:	leave
   1ecee:	lea    -0x8(%r10),%rsp
   1ecf2:	ret
   1ecf3:	vzeroupper
   1ecf6:	call   4280 <__stack_chk_fail@plt>
   1ecfb:	nopl   0x0(%rax,%rax,1)

000000000001ed00 <hf1_g19_nat>:
   1ed00:	endbr64
   1ed04:	push   %rbp
   1ed05:	mov    %rdi,%rdx
   1ed08:	mov    %rsp,%rbp
   1ed0b:	and    $0xffffffffffffffc0,%rsp
   1ed0f:	sub    $0x140,%rsp
   1ed16:	vbroadcastss 0x3f2e0(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   1ed20:	mov    %fs:0x28,%rax
   1ed29:	mov    %rax,0x138(%rsp)
   1ed31:	xor    %eax,%eax
   1ed33:	mov    %rsp,%rdi
   1ed36:	vzeroupper
   1ed39:	call   10120 <inl_consts.constprop.0>
   1ed3e:	vmovaps (%rsp),%zmm7
   1ed45:	vmovaps 0x40(%rsp),%zmm6
   1ed4d:	vmovaps 0x80(%rsp),%zmm5
   1ed55:	vmovaps 0xc0(%rsp),%zmm4
   1ed5d:	test   %rsi,%rsi
   1ed60:	je     1f0b7 <hf1_g19_nat+0x3b7>
   1ed66:	vbroadcastss 0x3e298(%rip),%zmm1        # 5d008 <_IO_stdin_used+0x8>
   1ed70:	mov    %rdx,%rax
   1ed73:	lea    -0x4(,%rsi,4),%rdx
   1ed7b:	and    $0xfffffffffffffe00,%rdx
   1ed82:	lea    0x200(%rax,%rdx,1),%rdx
   1ed8a:	nopw   0x0(%rax,%rax,1)
   1ed90:	vpxord (%rax),%zmm7,%zmm2
   1ed96:	vpermilps $0xb1,(%rax),%zmm0
   1ed9d:	add    $0x200,%rax
   1eda3:	vpxord -0x140(%rax),%zmm7,%zmm11
   1edaa:	vpxord -0x100(%rax),%zmm7,%zmm12
   1edb1:	vaddps %zmm2,%zmm0,%zmm0
   1edb7:	vpxord -0xc0(%rax),%zmm7,%zmm13
   1edbe:	vpxord -0x80(%rax),%zmm7,%zmm14
   1edc5:	vpxord %zmm0,%zmm6,%zmm2
   1edcb:	vpermilps $0x4e,%zmm0,%zmm0
   1edd2:	vaddps %zmm2,%zmm0,%zmm0
   1edd8:	vpxord -0x1c0(%rax),%zmm7,%zmm2
   1eddf:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm10
   1ede6:	vpxord %zmm0,%zmm5,%zmm0
   1edec:	vaddps %zmm0,%zmm10,%zmm10
   1edf2:	vpermilps $0xb1,-0x1c0(%rax),%zmm0
   1edfa:	vaddps %zmm2,%zmm0,%zmm0
   1ee00:	vshuff32x4 $0x4e,%zmm10,%zmm10,%zmm3
   1ee07:	vpxord %zmm10,%zmm4,%zmm10
   1ee0d:	vaddps %zmm10,%zmm3,%zmm3
   1ee13:	vpxord %zmm0,%zmm6,%zmm2
   1ee19:	vpermilps $0x4e,%zmm0,%zmm0
   1ee20:	vaddps %zmm2,%zmm0,%zmm0
   1ee26:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm2
   1ee2d:	vpxord %zmm0,%zmm5,%zmm0
   1ee33:	vaddps %zmm0,%zmm2,%zmm0
   1ee39:	vpxord -0x180(%rax),%zmm7,%zmm2
   1ee40:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm8
   1ee47:	vpxord %zmm0,%zmm4,%zmm0
   1ee4d:	vaddps %zmm0,%zmm8,%zmm8
   1ee53:	vpermilps $0xb1,-0x180(%rax),%zmm0
   1ee5b:	vaddps %zmm2,%zmm0,%zmm0
   1ee61:	vpxord %zmm0,%zmm6,%zmm2
   1ee67:	vpermilps $0x4e,%zmm0,%zmm0
   1ee6e:	vaddps %zmm2,%zmm0,%zmm0
   1ee74:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm9
   1ee7b:	vpxord %zmm0,%zmm5,%zmm0
   1ee81:	vaddps %zmm0,%zmm9,%zmm9
   1ee87:	vpermilps $0xb1,-0x140(%rax),%zmm0
   1ee8f:	vaddps %zmm11,%zmm0,%zmm0
   1ee95:	vshuff32x4 $0x4e,%zmm9,%zmm9,%zmm2
   1ee9c:	vpxord %zmm9,%zmm4,%zmm9
   1eea2:	vaddps %zmm9,%zmm2,%zmm2
   1eea8:	vpxord %zmm0,%zmm6,%zmm11
   1eeae:	vpermilps $0x4e,%zmm0,%zmm0
   1eeb5:	vaddps %zmm11,%zmm0,%zmm0
   1eebb:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm11
   1eec2:	vpxord %zmm0,%zmm5,%zmm0
   1eec8:	vaddps %zmm0,%zmm11,%zmm0
   1eece:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm11
   1eed5:	vpxord %zmm0,%zmm4,%zmm0
   1eedb:	vaddps %zmm0,%zmm11,%zmm11
   1eee1:	vpermilps $0xb1,-0x100(%rax),%zmm0
   1eee9:	vaddps %zmm12,%zmm0,%zmm0
   1eeef:	vpxord %zmm0,%zmm6,%zmm12
   1eef5:	vpermilps $0x4e,%zmm0,%zmm0
   1eefc:	vaddps %zmm12,%zmm0,%zmm0
   1ef02:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm12
   1ef09:	vpxord %zmm0,%zmm5,%zmm0
   1ef0f:	vaddps %zmm0,%zmm12,%zmm0
   1ef15:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm12
   1ef1c:	vpxord %zmm0,%zmm4,%zmm0
   1ef22:	vaddps %zmm0,%zmm12,%zmm12
   1ef28:	vpermilps $0xb1,-0xc0(%rax),%zmm0
   1ef30:	vaddps %zmm13,%zmm0,%zmm0
   1ef36:	vsubps %zmm12,%zmm11,%zmm10
   1ef3c:	vpxord %zmm0,%zmm6,%zmm13
   1ef42:	vpermilps $0x4e,%zmm0,%zmm0
   1ef49:	vaddps %zmm13,%zmm0,%zmm0
   1ef4f:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm13
   1ef56:	vpxord %zmm0,%zmm5,%zmm0
   1ef5c:	vaddps %zmm0,%zmm13,%zmm0
   1ef62:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm13
   1ef69:	vpxord %zmm0,%zmm4,%zmm0
   1ef6f:	vaddps %zmm0,%zmm13,%zmm13
   1ef75:	vpermilps $0xb1,-0x80(%rax),%zmm0
   1ef7d:	vaddps %zmm14,%zmm0,%zmm0
   1ef83:	vsubps %zmm13,%zmm2,%zmm2
   1ef89:	vpxord %zmm0,%zmm6,%zmm14
   1ef8f:	vpermilps $0x4e,%zmm0,%zmm0
   1ef96:	vaddps %zmm14,%zmm0,%zmm0
   1ef9c:	vaddps %zmm10,%zmm2,%zmm17
   1efa2:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm14
   1efa9:	vpxord %zmm0,%zmm5,%zmm0
   1efaf:	vaddps %zmm0,%zmm14,%zmm0
   1efb5:	vpxord -0x40(%rax),%zmm7,%zmm14
   1efbc:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm15
   1efc3:	vpxord %zmm0,%zmm4,%zmm0
   1efc9:	vaddps %zmm0,%zmm15,%zmm15
   1efcf:	vpermilps $0xb1,-0x40(%rax),%zmm0
   1efd7:	vaddps %zmm14,%zmm0,%zmm0
   1efdd:	vpxord %zmm0,%zmm6,%zmm14
   1efe3:	vpermilps $0x4e,%zmm0,%zmm0
   1efea:	vaddps %zmm14,%zmm0,%zmm0
   1eff0:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm14
   1eff7:	vpxord %zmm0,%zmm5,%zmm0
   1effd:	vaddps %zmm0,%zmm14,%zmm14
   1f003:	vshuff32x4 $0x4e,%zmm14,%zmm14,%zmm0
   1f00a:	vpxord %zmm14,%zmm4,%zmm14
   1f010:	vaddps %zmm14,%zmm0,%zmm0
   1f016:	vaddps %zmm15,%zmm8,%zmm14
   1f01c:	vaddps %zmm0,%zmm3,%zmm3
   1f022:	vsubps %zmm14,%zmm3,%zmm16
   1f028:	vsubps %zmm17,%zmm16,%zmm9
   1f02e:	vfnmadd132ps %zmm1,%zmm9,%zmm0
   1f034:	vfnmadd132ps %zmm1,%zmm9,%zmm13
   1f03a:	vfmadd132ps %zmm1,%zmm0,%zmm15
   1f040:	vfnmadd132ps %zmm1,%zmm13,%zmm12
   1f046:	vfmadd132ps %zmm1,%zmm13,%zmm11
   1f04c:	vfmadd132ps %zmm1,%zmm0,%zmm8
   1f052:	vfmadd132ps %zmm1,%zmm15,%zmm10
   1f058:	vfmadd132ps %zmm1,%zmm15,%zmm2
   1f05e:	vfmsub132ps %zmm1,%zmm11,%zmm16
   1f064:	vfmadd132ps %zmm1,%zmm12,%zmm14
   1f06a:	vmovups %zmm8,-0x180(%rax)
   1f071:	vfmadd132ps %zmm1,%zmm8,%zmm17
   1f077:	vfmsub132ps %zmm1,%zmm12,%zmm3
   1f07d:	vmovups %zmm11,-0x140(%rax)
   1f084:	vmovups %zmm2,-0x1c0(%rax)
   1f08b:	vmovups %zmm16,-0xc0(%rax)
   1f092:	vmovups %zmm3,-0x200(%rax)
   1f099:	vmovups %zmm17,-0x100(%rax)
   1f0a0:	vmovups %zmm14,-0x80(%rax)
   1f0a7:	vmovups %zmm10,-0x40(%rax)
   1f0ae:	cmp    %rax,%rdx
   1f0b1:	jne    1ed90 <hf1_g19_nat+0x90>
   1f0b7:	mov    0x138(%rsp),%rax
   1f0bf:	sub    %fs:0x28,%rax
   1f0c8:	jne    1f0cf <hf1_g19_nat+0x3cf>
   1f0ca:	vzeroupper
   1f0cd:	leave
   1f0ce:	ret
   1f0cf:	vzeroupper
   1f0d2:	call   4280 <__stack_chk_fail@plt>
   1f0d7:	nopw   0x0(%rax,%rax,1)

000000000001f0e0 <hf1_h20_nat>:
   1f0e0:	endbr64
   1f0e4:	push   %rbp
   1f0e5:	mov    %rdi,%rdx
   1f0e8:	mov    %rsp,%rbp
   1f0eb:	and    $0xffffffffffffffc0,%rsp
   1f0ef:	sub    $0x140,%rsp
   1f0f6:	vbroadcastss 0x3ef00(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   1f100:	mov    %fs:0x28,%rax
   1f109:	mov    %rax,0x138(%rsp)
   1f111:	xor    %eax,%eax
   1f113:	mov    %rsp,%rdi
   1f116:	vzeroupper
   1f119:	call   10120 <inl_consts.constprop.0>
   1f11e:	vmovaps (%rsp),%zmm6
   1f125:	vmovaps 0x40(%rsp),%zmm5
   1f12d:	vmovaps 0x80(%rsp),%zmm4
   1f135:	vmovaps 0xc0(%rsp),%zmm3
   1f13d:	test   %rsi,%rsi
   1f140:	je     1f497 <hf1_h20_nat+0x3b7>
   1f146:	vbroadcastss 0x3deb4(%rip),%zmm10        # 5d004 <_IO_stdin_used+0x4>
   1f150:	mov    %rdx,%rax
   1f153:	lea    -0x4(,%rsi,4),%rdx
   1f15b:	and    $0xfffffffffffffe00,%rdx
   1f162:	lea    0x200(%rax,%rdx,1),%rdx
   1f16a:	nopw   0x0(%rax,%rax,1)
   1f170:	vpxord (%rax),%zmm6,%zmm1
   1f176:	vpermilps $0xb1,(%rax),%zmm0
   1f17d:	add    $0x200,%rax
   1f183:	vpxord -0x140(%rax),%zmm6,%zmm11
   1f18a:	vpxord -0x100(%rax),%zmm6,%zmm12
   1f191:	vaddps %zmm1,%zmm0,%zmm0
   1f197:	vpxord -0xc0(%rax),%zmm6,%zmm13
   1f19e:	vpxord %zmm0,%zmm5,%zmm1
   1f1a4:	vpermilps $0x4e,%zmm0,%zmm0
   1f1ab:	vaddps %zmm1,%zmm0,%zmm0
   1f1b1:	vpxord -0x1c0(%rax),%zmm6,%zmm1
   1f1b8:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm8
   1f1bf:	vpxord %zmm0,%zmm4,%zmm0
   1f1c5:	vaddps %zmm0,%zmm8,%zmm8
   1f1cb:	vpermilps $0xb1,-0x1c0(%rax),%zmm0
   1f1d3:	vaddps %zmm1,%zmm0,%zmm0
   1f1d9:	vshuff32x4 $0x4e,%zmm8,%zmm8,%zmm2
   1f1e0:	vpxord %zmm8,%zmm3,%zmm8
   1f1e6:	vaddps %zmm8,%zmm2,%zmm2
   1f1ec:	vpxord %zmm0,%zmm5,%zmm1
   1f1f2:	vpermilps $0x4e,%zmm0,%zmm0
   1f1f9:	vaddps %zmm1,%zmm0,%zmm0
   1f1ff:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1f206:	vpxord %zmm0,%zmm4,%zmm0
   1f20c:	vaddps %zmm0,%zmm1,%zmm0
   1f212:	vpxord -0x180(%rax),%zmm6,%zmm1
   1f219:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm9
   1f220:	vpxord %zmm0,%zmm3,%zmm0
   1f226:	vaddps %zmm0,%zmm9,%zmm9
   1f22c:	vpermilps $0xb1,-0x180(%rax),%zmm0
   1f234:	vaddps %zmm1,%zmm0,%zmm0
   1f23a:	vpxord %zmm0,%zmm5,%zmm1
   1f240:	vpermilps $0x4e,%zmm0,%zmm0
   1f247:	vaddps %zmm1,%zmm0,%zmm0
   1f24d:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm7
   1f254:	vpxord %zmm0,%zmm4,%zmm0
   1f25a:	vaddps %zmm0,%zmm7,%zmm7
   1f260:	vpermilps $0xb1,-0x140(%rax),%zmm0
   1f268:	vaddps %zmm11,%zmm0,%zmm0
   1f26e:	vshuff32x4 $0x4e,%zmm7,%zmm7,%zmm1
   1f275:	vpxord %zmm7,%zmm3,%zmm7
   1f27b:	vaddps %zmm7,%zmm1,%zmm1
   1f281:	vpxord %zmm0,%zmm5,%zmm11
   1f287:	vpermilps $0x4e,%zmm0,%zmm0
   1f28e:	vaddps %zmm11,%zmm0,%zmm0
   1f294:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm11
   1f29b:	vpxord %zmm0,%zmm4,%zmm0
   1f2a1:	vaddps %zmm0,%zmm11,%zmm0
   1f2a7:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm11
   1f2ae:	vpxord %zmm0,%zmm3,%zmm0
   1f2b4:	vaddps %zmm0,%zmm11,%zmm11
   1f2ba:	vpermilps $0xb1,-0x100(%rax),%zmm0
   1f2c2:	vaddps %zmm12,%zmm0,%zmm0
   1f2c8:	vpxord %zmm0,%zmm5,%zmm12
   1f2ce:	vpermilps $0x4e,%zmm0,%zmm0
   1f2d5:	vaddps %zmm12,%zmm0,%zmm0
   1f2db:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm12
   1f2e2:	vpxord %zmm0,%zmm4,%zmm0
   1f2e8:	vaddps %zmm0,%zmm12,%zmm0
   1f2ee:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm12
   1f2f5:	vpxord %zmm0,%zmm3,%zmm0
   1f2fb:	vaddps %zmm0,%zmm12,%zmm12
   1f301:	vpermilps $0xb1,-0xc0(%rax),%zmm0
   1f309:	vaddps %zmm13,%zmm0,%zmm0
   1f30f:	vpxord %zmm0,%zmm5,%zmm13
   1f315:	vpermilps $0x4e,%zmm0,%zmm0
   1f31c:	vaddps %zmm13,%zmm0,%zmm0
   1f322:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm13
   1f329:	vpxord %zmm0,%zmm4,%zmm0
   1f32f:	vaddps %zmm0,%zmm13,%zmm0
   1f335:	vpxord -0x80(%rax),%zmm6,%zmm13
   1f33c:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm14
   1f343:	vpxord %zmm0,%zmm3,%zmm0
   1f349:	vaddps %zmm0,%zmm14,%zmm14
   1f34f:	vpermilps $0xb1,-0x80(%rax),%zmm0
   1f357:	vaddps %zmm13,%zmm0,%zmm0
   1f35d:	vsubps %zmm14,%zmm1,%zmm1
   1f363:	vpxord %zmm0,%zmm5,%zmm13
   1f369:	vpermilps $0x4e,%zmm0,%zmm0
   1f370:	vaddps %zmm13,%zmm0,%zmm0
   1f376:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm13
   1f37d:	vpxord %zmm0,%zmm4,%zmm0
   1f383:	vaddps %zmm0,%zmm13,%zmm0
   1f389:	vpxord -0x40(%rax),%zmm6,%zmm13
   1f390:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm15
   1f397:	vpxord %zmm0,%zmm3,%zmm0
   1f39d:	vaddps %zmm0,%zmm15,%zmm15
   1f3a3:	vpermilps $0xb1,-0x40(%rax),%zmm0
   1f3ab:	vaddps %zmm13,%zmm0,%zmm0
   1f3b1:	vaddps %zmm15,%zmm9,%zmm16
   1f3b7:	vpxord %zmm0,%zmm5,%zmm13
   1f3bd:	vpermilps $0x4e,%zmm0,%zmm0
   1f3c4:	vaddps %zmm13,%zmm0,%zmm0
   1f3ca:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm13
   1f3d1:	vpxord %zmm0,%zmm4,%zmm0
   1f3d7:	vaddps %zmm0,%zmm13,%zmm13
   1f3dd:	vshuff32x4 $0x4e,%zmm13,%zmm13,%zmm0
   1f3e4:	vpxord %zmm13,%zmm3,%zmm13
   1f3ea:	vaddps %zmm13,%zmm0,%zmm0
   1f3f0:	vsubps %zmm12,%zmm11,%zmm13
   1f3f6:	vaddps %zmm0,%zmm2,%zmm2
   1f3fc:	vaddps %zmm13,%zmm1,%zmm18
   1f402:	vsubps %zmm16,%zmm2,%zmm17
   1f408:	vsubps %zmm18,%zmm17,%zmm7
   1f40e:	vfmsub231ps %zmm10,%zmm7,%zmm0
   1f414:	vfmsub132ps %zmm10,%zmm14,%zmm7
   1f41a:	vaddps %zmm15,%zmm0,%zmm8
   1f420:	vsubps %zmm12,%zmm7,%zmm12
   1f426:	vaddps %zmm9,%zmm0,%zmm0
   1f42c:	vaddps %zmm11,%zmm7,%zmm7
   1f432:	vsubps %zmm12,%zmm2,%zmm2
   1f438:	vaddps %zmm8,%zmm1,%zmm1
   1f43e:	vaddps %zmm0,%zmm18,%zmm18
   1f444:	vsubps %zmm7,%zmm17,%zmm17
   1f44a:	vmovups %zmm0,-0x180(%rax)
   1f451:	vaddps %zmm12,%zmm16,%zmm16
   1f457:	vaddps %zmm8,%zmm13,%zmm13
   1f45d:	vmovups %zmm7,-0x140(%rax)
   1f464:	vmovups %zmm2,-0x200(%rax)
   1f46b:	vmovups %zmm1,-0x1c0(%rax)
   1f472:	vmovups %zmm18,-0x100(%rax)
   1f479:	vmovups %zmm17,-0xc0(%rax)
   1f480:	vmovups %zmm16,-0x80(%rax)
   1f487:	vmovups %zmm13,-0x40(%rax)
   1f48e:	cmp    %rax,%rdx
   1f491:	jne    1f170 <hf1_h20_nat+0x90>
   1f497:	mov    0x138(%rsp),%rax
   1f49f:	sub    %fs:0x28,%rax
   1f4a8:	jne    1f4af <hf1_h20_nat+0x3cf>
   1f4aa:	vzeroupper
   1f4ad:	leave
   1f4ae:	ret
   1f4af:	vzeroupper
   1f4b2:	call   4280 <__stack_chk_fail@plt>
   1f4b7:	nopw   0x0(%rax,%rax,1)

000000000001f4c0 <hf1_broken_g20>:
   1f4c0:	endbr64
   1f4c4:	push   %rbp
   1f4c5:	mov    %rdi,%rdx
   1f4c8:	mov    %rsp,%rbp
   1f4cb:	and    $0xffffffffffffffc0,%rsp
   1f4cf:	sub    $0x340,%rsp
   1f4d6:	vbroadcastss 0x3eb20(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   1f4e0:	mov    %fs:0x28,%rax
   1f4e9:	mov    %rax,0x338(%rsp)
   1f4f1:	xor    %eax,%eax
   1f4f3:	mov    %rsp,%rdi
   1f4f6:	vzeroupper
   1f4f9:	call   10120 <inl_consts.constprop.0>
   1f4fe:	vmovaps (%rsp),%zmm19
   1f505:	vmovaps 0x40(%rsp),%zmm18
   1f50d:	vmovaps 0x80(%rsp),%zmm17
   1f515:	vmovaps 0xc0(%rsp),%zmm16
   1f51d:	test   %rsi,%rsi
   1f520:	je     1f887 <hf1_broken_g20+0x3c7>
   1f526:	sub    $0x1,%rsi
   1f52a:	mov    %rdx,%rax
   1f52d:	lea    0x100(%rsp),%rdi
   1f535:	xor    %edx,%edx
   1f537:	shr    $0x7,%rsi
   1f53b:	nopl   0x0(%rax,%rax,1)
   1f540:	vpxord (%rax),%zmm19,%zmm1
   1f546:	vpermilps $0xb1,(%rax),%zmm0
   1f54d:	mov    %rdx,%rcx
   1f550:	vaddps %zmm1,%zmm0,%zmm0
   1f556:	vpxord %zmm0,%zmm18,%zmm1
   1f55c:	vpermilps $0x4e,%zmm0,%zmm0
   1f563:	vaddps %zmm1,%zmm0,%zmm0
   1f569:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1f570:	vpxord %zmm0,%zmm17,%zmm0
   1f576:	vaddps %zmm0,%zmm1,%zmm0
   1f57c:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1f583:	vpxord %zmm0,%zmm16,%zmm0
   1f589:	vaddps %zmm0,%zmm1,%zmm0
   1f58f:	vpxord 0x40(%rax),%zmm19,%zmm1
   1f596:	vmovaps %zmm0,0x100(%rsp)
   1f59e:	vpermilps $0xb1,0x40(%rax),%zmm0
   1f5a6:	vaddps %zmm1,%zmm0,%zmm0
   1f5ac:	vpxord %zmm0,%zmm18,%zmm1
   1f5b2:	vpermilps $0x4e,%zmm0,%zmm0
   1f5b9:	vaddps %zmm1,%zmm0,%zmm0
   1f5bf:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1f5c6:	vpxord %zmm0,%zmm17,%zmm0
   1f5cc:	vaddps %zmm0,%zmm1,%zmm0
   1f5d2:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1f5d9:	vpxord %zmm0,%zmm16,%zmm0
   1f5df:	vaddps %zmm0,%zmm1,%zmm0
   1f5e5:	vpxord 0x80(%rax),%zmm19,%zmm1
   1f5ec:	vmovaps %zmm0,0x140(%rsp)
   1f5f4:	vpermilps $0xb1,0x80(%rax),%zmm0
   1f5fc:	vaddps %zmm1,%zmm0,%zmm0
   1f602:	vpxord %zmm0,%zmm18,%zmm1
   1f608:	vpermilps $0x4e,%zmm0,%zmm0
   1f60f:	vaddps %zmm1,%zmm0,%zmm0
   1f615:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1f61c:	vpxord %zmm0,%zmm17,%zmm0
   1f622:	vaddps %zmm0,%zmm1,%zmm0
   1f628:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1f62f:	vpxord %zmm0,%zmm16,%zmm0
   1f635:	vaddps %zmm0,%zmm1,%zmm0
   1f63b:	vpxord 0xc0(%rax),%zmm19,%zmm1
   1f642:	vmovaps %zmm0,0x180(%rsp)
   1f64a:	vpermilps $0xb1,0xc0(%rax),%zmm0
   1f652:	vaddps %zmm1,%zmm0,%zmm0
   1f658:	vpxord %zmm0,%zmm18,%zmm1
   1f65e:	vpermilps $0x4e,%zmm0,%zmm0
   1f665:	vaddps %zmm1,%zmm0,%zmm0
   1f66b:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1f672:	vpxord %zmm0,%zmm17,%zmm0
   1f678:	vaddps %zmm0,%zmm1,%zmm0
   1f67e:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1f685:	vpxord %zmm0,%zmm16,%zmm0
   1f68b:	vaddps %zmm0,%zmm1,%zmm0
   1f691:	vpxord 0x100(%rax),%zmm19,%zmm1
   1f698:	vmovaps %zmm0,0x1c0(%rsp)
   1f6a0:	vpermilps $0xb1,0x100(%rax),%zmm0
   1f6a8:	vaddps %zmm1,%zmm0,%zmm0
   1f6ae:	vpxord %zmm0,%zmm18,%zmm1
   1f6b4:	vpermilps $0x4e,%zmm0,%zmm0
   1f6bb:	vaddps %zmm1,%zmm0,%zmm0
   1f6c1:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1f6c8:	vpxord %zmm0,%zmm17,%zmm0
   1f6ce:	vaddps %zmm0,%zmm1,%zmm0
   1f6d4:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1f6db:	vpxord %zmm0,%zmm16,%zmm0
   1f6e1:	vaddps %zmm0,%zmm1,%zmm0
   1f6e7:	vpxord 0x140(%rax),%zmm19,%zmm1
   1f6ee:	vmovaps %zmm0,0x200(%rsp)
   1f6f6:	vpermilps $0xb1,0x140(%rax),%zmm0
   1f6fe:	vaddps %zmm1,%zmm0,%zmm0
   1f704:	vpxord %zmm0,%zmm18,%zmm1
   1f70a:	vpermilps $0x4e,%zmm0,%zmm0
   1f711:	vaddps %zmm1,%zmm0,%zmm0
   1f717:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1f71e:	vpxord %zmm0,%zmm17,%zmm0
   1f724:	vaddps %zmm0,%zmm1,%zmm0
   1f72a:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1f731:	vpxord %zmm0,%zmm16,%zmm0
   1f737:	vaddps %zmm0,%zmm1,%zmm0
   1f73d:	vpxord 0x180(%rax),%zmm19,%zmm1
   1f744:	vmovaps %zmm0,0x240(%rsp)
   1f74c:	vpermilps $0xb1,0x180(%rax),%zmm0
   1f754:	vaddps %zmm1,%zmm0,%zmm0
   1f75a:	vpxord %zmm0,%zmm18,%zmm1
   1f760:	vpermilps $0x4e,%zmm0,%zmm0
   1f767:	vaddps %zmm1,%zmm0,%zmm0
   1f76d:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1f774:	vpxord %zmm0,%zmm17,%zmm0
   1f77a:	vaddps %zmm0,%zmm1,%zmm0
   1f780:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1f787:	vpxord %zmm0,%zmm16,%zmm0
   1f78d:	vaddps %zmm0,%zmm1,%zmm0
   1f793:	vpxord 0x1c0(%rax),%zmm19,%zmm1
   1f79a:	vmovaps %zmm0,0x280(%rsp)
   1f7a2:	vpermilps $0xb1,0x1c0(%rax),%zmm0
   1f7aa:	vaddps %zmm1,%zmm0,%zmm0
   1f7b0:	vpxord %zmm0,%zmm18,%zmm1
   1f7b6:	vpermilps $0x4e,%zmm0,%zmm0
   1f7bd:	vaddps %zmm1,%zmm0,%zmm0
   1f7c3:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   1f7ca:	vpxord %zmm0,%zmm17,%zmm0
   1f7d0:	vaddps %zmm0,%zmm1,%zmm0
   1f7d6:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   1f7dd:	vpxord %zmm0,%zmm16,%zmm0
   1f7e3:	vaddps %zmm0,%zmm1,%zmm0
   1f7e9:	vmovaps %zmm0,0x2c0(%rsp)
   1f7f1:	vzeroupper
   1f7f4:	call   13010 <g20_nat.constprop.0>
   1f7f9:	add    $0x1,%rdx
   1f7fd:	vmovaps 0x100(%rsp),%zmm2
   1f805:	vmovaps 0x140(%rsp),%zmm3
   1f80d:	vmovaps 0x180(%rsp),%zmm4
   1f815:	add    $0x200,%rax
   1f81b:	vmovups %zmm2,-0x200(%rax)
   1f822:	vmovaps 0x1c0(%rsp),%zmm5
   1f82a:	vmovaps 0x200(%rsp),%zmm6
   1f832:	vmovups %zmm3,-0x1c0(%rax)
   1f839:	vmovaps 0x280(%rsp),%zmm7
   1f841:	vmovaps 0x240(%rsp),%zmm2
   1f849:	vmovaps 0x2c0(%rsp),%zmm3
   1f851:	vmovups %zmm4,-0x180(%rax)
   1f858:	vmovups %zmm5,-0x140(%rax)
   1f85f:	vmovups %zmm6,-0x100(%rax)
   1f866:	vmovups %zmm7,-0xc0(%rax)
   1f86d:	vmovups %zmm2,-0x80(%rax)
   1f874:	vmovups %zmm3,-0x40(%rax)
   1f87b:	cmp    %rcx,%rsi
   1f87e:	jne    1f540 <hf1_broken_g20+0x80>
   1f884:	vzeroupper
   1f887:	mov    0x338(%rsp),%rax
   1f88f:	sub    %fs:0x28,%rax
   1f898:	jne    1f89c <hf1_broken_g20+0x3dc>
   1f89a:	leave
   1f89b:	ret
   1f89c:	call   4280 <__stack_chk_fail@plt>
   1f8a1:	data16 cs nopw 0x0(%rax,%rax,1)
   1f8ac:	nopl   0x0(%rax)

0000000000021720 <hs_g19_nat>:
   21720:	endbr64
   21724:	vbroadcastss 0x3c8d2(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   2172e:	test   %rsi,%rsi
   21731:	je     218c0 <hs_g19_nat+0x1a0>
   21737:	push   %rbp
   21738:	mov    %rsp,%rbp
   2173b:	push   %r15
   2173d:	lea    0x0(,%rdx,8),%r15
   21745:	push   %r14
   21747:	push   %r13
   21749:	push   %r12
   2174b:	push   %rbx
   2174c:	test   %rdx,%rdx
   2174f:	je     218b2 <hs_g19_nat+0x192>
   21755:	mov    %rdx,%r9
   21758:	mov    %rdi,%rbx
   2175b:	lea    (%rdx,%rdx,2),%rcx
   2175f:	mov    %rdx,%r10
   21762:	lea    -0x1(%rdx),%r13
   21766:	neg    %r9
   21769:	lea    (%rdx,%rdx,4),%r8
   2176d:	mov    %rsi,%r12
   21770:	and    $0xfffffffffffffff0,%r13
   21774:	shl    $0x2,%r9
   21778:	mov    %rdx,%rdi
   2177b:	lea    0x40(%rbx),%r14
   2177f:	lea    0x0(,%rcx,4),%r11
   21787:	shl    $0x4,%r10
   2178b:	shl    $0x2,%r8
   2178f:	vbroadcastss 0x3b86f(%rip),%zmm0        # 5d008 <_IO_stdin_used+0x8>
   21799:	shl    $0x3,%rcx
   2179d:	nopl   (%rax)
   217a0:	lea    (%rdi,%r13,1),%rsi
   217a4:	lea    (%rbx,%rdi,4),%rax
   217a8:	lea    (%r14,%rsi,4),%rsi
   217ac:	nopl   0x0(%rax)
   217b0:	vmovups (%rax,%r9,1),%zmm1
   217b7:	vmovups (%rax),%zmm6
   217bd:	vmovaps %zmm0,%zmm3
   217c3:	vaddps (%rax,%rcx,1),%zmm1,%zmm10
   217ca:	vaddps (%rax,%r8,1),%zmm6,%zmm7
   217d1:	vmovups (%rax,%rdx,4),%zmm4
   217d8:	vmovups (%rax,%rdx,8),%zmm5
   217df:	vsubps (%rax,%r10,1),%zmm4,%zmm1
   217e6:	vsubps (%rax,%r11,1),%zmm5,%zmm6
   217ed:	vmovaps %zmm0,%zmm4
   217f3:	vsubps %zmm7,%zmm10,%zmm8
   217f9:	vmovaps %zmm0,%zmm5
   217ff:	vaddps %zmm6,%zmm1,%zmm9
   21805:	vsubps %zmm9,%zmm8,%zmm2
   2180b:	vfnmadd132ps (%rax,%rcx,1),%zmm2,%zmm3
   21812:	vfnmadd231ps (%rax,%r10,1),%zmm0,%zmm2
   21819:	vfmadd132ps (%rax,%r8,1),%zmm3,%zmm5
   21820:	vfnmadd132ps (%rax,%r11,1),%zmm2,%zmm4
   21827:	vfmadd231ps (%rax),%zmm0,%zmm3
   2182d:	vfmadd231ps (%rax,%rdx,8),%zmm0,%zmm2
   21834:	vfmadd132ps %zmm0,%zmm5,%zmm6
   2183a:	vfmadd132ps %zmm0,%zmm5,%zmm1
   21840:	vfmadd132ps %zmm0,%zmm4,%zmm7
   21846:	vfmadd132ps %zmm0,%zmm3,%zmm9
   2184c:	vfmsub132ps %zmm0,%zmm2,%zmm8
   21852:	vfmsub132ps %zmm0,%zmm4,%zmm10
   21858:	vmovups %zmm10,(%rax,%r9,1)
   2185f:	vmovups %zmm1,(%rax)
   21865:	vmovups %zmm3,(%rax,%rdx,4)
   2186c:	vmovups %zmm2,(%rax,%rdx,8)
   21873:	add    $0x40,%rax
   21877:	vmovups %zmm9,-0x40(%rax,%r11,1)
   2187f:	vmovups %zmm8,-0x40(%rax,%r10,1)
   21887:	vmovups %zmm7,-0x40(%rax,%r8,1)
   2188f:	vmovups %zmm6,-0x40(%rax,%rcx,1)
   21897:	cmp    %rax,%rsi
   2189a:	jne    217b0 <hs_g19_nat+0x90>
   218a0:	add    %r15,%rdi
   218a3:	mov    %rdi,%rax
   218a6:	sub    %rdx,%rax
   218a9:	cmp    %r12,%rax
   218ac:	jb     217a0 <hs_g19_nat+0x80>
   218b2:	vzeroupper
   218b5:	pop    %rbx
   218b6:	pop    %r12
   218b8:	pop    %r13
   218ba:	pop    %r14
   218bc:	pop    %r15
   218be:	pop    %rbp
   218bf:	ret
   218c0:	vzeroupper
   218c3:	ret
   218c4:	data16 cs nopw 0x0(%rax,%rax,1)
   218cf:	nop

0000000000023440 <hs_h20_nat>:
   23440:	endbr64
   23444:	vbroadcastss 0x3abb2(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   2344e:	test   %rsi,%rsi
   23451:	je     235d4 <hs_h20_nat+0x194>
   23457:	push   %rbp
   23458:	mov    %rsp,%rbp
   2345b:	push   %r15
   2345d:	lea    0x0(,%rdx,8),%r15
   23465:	push   %r14
   23467:	push   %r13
   23469:	push   %r12
   2346b:	push   %rbx
   2346c:	test   %rdx,%rdx
   2346f:	je     235c6 <hs_h20_nat+0x186>
   23475:	mov    %rdx,%r9
   23478:	mov    %rdi,%rbx
   2347b:	lea    (%rdx,%rdx,2),%rcx
   2347f:	mov    %rdx,%r10
   23482:	lea    -0x1(%rdx),%r13
   23486:	neg    %r9
   23489:	lea    (%rdx,%rdx,4),%r8
   2348d:	mov    %rsi,%r12
   23490:	and    $0xfffffffffffffff0,%r13
   23494:	shl    $0x2,%r9
   23498:	mov    %rdx,%rdi
   2349b:	lea    0x40(%rbx),%r14
   2349f:	lea    0x0(,%rcx,4),%r11
   234a7:	shl    $0x4,%r10
   234ab:	shl    $0x2,%r8
   234af:	vbroadcastss 0x39b4b(%rip),%zmm10        # 5d004 <_IO_stdin_used+0x4>
   234b9:	shl    $0x3,%rcx
   234bd:	nopl   (%rax)
   234c0:	lea    (%rdi,%r13,1),%rsi
   234c4:	lea    (%rbx,%rdi,4),%rax
   234c8:	lea    (%r14,%rsi,4),%rsi
   234cc:	nopl   0x0(%rax)
   234d0:	vmovups (%rax,%r9,1),%zmm3
   234d7:	vmovups (%rax),%zmm4
   234dd:	vaddps (%rax,%rcx,1),%zmm3,%zmm9
   234e4:	vaddps (%rax,%r8,1),%zmm4,%zmm6
   234eb:	vmovups (%rax,%rdx,8),%zmm3
   234f2:	vmovups (%rax,%rdx,4),%zmm2
   234f9:	vsubps (%rax,%r11,1),%zmm3,%zmm5
   23500:	vsubps (%rax,%r10,1),%zmm2,%zmm2
   23507:	vsubps %zmm6,%zmm9,%zmm7
   2350d:	vaddps %zmm5,%zmm2,%zmm8
   23513:	vsubps %zmm8,%zmm7,%zmm0
   23519:	vmovaps %zmm0,%zmm1
   2351f:	vfmsub213ps (%rax,%r10,1),%zmm10,%zmm0
   23526:	vfmsub213ps (%rax,%rcx,1),%zmm10,%zmm1
   2352d:	vsubps (%rax,%r11,1),%zmm0,%zmm4
   23534:	vaddps (%rax,%r8,1),%zmm1,%zmm3
   2353b:	vaddps (%rax,%rdx,8),%zmm0,%zmm0
   23542:	vaddps (%rax),%zmm1,%zmm1
   23548:	vsubps %zmm4,%zmm9,%zmm9
   2354e:	vaddps %zmm4,%zmm6,%zmm6
   23554:	vaddps %zmm3,%zmm2,%zmm2
   2355a:	vsubps %zmm0,%zmm7,%zmm7
   23560:	vaddps %zmm1,%zmm8,%zmm8
   23566:	vaddps %zmm3,%zmm5,%zmm5
   2356c:	vmovups %zmm9,(%rax,%r9,1)
   23573:	vmovups %zmm2,(%rax)
   23579:	vmovups %zmm1,(%rax,%rdx,4)
   23580:	vmovups %zmm0,(%rax,%rdx,8)
   23587:	add    $0x40,%rax
   2358b:	vmovups %zmm8,-0x40(%rax,%r11,1)
   23593:	vmovups %zmm7,-0x40(%rax,%r10,1)
   2359b:	vmovups %zmm6,-0x40(%rax,%r8,1)
   235a3:	vmovups %zmm5,-0x40(%rax,%rcx,1)
   235ab:	cmp    %rax,%rsi
   235ae:	jne    234d0 <hs_h20_nat+0x90>
   235b4:	add    %r15,%rdi
   235b7:	mov    %rdi,%rax
   235ba:	sub    %rdx,%rax
   235bd:	cmp    %r12,%rax
   235c0:	jb     234c0 <hs_h20_nat+0x80>
   235c6:	vzeroupper
   235c9:	pop    %rbx
   235ca:	pop    %r12
   235cc:	pop    %r13
   235ce:	pop    %r14
   235d0:	pop    %r15
   235d2:	pop    %rbp
   235d3:	ret
   235d4:	vzeroupper
   235d7:	ret
   235d8:	nopl   0x0(%rax,%rax,1)

00000000000235e0 <hs_g20_nat>:
   235e0:	endbr64
   235e4:	vbroadcastss 0x3aa12(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   235ee:	test   %rsi,%rsi
   235f1:	je     23784 <hs_g20_nat+0x1a4>
   235f7:	push   %rbp
   235f8:	mov    %rsp,%rbp
   235fb:	push   %r15
   235fd:	lea    0x0(,%rdx,8),%r15
   23605:	push   %r14
   23607:	push   %r13
   23609:	push   %r12
   2360b:	push   %rbx
   2360c:	test   %rdx,%rdx
   2360f:	je     23776 <hs_g20_nat+0x196>
   23615:	mov    %rdx,%r9
   23618:	mov    %rdi,%rbx
   2361b:	lea    (%rdx,%rdx,2),%rcx
   2361f:	mov    %rdx,%r10
   23622:	lea    -0x1(%rdx),%r13
   23626:	neg    %r9
   23629:	lea    (%rdx,%rdx,4),%r8
   2362d:	mov    %rsi,%r12
   23630:	and    $0xfffffffffffffff0,%r13
   23634:	shl    $0x2,%r9
   23638:	mov    %rdx,%rdi
   2363b:	lea    0x40(%rbx),%r14
   2363f:	lea    0x0(,%rcx,4),%r11
   23647:	shl    $0x4,%r10
   2364b:	shl    $0x2,%r8
   2364f:	vbroadcastss 0x399af(%rip),%zmm0        # 5d008 <_IO_stdin_used+0x8>
   23659:	shl    $0x3,%rcx
   2365d:	nopl   (%rax)
   23660:	lea    (%rdi,%r13,1),%rsi
   23664:	lea    (%rbx,%rdi,4),%rax
   23668:	lea    (%r14,%rsi,4),%rsi
   2366c:	nopl   0x0(%rax)
   23670:	vmovups (%rax,%rdx,4),%zmm6
   23677:	vmovups (%rax),%zmm5
   2367d:	vmovaps %zmm0,%zmm4
   23683:	vsubps (%rax,%rdx,8),%zmm6,%zmm7
   2368a:	vaddps (%rax,%r9,1),%zmm5,%zmm5
   23691:	vmovups (%rax,%r10,1),%zmm3
   23698:	vsubps %zmm7,%zmm5,%zmm1
   2369e:	vfmadd132ps %zmm6,%zmm1,%zmm4
   236a4:	vaddps (%rax,%r11,1),%zmm3,%zmm6
   236ab:	vmovups (%rax,%r8,1),%zmm3
   236b2:	vmovaps %zmm1,%zmm2
   236b8:	vsubps (%rax,%rcx,1),%zmm3,%zmm8
   236bf:	vmovaps %zmm0,%zmm3
   236c5:	vfmsub231ps (%rax,%r9,1),%zmm0,%zmm2
   236cc:	vaddps %zmm8,%zmm6,%zmm1
   236d2:	vfnmadd132ps (%rax,%r8,1),%zmm1,%zmm3
   236d9:	vfmsub231ps (%rax,%r11,1),%zmm0,%zmm1
   236e0:	vaddps %zmm3,%zmm4,%zmm9
   236e6:	vfnmadd132ps %zmm0,%zmm9,%zmm6
   236ec:	vfmsub132ps %zmm0,%zmm9,%zmm5
   236f2:	vaddps %zmm1,%zmm2,%zmm9
   236f8:	vfmadd132ps %zmm0,%zmm9,%zmm8
   236fe:	vfnmadd132ps %zmm0,%zmm9,%zmm7
   23704:	vfmsub132ps %zmm0,%zmm6,%zmm4
   2370a:	vfmadd132ps %zmm0,%zmm5,%zmm3
   23710:	vfmsub132ps %zmm0,%zmm8,%zmm2
   23716:	vfnmadd132ps %zmm0,%zmm7,%zmm1
   2371c:	vmovups %zmm4,(%rax,%r9,1)
   23723:	vmovups %zmm8,(%rax)
   23729:	vmovups %zmm3,(%rax,%rdx,4)
   23730:	vmovups %zmm7,(%rax,%rdx,8)
   23737:	add    $0x40,%rax
   2373b:	vmovups %zmm6,-0x40(%rax,%r11,1)
   23743:	vmovups %zmm2,-0x40(%rax,%r10,1)
   2374b:	vmovups %zmm5,-0x40(%rax,%r8,1)
   23753:	vmovups %zmm1,-0x40(%rax,%rcx,1)
   2375b:	cmp    %rax,%rsi
   2375e:	jne    23670 <hs_g20_nat+0x90>
   23764:	add    %r15,%rdi
   23767:	mov    %rdi,%rax
   2376a:	sub    %rdx,%rax
   2376d:	cmp    %r12,%rax
   23770:	jb     23660 <hs_g20_nat+0x80>
   23776:	vzeroupper
   23779:	pop    %rbx
   2377a:	pop    %r12
   2377c:	pop    %r13
   2377e:	pop    %r14
   23780:	pop    %r15
   23782:	pop    %rbp
   23783:	ret
   23784:	vzeroupper
   23787:	ret
   23788:	nopl   0x0(%rax,%rax,1)

00000000000244f0 <hf1_tb4_nat>:
   244f0:	endbr64
   244f4:	push   %rbp
   244f5:	mov    %rdi,%rdx
   244f8:	mov    %rsp,%rbp
   244fb:	and    $0xffffffffffffffc0,%rsp
   244ff:	sub    $0x140,%rsp
   24506:	vbroadcastss 0x39af0(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   24510:	mov    %fs:0x28,%rax
   24519:	mov    %rax,0x138(%rsp)
   24521:	xor    %eax,%eax
   24523:	mov    %rsp,%rdi
   24526:	vzeroupper
   24529:	call   10120 <inl_consts.constprop.0>
   2452e:	vmovaps (%rsp),%zmm6
   24535:	vmovaps 0x40(%rsp),%zmm5
   2453d:	vmovaps 0x80(%rsp),%zmm4
   24545:	vmovaps 0xc0(%rsp),%zmm3
   2454d:	test   %rsi,%rsi
   24550:	je     24701 <hf1_tb4_nat+0x211>
   24556:	mov    %rdx,%rax
   24559:	lea    -0x4(,%rsi,4),%rdx
   24561:	xor    %dl,%dl
   24563:	lea    0x100(%rax,%rdx,1),%rdx
   2456b:	nopl   0x0(%rax,%rax,1)
   24570:	vpxord (%rax),%zmm6,%zmm1
   24576:	vpermilps $0xb1,(%rax),%zmm0
   2457d:	add    $0x100,%rax
   24583:	vpxord -0x40(%rax),%zmm6,%zmm7
   2458a:	vaddps %zmm1,%zmm0,%zmm0
   24590:	vpxord %zmm0,%zmm5,%zmm1
   24596:	vpermilps $0x4e,%zmm0,%zmm0
   2459d:	vaddps %zmm1,%zmm0,%zmm0
   245a3:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm2
   245aa:	vpxord %zmm0,%zmm4,%zmm0
   245b0:	vaddps %zmm0,%zmm2,%zmm2
   245b6:	vshuff32x4 $0x4e,%zmm2,%zmm2,%zmm0
   245bd:	vpxord %zmm2,%zmm3,%zmm2
   245c3:	vaddps %zmm2,%zmm0,%zmm1
   245c9:	vpxord -0xc0(%rax),%zmm6,%zmm2
   245d0:	vpermilps $0xb1,-0xc0(%rax),%zmm0
   245d8:	vaddps %zmm2,%zmm0,%zmm0
   245de:	vpxord %zmm0,%zmm5,%zmm2
   245e4:	vpermilps $0x4e,%zmm0,%zmm0
   245eb:	vaddps %zmm2,%zmm0,%zmm0
   245f1:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm2
   245f8:	vpxord %zmm0,%zmm4,%zmm0
   245fe:	vaddps %zmm0,%zmm2,%zmm0
   24604:	vpxord -0x80(%rax),%zmm6,%zmm2
   2460b:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm9
   24612:	vpxord %zmm0,%zmm3,%zmm0
   24618:	vaddps %zmm0,%zmm9,%zmm9
   2461e:	vpermilps $0xb1,-0x80(%rax),%zmm0
   24626:	vaddps %zmm2,%zmm0,%zmm0
   2462c:	vpxord %zmm0,%zmm5,%zmm2
   24632:	vpermilps $0x4e,%zmm0,%zmm0
   24639:	vaddps %zmm2,%zmm0,%zmm0
   2463f:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm2
   24646:	vpxord %zmm0,%zmm4,%zmm0
   2464c:	vaddps %zmm0,%zmm2,%zmm0
   24652:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm2
   24659:	vpxord %zmm0,%zmm3,%zmm0
   2465f:	vaddps %zmm0,%zmm2,%zmm2
   24665:	vpermilps $0xb1,-0x40(%rax),%zmm0
   2466d:	vaddps %zmm7,%zmm0,%zmm0
   24673:	vpxord %zmm0,%zmm5,%zmm7
   24679:	vpermilps $0x4e,%zmm0,%zmm0
   24680:	vaddps %zmm7,%zmm0,%zmm0
   24686:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm7
   2468d:	vpxord %zmm0,%zmm4,%zmm0
   24693:	vaddps %zmm0,%zmm7,%zmm0
   24699:	vaddps %zmm9,%zmm1,%zmm7
   2469f:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm8
   246a6:	vpxord %zmm0,%zmm3,%zmm0
   246ac:	vaddps %zmm0,%zmm8,%zmm8
   246b2:	vsubps %zmm9,%zmm1,%zmm0
   246b8:	vaddps %zmm8,%zmm2,%zmm9
   246be:	vsubps %zmm8,%zmm2,%zmm1
   246c4:	vaddps %zmm9,%zmm7,%zmm2
   246ca:	vsubps %zmm9,%zmm7,%zmm7
   246d0:	vmovups %zmm2,-0x100(%rax)
   246d7:	vaddps %zmm1,%zmm0,%zmm2
   246dd:	vsubps %zmm1,%zmm0,%zmm0
   246e3:	vmovups %zmm7,-0x80(%rax)
   246ea:	vmovups %zmm2,-0xc0(%rax)
   246f1:	vmovups %zmm0,-0x40(%rax)
   246f8:	cmp    %rax,%rdx
   246fb:	jne    24570 <hf1_tb4_nat+0x80>
   24701:	mov    0x138(%rsp),%rax
   24709:	sub    %fs:0x28,%rax
   24712:	jne    24719 <hf1_tb4_nat+0x229>
   24714:	vzeroupper
   24717:	leave
   24718:	ret
   24719:	vzeroupper
   2471c:	call   4280 <__stack_chk_fail@plt>
   24721:	data16 cs nopw 0x0(%rax,%rax,1)
   2472c:	nopl   0x0(%rax)

0000000000024940 <hs_broken_g20>:
   24940:	endbr64
   24944:	vbroadcastss 0x396b2(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   2494e:	test   %rsi,%rsi
   24951:	je     24ae4 <hs_broken_g20+0x1a4>
   24957:	push   %rbp
   24958:	mov    %rsp,%rbp
   2495b:	push   %r15
   2495d:	lea    0x0(,%rdx,8),%r15
   24965:	push   %r14
   24967:	push   %r13
   24969:	push   %r12
   2496b:	push   %rbx
   2496c:	test   %rdx,%rdx
   2496f:	je     24ad6 <hs_broken_g20+0x196>
   24975:	mov    %rdx,%r9
   24978:	mov    %rdi,%rbx
   2497b:	lea    (%rdx,%rdx,2),%rcx
   2497f:	mov    %rdx,%r10
   24982:	lea    -0x1(%rdx),%r13
   24986:	neg    %r9
   24989:	lea    (%rdx,%rdx,4),%r8
   2498d:	mov    %rsi,%r12
   24990:	and    $0xfffffffffffffff0,%r13
   24994:	shl    $0x2,%r9
   24998:	mov    %rdx,%rdi
   2499b:	lea    0x40(%rbx),%r14
   2499f:	lea    0x0(,%rcx,4),%r11
   249a7:	shl    $0x4,%r10
   249ab:	shl    $0x2,%r8
   249af:	vbroadcastss 0x3864f(%rip),%zmm0        # 5d008 <_IO_stdin_used+0x8>
   249b9:	shl    $0x3,%rcx
   249bd:	nopl   (%rax)
   249c0:	lea    (%rdi,%r13,1),%rsi
   249c4:	lea    (%rbx,%rdi,4),%rax
   249c8:	lea    (%r14,%rsi,4),%rsi
   249cc:	nopl   0x0(%rax)
   249d0:	vmovups (%rax,%rdx,4),%zmm6
   249d7:	vmovups (%rax),%zmm5
   249dd:	vmovaps %zmm0,%zmm4
   249e3:	vsubps (%rax,%rdx,8),%zmm6,%zmm7
   249ea:	vaddps (%rax,%r9,1),%zmm5,%zmm5
   249f1:	vmovups (%rax,%r10,1),%zmm3
   249f8:	vsubps %zmm7,%zmm5,%zmm1
   249fe:	vfmadd132ps %zmm6,%zmm1,%zmm4
   24a04:	vaddps (%rax,%r11,1),%zmm3,%zmm6
   24a0b:	vmovups (%rax,%r8,1),%zmm3
   24a12:	vmovaps %zmm1,%zmm2
   24a18:	vsubps (%rax,%rcx,1),%zmm3,%zmm8
   24a1f:	vmovaps %zmm0,%zmm3
   24a25:	vfmsub231ps (%rax,%r9,1),%zmm0,%zmm2
   24a2c:	vaddps %zmm8,%zmm6,%zmm1
   24a32:	vfnmadd132ps (%rax,%r8,1),%zmm1,%zmm3
   24a39:	vfmsub231ps (%rax,%r11,1),%zmm0,%zmm1
   24a40:	vaddps %zmm3,%zmm4,%zmm9
   24a46:	vfnmadd132ps %zmm0,%zmm9,%zmm6
   24a4c:	vfmsub132ps %zmm0,%zmm9,%zmm5
   24a52:	vaddps %zmm1,%zmm2,%zmm9
   24a58:	vfmadd132ps %zmm0,%zmm9,%zmm8
   24a5e:	vfnmadd132ps %zmm0,%zmm9,%zmm7
   24a64:	vfmsub132ps %zmm0,%zmm6,%zmm4
   24a6a:	vfmadd132ps %zmm0,%zmm5,%zmm3
   24a70:	vfmsub132ps %zmm0,%zmm8,%zmm2
   24a76:	vfnmadd132ps %zmm0,%zmm7,%zmm1
   24a7c:	vmovups %zmm4,(%rax,%r9,1)
   24a83:	vmovups %zmm8,(%rax)
   24a89:	vmovups %zmm3,(%rax,%rdx,4)
   24a90:	vmovups %zmm7,(%rax,%rdx,8)
   24a97:	add    $0x40,%rax
   24a9b:	vmovups %zmm6,-0x40(%rax,%r11,1)
   24aa3:	vmovups %zmm5,-0x40(%rax,%r10,1)
   24aab:	vmovups %zmm2,-0x40(%rax,%r8,1)
   24ab3:	vmovups %zmm1,-0x40(%rax,%rcx,1)
   24abb:	cmp    %rax,%rsi
   24abe:	jne    249d0 <hs_broken_g20+0x90>
   24ac4:	add    %r15,%rdi
   24ac7:	mov    %rdi,%rax
   24aca:	sub    %rdx,%rax
   24acd:	cmp    %r12,%rax
   24ad0:	jb     249c0 <hs_broken_g20+0x80>
   24ad6:	vzeroupper
   24ad9:	pop    %rbx
   24ada:	pop    %r12
   24adc:	pop    %r13
   24ade:	pop    %r14
   24ae0:	pop    %r15
   24ae2:	pop    %rbp
   24ae3:	ret
   24ae4:	vzeroupper
   24ae7:	ret
   24ae8:	nopl   0x0(%rax,%rax,1)

00000000000284b0 <hs_tb8_nat>:
   284b0:	endbr64
   284b4:	vbroadcastss 0x35b42(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   284be:	test   %rsi,%rsi
   284c1:	je     28652 <hs_tb8_nat+0x1a2>
   284c7:	push   %rbp
   284c8:	mov    %rsp,%rbp
   284cb:	push   %r15
   284cd:	lea    0x0(,%rdx,8),%r15
   284d5:	push   %r14
   284d7:	push   %r13
   284d9:	push   %r12
   284db:	push   %rbx
   284dc:	test   %rdx,%rdx
   284df:	je     28644 <hs_tb8_nat+0x194>
   284e5:	mov    %rdx,%r9
   284e8:	mov    %rdi,%rbx
   284eb:	lea    (%rdx,%rdx,2),%rcx
   284ef:	mov    %rdx,%r10
   284f2:	lea    -0x1(%rdx),%r13
   284f6:	neg    %r9
   284f9:	lea    (%rdx,%rdx,4),%r8
   284fd:	mov    %rsi,%r12
   28500:	and    $0xfffffffffffffff0,%r13
   28504:	shl    $0x2,%r9
   28508:	mov    %rdx,%rdi
   2850b:	lea    0x40(%rbx),%r14
   2850f:	lea    0x0(,%rcx,4),%r11
   28517:	shl    $0x4,%r10
   2851b:	shl    $0x2,%r8
   2851f:	shl    $0x3,%rcx
   28523:	nopl   0x0(%rax,%rax,1)
   28528:	lea    (%rdi,%r13,1),%rsi
   2852c:	lea    (%rbx,%rdi,4),%rax
   28530:	lea    (%r14,%rsi,4),%rsi
   28534:	nopl   0x0(%rax)
   28538:	vmovups (%rax,%r9,1),%zmm7
   2853f:	vmovups (%rax,%rdx,4),%zmm3
   28546:	vaddps (%rax),%zmm7,%zmm2
   2854c:	vaddps (%rax,%rdx,8),%zmm3,%zmm6
   28553:	vsubps (%rax,%rdx,8),%zmm3,%zmm5
   2855a:	vsubps (%rax),%zmm7,%zmm0
   28560:	vmovups (%rax,%r11,1),%zmm7
   28567:	vaddps (%rax,%r10,1),%zmm7,%zmm3
   2856e:	vsubps (%rax,%r10,1),%zmm7,%zmm1
   28575:	vmovups (%rax,%r8,1),%zmm7
   2857c:	vaddps (%rax,%rcx,1),%zmm7,%zmm9
   28583:	vsubps (%rax,%rcx,1),%zmm7,%zmm4
   2858a:	vaddps %zmm6,%zmm2,%zmm7
   28590:	vsubps %zmm6,%zmm2,%zmm2
   28596:	vaddps %zmm5,%zmm0,%zmm6
   2859c:	vsubps %zmm5,%zmm0,%zmm0
   285a2:	vaddps %zmm9,%zmm3,%zmm8
   285a8:	vaddps %zmm4,%zmm1,%zmm5
   285ae:	vsubps %zmm4,%zmm1,%zmm1
   285b4:	vsubps %zmm9,%zmm3,%zmm3
   285ba:	vaddps %zmm8,%zmm7,%zmm4
   285c0:	vsubps %zmm8,%zmm7,%zmm7
   285c6:	vmovups %zmm4,(%rax,%r9,1)
   285cd:	vaddps %zmm5,%zmm6,%zmm4
   285d3:	vsubps %zmm5,%zmm6,%zmm6
   285d9:	vmovups %zmm4,(%rax)
   285df:	vaddps %zmm3,%zmm2,%zmm4
   285e5:	vsubps %zmm3,%zmm2,%zmm2
   285eb:	vmovups %zmm4,(%rax,%rdx,4)
   285f2:	vaddps %zmm1,%zmm0,%zmm4
   285f8:	vsubps %zmm1,%zmm0,%zmm0
   285fe:	vmovups %zmm4,(%rax,%rdx,8)
   28605:	add    $0x40,%rax
   28609:	vmovups %zmm7,-0x40(%rax,%r11,1)
   28611:	vmovups %zmm6,-0x40(%rax,%r10,1)
   28619:	vmovups %zmm2,-0x40(%rax,%r8,1)
   28621:	vmovups %zmm0,-0x40(%rax,%rcx,1)
   28629:	cmp    %rax,%rsi
   2862c:	jne    28538 <hs_tb8_nat+0x88>
   28632:	add    %r15,%rdi
   28635:	mov    %rdi,%rax
   28638:	sub    %rdx,%rax
   2863b:	cmp    %r12,%rax
   2863e:	jb     28528 <hs_tb8_nat+0x78>
   28644:	vzeroupper
   28647:	pop    %rbx
   28648:	pop    %r12
   2864a:	pop    %r13
   2864c:	pop    %r14
   2864e:	pop    %r15
   28650:	pop    %rbp
   28651:	ret
   28652:	vzeroupper
   28655:	ret
   28656:	cs nopw 0x0(%rax,%rax,1)

0000000000028660 <hs_tb8_bal>:
   28660:	endbr64
   28664:	vbroadcastss 0x35992(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   2866e:	test   %rsi,%rsi
   28671:	je     2884e <hs_tb8_bal+0x1ee>
   28677:	push   %rbp
   28678:	mov    %rsp,%rbp
   2867b:	push   %r15
   2867d:	lea    0x0(,%rdx,8),%r15
   28685:	push   %r14
   28687:	push   %r13
   28689:	push   %r12
   2868b:	push   %rbx
   2868c:	test   %rdx,%rdx
   2868f:	je     28840 <hs_tb8_bal+0x1e0>
   28695:	mov    %rdx,%r9
   28698:	mov    %rdi,%rbx
   2869b:	lea    (%rdx,%rdx,2),%rcx
   2869f:	mov    %rdx,%r10
   286a2:	lea    -0x1(%rdx),%r13
   286a6:	neg    %r9
   286a9:	lea    (%rdx,%rdx,4),%r8
   286ad:	mov    %rsi,%r12
   286b0:	and    $0xfffffffffffffff0,%r13
   286b4:	shl    $0x2,%r9
   286b8:	mov    %rdx,%rdi
   286bb:	lea    0x40(%rbx),%r14
   286bf:	lea    0x0(,%rcx,4),%r11
   286c7:	shl    $0x4,%r10
   286cb:	shl    $0x2,%r8
   286cf:	shl    $0x3,%rcx
   286d3:	nopl   0x0(%rax,%rax,1)
   286d8:	lea    (%rdi,%r13,1),%rsi
   286dc:	lea    (%rbx,%rdi,4),%rax
   286e0:	lea    (%r14,%rsi,4),%rsi
   286e4:	nopl   0x0(%rax)
   286e8:	vmovups (%rax,%rdx,8),%zmm7
   286ef:	vfmadd213ps (%rax,%rdx,4),%zmm0,%zmm7
   286f6:	vmovups (%rax),%zmm3
   286fc:	vfmadd213ps (%rax,%r9,1),%zmm0,%zmm3
   28703:	vmovups (%rax,%rcx,1),%zmm10
   2870a:	vfmadd213ps (%rax,%r8,1),%zmm0,%zmm10
   28711:	vmovups (%rax,%r9,1),%zmm2
   28718:	vmovups (%rax,%r10,1),%zmm4
   2871f:	vsubps (%rax),%zmm2,%zmm1
   28725:	vfmadd213ps (%rax,%r11,1),%zmm0,%zmm4
   2872c:	vmovups (%rax,%rdx,4),%zmm2
   28733:	vsubps (%rax,%rdx,8),%zmm2,%zmm6
   2873a:	vmovaps %zmm7,%zmm8
   28740:	vmovups (%rax,%r11,1),%zmm5
   28747:	vsubps (%rax,%r10,1),%zmm5,%zmm2
   2874e:	vfmadd132ps %zmm0,%zmm3,%zmm8
   28754:	vsubps %zmm7,%zmm3,%zmm3
   2875a:	vmovups (%rax,%r8,1),%zmm5
   28761:	vsubps (%rax,%rcx,1),%zmm5,%zmm5
   28768:	vmovaps %zmm10,%zmm9
   2876e:	vmovaps %zmm6,%zmm7
   28774:	vfmadd132ps %zmm0,%zmm1,%zmm7
   2877a:	vsubps %zmm6,%zmm1,%zmm1
   28780:	vmovaps %zmm5,%zmm6
   28786:	vfmadd132ps %zmm0,%zmm4,%zmm9
   2878c:	vsubps %zmm10,%zmm4,%zmm4
   28792:	vfmadd132ps %zmm0,%zmm2,%zmm6
   28798:	vsubps %zmm5,%zmm2,%zmm2
   2879e:	vmovaps %zmm4,%zmm10
   287a4:	vmovaps %zmm2,%zmm5
   287aa:	vfmadd132ps %zmm0,%zmm3,%zmm10
   287b0:	vsubps %zmm4,%zmm3,%zmm3
   287b6:	vmovaps %zmm9,%zmm12
   287bc:	vfmadd132ps %zmm0,%zmm1,%zmm5
   287c2:	vsubps %zmm2,%zmm1,%zmm1
   287c8:	vmovaps %zmm6,%zmm11
   287ce:	vfmadd132ps %zmm0,%zmm8,%zmm12
   287d4:	vsubps %zmm9,%zmm8,%zmm8
   287da:	vfmadd132ps %zmm0,%zmm7,%zmm11
   287e0:	vsubps %zmm6,%zmm7,%zmm7
   287e6:	vmovups %zmm12,(%rax,%r9,1)
   287ed:	vmovups %zmm11,(%rax)
   287f3:	vmovups %zmm10,(%rax,%rdx,4)
   287fa:	vmovups %zmm5,(%rax,%rdx,8)
   28801:	add    $0x40,%rax
   28805:	vmovups %zmm8,-0x40(%rax,%r11,1)
   2880d:	vmovups %zmm7,-0x40(%rax,%r10,1)
   28815:	vmovups %zmm3,-0x40(%rax,%r8,1)
   2881d:	vmovups %zmm1,-0x40(%rax,%rcx,1)
   28825:	cmp    %rax,%rsi
   28828:	jne    286e8 <hs_tb8_bal+0x88>
   2882e:	add    %r15,%rdi
   28831:	mov    %rdi,%rax
   28834:	sub    %rdx,%rax
   28837:	cmp    %r12,%rax
   2883a:	jb     286d8 <hs_tb8_bal+0x78>
   28840:	vzeroupper
   28843:	pop    %rbx
   28844:	pop    %r12
   28846:	pop    %r13
   28848:	pop    %r14
   2884a:	pop    %r15
   2884c:	pop    %rbp
   2884d:	ret
   2884e:	vzeroupper
   28851:	ret
   28852:	data16 cs nopw 0x0(%rax,%rax,1)
   2885d:	nopl   (%rax)

0000000000028860 <hs_tb8_balS>:
   28860:	endbr64
   28864:	vbroadcastss 0x35792(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   2886e:	test   %rsi,%rsi
   28871:	je     28a33 <hs_tb8_balS+0x1d3>
   28877:	push   %rbp
   28878:	mov    %rsp,%rbp
   2887b:	push   %r15
   2887d:	lea    0x0(,%rdx,8),%r15
   28885:	push   %r14
   28887:	push   %r13
   28889:	push   %r12
   2888b:	push   %rbx
   2888c:	test   %rdx,%rdx
   2888f:	je     28a25 <hs_tb8_balS+0x1c5>
   28895:	mov    %rdx,%r9
   28898:	mov    %rdi,%rbx
   2889b:	lea    (%rdx,%rdx,2),%rcx
   2889f:	mov    %rdx,%r10
   288a2:	lea    -0x1(%rdx),%r13
   288a6:	neg    %r9
   288a9:	lea    (%rdx,%rdx,4),%r8
   288ad:	mov    %rsi,%r12
   288b0:	and    $0xfffffffffffffff0,%r13
   288b4:	shl    $0x2,%r9
   288b8:	mov    %rdx,%rdi
   288bb:	lea    0x40(%rbx),%r14
   288bf:	lea    0x0(,%rcx,4),%r11
   288c7:	shl    $0x4,%r10
   288cb:	shl    $0x2,%r8
   288cf:	shl    $0x3,%rcx
   288d3:	nopl   0x0(%rax,%rax,1)
   288d8:	lea    (%rdi,%r13,1),%rsi
   288dc:	lea    (%rbx,%rdi,4),%rax
   288e0:	lea    (%r14,%rsi,4),%rsi
   288e4:	nopl   0x0(%rax)
   288e8:	vmovups (%rax,%r9,1),%zmm7
   288ef:	vmovups (%rax),%zmm6
   288f5:	vsubps (%rax),%zmm7,%zmm8
   288fb:	vmovups (%rax,%rdx,4),%zmm4
   28902:	vmovups (%rax,%rdx,8),%zmm1
   28909:	vmovups (%rax,%r10,1),%zmm5
   28910:	vfmadd132ps %zmm0,%zmm7,%zmm6
   28916:	vmovups (%rax,%r11,1),%zmm7
   2891d:	vmovups (%rax,%rcx,1),%zmm2
   28924:	vfmadd132ps %zmm0,%zmm4,%zmm1
   2892a:	vfmadd213ps (%rax,%r8,1),%zmm0,%zmm2
   28931:	vsubps (%rax,%r10,1),%zmm7,%zmm9
   28938:	vfmadd132ps %zmm0,%zmm7,%zmm5
   2893e:	vsubps (%rax,%rdx,8),%zmm4,%zmm3
   28945:	vmovups (%rax,%r8,1),%zmm4
   2894c:	vsubps (%rax,%rcx,1),%zmm4,%zmm4
   28953:	vsubps %zmm1,%zmm6,%zmm7
   28959:	vfmadd132ps %zmm0,%zmm6,%zmm1
   2895f:	vsubps %zmm3,%zmm8,%zmm6
   28965:	vfmadd132ps %zmm0,%zmm8,%zmm3
   2896b:	vsubps %zmm2,%zmm5,%zmm8
   28971:	vfmadd132ps %zmm0,%zmm5,%zmm2
   28977:	vsubps %zmm4,%zmm9,%zmm5
   2897d:	vfmadd132ps %zmm0,%zmm9,%zmm4
   28983:	vmovaps %zmm8,%zmm10
   28989:	vmovaps %zmm5,%zmm9
   2898f:	vfmadd132ps %zmm0,%zmm7,%zmm10
   28995:	vsubps %zmm8,%zmm7,%zmm7
   2899b:	vfmadd132ps %zmm0,%zmm6,%zmm9
   289a1:	vsubps %zmm5,%zmm6,%zmm6
   289a7:	vmovaps %zmm2,%zmm12
   289ad:	vmovaps %zmm4,%zmm11
   289b3:	vfmadd132ps %zmm0,%zmm1,%zmm12
   289b9:	vsubps %zmm2,%zmm1,%zmm1
   289bf:	vfmadd132ps %zmm0,%zmm3,%zmm11
   289c5:	vsubps %zmm4,%zmm3,%zmm3
   289cb:	vmovups %zmm12,(%rax,%r9,1)
   289d2:	vmovups %zmm11,(%rax)
   289d8:	vmovups %zmm10,(%rax,%rdx,4)
   289df:	vmovups %zmm9,(%rax,%rdx,8)
   289e6:	add    $0x40,%rax
   289ea:	vmovups %zmm1,-0x40(%rax,%r11,1)
   289f2:	vmovups %zmm3,-0x40(%rax,%r10,1)
   289fa:	vmovups %zmm7,-0x40(%rax,%r8,1)
   28a02:	vmovups %zmm6,-0x40(%rax,%rcx,1)
   28a0a:	cmp    %rax,%rsi
   28a0d:	jne    288e8 <hs_tb8_balS+0x88>
   28a13:	add    %r15,%rdi
   28a16:	mov    %rdi,%rax
   28a19:	sub    %rdx,%rax
   28a1c:	cmp    %r12,%rax
   28a1f:	jb     288d8 <hs_tb8_balS+0x78>
   28a25:	vzeroupper
   28a28:	pop    %rbx
   28a29:	pop    %r12
   28a2b:	pop    %r13
   28a2d:	pop    %r14
   28a2f:	pop    %r15
   28a31:	pop    %rbp
   28a32:	ret
   28a33:	vzeroupper
   28a36:	ret
   28a37:	nopw   0x0(%rax,%rax,1)

000000000002d4c0 <hf1_tb2_nat>:
   2d4c0:	endbr64
   2d4c4:	push   %rbp
   2d4c5:	mov    %rdi,%rdx
   2d4c8:	mov    %rsp,%rbp
   2d4cb:	and    $0xffffffffffffffc0,%rsp
   2d4cf:	sub    $0x140,%rsp
   2d4d6:	vbroadcastss 0x30b20(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   2d4e0:	mov    %fs:0x28,%rax
   2d4e9:	mov    %rax,0x138(%rsp)
   2d4f1:	xor    %eax,%eax
   2d4f3:	mov    %rsp,%rdi
   2d4f6:	vzeroupper
   2d4f9:	call   10120 <inl_consts.constprop.0>
   2d4fe:	vmovaps (%rsp),%zmm6
   2d505:	vmovaps 0x40(%rsp),%zmm5
   2d50d:	vmovaps 0x80(%rsp),%zmm4
   2d515:	vmovaps 0xc0(%rsp),%zmm3
   2d51d:	test   %rsi,%rsi
   2d520:	je     2d601 <hf1_tb2_nat+0x141>
   2d526:	lea    -0x4(,%rsi,4),%rax
   2d52e:	mov    %rdx,%rdi
   2d531:	and    $0xffffffffffffff80,%rax
   2d535:	lea    0x80(%rdx,%rax,1),%rax
   2d53d:	nopl   (%rax)
   2d540:	vpxord (%rdi),%zmm6,%zmm1
   2d546:	vpermilps $0xb1,(%rdi),%zmm0
   2d54d:	sub    $0xffffffffffffff80,%rdi
   2d551:	vaddps %zmm1,%zmm0,%zmm0
   2d557:	vpxord %zmm0,%zmm5,%zmm1
   2d55d:	vpermilps $0x4e,%zmm0,%zmm0
   2d564:	vaddps %zmm1,%zmm0,%zmm0
   2d56a:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   2d571:	vpxord %zmm0,%zmm4,%zmm0
   2d577:	vaddps %zmm0,%zmm1,%zmm0
   2d57d:	vpxord -0x40(%rdi),%zmm6,%zmm1
   2d584:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm2
   2d58b:	vpxord %zmm0,%zmm3,%zmm0
   2d591:	vaddps %zmm0,%zmm2,%zmm2
   2d597:	vpermilps $0xb1,-0x40(%rdi),%zmm0
   2d59f:	vaddps %zmm1,%zmm0,%zmm0
   2d5a5:	vpxord %zmm0,%zmm5,%zmm1
   2d5ab:	vpermilps $0x4e,%zmm0,%zmm0
   2d5b2:	vaddps %zmm1,%zmm0,%zmm0
   2d5b8:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   2d5bf:	vpxord %zmm0,%zmm4,%zmm0
   2d5c5:	vaddps %zmm0,%zmm1,%zmm0
   2d5cb:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   2d5d2:	vpxord %zmm0,%zmm3,%zmm0
   2d5d8:	vaddps %zmm0,%zmm1,%zmm0
   2d5de:	vaddps %zmm0,%zmm2,%zmm1
   2d5e4:	vsubps %zmm0,%zmm2,%zmm2
   2d5ea:	vmovups %zmm1,-0x80(%rdi)
   2d5f1:	vmovups %zmm2,-0x40(%rdi)
   2d5f8:	cmp    %rdi,%rax
   2d5fb:	jne    2d540 <hf1_tb2_nat+0x80>
   2d601:	mov    0x138(%rsp),%rax
   2d609:	sub    %fs:0x28,%rax
   2d612:	jne    2d619 <hf1_tb2_nat+0x159>
   2d614:	vzeroupper
   2d617:	leave
   2d618:	ret
   2d619:	vzeroupper
   2d61c:	call   4280 <__stack_chk_fail@plt>
   2d621:	data16 cs nopw 0x0(%rax,%rax,1)
   2d62c:	nopl   0x0(%rax)

0000000000030ec0 <hf1_kid_nat>:
   30ec0:	endbr64
   30ec4:	push   %rbp
   30ec5:	mov    %rdi,%rdx
   30ec8:	mov    %rsp,%rbp
   30ecb:	and    $0xffffffffffffffc0,%rsp
   30ecf:	sub    $0x140,%rsp
   30ed6:	vbroadcastss 0x2d120(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   30ee0:	mov    %fs:0x28,%rax
   30ee9:	mov    %rax,0x138(%rsp)
   30ef1:	xor    %eax,%eax
   30ef3:	mov    %rsp,%rdi
   30ef6:	vzeroupper
   30ef9:	call   10120 <inl_consts.constprop.0>
   30efe:	vmovaps (%rsp),%zmm5
   30f05:	vmovaps 0x40(%rsp),%zmm4
   30f0d:	vmovaps 0x80(%rsp),%zmm3
   30f15:	vmovaps 0xc0(%rsp),%zmm2
   30f1d:	test   %rsi,%rsi
   30f20:	je     30f9c <hf1_kid_nat+0xdc>
   30f22:	lea    -0x4(,%rsi,4),%rax
   30f2a:	mov    %rdx,%rdi
   30f2d:	and    $0xffffffffffffffc0,%rax
   30f31:	lea    0x40(%rdx,%rax,1),%rax
   30f36:	cs nopw 0x0(%rax,%rax,1)
   30f40:	vpxord (%rdi),%zmm5,%zmm1
   30f46:	vpermilps $0xb1,(%rdi),%zmm0
   30f4d:	add    $0x40,%rdi
   30f51:	vaddps %zmm1,%zmm0,%zmm0
   30f57:	vpxord %zmm0,%zmm4,%zmm1
   30f5d:	vpermilps $0x4e,%zmm0,%zmm0
   30f64:	vaddps %zmm1,%zmm0,%zmm0
   30f6a:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   30f71:	vpxord %zmm0,%zmm3,%zmm0
   30f77:	vaddps %zmm0,%zmm1,%zmm0
   30f7d:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   30f84:	vpxord %zmm0,%zmm2,%zmm0
   30f8a:	vaddps %zmm0,%zmm1,%zmm0
   30f90:	vmovups %zmm0,-0x40(%rdi)
   30f97:	cmp    %rdi,%rax
   30f9a:	jne    30f40 <hf1_kid_nat+0x80>
   30f9c:	mov    0x138(%rsp),%rax
   30fa4:	sub    %fs:0x28,%rax
   30fad:	jne    30fb4 <hf1_kid_nat+0xf4>
   30faf:	vzeroupper
   30fb2:	leave
   30fb3:	ret
   30fb4:	vzeroupper
   30fb7:	call   4280 <__stack_chk_fail@plt>
   30fbc:	nopl   0x0(%rax)

0000000000032bf0 <hs_g52_nat>:
   32bf0:	endbr64
   32bf4:	vbroadcastss 0x2b402(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   32bfe:	test   %rsi,%rsi
   32c01:	je     32ede <hs_g52_nat+0x2ee>
   32c07:	push   %rbp
   32c08:	lea    (%rdx,%rdx,2),%r11
   32c0c:	mov    %rdx,%rcx
   32c0f:	lea    0x0(,%rdx,8),%r9
   32c17:	shl    $0x2,%r11
   32c1b:	mov    %rsp,%rbp
   32c1e:	push   %r15
   32c20:	push   %r14
   32c22:	push   %r13
   32c24:	push   %r12
   32c26:	mov    %rsi,%r12
   32c29:	mov    %rdx,%rsi
   32c2c:	push   %rbx
   32c2d:	shl    $0x4,%rsi
   32c31:	test   %rdx,%rdx
   32c34:	je     32ed0 <hs_g52_nat+0x2e0>
   32c3a:	lea    (%rdi,%r9,1),%rax
   32c3e:	mov    %rdx,%r10
   32c41:	lea    (%rdx,%rdx,4),%r8
   32c45:	neg    %r9
   32c48:	vmovq  %rax,%xmm16
   32c4e:	lea    -0x1(%rdx),%rax
   32c52:	neg    %r10
   32c55:	xor    %ebx,%ebx
   32c57:	shr    $0x4,%rax
   32c5b:	lea    (%rdi,%r8,8),%r15
   32c5f:	shl    $0x2,%r10
   32c63:	lea    0x40(%rdi),%r14
   32c67:	lea    (%rdx,%rax,8),%r13
   32c6b:	shl    $0x2,%r8
   32c6f:	vbroadcastss 0x2a38f(%rip),%zmm0        # 5d008 <_IO_stdin_used+0x8>
   32c79:	add    %r13,%r13
   32c7c:	lea    0x0(,%rbx,4),%rdx
   32c84:	vmovq  %xmm16,%rax
   32c8a:	lea    (%rbx,%r13,1),%rdi
   32c8e:	add    %rdx,%rax
   32c91:	lea    (%r14,%rdi,4),%rdi
   32c95:	add    %r15,%rdx
   32c98:	nopl   0x0(%rax,%rax,1)
   32ca0:	vmovups (%rax),%zmm3
   32ca6:	vmovups (%rax,%rsi,1),%zmm5
   32cad:	vmovaps %zmm0,%zmm7
   32cb3:	vmovaps %zmm0,%zmm12
   32cb9:	vsubps (%rax,%rcx,4),%zmm3,%zmm14
   32cc0:	vsubps (%rax,%r8,1),%zmm5,%zmm17
   32cc7:	vmovups (%rax,%r10,1),%zmm1
   32cce:	vmovups (%rax,%r11,1),%zmm4
   32cd5:	vaddps (%rax,%r9,1),%zmm1,%zmm15
   32cdc:	vaddps (%rax,%rcx,8),%zmm4,%zmm11
   32ce3:	vmovaps %zmm0,%zmm4
   32ce9:	vmovups (%rdx,%r10,1),%zmm6
   32cf0:	vaddps (%rdx,%r9,1),%zmm6,%zmm9
   32cf7:	vmovups (%rdx,%r11,1),%zmm6
   32cfe:	vaddps (%rdx,%rcx,8),%zmm6,%zmm10
   32d05:	vmovaps %zmm0,%zmm6
   32d0b:	vaddps %zmm17,%zmm11,%zmm2
   32d11:	vsubps %zmm14,%zmm15,%zmm1
   32d17:	vfnmadd132ps %zmm5,%zmm2,%zmm4
   32d1d:	vfmadd132ps %zmm3,%zmm1,%zmm7
   32d23:	vmovaps %zmm2,%zmm3
   32d29:	vmovups (%rdx),%zmm5
   32d2f:	vfmsub231ps (%rax,%r9,1),%zmm0,%zmm1
   32d36:	vfmsub231ps (%rax,%rcx,8),%zmm0,%zmm3
   32d3d:	vsubps (%rdx,%rcx,4),%zmm5,%zmm13
   32d44:	vsubps %zmm4,%zmm7,%zmm2
   32d4a:	vfmadd132ps %zmm0,%zmm2,%zmm11
   32d50:	vfmsub132ps %zmm0,%zmm2,%zmm15
   32d56:	vaddps %zmm3,%zmm1,%zmm2
   32d5c:	vfmadd132ps %zmm0,%zmm2,%zmm17
   32d62:	vfnmadd132ps %zmm0,%zmm2,%zmm14
   32d68:	vsubps %zmm13,%zmm9,%zmm2
   32d6e:	vfmadd132ps %zmm5,%zmm2,%zmm12
   32d74:	vfmsub231ps (%rdx,%r9,1),%zmm0,%zmm2
   32d7b:	vmovups (%rdx,%rsi,1),%zmm5
   32d82:	vmovaps %zmm2,%zmm8
   32d88:	vsubps (%rdx,%r8,1),%zmm5,%zmm2
   32d8f:	vaddps %zmm2,%zmm10,%zmm5
   32d95:	vfnmadd132ps (%rdx,%rsi,1),%zmm5,%zmm6
   32d9c:	vfmsub231ps (%rdx,%rcx,8),%zmm0,%zmm5
   32da3:	vaddps %zmm6,%zmm12,%zmm18
   32da9:	vfnmadd132ps %zmm0,%zmm18,%zmm10
   32daf:	vfmsub132ps %zmm0,%zmm18,%zmm9
   32db5:	vsubps %zmm5,%zmm8,%zmm18
   32dbb:	vfnmadd132ps %zmm0,%zmm18,%zmm2
   32dc1:	vfnmadd132ps %zmm0,%zmm18,%zmm13
   32dc7:	vaddps %zmm10,%zmm11,%zmm18
   32dcd:	vfnmadd132ps %zmm0,%zmm18,%zmm12
   32dd3:	vfmsub132ps %zmm0,%zmm18,%zmm7
   32dd9:	vaddps %zmm2,%zmm17,%zmm18
   32ddf:	vfnmadd132ps %zmm0,%zmm18,%zmm8
   32de5:	vfmsub132ps %zmm0,%zmm18,%zmm1
   32deb:	vaddps %zmm9,%zmm15,%zmm18
   32df1:	vfmsub132ps %zmm0,%zmm12,%zmm11
   32df7:	vfmadd132ps %zmm0,%zmm7,%zmm10
   32dfd:	vfmadd132ps %zmm0,%zmm18,%zmm6
   32e03:	vfnmadd132ps %zmm0,%zmm18,%zmm4
   32e09:	vaddps %zmm13,%zmm14,%zmm18
   32e0f:	vfmsub132ps %zmm0,%zmm8,%zmm17
   32e15:	vfmadd132ps %zmm0,%zmm1,%zmm2
   32e1b:	vfmadd132ps %zmm0,%zmm18,%zmm5
   32e21:	vfnmadd132ps %zmm0,%zmm18,%zmm3
   32e27:	vmovups %zmm11,(%rax,%r9,1)
   32e2e:	vfmsub132ps %zmm0,%zmm6,%zmm15
   32e34:	vfnmadd132ps %zmm0,%zmm4,%zmm9
   32e3a:	vmovups %zmm17,(%rax,%r10,1)
   32e41:	vfmsub132ps %zmm0,%zmm5,%zmm14
   32e47:	vfnmadd132ps %zmm0,%zmm3,%zmm13
   32e4d:	vmovups %zmm6,(%rax)
   32e53:	vmovups %zmm5,(%rax,%rcx,4)
   32e5a:	vmovups %zmm10,(%rax,%rcx,8)
   32e61:	add    $0x40,%rax
   32e65:	vmovups %zmm2,-0x40(%rax,%r11,1)
   32e6d:	vmovups %zmm4,-0x40(%rax,%rsi,1)
   32e75:	vmovups %zmm3,-0x40(%rax,%r8,1)
   32e7d:	vmovups %zmm12,(%rdx,%r9,1)
   32e84:	vmovups %zmm8,(%rdx,%r10,1)
   32e8b:	vmovups %zmm15,(%rdx)
   32e91:	vmovups %zmm14,(%rdx,%rcx,4)
   32e98:	vmovups %zmm7,(%rdx,%rcx,8)
   32e9f:	add    $0x40,%rdx
   32ea3:	vmovups %zmm1,-0x40(%rdx,%r11,1)
   32eab:	vmovups %zmm9,-0x40(%rdx,%rsi,1)
   32eb3:	vmovups %zmm13,-0x40(%rdx,%r8,1)
   32ebb:	cmp    %rdi,%rax
   32ebe:	jne    32ca0 <hs_g52_nat+0xb0>
   32ec4:	add    %rsi,%rbx
   32ec7:	cmp    %r12,%rbx
   32eca:	jb     32c7c <hs_g52_nat+0x8c>
   32ed0:	vzeroupper
   32ed3:	pop    %rbx
   32ed4:	pop    %r12
   32ed6:	pop    %r13
   32ed8:	pop    %r14
   32eda:	pop    %r15
   32edc:	pop    %rbp
   32edd:	ret
   32ede:	vzeroupper
   32ee1:	ret
   32ee2:	data16 cs nopw 0x0(%rax,%rax,1)
   32eed:	nopl   (%rax)

0000000000032ef0 <hs_broken_g52>:
   32ef0:	endbr64
   32ef4:	vbroadcastss 0x2b102(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   32efe:	test   %rsi,%rsi
   32f01:	je     331de <hs_broken_g52+0x2ee>
   32f07:	push   %rbp
   32f08:	lea    (%rdx,%rdx,2),%r11
   32f0c:	mov    %rdx,%rcx
   32f0f:	lea    0x0(,%rdx,8),%r9
   32f17:	shl    $0x2,%r11
   32f1b:	mov    %rsp,%rbp
   32f1e:	push   %r15
   32f20:	push   %r14
   32f22:	push   %r13
   32f24:	push   %r12
   32f26:	mov    %rsi,%r12
   32f29:	mov    %rdx,%rsi
   32f2c:	push   %rbx
   32f2d:	shl    $0x4,%rsi
   32f31:	test   %rdx,%rdx
   32f34:	je     331d0 <hs_broken_g52+0x2e0>
   32f3a:	lea    (%rdi,%r9,1),%rax
   32f3e:	mov    %rdx,%r10
   32f41:	lea    (%rdx,%rdx,4),%r8
   32f45:	neg    %r9
   32f48:	vmovq  %rax,%xmm16
   32f4e:	lea    -0x1(%rdx),%rax
   32f52:	neg    %r10
   32f55:	xor    %ebx,%ebx
   32f57:	shr    $0x4,%rax
   32f5b:	lea    (%rdi,%r8,8),%r15
   32f5f:	shl    $0x2,%r10
   32f63:	lea    0x40(%rdi),%r14
   32f67:	lea    (%rdx,%rax,8),%r13
   32f6b:	shl    $0x2,%r8
   32f6f:	vbroadcastss 0x2a08f(%rip),%zmm0        # 5d008 <_IO_stdin_used+0x8>
   32f79:	add    %r13,%r13
   32f7c:	lea    0x0(,%rbx,4),%rdx
   32f84:	vmovq  %xmm16,%rax
   32f8a:	lea    (%rbx,%r13,1),%rdi
   32f8e:	add    %rdx,%rax
   32f91:	lea    (%r14,%rdi,4),%rdi
   32f95:	add    %r15,%rdx
   32f98:	nopl   0x0(%rax,%rax,1)
   32fa0:	vmovups (%rax),%zmm3
   32fa6:	vmovups (%rax,%rsi,1),%zmm5
   32fad:	vmovaps %zmm0,%zmm7
   32fb3:	vmovaps %zmm0,%zmm12
   32fb9:	vsubps (%rax,%rcx,4),%zmm3,%zmm14
   32fc0:	vsubps (%rax,%r8,1),%zmm5,%zmm17
   32fc7:	vmovups (%rax,%r10,1),%zmm1
   32fce:	vmovups (%rax,%r11,1),%zmm4
   32fd5:	vaddps (%rax,%r9,1),%zmm1,%zmm15
   32fdc:	vaddps (%rax,%rcx,8),%zmm4,%zmm11
   32fe3:	vmovaps %zmm0,%zmm4
   32fe9:	vmovups (%rdx,%r10,1),%zmm6
   32ff0:	vaddps (%rdx,%r9,1),%zmm6,%zmm9
   32ff7:	vmovups (%rdx,%r11,1),%zmm6
   32ffe:	vaddps (%rdx,%rcx,8),%zmm6,%zmm10
   33005:	vmovaps %zmm0,%zmm6
   3300b:	vaddps %zmm17,%zmm11,%zmm2
   33011:	vsubps %zmm14,%zmm15,%zmm1
   33017:	vfnmadd132ps %zmm5,%zmm2,%zmm4
   3301d:	vfmadd132ps %zmm3,%zmm1,%zmm7
   33023:	vmovaps %zmm2,%zmm3
   33029:	vmovups (%rdx),%zmm5
   3302f:	vfmsub231ps (%rax,%r9,1),%zmm0,%zmm1
   33036:	vfmsub231ps (%rax,%rcx,8),%zmm0,%zmm3
   3303d:	vsubps (%rdx,%rcx,4),%zmm5,%zmm13
   33044:	vsubps %zmm4,%zmm7,%zmm2
   3304a:	vfmadd132ps %zmm0,%zmm2,%zmm11
   33050:	vfmsub132ps %zmm0,%zmm2,%zmm15
   33056:	vaddps %zmm3,%zmm1,%zmm2
   3305c:	vfmadd132ps %zmm0,%zmm2,%zmm17
   33062:	vfnmadd132ps %zmm0,%zmm2,%zmm14
   33068:	vsubps %zmm13,%zmm9,%zmm2
   3306e:	vfmadd132ps %zmm5,%zmm2,%zmm12
   33074:	vfmsub231ps (%rdx,%r9,1),%zmm0,%zmm2
   3307b:	vmovups (%rdx,%rsi,1),%zmm5
   33082:	vmovaps %zmm2,%zmm8
   33088:	vsubps (%rdx,%r8,1),%zmm5,%zmm2
   3308f:	vaddps %zmm2,%zmm10,%zmm5
   33095:	vfnmadd132ps (%rdx,%rsi,1),%zmm5,%zmm6
   3309c:	vfmsub231ps (%rdx,%rcx,8),%zmm0,%zmm5
   330a3:	vaddps %zmm6,%zmm12,%zmm18
   330a9:	vfnmadd132ps %zmm0,%zmm18,%zmm10
   330af:	vfmsub132ps %zmm0,%zmm18,%zmm9
   330b5:	vsubps %zmm5,%zmm8,%zmm18
   330bb:	vfnmadd132ps %zmm0,%zmm18,%zmm2
   330c1:	vfnmadd132ps %zmm0,%zmm18,%zmm13
   330c7:	vaddps %zmm10,%zmm11,%zmm18
   330cd:	vfnmadd132ps %zmm0,%zmm18,%zmm12
   330d3:	vfmsub132ps %zmm0,%zmm18,%zmm7
   330d9:	vaddps %zmm2,%zmm17,%zmm18
   330df:	vfnmadd132ps %zmm0,%zmm18,%zmm8
   330e5:	vfmsub132ps %zmm0,%zmm18,%zmm1
   330eb:	vaddps %zmm9,%zmm15,%zmm18
   330f1:	vfmsub132ps %zmm0,%zmm12,%zmm11
   330f7:	vfmadd132ps %zmm0,%zmm7,%zmm10
   330fd:	vfmadd132ps %zmm0,%zmm18,%zmm6
   33103:	vfnmadd132ps %zmm0,%zmm18,%zmm4
   33109:	vaddps %zmm13,%zmm14,%zmm18
   3310f:	vfmsub132ps %zmm0,%zmm8,%zmm17
   33115:	vfmadd132ps %zmm0,%zmm1,%zmm2
   3311b:	vfmadd132ps %zmm0,%zmm18,%zmm5
   33121:	vfnmadd132ps %zmm0,%zmm18,%zmm3
   33127:	vmovups %zmm11,(%rax,%r9,1)
   3312e:	vfmsub132ps %zmm0,%zmm6,%zmm15
   33134:	vfnmadd132ps %zmm0,%zmm4,%zmm9
   3313a:	vmovups %zmm17,(%rax,%r10,1)
   33141:	vfmsub132ps %zmm0,%zmm5,%zmm14
   33147:	vfnmadd132ps %zmm0,%zmm3,%zmm13
   3314d:	vmovups %zmm6,(%rax)
   33153:	vmovups %zmm5,(%rax,%rcx,4)
   3315a:	vmovups %zmm10,(%rax,%rcx,8)
   33161:	add    $0x40,%rax
   33165:	vmovups %zmm4,-0x40(%rax,%r11,1)
   3316d:	vmovups %zmm2,-0x40(%rax,%rsi,1)
   33175:	vmovups %zmm3,-0x40(%rax,%r8,1)
   3317d:	vmovups %zmm12,(%rdx,%r9,1)
   33184:	vmovups %zmm8,(%rdx,%r10,1)
   3318b:	vmovups %zmm15,(%rdx)
   33191:	vmovups %zmm14,(%rdx,%rcx,4)
   33198:	vmovups %zmm7,(%rdx,%rcx,8)
   3319f:	add    $0x40,%rdx
   331a3:	vmovups %zmm1,-0x40(%rdx,%r11,1)
   331ab:	vmovups %zmm9,-0x40(%rdx,%rsi,1)
   331b3:	vmovups %zmm13,-0x40(%rdx,%r8,1)
   331bb:	cmp    %rdi,%rax
   331be:	jne    32fa0 <hs_broken_g52+0xb0>
   331c4:	add    %rsi,%rbx
   331c7:	cmp    %r12,%rbx
   331ca:	jb     32f7c <hs_broken_g52+0x8c>
   331d0:	vzeroupper
   331d3:	pop    %rbx
   331d4:	pop    %r12
   331d6:	pop    %r13
   331d8:	pop    %r14
   331da:	pop    %r15
   331dc:	pop    %rbp
   331dd:	ret
   331de:	vzeroupper
   331e1:	ret
   331e2:	data16 cs nopw 0x0(%rax,%rax,1)
   331ed:	nopl   (%rax)

0000000000034570 <hs_tb16_balS>:
   34570:	endbr64
   34574:	vbroadcastss 0x29a82(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   3457e:	test   %rsi,%rsi
   34581:	je     348f4 <hs_tb16_balS+0x384>
   34587:	push   %rbp
   34588:	lea    (%rdx,%rdx,2),%r11
   3458c:	mov    %rdx,%rcx
   3458f:	lea    0x0(,%rdx,8),%r9
   34597:	shl    $0x2,%r11
   3459b:	mov    %rsp,%rbp
   3459e:	push   %r15
   345a0:	push   %r14
   345a2:	push   %r13
   345a4:	push   %r12
   345a6:	mov    %rsi,%r12
   345a9:	mov    %rdx,%rsi
   345ac:	push   %rbx
   345ad:	shl    $0x4,%rsi
   345b1:	test   %rdx,%rdx
   345b4:	je     348e6 <hs_tb16_balS+0x376>
   345ba:	lea    (%rdi,%r9,1),%rax
   345be:	mov    %rdx,%r10
   345c1:	lea    (%rdx,%rdx,4),%r8
   345c5:	neg    %r9
   345c8:	vmovq  %rax,%xmm14
   345cd:	lea    -0x1(%rdx),%rax
   345d1:	neg    %r10
   345d4:	xor    %ebx,%ebx
   345d6:	shr    $0x4,%rax
   345da:	lea    (%rdi,%r8,8),%r15
   345de:	shl    $0x2,%r10
   345e2:	lea    0x40(%rdi),%r14
   345e6:	lea    (%rdx,%rax,8),%r13
   345ea:	shl    $0x2,%r8
   345ee:	add    %r13,%r13
   345f1:	lea    0x0(,%rbx,4),%rdx
   345f9:	vmovq  %xmm14,%rax
   345fe:	lea    (%rbx,%r13,1),%rdi
   34602:	add    %rdx,%rax
   34605:	lea    (%r14,%rdi,4),%rdi
   34609:	add    %r15,%rdx
   3460c:	nopl   0x0(%rax)
   34610:	vmovups (%rax,%r9,1),%zmm3
   34617:	vmovups (%rax,%r10,1),%zmm8
   3461e:	vsubps (%rax,%r10,1),%zmm3,%zmm18
   34625:	vmovups (%rax,%rcx,4),%zmm2
   3462c:	vfmadd132ps %zmm0,%zmm3,%zmm8
   34632:	vmovups (%rax),%zmm3
   34638:	vmovups (%rax,%r8,1),%zmm1
   3463f:	vsubps (%rax,%rcx,4),%zmm3,%zmm21
   34646:	vmovups (%rax,%rcx,8),%zmm6
   3464d:	vfmadd132ps %zmm0,%zmm3,%zmm2
   34653:	vmovups (%rax,%rsi,1),%zmm3
   3465a:	vmovups (%rdx,%r9,1),%zmm4
   34661:	vsubps (%rax,%r8,1),%zmm3,%zmm13
   34668:	vmovups (%rax,%r11,1),%zmm5
   3466f:	vfmadd132ps %zmm0,%zmm3,%zmm1
   34675:	vmovups (%rdx,%r10,1),%zmm3
   3467c:	vsubps (%rax,%r11,1),%zmm6,%zmm11
   34683:	vsubps %zmm21,%zmm18,%zmm17
   34689:	vsubps (%rdx,%r10,1),%zmm4,%zmm10
   34690:	vfmadd132ps %zmm0,%zmm6,%zmm5
   34696:	vmovups (%rdx),%zmm6
   3469c:	vfmadd132ps %zmm0,%zmm4,%zmm3
   346a2:	vmovups (%rdx,%rcx,4),%zmm4
   346a9:	vsubps (%rdx,%rcx,4),%zmm6,%zmm9
   346b0:	vmovups (%rdx,%rcx,8),%zmm7
   346b7:	vsubps (%rdx,%r11,1),%zmm7,%zmm16
   346be:	vsubps %zmm13,%zmm11,%zmm19
   346c4:	vfmadd132ps %zmm0,%zmm18,%zmm21
   346ca:	vfmadd132ps %zmm0,%zmm6,%zmm4
   346d0:	vmovups (%rdx,%r11,1),%zmm6
   346d7:	vsubps %zmm2,%zmm8,%zmm15
   346dd:	vsubps %zmm9,%zmm10,%zmm18
   346e3:	vfmadd132ps %zmm0,%zmm8,%zmm2
   346e9:	vfmadd132ps %zmm0,%zmm7,%zmm6
   346ef:	vmovups (%rdx,%rsi,1),%zmm7
   346f6:	vsubps (%rdx,%r8,1),%zmm7,%zmm12
   346fd:	vsubps %zmm1,%zmm5,%zmm20
   34703:	vmovups (%rdx,%r8,1),%zmm7
   3470a:	vfmadd213ps (%rdx,%rsi,1),%zmm0,%zmm7
   34711:	vfmadd132ps %zmm0,%zmm5,%zmm1
   34717:	vmovaps %zmm13,%zmm5
   3471d:	vfmadd132ps %zmm0,%zmm11,%zmm5
   34723:	vfmadd132ps %zmm0,%zmm10,%zmm9
   34729:	vsubps %zmm4,%zmm3,%zmm8
   3472f:	vsubps %zmm12,%zmm16,%zmm10
   34735:	vfmadd132ps %zmm0,%zmm3,%zmm4
   3473b:	vfmadd132ps %zmm0,%zmm16,%zmm12
   34741:	vsubps %zmm7,%zmm6,%zmm11
   34747:	vfmadd132ps %zmm0,%zmm6,%zmm7
   3474d:	vmovaps %zmm20,%zmm6
   34753:	vsubps %zmm5,%zmm21,%zmm3
   34759:	vsubps %zmm1,%zmm2,%zmm16
   3475f:	vfmadd132ps %zmm0,%zmm15,%zmm6
   34765:	vfmadd132ps %zmm0,%zmm2,%zmm1
   3476b:	vsubps %zmm20,%zmm15,%zmm2
   34771:	vsubps %zmm19,%zmm17,%zmm15
   34777:	vmovaps %zmm7,%zmm13
   3477d:	vmovaps %zmm5,%zmm7
   34783:	vmovaps %zmm19,%zmm5
   34789:	vfmadd132ps %zmm0,%zmm17,%zmm5
   3478f:	vsubps %zmm12,%zmm9,%zmm19
   34795:	vsubps %zmm13,%zmm4,%zmm17
   3479b:	vfmadd132ps %zmm0,%zmm9,%zmm12
   347a1:	vfmadd132ps %zmm0,%zmm4,%zmm13
   347a7:	vsubps %zmm11,%zmm8,%zmm9
   347ad:	vfmadd132ps %zmm0,%zmm8,%zmm11
   347b3:	vsubps %zmm10,%zmm18,%zmm8
   347b9:	vfmadd132ps %zmm0,%zmm18,%zmm10
   347bf:	vfmadd132ps %zmm0,%zmm21,%zmm7
   347c5:	vmovaps %zmm19,%zmm20
   347cb:	vmovaps %zmm17,%zmm21
   347d1:	vmovaps %zmm9,%zmm18
   347d7:	vmovaps %zmm8,%zmm4
   347dd:	vfmadd132ps %zmm0,%zmm3,%zmm20
   347e3:	vsubps %zmm19,%zmm3,%zmm3
   347e9:	vmovaps %zmm13,%zmm25
   347ef:	vmovaps %zmm12,%zmm24
   347f5:	vmovaps %zmm11,%zmm23
   347fb:	vfmadd132ps %zmm0,%zmm1,%zmm25
   34801:	vsubps %zmm13,%zmm1,%zmm1
   34807:	vmovaps %zmm10,%zmm22
   3480d:	vfmadd132ps %zmm0,%zmm7,%zmm24
   34813:	vsubps %zmm12,%zmm7,%zmm7
   34819:	vfmadd132ps %zmm0,%zmm6,%zmm23
   3481f:	vfmadd132ps %zmm0,%zmm5,%zmm22
   34825:	vsubps %zmm11,%zmm6,%zmm6
   3482b:	vfmadd132ps %zmm0,%zmm2,%zmm18
   34831:	vfmadd132ps %zmm0,%zmm15,%zmm4
   34837:	vsubps %zmm10,%zmm5,%zmm5
   3483d:	vfmadd132ps %zmm0,%zmm16,%zmm21
   34843:	vsubps %zmm9,%zmm2,%zmm2
   34849:	vmovups %zmm25,(%rax,%r9,1)
   34850:	vmovups %zmm24,(%rax,%r10,1)
   34857:	vmovups %zmm23,(%rax)
   3485d:	vmovups %zmm22,(%rax,%rcx,4)
   34864:	vmovups %zmm21,(%rax,%rcx,8)
   3486b:	add    $0x40,%rax
   3486f:	vmovups %zmm20,-0x40(%rax,%r11,1)
   34877:	vmovups %zmm18,-0x40(%rax,%rsi,1)
   3487f:	vmovups %zmm4,-0x40(%rax,%r8,1)
   34887:	vsubps %zmm17,%zmm16,%zmm4
   3488d:	vmovups %zmm1,(%rdx,%r9,1)
   34894:	vsubps %zmm8,%zmm15,%zmm1
   3489a:	vmovups %zmm7,(%rdx,%r10,1)
   348a1:	vmovups %zmm6,(%rdx)
   348a7:	vmovups %zmm5,(%rdx,%rcx,4)
   348ae:	vmovups %zmm4,(%rdx,%rcx,8)
   348b5:	add    $0x40,%rdx
   348b9:	vmovups %zmm3,-0x40(%rdx,%r11,1)
   348c1:	vmovups %zmm2,-0x40(%rdx,%rsi,1)
   348c9:	vmovups %zmm1,-0x40(%rdx,%r8,1)
   348d1:	cmp    %rdi,%rax
   348d4:	jne    34610 <hs_tb16_balS+0xa0>
   348da:	add    %rsi,%rbx
   348dd:	cmp    %r12,%rbx
   348e0:	jb     345f1 <hs_tb16_balS+0x81>
   348e6:	vzeroupper
   348e9:	pop    %rbx
   348ea:	pop    %r12
   348ec:	pop    %r13
   348ee:	pop    %r14
   348f0:	pop    %r15
   348f2:	pop    %rbp
   348f3:	ret
   348f4:	vzeroupper
   348f7:	ret
   348f8:	nopl   0x0(%rax,%rax,1)

0000000000037920 <hf2_g19_nat>:
   37920:	endbr64
   37924:	vbroadcastss 0x266d2(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   3792e:	test   %rsi,%rsi
   37931:	je     37cc5 <hf2_g19_nat+0x3a5>
   37937:	mov    $0xffffaaaa,%ecx
   3793c:	mov    %rdi,%rax
   3793f:	lea    -0x4(,%rsi,4),%rdx
   37947:	vmovdqa32 0x264af(%rip),%zmm7        # 5de00 <_IO_stdin_used+0xe00>
   37951:	kmovw  %ecx,%k4
   37955:	mov    $0xffffcccc,%ecx
   3795a:	and    $0xfffffffffffffe00,%rdx
   37961:	vmovdqa32 0x264d5(%rip),%zmm6        # 5de40 <_IO_stdin_used+0xe40>
   3796b:	kmovw  %ecx,%k3
   3796f:	mov    $0xfffff0f0,%ecx
   37974:	vmovdqa32 0x26502(%rip),%zmm5        # 5de80 <_IO_stdin_used+0xe80>
   3797e:	vmovdqa32 0x26538(%rip),%zmm4        # 5dec0 <_IO_stdin_used+0xec0>
   37988:	vbroadcastss 0x25676(%rip),%zmm0        # 5d008 <_IO_stdin_used+0x8>
   37992:	kmovw  %ecx,%k2
   37996:	lea    0x200(%rdi,%rdx,1),%rdx
   3799e:	mov    $0xffffff00,%ecx
   379a3:	kmovw  %ecx,%k1
   379a7:	nopw   0x0(%rax,%rax,1)
   379b0:	vpermps (%rax),%zmm7,%zmm2
   379b6:	vaddps (%rax),%zmm2,%zmm1
   379bc:	add    $0x200,%rax
   379c2:	vsubps -0x200(%rax),%zmm2,%zmm1{%k4}
   379c9:	vpermps %zmm1,%zmm6,%zmm3
   379cf:	vaddps %zmm3,%zmm1,%zmm2
   379d5:	vsubps %zmm1,%zmm3,%zmm2{%k3}
   379db:	vpermps %zmm2,%zmm5,%zmm3
   379e1:	vaddps %zmm3,%zmm2,%zmm1
   379e7:	vsubps %zmm2,%zmm3,%zmm1{%k2}
   379ed:	vpermps %zmm1,%zmm4,%zmm2
   379f3:	vaddps %zmm2,%zmm1,%zmm3
   379f9:	vsubps %zmm1,%zmm2,%zmm3{%k1}
   379ff:	vpermps -0x1c0(%rax),%zmm7,%zmm1
   37a06:	vaddps -0x1c0(%rax),%zmm1,%zmm2
   37a0d:	vsubps -0x1c0(%rax),%zmm1,%zmm2{%k4}
   37a14:	vpermps %zmm2,%zmm6,%zmm8
   37a1a:	vaddps %zmm8,%zmm2,%zmm1
   37a20:	vsubps %zmm2,%zmm8,%zmm1{%k3}
   37a26:	vpermps %zmm1,%zmm5,%zmm8
   37a2c:	vaddps %zmm8,%zmm1,%zmm2
   37a32:	vsubps %zmm1,%zmm8,%zmm2{%k2}
   37a38:	vpermps %zmm2,%zmm4,%zmm8
   37a3e:	vaddps %zmm8,%zmm2,%zmm1
   37a44:	vsubps %zmm2,%zmm8,%zmm1{%k1}
   37a4a:	vpermps -0x180(%rax),%zmm7,%zmm2
   37a51:	vmovaps %zmm1,%zmm9
   37a57:	vaddps -0x180(%rax),%zmm2,%zmm1
   37a5e:	vsubps -0x180(%rax),%zmm2,%zmm1{%k4}
   37a65:	vpermps %zmm1,%zmm6,%zmm8
   37a6b:	vaddps %zmm8,%zmm1,%zmm2
   37a71:	vsubps %zmm1,%zmm8,%zmm2{%k3}
   37a77:	vpermps %zmm2,%zmm5,%zmm8
   37a7d:	vaddps %zmm8,%zmm2,%zmm1
   37a83:	vsubps %zmm2,%zmm8,%zmm1{%k2}
   37a89:	vpermps %zmm1,%zmm4,%zmm8
   37a8f:	vaddps %zmm8,%zmm1,%zmm2
   37a95:	vsubps %zmm1,%zmm8,%zmm2{%k1}
   37a9b:	vpermps -0x140(%rax),%zmm7,%zmm8
   37aa2:	vaddps -0x140(%rax),%zmm8,%zmm1
   37aa9:	vsubps -0x140(%rax),%zmm8,%zmm1{%k4}
   37ab0:	vpermps %zmm1,%zmm6,%zmm10
   37ab6:	vaddps %zmm10,%zmm1,%zmm8
   37abc:	vsubps %zmm1,%zmm10,%zmm8{%k3}
   37ac2:	vpermps %zmm8,%zmm5,%zmm10
   37ac8:	vaddps %zmm10,%zmm8,%zmm1
   37ace:	vsubps %zmm8,%zmm10,%zmm1{%k2}
   37ad4:	vpermps %zmm1,%zmm4,%zmm10
   37ada:	vaddps %zmm10,%zmm1,%zmm8
   37ae0:	vsubps %zmm1,%zmm10,%zmm8{%k1}
   37ae6:	vpermps -0x100(%rax),%zmm7,%zmm10
   37aed:	vaddps -0x100(%rax),%zmm10,%zmm1
   37af4:	vsubps -0x100(%rax),%zmm10,%zmm1{%k4}
   37afb:	vpermps %zmm1,%zmm6,%zmm11
   37b01:	vaddps %zmm11,%zmm1,%zmm10
   37b07:	vsubps %zmm1,%zmm11,%zmm10{%k3}
   37b0d:	vpermps %zmm10,%zmm5,%zmm11
   37b13:	vaddps %zmm11,%zmm10,%zmm1
   37b19:	vsubps %zmm10,%zmm11,%zmm1{%k2}
   37b1f:	vpermps %zmm1,%zmm4,%zmm11
   37b25:	vaddps %zmm11,%zmm1,%zmm10
   37b2b:	vsubps %zmm1,%zmm11,%zmm10{%k1}
   37b31:	vpermps -0xc0(%rax),%zmm7,%zmm11
   37b38:	vaddps -0xc0(%rax),%zmm11,%zmm1
   37b3f:	vsubps -0xc0(%rax),%zmm11,%zmm1{%k4}
   37b46:	vpermps %zmm1,%zmm6,%zmm12
   37b4c:	vaddps %zmm12,%zmm1,%zmm11
   37b52:	vsubps %zmm1,%zmm12,%zmm11{%k3}
   37b58:	vpermps %zmm11,%zmm5,%zmm12
   37b5e:	vaddps %zmm12,%zmm11,%zmm1
   37b64:	vsubps %zmm11,%zmm12,%zmm1{%k2}
   37b6a:	vpermps %zmm1,%zmm4,%zmm11
   37b70:	vaddps %zmm11,%zmm1,%zmm12
   37b76:	vsubps %zmm1,%zmm11,%zmm12{%k1}
   37b7c:	vpermps -0x80(%rax),%zmm7,%zmm11
   37b83:	vaddps -0x80(%rax),%zmm11,%zmm1
   37b8a:	vsubps -0x80(%rax),%zmm11,%zmm1{%k4}
   37b91:	vsubps %zmm12,%zmm2,%zmm2
   37b97:	vpermps %zmm1,%zmm6,%zmm13
   37b9d:	vaddps %zmm13,%zmm1,%zmm11
   37ba3:	vsubps %zmm1,%zmm13,%zmm11{%k3}
   37ba9:	vpermps %zmm11,%zmm5,%zmm13
   37baf:	vaddps %zmm13,%zmm11,%zmm1
   37bb5:	vsubps %zmm11,%zmm13,%zmm1{%k2}
   37bbb:	vpermps %zmm1,%zmm4,%zmm13
   37bc1:	vaddps %zmm13,%zmm1,%zmm11
   37bc7:	vsubps %zmm1,%zmm13,%zmm11{%k1}
   37bcd:	vpermps -0x40(%rax),%zmm7,%zmm1
   37bd4:	vaddps -0x40(%rax),%zmm1,%zmm13
   37bdb:	vsubps -0x40(%rax),%zmm1,%zmm13{%k4}
   37be2:	vpermps %zmm13,%zmm6,%zmm14
   37be8:	vaddps %zmm13,%zmm14,%zmm1
   37bee:	vsubps %zmm13,%zmm14,%zmm1{%k3}
   37bf4:	vpermps %zmm1,%zmm5,%zmm14
   37bfa:	vaddps %zmm14,%zmm1,%zmm13
   37c00:	vsubps %zmm1,%zmm14,%zmm13{%k2}
   37c06:	vpermps %zmm13,%zmm4,%zmm14
   37c0c:	vaddps %zmm13,%zmm14,%zmm1
   37c12:	vsubps %zmm13,%zmm14,%zmm1{%k1}
   37c18:	vsubps %zmm10,%zmm8,%zmm13
   37c1e:	vaddps %zmm11,%zmm9,%zmm14
   37c24:	vaddps %zmm3,%zmm1,%zmm3
   37c2a:	vaddps %zmm13,%zmm2,%zmm16
   37c30:	vsubps %zmm14,%zmm3,%zmm15
   37c36:	vsubps %zmm16,%zmm15,%zmm17
   37c3c:	vfnmadd132ps %zmm0,%zmm17,%zmm1
   37c42:	vfnmadd132ps %zmm0,%zmm17,%zmm12
   37c48:	vfmadd132ps %zmm0,%zmm1,%zmm11
   37c4e:	vfnmadd132ps %zmm0,%zmm12,%zmm10
   37c54:	vfmadd132ps %zmm0,%zmm12,%zmm8
   37c5a:	vfmadd231ps %zmm0,%zmm9,%zmm1
   37c60:	vfmadd132ps %zmm0,%zmm11,%zmm13
   37c66:	vfmadd132ps %zmm0,%zmm11,%zmm2
   37c6c:	vfmsub132ps %zmm0,%zmm8,%zmm15
   37c72:	vfmadd132ps %zmm0,%zmm10,%zmm14
   37c78:	vmovups %zmm1,-0x180(%rax)
   37c7f:	vfmadd132ps %zmm0,%zmm1,%zmm16
   37c85:	vfmsub132ps %zmm0,%zmm10,%zmm3
   37c8b:	vmovups %zmm8,-0x140(%rax)
   37c92:	vmovups %zmm2,-0x1c0(%rax)
   37c99:	vmovups %zmm15,-0xc0(%rax)
   37ca0:	vmovups %zmm3,-0x200(%rax)
   37ca7:	vmovups %zmm16,-0x100(%rax)
   37cae:	vmovups %zmm14,-0x80(%rax)
   37cb5:	vmovups %zmm13,-0x40(%rax)
   37cbc:	cmp    %rdx,%rax
   37cbf:	jne    379b0 <hf2_g19_nat+0x90>
   37cc5:	vzeroupper
   37cc8:	ret
   37cc9:	nopl   0x0(%rax)

0000000000037cd0 <hf2_h20_nat>:
   37cd0:	endbr64
   37cd4:	vbroadcastss 0x26322(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   37cde:	test   %rsi,%rsi
   37ce1:	je     3806f <hf2_h20_nat+0x39f>
   37ce7:	mov    $0xffffaaaa,%ecx
   37cec:	mov    %rdi,%rax
   37cef:	lea    -0x4(,%rsi,4),%rdx
   37cf7:	vmovdqa32 0x260ff(%rip),%zmm7        # 5de00 <_IO_stdin_used+0xe00>
   37d01:	kmovw  %ecx,%k4
   37d05:	mov    $0xffffcccc,%ecx
   37d0a:	and    $0xfffffffffffffe00,%rdx
   37d11:	vmovdqa32 0x26125(%rip),%zmm6        # 5de40 <_IO_stdin_used+0xe40>
   37d1b:	kmovw  %ecx,%k3
   37d1f:	mov    $0xfffff0f0,%ecx
   37d24:	vmovdqa32 0x26152(%rip),%zmm5        # 5de80 <_IO_stdin_used+0xe80>
   37d2e:	vmovdqa32 0x26188(%rip),%zmm4        # 5dec0 <_IO_stdin_used+0xec0>
   37d38:	vbroadcastss 0x252c2(%rip),%zmm10        # 5d004 <_IO_stdin_used+0x4>
   37d42:	kmovw  %ecx,%k2
   37d46:	lea    0x200(%rdi,%rdx,1),%rdx
   37d4e:	mov    $0xffffff00,%ecx
   37d53:	kmovw  %ecx,%k1
   37d57:	nopw   0x0(%rax,%rax,1)
   37d60:	vpermps (%rax),%zmm7,%zmm1
   37d66:	vaddps (%rax),%zmm1,%zmm0
   37d6c:	add    $0x200,%rax
   37d72:	vsubps -0x200(%rax),%zmm1,%zmm0{%k4}
   37d79:	vpermps %zmm0,%zmm6,%zmm2
   37d7f:	vaddps %zmm2,%zmm0,%zmm1
   37d85:	vsubps %zmm0,%zmm2,%zmm1{%k3}
   37d8b:	vpermps %zmm1,%zmm5,%zmm2
   37d91:	vaddps %zmm2,%zmm1,%zmm0
   37d97:	vsubps %zmm1,%zmm2,%zmm0{%k2}
   37d9d:	vpermps %zmm0,%zmm4,%zmm1
   37da3:	vaddps %zmm1,%zmm0,%zmm3
   37da9:	vsubps %zmm0,%zmm1,%zmm3{%k1}
   37daf:	vpermps -0x1c0(%rax),%zmm7,%zmm1
   37db6:	vaddps -0x1c0(%rax),%zmm1,%zmm0
   37dbd:	vsubps -0x1c0(%rax),%zmm1,%zmm0{%k4}
   37dc4:	vpermps %zmm0,%zmm6,%zmm2
   37dca:	vaddps %zmm2,%zmm0,%zmm1
   37dd0:	vsubps %zmm0,%zmm2,%zmm1{%k3}
   37dd6:	vpermps %zmm1,%zmm5,%zmm2
   37ddc:	vaddps %zmm2,%zmm1,%zmm0
   37de2:	vsubps %zmm1,%zmm2,%zmm0{%k2}
   37de8:	vpermps %zmm0,%zmm4,%zmm1
   37dee:	vaddps %zmm1,%zmm0,%zmm11
   37df4:	vsubps %zmm0,%zmm1,%zmm11{%k1}
   37dfa:	vpermps -0x180(%rax),%zmm7,%zmm1
   37e01:	vaddps -0x180(%rax),%zmm1,%zmm0
   37e08:	vsubps -0x180(%rax),%zmm1,%zmm0{%k4}
   37e0f:	vpermps %zmm0,%zmm6,%zmm2
   37e15:	vaddps %zmm2,%zmm0,%zmm1
   37e1b:	vsubps %zmm0,%zmm2,%zmm1{%k3}
   37e21:	vpermps %zmm1,%zmm5,%zmm2
   37e27:	vaddps %zmm2,%zmm1,%zmm0
   37e2d:	vsubps %zmm1,%zmm2,%zmm0{%k2}
   37e33:	vpermps %zmm0,%zmm4,%zmm1
   37e39:	vaddps %zmm1,%zmm0,%zmm2
   37e3f:	vsubps %zmm0,%zmm1,%zmm2{%k1}
   37e45:	vpermps -0x140(%rax),%zmm7,%zmm1
   37e4c:	vaddps -0x140(%rax),%zmm1,%zmm0
   37e53:	vsubps -0x140(%rax),%zmm1,%zmm0{%k4}
   37e5a:	vpermps %zmm0,%zmm6,%zmm8
   37e60:	vaddps %zmm8,%zmm0,%zmm1
   37e66:	vsubps %zmm0,%zmm8,%zmm1{%k3}
   37e6c:	vpermps %zmm1,%zmm5,%zmm8
   37e72:	vaddps %zmm8,%zmm1,%zmm0
   37e78:	vsubps %zmm1,%zmm8,%zmm0{%k2}
   37e7e:	vpermps %zmm0,%zmm4,%zmm1
   37e84:	vaddps %zmm1,%zmm0,%zmm12
   37e8a:	vsubps %zmm0,%zmm1,%zmm12{%k1}
   37e90:	vpermps -0x100(%rax),%zmm7,%zmm1
   37e97:	vaddps -0x100(%rax),%zmm1,%zmm0
   37e9e:	vsubps -0x100(%rax),%zmm1,%zmm0{%k4}
   37ea5:	vpermps %zmm0,%zmm6,%zmm8
   37eab:	vaddps %zmm8,%zmm0,%zmm1
   37eb1:	vsubps %zmm0,%zmm8,%zmm1{%k3}
   37eb7:	vpermps %zmm1,%zmm5,%zmm8
   37ebd:	vaddps %zmm8,%zmm1,%zmm0
   37ec3:	vsubps %zmm1,%zmm8,%zmm0{%k2}
   37ec9:	vpermps %zmm0,%zmm4,%zmm1
   37ecf:	vaddps %zmm1,%zmm0,%zmm9
   37ed5:	vsubps %zmm0,%zmm1,%zmm9{%k1}
   37edb:	vpermps -0xc0(%rax),%zmm7,%zmm1
   37ee2:	vaddps -0xc0(%rax),%zmm1,%zmm0
   37ee9:	vsubps -0xc0(%rax),%zmm1,%zmm0{%k4}
   37ef0:	vpermps %zmm0,%zmm6,%zmm8
   37ef6:	vaddps %zmm8,%zmm0,%zmm1
   37efc:	vsubps %zmm0,%zmm8,%zmm1{%k3}
   37f02:	vpermps %zmm1,%zmm5,%zmm8
   37f08:	vaddps %zmm8,%zmm1,%zmm0
   37f0e:	vsubps %zmm1,%zmm8,%zmm0{%k2}
   37f14:	vpermps %zmm0,%zmm4,%zmm1
   37f1a:	vaddps %zmm1,%zmm0,%zmm14
   37f20:	vsubps %zmm0,%zmm1,%zmm14{%k1}
   37f26:	vpermps -0x80(%rax),%zmm7,%zmm1
   37f2d:	vaddps -0x80(%rax),%zmm1,%zmm0
   37f34:	vsubps -0x80(%rax),%zmm1,%zmm0{%k4}
   37f3b:	vsubps %zmm14,%zmm2,%zmm2
   37f41:	vpermps %zmm0,%zmm6,%zmm8
   37f47:	vaddps %zmm8,%zmm0,%zmm1
   37f4d:	vsubps %zmm0,%zmm8,%zmm1{%k3}
   37f53:	vpermps %zmm1,%zmm5,%zmm8
   37f59:	vaddps %zmm8,%zmm1,%zmm0
   37f5f:	vsubps %zmm1,%zmm8,%zmm0{%k2}
   37f65:	vpermps %zmm0,%zmm4,%zmm1
   37f6b:	vaddps %zmm1,%zmm0,%zmm8
   37f71:	vsubps %zmm0,%zmm1,%zmm8{%k1}
   37f77:	vpermps -0x40(%rax),%zmm7,%zmm0
   37f7e:	vaddps -0x40(%rax),%zmm0,%zmm1
   37f85:	vsubps -0x40(%rax),%zmm0,%zmm1{%k4}
   37f8c:	vaddps %zmm8,%zmm11,%zmm15
   37f92:	vpermps %zmm1,%zmm6,%zmm13
   37f98:	vaddps %zmm1,%zmm13,%zmm0
   37f9e:	vsubps %zmm1,%zmm13,%zmm0{%k3}
   37fa4:	vpermps %zmm0,%zmm5,%zmm13
   37faa:	vaddps %zmm13,%zmm0,%zmm1
   37fb0:	vsubps %zmm0,%zmm13,%zmm1{%k2}
   37fb6:	vpermps %zmm1,%zmm4,%zmm13
   37fbc:	vaddps %zmm1,%zmm13,%zmm0
   37fc2:	vsubps %zmm1,%zmm13,%zmm0{%k1}
   37fc8:	vsubps %zmm9,%zmm12,%zmm13
   37fce:	vaddps %zmm3,%zmm0,%zmm3
   37fd4:	vaddps %zmm13,%zmm2,%zmm17
   37fda:	vsubps %zmm15,%zmm3,%zmm16
   37fe0:	vsubps %zmm17,%zmm16,%zmm1
   37fe6:	vfmsub231ps %zmm10,%zmm1,%zmm0
   37fec:	vfmsub132ps %zmm10,%zmm14,%zmm1
   37ff2:	vaddps %zmm8,%zmm0,%zmm8
   37ff8:	vsubps %zmm9,%zmm1,%zmm9
   37ffe:	vaddps %zmm11,%zmm0,%zmm0
   38004:	vaddps %zmm12,%zmm1,%zmm1
   3800a:	vsubps %zmm9,%zmm3,%zmm3
   38010:	vaddps %zmm8,%zmm2,%zmm2
   38016:	vaddps %zmm0,%zmm17,%zmm17
   3801c:	vsubps %zmm1,%zmm16,%zmm16
   38022:	vmovups %zmm0,-0x180(%rax)
   38029:	vaddps %zmm9,%zmm15,%zmm15
   3802f:	vaddps %zmm8,%zmm13,%zmm13
   38035:	vmovups %zmm1,-0x140(%rax)
   3803c:	vmovups %zmm3,-0x200(%rax)
   38043:	vmovups %zmm2,-0x1c0(%rax)
   3804a:	vmovups %zmm17,-0x100(%rax)
   38051:	vmovups %zmm16,-0xc0(%rax)
   38058:	vmovups %zmm15,-0x80(%rax)
   3805f:	vmovups %zmm13,-0x40(%rax)
   38066:	cmp    %rdx,%rax
   38069:	jne    37d60 <hf2_h20_nat+0x90>
   3806f:	vzeroupper
   38072:	ret
   38073:	data16 cs nopw 0x0(%rax,%rax,1)
   3807e:	xchg   %ax,%ax

0000000000038080 <hf2_g20_nat>:
   38080:	endbr64
   38084:	vbroadcastss 0x25f72(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   3808e:	test   %rsi,%rsi
   38091:	je     38425 <hf2_g20_nat+0x3a5>
   38097:	mov    $0xffffaaaa,%ecx
   3809c:	mov    %rdi,%rax
   3809f:	lea    -0x4(,%rsi,4),%rdx
   380a7:	vmovdqa32 0x25d4f(%rip),%zmm12        # 5de00 <_IO_stdin_used+0xe00>
   380b1:	kmovw  %ecx,%k4
   380b5:	mov    $0xffffcccc,%ecx
   380ba:	and    $0xfffffffffffffe00,%rdx
   380c1:	vmovdqa32 0x25d75(%rip),%zmm11        # 5de40 <_IO_stdin_used+0xe40>
   380cb:	kmovw  %ecx,%k3
   380cf:	mov    $0xfffff0f0,%ecx
   380d4:	vmovdqa32 0x25da2(%rip),%zmm10        # 5de80 <_IO_stdin_used+0xe80>
   380de:	vmovdqa32 0x25dd8(%rip),%zmm9        # 5dec0 <_IO_stdin_used+0xec0>
   380e8:	vbroadcastss 0x24f16(%rip),%zmm0        # 5d008 <_IO_stdin_used+0x8>
   380f2:	kmovw  %ecx,%k2
   380f6:	lea    0x200(%rdi,%rdx,1),%rdx
   380fe:	mov    $0xffffff00,%ecx
   38103:	kmovw  %ecx,%k1
   38107:	nopw   0x0(%rax,%rax,1)
   38110:	vpermps (%rax),%zmm12,%zmm2
   38116:	vaddps (%rax),%zmm2,%zmm1
   3811c:	add    $0x200,%rax
   38122:	vsubps -0x200(%rax),%zmm2,%zmm1{%k4}
   38129:	vpermps %zmm1,%zmm11,%zmm3
   3812f:	vaddps %zmm3,%zmm1,%zmm2
   38135:	vsubps %zmm1,%zmm3,%zmm2{%k3}
   3813b:	vpermps %zmm2,%zmm10,%zmm3
   38141:	vaddps %zmm3,%zmm2,%zmm1
   38147:	vsubps %zmm2,%zmm3,%zmm1{%k2}
   3814d:	vpermps %zmm1,%zmm9,%zmm2
   38153:	vaddps %zmm2,%zmm1,%zmm4
   38159:	vsubps %zmm1,%zmm2,%zmm4{%k1}
   3815f:	vpermps -0x1c0(%rax),%zmm12,%zmm2
   38166:	vaddps -0x1c0(%rax),%zmm2,%zmm1
   3816d:	vsubps -0x1c0(%rax),%zmm2,%zmm1{%k4}
   38174:	vpermps %zmm1,%zmm11,%zmm3
   3817a:	vaddps %zmm3,%zmm1,%zmm2
   38180:	vsubps %zmm1,%zmm3,%zmm2{%k3}
   38186:	vpermps %zmm2,%zmm10,%zmm3
   3818c:	vaddps %zmm3,%zmm2,%zmm1
   38192:	vsubps %zmm2,%zmm3,%zmm1{%k2}
   38198:	vpermps %zmm1,%zmm9,%zmm2
   3819e:	vaddps %zmm2,%zmm1,%zmm3
   381a4:	vsubps %zmm1,%zmm2,%zmm3{%k1}
   381aa:	vpermps -0x180(%rax),%zmm12,%zmm2
   381b1:	vaddps -0x180(%rax),%zmm2,%zmm1
   381b8:	vsubps -0x180(%rax),%zmm2,%zmm1{%k4}
   381bf:	vaddps %zmm3,%zmm4,%zmm3
   381c5:	vpermps %zmm1,%zmm11,%zmm5
   381cb:	vaddps %zmm5,%zmm1,%zmm2
   381d1:	vsubps %zmm1,%zmm5,%zmm2{%k3}
   381d7:	vpermps %zmm2,%zmm10,%zmm5
   381dd:	vaddps %zmm5,%zmm2,%zmm1
   381e3:	vsubps %zmm2,%zmm5,%zmm1{%k2}
   381e9:	vpermps %zmm1,%zmm9,%zmm2
   381ef:	vaddps %zmm2,%zmm1,%zmm8
   381f5:	vsubps %zmm1,%zmm2,%zmm8{%k1}
   381fb:	vpermps -0x140(%rax),%zmm12,%zmm2
   38202:	vaddps -0x140(%rax),%zmm2,%zmm1
   38209:	vsubps -0x140(%rax),%zmm2,%zmm1{%k4}
   38210:	vpermps %zmm1,%zmm11,%zmm5
   38216:	vaddps %zmm5,%zmm1,%zmm2
   3821c:	vsubps %zmm1,%zmm5,%zmm2{%k3}
   38222:	vpermps %zmm2,%zmm10,%zmm5
   38228:	vaddps %zmm5,%zmm2,%zmm1
   3822e:	vsubps %zmm2,%zmm5,%zmm1{%k2}
   38234:	vpermps %zmm1,%zmm9,%zmm2
   3823a:	vaddps %zmm2,%zmm1,%zmm6
   38240:	vsubps %zmm1,%zmm2,%zmm6{%k1}
   38246:	vpermps -0x100(%rax),%zmm12,%zmm2
   3824d:	vaddps -0x100(%rax),%zmm2,%zmm1
   38254:	vsubps -0x100(%rax),%zmm2,%zmm1{%k4}
   3825b:	vsubps %zmm6,%zmm8,%zmm6
   38261:	vpermps %zmm1,%zmm11,%zmm5
   38267:	vaddps %zmm5,%zmm1,%zmm2
   3826d:	vsubps %zmm1,%zmm5,%zmm2{%k3}
   38273:	vpermps %zmm2,%zmm10,%zmm5
   38279:	vaddps %zmm5,%zmm2,%zmm1
   3827f:	vsubps %zmm2,%zmm5,%zmm1{%k2}
   38285:	vpermps %zmm1,%zmm9,%zmm5
   3828b:	vaddps %zmm5,%zmm1,%zmm2
   38291:	vsubps %zmm1,%zmm5,%zmm2{%k1}
   38297:	vpermps -0xc0(%rax),%zmm12,%zmm5
   3829e:	vaddps -0xc0(%rax),%zmm5,%zmm1
   382a5:	vsubps -0xc0(%rax),%zmm5,%zmm1{%k4}
   382ac:	vpermps %zmm1,%zmm11,%zmm7
   382b2:	vaddps %zmm7,%zmm1,%zmm5
   382b8:	vsubps %zmm1,%zmm7,%zmm5{%k3}
   382be:	vpermps %zmm5,%zmm10,%zmm7
   382c4:	vaddps %zmm7,%zmm5,%zmm1
   382ca:	vsubps %zmm5,%zmm7,%zmm1{%k2}
   382d0:	vpermps %zmm1,%zmm9,%zmm7
   382d6:	vaddps %zmm7,%zmm1,%zmm5
   382dc:	vsubps %zmm1,%zmm7,%zmm5{%k1}
   382e2:	vpermps -0x80(%rax),%zmm12,%zmm7
   382e9:	vaddps -0x80(%rax),%zmm7,%zmm1
   382f0:	vsubps -0x80(%rax),%zmm7,%zmm1{%k4}
   382f7:	vaddps %zmm5,%zmm2,%zmm5
   382fd:	vpermps %zmm1,%zmm11,%zmm13
   38303:	vaddps %zmm13,%zmm1,%zmm7
   38309:	vsubps %zmm1,%zmm13,%zmm7{%k3}
   3830f:	vpermps %zmm7,%zmm10,%zmm13
   38315:	vaddps %zmm13,%zmm7,%zmm1
   3831b:	vsubps %zmm7,%zmm13,%zmm1{%k2}
   38321:	vpermps %zmm1,%zmm9,%zmm13
   38327:	vaddps %zmm13,%zmm1,%zmm7
   3832d:	vsubps %zmm1,%zmm13,%zmm7{%k1}
   38333:	vpermps -0x40(%rax),%zmm12,%zmm1
   3833a:	vaddps -0x40(%rax),%zmm1,%zmm13
   38341:	vsubps -0x40(%rax),%zmm1,%zmm13{%k4}
   38348:	vpermps %zmm13,%zmm11,%zmm14
   3834e:	vaddps %zmm13,%zmm14,%zmm1
   38354:	vsubps %zmm13,%zmm14,%zmm1{%k3}
   3835a:	vpermps %zmm1,%zmm10,%zmm14
   38360:	vaddps %zmm14,%zmm1,%zmm13
   38366:	vsubps %zmm1,%zmm14,%zmm13{%k2}
   3836c:	vpermps %zmm13,%zmm9,%zmm14
   38372:	vaddps %zmm13,%zmm14,%zmm1
   38378:	vsubps %zmm13,%zmm14,%zmm1{%k1}
   3837e:	vsubps %zmm6,%zmm3,%zmm13
   38384:	vsubps %zmm1,%zmm7,%zmm1
   3838a:	vfmadd132ps %zmm0,%zmm13,%zmm8
   38390:	vfmsub132ps %zmm0,%zmm13,%zmm4
   38396:	vaddps %zmm1,%zmm5,%zmm13
   3839c:	vfnmadd132ps %zmm0,%zmm13,%zmm7
   383a2:	vfmsub132ps %zmm0,%zmm13,%zmm2
   383a8:	vaddps %zmm7,%zmm8,%zmm13
   383ae:	vfnmadd132ps %zmm0,%zmm13,%zmm5
   383b4:	vfmsub132ps %zmm0,%zmm13,%zmm3
   383ba:	vaddps %zmm2,%zmm4,%zmm13
   383c0:	vfmadd132ps %zmm0,%zmm13,%zmm1
   383c6:	vfnmadd132ps %zmm0,%zmm13,%zmm6
   383cc:	vfmsub132ps %zmm0,%zmm5,%zmm8
   383d2:	vfmadd132ps %zmm0,%zmm3,%zmm7
   383d8:	vmovups %zmm5,-0x100(%rax)
   383df:	vmovups %zmm3,-0x80(%rax)
   383e6:	vfmsub132ps %zmm0,%zmm1,%zmm4
   383ec:	vfnmadd132ps %zmm0,%zmm6,%zmm2
   383f2:	vmovups %zmm1,-0x1c0(%rax)
   383f9:	vmovups %zmm6,-0x140(%rax)
   38400:	vmovups %zmm8,-0x200(%rax)
   38407:	vmovups %zmm7,-0x180(%rax)
   3840e:	vmovups %zmm4,-0xc0(%rax)
   38415:	vmovups %zmm2,-0x40(%rax)
   3841c:	cmp    %rdx,%rax
   3841f:	jne    38110 <hf2_g20_nat+0x90>
   38425:	vzeroupper
   38428:	ret
   38429:	nopl   0x0(%rax)

0000000000039a10 <hf2_broken_g20>:
   39a10:	endbr64
   39a14:	vbroadcastss 0x245e2(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   39a1e:	test   %rsi,%rsi
   39a21:	je     39db5 <hf2_broken_g20+0x3a5>
   39a27:	mov    $0xffffaaaa,%ecx
   39a2c:	mov    %rdi,%rax
   39a2f:	lea    -0x4(,%rsi,4),%rdx
   39a37:	vmovdqa32 0x243bf(%rip),%zmm12        # 5de00 <_IO_stdin_used+0xe00>
   39a41:	kmovw  %ecx,%k4
   39a45:	mov    $0xffffcccc,%ecx
   39a4a:	and    $0xfffffffffffffe00,%rdx
   39a51:	vmovdqa32 0x243e5(%rip),%zmm11        # 5de40 <_IO_stdin_used+0xe40>
   39a5b:	kmovw  %ecx,%k3
   39a5f:	mov    $0xfffff0f0,%ecx
   39a64:	vmovdqa32 0x24412(%rip),%zmm10        # 5de80 <_IO_stdin_used+0xe80>
   39a6e:	vmovdqa32 0x24448(%rip),%zmm9        # 5dec0 <_IO_stdin_used+0xec0>
   39a78:	vbroadcastss 0x23586(%rip),%zmm0        # 5d008 <_IO_stdin_used+0x8>
   39a82:	kmovw  %ecx,%k2
   39a86:	lea    0x200(%rdi,%rdx,1),%rdx
   39a8e:	mov    $0xffffff00,%ecx
   39a93:	kmovw  %ecx,%k1
   39a97:	nopw   0x0(%rax,%rax,1)
   39aa0:	vpermps (%rax),%zmm12,%zmm2
   39aa6:	vaddps (%rax),%zmm2,%zmm1
   39aac:	add    $0x200,%rax
   39ab2:	vsubps -0x200(%rax),%zmm2,%zmm1{%k4}
   39ab9:	vpermps %zmm1,%zmm11,%zmm3
   39abf:	vaddps %zmm3,%zmm1,%zmm2
   39ac5:	vsubps %zmm1,%zmm3,%zmm2{%k3}
   39acb:	vpermps %zmm2,%zmm10,%zmm3
   39ad1:	vaddps %zmm3,%zmm2,%zmm1
   39ad7:	vsubps %zmm2,%zmm3,%zmm1{%k2}
   39add:	vpermps %zmm1,%zmm9,%zmm2
   39ae3:	vaddps %zmm2,%zmm1,%zmm3
   39ae9:	vsubps %zmm1,%zmm2,%zmm3{%k1}
   39aef:	vpermps -0x1c0(%rax),%zmm12,%zmm2
   39af6:	vaddps -0x1c0(%rax),%zmm2,%zmm1
   39afd:	vsubps -0x1c0(%rax),%zmm2,%zmm1{%k4}
   39b04:	vpermps %zmm1,%zmm11,%zmm4
   39b0a:	vaddps %zmm4,%zmm1,%zmm2
   39b10:	vsubps %zmm1,%zmm4,%zmm2{%k3}
   39b16:	vpermps %zmm2,%zmm10,%zmm4
   39b1c:	vaddps %zmm4,%zmm2,%zmm1
   39b22:	vsubps %zmm2,%zmm4,%zmm1{%k2}
   39b28:	vpermps %zmm1,%zmm9,%zmm2
   39b2e:	vaddps %zmm2,%zmm1,%zmm4
   39b34:	vsubps %zmm1,%zmm2,%zmm4{%k1}
   39b3a:	vpermps -0x180(%rax),%zmm12,%zmm2
   39b41:	vaddps -0x180(%rax),%zmm2,%zmm1
   39b48:	vsubps -0x180(%rax),%zmm2,%zmm1{%k4}
   39b4f:	vaddps %zmm4,%zmm3,%zmm4
   39b55:	vpermps %zmm1,%zmm11,%zmm5
   39b5b:	vaddps %zmm5,%zmm1,%zmm2
   39b61:	vsubps %zmm1,%zmm5,%zmm2{%k3}
   39b67:	vpermps %zmm2,%zmm10,%zmm5
   39b6d:	vaddps %zmm5,%zmm2,%zmm1
   39b73:	vsubps %zmm2,%zmm5,%zmm1{%k2}
   39b79:	vpermps %zmm1,%zmm9,%zmm2
   39b7f:	vaddps %zmm2,%zmm1,%zmm8
   39b85:	vsubps %zmm1,%zmm2,%zmm8{%k1}
   39b8b:	vpermps -0x140(%rax),%zmm12,%zmm2
   39b92:	vaddps -0x140(%rax),%zmm2,%zmm1
   39b99:	vsubps -0x140(%rax),%zmm2,%zmm1{%k4}
   39ba0:	vpermps %zmm1,%zmm11,%zmm5
   39ba6:	vaddps %zmm5,%zmm1,%zmm2
   39bac:	vsubps %zmm1,%zmm5,%zmm2{%k3}
   39bb2:	vpermps %zmm2,%zmm10,%zmm5
   39bb8:	vaddps %zmm5,%zmm2,%zmm1
   39bbe:	vsubps %zmm2,%zmm5,%zmm1{%k2}
   39bc4:	vpermps %zmm1,%zmm9,%zmm2
   39bca:	vaddps %zmm2,%zmm1,%zmm6
   39bd0:	vsubps %zmm1,%zmm2,%zmm6{%k1}
   39bd6:	vpermps -0x100(%rax),%zmm12,%zmm2
   39bdd:	vaddps -0x100(%rax),%zmm2,%zmm1
   39be4:	vsubps -0x100(%rax),%zmm2,%zmm1{%k4}
   39beb:	vsubps %zmm6,%zmm8,%zmm6
   39bf1:	vpermps %zmm1,%zmm11,%zmm5
   39bf7:	vaddps %zmm5,%zmm1,%zmm2
   39bfd:	vsubps %zmm1,%zmm5,%zmm2{%k3}
   39c03:	vpermps %zmm2,%zmm10,%zmm5
   39c09:	vaddps %zmm5,%zmm2,%zmm1
   39c0f:	vsubps %zmm2,%zmm5,%zmm1{%k2}
   39c15:	vpermps %zmm1,%zmm9,%zmm5
   39c1b:	vaddps %zmm5,%zmm1,%zmm2
   39c21:	vsubps %zmm1,%zmm5,%zmm2{%k1}
   39c27:	vpermps -0xc0(%rax),%zmm12,%zmm5
   39c2e:	vaddps -0xc0(%rax),%zmm5,%zmm1
   39c35:	vsubps -0xc0(%rax),%zmm5,%zmm1{%k4}
   39c3c:	vpermps %zmm1,%zmm11,%zmm7
   39c42:	vaddps %zmm7,%zmm1,%zmm5
   39c48:	vsubps %zmm1,%zmm7,%zmm5{%k3}
   39c4e:	vpermps %zmm5,%zmm10,%zmm7
   39c54:	vaddps %zmm7,%zmm5,%zmm1
   39c5a:	vsubps %zmm5,%zmm7,%zmm1{%k2}
   39c60:	vpermps %zmm1,%zmm9,%zmm7
   39c66:	vaddps %zmm7,%zmm1,%zmm5
   39c6c:	vsubps %zmm1,%zmm7,%zmm5{%k1}
   39c72:	vpermps -0x80(%rax),%zmm12,%zmm7
   39c79:	vaddps -0x80(%rax),%zmm7,%zmm1
   39c80:	vsubps -0x80(%rax),%zmm7,%zmm1{%k4}
   39c87:	vaddps %zmm5,%zmm2,%zmm5
   39c8d:	vpermps %zmm1,%zmm11,%zmm13
   39c93:	vaddps %zmm13,%zmm1,%zmm7
   39c99:	vsubps %zmm1,%zmm13,%zmm7{%k3}
   39c9f:	vpermps %zmm7,%zmm10,%zmm13
   39ca5:	vaddps %zmm13,%zmm7,%zmm1
   39cab:	vsubps %zmm7,%zmm13,%zmm1{%k2}
   39cb1:	vpermps %zmm1,%zmm9,%zmm13
   39cb7:	vaddps %zmm13,%zmm1,%zmm7
   39cbd:	vsubps %zmm1,%zmm13,%zmm7{%k1}
   39cc3:	vpermps -0x40(%rax),%zmm12,%zmm1
   39cca:	vaddps -0x40(%rax),%zmm1,%zmm13
   39cd1:	vsubps -0x40(%rax),%zmm1,%zmm13{%k4}
   39cd8:	vpermps %zmm13,%zmm11,%zmm14
   39cde:	vaddps %zmm13,%zmm14,%zmm1
   39ce4:	vsubps %zmm13,%zmm14,%zmm1{%k3}
   39cea:	vpermps %zmm1,%zmm10,%zmm14
   39cf0:	vaddps %zmm14,%zmm1,%zmm13
   39cf6:	vsubps %zmm1,%zmm14,%zmm13{%k2}
   39cfc:	vpermps %zmm13,%zmm9,%zmm14
   39d02:	vaddps %zmm13,%zmm14,%zmm1
   39d08:	vsubps %zmm13,%zmm14,%zmm1{%k1}
   39d0e:	vsubps %zmm6,%zmm4,%zmm13
   39d14:	vsubps %zmm1,%zmm7,%zmm1
   39d1a:	vfmadd132ps %zmm0,%zmm13,%zmm8
   39d20:	vfmsub132ps %zmm0,%zmm13,%zmm3
   39d26:	vaddps %zmm1,%zmm5,%zmm13
   39d2c:	vfnmadd132ps %zmm0,%zmm13,%zmm7
   39d32:	vfmsub132ps %zmm0,%zmm13,%zmm2
   39d38:	vaddps %zmm7,%zmm8,%zmm13
   39d3e:	vfnmadd132ps %zmm0,%zmm13,%zmm5
   39d44:	vfmsub132ps %zmm0,%zmm13,%zmm4
   39d4a:	vaddps %zmm2,%zmm3,%zmm13
   39d50:	vfmadd132ps %zmm0,%zmm13,%zmm1
   39d56:	vfnmadd132ps %zmm0,%zmm13,%zmm6
   39d5c:	vfmsub132ps %zmm0,%zmm5,%zmm8
   39d62:	vfmadd132ps %zmm0,%zmm4,%zmm7
   39d68:	vmovups %zmm5,-0x100(%rax)
   39d6f:	vmovups %zmm4,-0xc0(%rax)
   39d76:	vfmsub132ps %zmm0,%zmm1,%zmm3
   39d7c:	vfnmadd132ps %zmm0,%zmm6,%zmm2
   39d82:	vmovups %zmm1,-0x1c0(%rax)
   39d89:	vmovups %zmm6,-0x140(%rax)
   39d90:	vmovups %zmm8,-0x200(%rax)
   39d97:	vmovups %zmm7,-0x180(%rax)
   39d9e:	vmovups %zmm3,-0x80(%rax)
   39da5:	vmovups %zmm2,-0x40(%rax)
   39dac:	cmp    %rdx,%rax
   39daf:	jne    39aa0 <hf2_broken_g20+0x90>
   39db5:	vzeroupper
   39db8:	ret
   39db9:	nopl   0x0(%rax)

000000000003afe0 <pass_tb8_nat_1>:
   3afe0:	endbr64
   3afe4:	vbroadcastss 0x23012(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   3afee:	test   %rsi,%rsi
   3aff1:	je     3b129 <pass_tb8_nat_1+0x149>
   3aff7:	lea    -0x1(%rsi),%r8
   3affb:	mov    %rsi,%rax
   3affe:	lea    0x0(,%rsi,4),%rcx
   3b006:	and    $0xfffffffffffffff0,%r8
   3b00a:	shl    $0x4,%rax
   3b00e:	lea    (%rdi,%rcx,1),%rdx
   3b012:	neg    %rcx
   3b015:	add    %rsi,%r8
   3b018:	add    %rdi,%rax
   3b01b:	lea    0x40(%rdi,%r8,4),%r8
   3b020:	lea    (%rsi,%rsi,2),%rdi
   3b024:	shl    $0x2,%rdi
   3b028:	nopl   0x0(%rax,%rax,1)
   3b030:	vmovups (%rdx,%rcx,1),%zmm7
   3b037:	vmovups (%rdx,%rsi,4),%zmm3
   3b03e:	vaddps (%rdx),%zmm7,%zmm2
   3b044:	vaddps (%rax,%rcx,1),%zmm3,%zmm6
   3b04b:	vsubps (%rax,%rcx,1),%zmm3,%zmm5
   3b052:	vsubps (%rdx),%zmm7,%zmm0
   3b058:	vmovups (%rax),%zmm7
   3b05e:	vaddps (%rax,%rsi,4),%zmm7,%zmm3
   3b065:	vsubps (%rax,%rsi,4),%zmm7,%zmm1
   3b06c:	vmovups (%rax,%rsi,8),%zmm7
   3b073:	vaddps (%rax,%rdi,1),%zmm7,%zmm9
   3b07a:	vsubps (%rax,%rdi,1),%zmm7,%zmm4
   3b081:	vaddps %zmm6,%zmm2,%zmm7
   3b087:	vsubps %zmm6,%zmm2,%zmm2
   3b08d:	vaddps %zmm5,%zmm0,%zmm6
   3b093:	vsubps %zmm5,%zmm0,%zmm0
   3b099:	vaddps %zmm9,%zmm3,%zmm8
   3b09f:	vaddps %zmm4,%zmm1,%zmm5
   3b0a5:	vsubps %zmm4,%zmm1,%zmm1
   3b0ab:	vsubps %zmm9,%zmm3,%zmm3
   3b0b1:	vaddps %zmm8,%zmm7,%zmm4
   3b0b7:	vsubps %zmm8,%zmm7,%zmm7
   3b0bd:	vmovups %zmm4,(%rdx,%rcx,1)
   3b0c4:	vaddps %zmm5,%zmm6,%zmm4
   3b0ca:	vsubps %zmm5,%zmm6,%zmm6
   3b0d0:	vmovups %zmm4,(%rdx)
   3b0d6:	vaddps %zmm3,%zmm2,%zmm4
   3b0dc:	vsubps %zmm3,%zmm2,%zmm2
   3b0e2:	vmovups %zmm4,(%rdx,%rsi,4)
   3b0e9:	vaddps %zmm1,%zmm0,%zmm4
   3b0ef:	add    $0x40,%rdx
   3b0f3:	vsubps %zmm1,%zmm0,%zmm0
   3b0f9:	vmovups %zmm4,(%rax,%rcx,1)
   3b100:	vmovups %zmm7,(%rax)
   3b106:	vmovups %zmm6,(%rax,%rsi,4)
   3b10d:	vmovups %zmm2,(%rax,%rsi,8)
   3b114:	add    $0x40,%rax
   3b118:	vmovups %zmm0,-0x40(%rax,%rdi,1)
   3b120:	cmp    %rdx,%r8
   3b123:	jne    3b030 <pass_tb8_nat_1+0x50>
   3b129:	vzeroupper
   3b12c:	ret
   3b12d:	nopl   (%rax)

000000000003b130 <pass_tb8_balS_1>:
   3b130:	endbr64
   3b134:	vbroadcastss 0x22ec2(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   3b13e:	test   %rsi,%rsi
   3b141:	je     3b2aa <pass_tb8_balS_1+0x17a>
   3b147:	lea    -0x1(%rsi),%r8
   3b14b:	mov    %rsi,%rax
   3b14e:	lea    0x0(,%rsi,4),%rcx
   3b156:	and    $0xfffffffffffffff0,%r8
   3b15a:	shl    $0x4,%rax
   3b15e:	lea    (%rdi,%rcx,1),%rdx
   3b162:	neg    %rcx
   3b165:	add    %rsi,%r8
   3b168:	add    %rdi,%rax
   3b16b:	lea    0x40(%rdi,%r8,4),%r8
   3b170:	lea    (%rsi,%rsi,2),%rdi
   3b174:	shl    $0x2,%rdi
   3b178:	nopl   0x0(%rax,%rax,1)
   3b180:	vmovups (%rdx,%rcx,1),%zmm7
   3b187:	vmovups (%rdx),%zmm6
   3b18d:	vsubps (%rdx),%zmm7,%zmm8
   3b193:	vmovups (%rdx,%rsi,4),%zmm4
   3b19a:	vmovups (%rax,%rcx,1),%zmm1
   3b1a1:	vmovups (%rax,%rsi,4),%zmm5
   3b1a8:	vfmadd132ps %zmm0,%zmm7,%zmm6
   3b1ae:	vmovups (%rax),%zmm7
   3b1b4:	vmovups (%rax,%rdi,1),%zmm2
   3b1bb:	vfmadd132ps %zmm0,%zmm4,%zmm1
   3b1c1:	vfmadd213ps (%rax,%rsi,8),%zmm0,%zmm2
   3b1c8:	vsubps (%rax,%rsi,4),%zmm7,%zmm9
   3b1cf:	vfmadd132ps %zmm0,%zmm7,%zmm5
   3b1d5:	vsubps (%rax,%rcx,1),%zmm4,%zmm3
   3b1dc:	vmovups (%rax,%rsi,8),%zmm4
   3b1e3:	vsubps (%rax,%rdi,1),%zmm4,%zmm4
   3b1ea:	vsubps %zmm1,%zmm6,%zmm7
   3b1f0:	vfmadd132ps %zmm0,%zmm6,%zmm1
   3b1f6:	vsubps %zmm3,%zmm8,%zmm6
   3b1fc:	vfmadd132ps %zmm0,%zmm8,%zmm3
   3b202:	vsubps %zmm2,%zmm5,%zmm8
   3b208:	vfmadd132ps %zmm0,%zmm5,%zmm2
   3b20e:	vsubps %zmm4,%zmm9,%zmm5
   3b214:	vfmadd132ps %zmm0,%zmm9,%zmm4
   3b21a:	vmovaps %zmm8,%zmm10
   3b220:	vfmadd132ps %zmm0,%zmm7,%zmm10
   3b226:	vmovaps %zmm5,%zmm9
   3b22c:	vsubps %zmm8,%zmm7,%zmm7
   3b232:	vfmadd132ps %zmm0,%zmm6,%zmm9
   3b238:	vsubps %zmm5,%zmm6,%zmm6
   3b23e:	vmovaps %zmm2,%zmm12
   3b244:	vmovaps %zmm4,%zmm11
   3b24a:	vfmadd132ps %zmm0,%zmm1,%zmm12
   3b250:	vsubps %zmm2,%zmm1,%zmm1
   3b256:	vfmadd132ps %zmm0,%zmm3,%zmm11
   3b25c:	vsubps %zmm4,%zmm3,%zmm3
   3b262:	vmovups %zmm12,(%rdx,%rcx,1)
   3b269:	vmovups %zmm11,(%rdx)
   3b26f:	vmovups %zmm10,(%rdx,%rsi,4)
   3b276:	add    $0x40,%rdx
   3b27a:	vmovups %zmm9,(%rax,%rcx,1)
   3b281:	vmovups %zmm1,(%rax)
   3b287:	vmovups %zmm3,(%rax,%rsi,4)
   3b28e:	vmovups %zmm7,(%rax,%rsi,8)
   3b295:	add    $0x40,%rax
   3b299:	vmovups %zmm6,-0x40(%rax,%rdi,1)
   3b2a1:	cmp    %rdx,%r8
   3b2a4:	jne    3b180 <pass_tb8_balS_1+0x50>
   3b2aa:	vzeroupper
   3b2ad:	ret
   3b2ae:	xchg   %ax,%ax

000000000003b2b0 <pass_tb8_bal_1>:
   3b2b0:	endbr64
   3b2b4:	vbroadcastss 0x22d42(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   3b2be:	test   %rsi,%rsi
   3b2c1:	je     3b444 <pass_tb8_bal_1+0x194>
   3b2c7:	lea    -0x1(%rsi),%r8
   3b2cb:	mov    %rsi,%rax
   3b2ce:	lea    0x0(,%rsi,4),%rcx
   3b2d6:	and    $0xfffffffffffffff0,%r8
   3b2da:	shl    $0x4,%rax
   3b2de:	lea    (%rdi,%rcx,1),%rdx
   3b2e2:	neg    %rcx
   3b2e5:	add    %rsi,%r8
   3b2e8:	add    %rdi,%rax
   3b2eb:	lea    0x40(%rdi,%r8,4),%r8
   3b2f0:	lea    (%rsi,%rsi,2),%rdi
   3b2f4:	shl    $0x2,%rdi
   3b2f8:	nopl   0x0(%rax,%rax,1)
   3b300:	vmovups (%rax,%rcx,1),%zmm7
   3b307:	vfmadd213ps (%rdx,%rsi,4),%zmm0,%zmm7
   3b30e:	vmovups (%rdx),%zmm3
   3b314:	vfmadd213ps (%rdx,%rcx,1),%zmm0,%zmm3
   3b31b:	vmovups (%rax,%rdi,1),%zmm10
   3b322:	vfmadd213ps (%rax,%rsi,8),%zmm0,%zmm10
   3b329:	vmovups (%rdx,%rcx,1),%zmm2
   3b330:	vmovups (%rax,%rsi,4),%zmm4
   3b337:	vsubps (%rdx),%zmm2,%zmm1
   3b33d:	vfmadd213ps (%rax),%zmm0,%zmm4
   3b343:	vmovups (%rdx,%rsi,4),%zmm2
   3b34a:	vsubps (%rax,%rcx,1),%zmm2,%zmm6
   3b351:	vmovaps %zmm7,%zmm8
   3b357:	vmovups (%rax),%zmm5
   3b35d:	vsubps (%rax,%rsi,4),%zmm5,%zmm2
   3b364:	vfmadd132ps %zmm0,%zmm3,%zmm8
   3b36a:	vsubps %zmm7,%zmm3,%zmm3
   3b370:	vmovups (%rax,%rsi,8),%zmm5
   3b377:	vsubps (%rax,%rdi,1),%zmm5,%zmm5
   3b37e:	vmovaps %zmm10,%zmm9
   3b384:	vmovaps %zmm6,%zmm7
   3b38a:	vfmadd132ps %zmm0,%zmm1,%zmm7
   3b390:	vsubps %zmm6,%zmm1,%zmm1
   3b396:	vmovaps %zmm5,%zmm6
   3b39c:	vfmadd132ps %zmm0,%zmm4,%zmm9
   3b3a2:	vsubps %zmm10,%zmm4,%zmm4
   3b3a8:	vfmadd132ps %zmm0,%zmm2,%zmm6
   3b3ae:	vsubps %zmm5,%zmm2,%zmm2
   3b3b4:	vmovaps %zmm4,%zmm10
   3b3ba:	vfmadd132ps %zmm0,%zmm3,%zmm10
   3b3c0:	vmovaps %zmm2,%zmm5
   3b3c6:	vsubps %zmm4,%zmm3,%zmm3
   3b3cc:	vmovaps %zmm9,%zmm12
   3b3d2:	vfmadd132ps %zmm0,%zmm1,%zmm5
   3b3d8:	vsubps %zmm2,%zmm1,%zmm1
   3b3de:	vmovaps %zmm6,%zmm11
   3b3e4:	vfmadd132ps %zmm0,%zmm8,%zmm12
   3b3ea:	vsubps %zmm9,%zmm8,%zmm8
   3b3f0:	vfmadd132ps %zmm0,%zmm7,%zmm11
   3b3f6:	vsubps %zmm6,%zmm7,%zmm7
   3b3fc:	vmovups %zmm12,(%rdx,%rcx,1)
   3b403:	vmovups %zmm11,(%rdx)
   3b409:	vmovups %zmm10,(%rdx,%rsi,4)
   3b410:	add    $0x40,%rdx
   3b414:	vmovups %zmm5,(%rax,%rcx,1)
   3b41b:	vmovups %zmm8,(%rax)
   3b421:	vmovups %zmm7,(%rax,%rsi,4)
   3b428:	vmovups %zmm3,(%rax,%rsi,8)
   3b42f:	add    $0x40,%rax
   3b433:	vmovups %zmm1,-0x40(%rax,%rdi,1)
   3b43b:	cmp    %rdx,%r8
   3b43e:	jne    3b300 <pass_tb8_bal_1+0x50>
   3b444:	vzeroupper
   3b447:	ret
   3b448:	nopl   0x0(%rax,%rax,1)

000000000003b450 <hf0_g19_nat>:
   3b450:	endbr64
   3b454:	push   %rbp
   3b455:	mov    %rdi,%rdx
   3b458:	mov    %rsp,%rbp
   3b45b:	and    $0xffffffffffffffc0,%rsp
   3b45f:	sub    $0x140,%rsp
   3b466:	vbroadcastss 0x22b90(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   3b470:	mov    %fs:0x28,%rax
   3b479:	mov    %rax,0x138(%rsp)
   3b481:	xor    %eax,%eax
   3b483:	mov    %rsp,%rdi
   3b486:	vzeroupper
   3b489:	call   10170 <inl_consts.constprop.1>
   3b48e:	vmovaps (%rsp),%zmm4
   3b495:	vmovaps 0x40(%rsp),%zmm5
   3b49d:	vmovaps 0x80(%rsp),%zmm6
   3b4a5:	vmovaps 0xc0(%rsp),%zmm7
   3b4ad:	test   %rsi,%rsi
   3b4b0:	je     3b75f <hf0_g19_nat+0x30f>
   3b4b6:	vbroadcastss 0x21b48(%rip),%zmm3        # 5d008 <_IO_stdin_used+0x8>
   3b4c0:	mov    %rdx,%rax
   3b4c3:	lea    -0x4(,%rsi,4),%rdx
   3b4cb:	and    $0xfffffffffffffe00,%rdx
   3b4d2:	lea    0x200(%rax,%rdx,1),%rdx
   3b4da:	nopw   0x0(%rax,%rax,1)
   3b4e0:	vpermilps $0xb1,(%rax),%zmm8
   3b4e7:	vfmadd231ps (%rax),%zmm4,%zmm8
   3b4ed:	add    $0x200,%rax
   3b4f3:	vpermilps $0xb1,-0x1c0(%rax),%zmm2
   3b4fb:	vfmadd231ps -0x1c0(%rax),%zmm4,%zmm2
   3b502:	vpermilps $0x4e,%zmm8,%zmm0
   3b509:	vfmadd132ps %zmm5,%zmm0,%zmm8
   3b50f:	vshuff32x4 $0xb1,%zmm8,%zmm8,%zmm0
   3b516:	vfmadd132ps %zmm6,%zmm0,%zmm8
   3b51c:	vshuff32x4 $0x4e,%zmm8,%zmm8,%zmm0
   3b523:	vfmadd132ps %zmm7,%zmm0,%zmm8
   3b529:	vpermilps $0x4e,%zmm2,%zmm0
   3b530:	vfmadd132ps %zmm5,%zmm0,%zmm2
   3b536:	vshuff32x4 $0xb1,%zmm2,%zmm2,%zmm0
   3b53d:	vfmadd132ps %zmm6,%zmm0,%zmm2
   3b543:	vshuff32x4 $0x4e,%zmm2,%zmm2,%zmm0
   3b54a:	vfmadd132ps %zmm7,%zmm0,%zmm2
   3b550:	vpermilps $0xb1,-0x180(%rax),%zmm0
   3b558:	vfmadd231ps -0x180(%rax),%zmm4,%zmm0
   3b55f:	vpermilps $0x4e,%zmm0,%zmm1
   3b566:	vfmadd132ps %zmm5,%zmm1,%zmm0
   3b56c:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3b573:	vfmadd132ps %zmm6,%zmm1,%zmm0
   3b579:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3b580:	vfmadd132ps %zmm7,%zmm1,%zmm0
   3b586:	vmovaps %zmm0,%zmm9
   3b58c:	vpermilps $0xb1,-0x140(%rax),%zmm0
   3b594:	vfmadd231ps -0x140(%rax),%zmm4,%zmm0
   3b59b:	vpermilps $0x4e,%zmm0,%zmm1
   3b5a2:	vfmadd132ps %zmm5,%zmm1,%zmm0
   3b5a8:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3b5af:	vfmadd132ps %zmm6,%zmm1,%zmm0
   3b5b5:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3b5bc:	vfmadd132ps %zmm7,%zmm1,%zmm0
   3b5c2:	vmovaps %zmm0,%zmm10
   3b5c8:	vpermilps $0xb1,-0x100(%rax),%zmm0
   3b5d0:	vfmadd231ps -0x100(%rax),%zmm4,%zmm0
   3b5d7:	vpermilps $0x4e,%zmm0,%zmm1
   3b5de:	vfmadd132ps %zmm5,%zmm1,%zmm0
   3b5e4:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3b5eb:	vfmadd132ps %zmm6,%zmm1,%zmm0
   3b5f1:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3b5f8:	vfmadd132ps %zmm7,%zmm1,%zmm0
   3b5fe:	vmovaps %zmm0,%zmm11
   3b604:	vpermilps $0xb1,-0xc0(%rax),%zmm0
   3b60c:	vfmadd231ps -0xc0(%rax),%zmm4,%zmm0
   3b613:	vpermilps $0x4e,%zmm0,%zmm1
   3b61a:	vfmadd132ps %zmm5,%zmm1,%zmm0
   3b620:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3b627:	vfmadd132ps %zmm6,%zmm1,%zmm0
   3b62d:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3b634:	vfmadd132ps %zmm7,%zmm1,%zmm0
   3b63a:	vmovaps %zmm0,%zmm12
   3b640:	vpermilps $0xb1,-0x80(%rax),%zmm0
   3b648:	vfmadd231ps -0x80(%rax),%zmm4,%zmm0
   3b64f:	vsubps %zmm12,%zmm9,%zmm9
   3b655:	vpermilps $0x4e,%zmm0,%zmm1
   3b65c:	vfmadd132ps %zmm5,%zmm1,%zmm0
   3b662:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3b669:	vfmadd132ps %zmm6,%zmm1,%zmm0
   3b66f:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3b676:	vfmadd231ps %zmm7,%zmm0,%zmm1
   3b67c:	vpermilps $0xb1,-0x40(%rax),%zmm0
   3b684:	vfmadd231ps -0x40(%rax),%zmm4,%zmm0
   3b68b:	vaddps %zmm1,%zmm2,%zmm14
   3b691:	vpermilps $0x4e,%zmm0,%zmm13
   3b698:	vfmadd132ps %zmm5,%zmm13,%zmm0
   3b69e:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm13
   3b6a5:	vfmadd132ps %zmm6,%zmm13,%zmm0
   3b6ab:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm13
   3b6b2:	vfmadd132ps %zmm7,%zmm13,%zmm0
   3b6b8:	vsubps %zmm11,%zmm10,%zmm13
   3b6be:	vaddps %zmm13,%zmm9,%zmm16
   3b6c4:	vaddps %zmm0,%zmm8,%zmm8
   3b6ca:	vsubps %zmm14,%zmm8,%zmm15
   3b6d0:	vsubps %zmm16,%zmm15,%zmm17
   3b6d6:	vfnmadd132ps %zmm3,%zmm17,%zmm0
   3b6dc:	vfnmadd132ps %zmm3,%zmm17,%zmm12
   3b6e2:	vfmadd132ps %zmm3,%zmm0,%zmm1
   3b6e8:	vfnmadd132ps %zmm3,%zmm12,%zmm11
   3b6ee:	vfmadd132ps %zmm3,%zmm12,%zmm10
   3b6f4:	vfmadd132ps %zmm3,%zmm0,%zmm2
   3b6fa:	vfmadd132ps %zmm3,%zmm1,%zmm13
   3b700:	vfmadd132ps %zmm3,%zmm1,%zmm9
   3b706:	vfmsub132ps %zmm3,%zmm10,%zmm15
   3b70c:	vfmadd132ps %zmm3,%zmm11,%zmm14
   3b712:	vmovups %zmm2,-0x180(%rax)
   3b719:	vfmadd132ps %zmm3,%zmm2,%zmm16
   3b71f:	vfmsub132ps %zmm3,%zmm11,%zmm8
   3b725:	vmovups %zmm10,-0x140(%rax)
   3b72c:	vmovups %zmm9,-0x1c0(%rax)
   3b733:	vmovups %zmm15,-0xc0(%rax)
   3b73a:	vmovups %zmm8,-0x200(%rax)
   3b741:	vmovups %zmm16,-0x100(%rax)
   3b748:	vmovups %zmm14,-0x80(%rax)
   3b74f:	vmovups %zmm13,-0x40(%rax)
   3b756:	cmp    %rax,%rdx
   3b759:	jne    3b4e0 <hf0_g19_nat+0x90>
   3b75f:	mov    0x138(%rsp),%rax
   3b767:	sub    %fs:0x28,%rax
   3b770:	jne    3b777 <hf0_g19_nat+0x327>
   3b772:	vzeroupper
   3b775:	leave
   3b776:	ret
   3b777:	vzeroupper
   3b77a:	call   4280 <__stack_chk_fail@plt>
   3b77f:	nop

000000000003c160 <hf2_tb8_nat>:
   3c160:	endbr64
   3c164:	vbroadcastss 0x21e92(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   3c16e:	test   %rsi,%rsi
   3c171:	je     3c50d <hf2_tb8_nat+0x3ad>
   3c177:	mov    $0xffffaaaa,%ecx
   3c17c:	mov    %rdi,%rax
   3c17f:	lea    -0x4(,%rsi,4),%rdx
   3c187:	vmovdqa32 0x21c6f(%rip),%zmm5        # 5de00 <_IO_stdin_used+0xe00>
   3c191:	kmovw  %ecx,%k4
   3c195:	mov    $0xffffcccc,%ecx
   3c19a:	and    $0xfffffffffffffe00,%rdx
   3c1a1:	vmovdqa32 0x21c95(%rip),%zmm4        # 5de40 <_IO_stdin_used+0xe40>
   3c1ab:	kmovw  %ecx,%k3
   3c1af:	mov    $0xfffff0f0,%ecx
   3c1b4:	vmovdqa32 0x21cc2(%rip),%zmm3        # 5de80 <_IO_stdin_used+0xe80>
   3c1be:	vmovdqa32 0x21cf8(%rip),%zmm2        # 5dec0 <_IO_stdin_used+0xec0>
   3c1c8:	kmovw  %ecx,%k2
   3c1cc:	lea    0x200(%rdi,%rdx,1),%rdx
   3c1d4:	mov    $0xffffff00,%ecx
   3c1d9:	kmovw  %ecx,%k1
   3c1dd:	nopl   (%rax)
   3c1e0:	vpermps (%rax),%zmm5,%zmm0
   3c1e6:	vaddps (%rax),%zmm0,%zmm1
   3c1ec:	add    $0x200,%rax
   3c1f2:	vsubps -0x200(%rax),%zmm0,%zmm1{%k4}
   3c1f9:	vpermps %zmm1,%zmm4,%zmm6
   3c1ff:	vaddps %zmm6,%zmm1,%zmm0
   3c205:	vsubps %zmm1,%zmm6,%zmm0{%k3}
   3c20b:	vpermps %zmm0,%zmm3,%zmm6
   3c211:	vaddps %zmm6,%zmm0,%zmm1
   3c217:	vsubps %zmm0,%zmm6,%zmm1{%k2}
   3c21d:	vpermps %zmm1,%zmm2,%zmm6
   3c223:	vaddps %zmm6,%zmm1,%zmm0
   3c229:	vsubps %zmm1,%zmm6,%zmm0{%k1}
   3c22f:	vpermps -0x1c0(%rax),%zmm5,%zmm6
   3c236:	vaddps -0x1c0(%rax),%zmm6,%zmm1
   3c23d:	vsubps -0x1c0(%rax),%zmm6,%zmm1{%k4}
   3c244:	vpermps %zmm1,%zmm4,%zmm7
   3c24a:	vaddps %zmm7,%zmm1,%zmm6
   3c250:	vsubps %zmm1,%zmm7,%zmm6{%k3}
   3c256:	vpermps %zmm6,%zmm3,%zmm7
   3c25c:	vaddps %zmm7,%zmm6,%zmm1
   3c262:	vsubps %zmm6,%zmm7,%zmm1{%k2}
   3c268:	vpermps %zmm1,%zmm2,%zmm6
   3c26e:	vaddps %zmm6,%zmm1,%zmm11
   3c274:	vsubps %zmm1,%zmm6,%zmm11{%k1}
   3c27a:	vpermps -0x180(%rax),%zmm5,%zmm6
   3c281:	vaddps -0x180(%rax),%zmm6,%zmm1
   3c288:	vsubps -0x180(%rax),%zmm6,%zmm1{%k4}
   3c28f:	vpermps %zmm1,%zmm4,%zmm7
   3c295:	vaddps %zmm7,%zmm1,%zmm6
   3c29b:	vsubps %zmm1,%zmm7,%zmm6{%k3}
   3c2a1:	vpermps %zmm6,%zmm3,%zmm7
   3c2a7:	vaddps %zmm7,%zmm6,%zmm1
   3c2ad:	vsubps %zmm6,%zmm7,%zmm1{%k2}
   3c2b3:	vpermps %zmm1,%zmm2,%zmm6
   3c2b9:	vaddps %zmm6,%zmm1,%zmm9
   3c2bf:	vsubps %zmm1,%zmm6,%zmm9{%k1}
   3c2c5:	vpermps -0x140(%rax),%zmm5,%zmm6
   3c2cc:	vaddps -0x140(%rax),%zmm6,%zmm1
   3c2d3:	vsubps -0x140(%rax),%zmm6,%zmm1{%k4}
   3c2da:	vpermps %zmm1,%zmm4,%zmm7
   3c2e0:	vaddps %zmm7,%zmm1,%zmm6
   3c2e6:	vsubps %zmm1,%zmm7,%zmm6{%k3}
   3c2ec:	vpermps %zmm6,%zmm3,%zmm7
   3c2f2:	vaddps %zmm7,%zmm6,%zmm1
   3c2f8:	vsubps %zmm6,%zmm7,%zmm1{%k2}
   3c2fe:	vpermps %zmm1,%zmm2,%zmm6
   3c304:	vaddps %zmm6,%zmm1,%zmm10
   3c30a:	vsubps %zmm1,%zmm6,%zmm10{%k1}
   3c310:	vpermps -0x100(%rax),%zmm5,%zmm1
   3c317:	vaddps -0x100(%rax),%zmm1,%zmm6
   3c31e:	vsubps -0x100(%rax),%zmm1,%zmm6{%k4}
   3c325:	vaddps %zmm10,%zmm9,%zmm14
   3c32b:	vsubps %zmm10,%zmm9,%zmm9
   3c331:	vpermps %zmm6,%zmm4,%zmm7
   3c337:	vaddps %zmm7,%zmm6,%zmm1
   3c33d:	vsubps %zmm6,%zmm7,%zmm1{%k3}
   3c343:	vpermps %zmm1,%zmm3,%zmm7
   3c349:	vaddps %zmm7,%zmm1,%zmm6
   3c34f:	vsubps %zmm1,%zmm7,%zmm6{%k2}
   3c355:	vpermps %zmm6,%zmm2,%zmm7
   3c35b:	vaddps %zmm7,%zmm6,%zmm1
   3c361:	vsubps %zmm6,%zmm7,%zmm1{%k1}
   3c367:	vpermps -0xc0(%rax),%zmm5,%zmm7
   3c36e:	vaddps -0xc0(%rax),%zmm7,%zmm6
   3c375:	vsubps -0xc0(%rax),%zmm7,%zmm6{%k4}
   3c37c:	vpermps %zmm6,%zmm4,%zmm8
   3c382:	vaddps %zmm8,%zmm6,%zmm7
   3c388:	vsubps %zmm6,%zmm8,%zmm7{%k3}
   3c38e:	vpermps %zmm7,%zmm3,%zmm8
   3c394:	vaddps %zmm8,%zmm7,%zmm6
   3c39a:	vsubps %zmm7,%zmm8,%zmm6{%k2}
   3c3a0:	vpermps %zmm6,%zmm2,%zmm7
   3c3a6:	vaddps %zmm7,%zmm6,%zmm13
   3c3ac:	vsubps %zmm6,%zmm7,%zmm13{%k1}
   3c3b2:	vpermps -0x80(%rax),%zmm5,%zmm7
   3c3b9:	vaddps -0x80(%rax),%zmm7,%zmm6
   3c3c0:	vsubps -0x80(%rax),%zmm7,%zmm6{%k4}
   3c3c7:	vpermps %zmm6,%zmm4,%zmm8
   3c3cd:	vaddps %zmm8,%zmm6,%zmm7
   3c3d3:	vsubps %zmm6,%zmm8,%zmm7{%k3}
   3c3d9:	vpermps %zmm7,%zmm3,%zmm8
   3c3df:	vaddps %zmm8,%zmm7,%zmm6
   3c3e5:	vsubps %zmm7,%zmm8,%zmm6{%k2}
   3c3eb:	vpermps %zmm6,%zmm2,%zmm7
   3c3f1:	vaddps %zmm7,%zmm6,%zmm8
   3c3f7:	vsubps %zmm6,%zmm7,%zmm8{%k1}
   3c3fd:	vpermps -0x40(%rax),%zmm5,%zmm7
   3c404:	vaddps -0x40(%rax),%zmm7,%zmm6
   3c40b:	vsubps -0x40(%rax),%zmm7,%zmm6{%k4}
   3c412:	vpermps %zmm6,%zmm4,%zmm12
   3c418:	vaddps %zmm6,%zmm12,%zmm7
   3c41e:	vsubps %zmm6,%zmm12,%zmm7{%k3}
   3c424:	vpermps %zmm7,%zmm3,%zmm12
   3c42a:	vaddps %zmm12,%zmm7,%zmm6
   3c430:	vsubps %zmm7,%zmm12,%zmm6{%k2}
   3c436:	vpermps %zmm6,%zmm2,%zmm7
   3c43c:	vaddps %zmm6,%zmm7,%zmm12
   3c442:	vsubps %zmm6,%zmm7,%zmm12{%k1}
   3c448:	vaddps %zmm13,%zmm1,%zmm7
   3c44e:	vaddps %zmm11,%zmm0,%zmm6
   3c454:	vsubps %zmm13,%zmm1,%zmm1
   3c45a:	vsubps %zmm11,%zmm0,%zmm0
   3c460:	vaddps %zmm8,%zmm12,%zmm13
   3c466:	vsubps %zmm12,%zmm8,%zmm8
   3c46c:	vaddps %zmm14,%zmm6,%zmm11
   3c472:	vsubps %zmm14,%zmm6,%zmm6
   3c478:	vaddps %zmm9,%zmm0,%zmm10
   3c47e:	vsubps %zmm9,%zmm0,%zmm0
   3c484:	vaddps %zmm13,%zmm7,%zmm12
   3c48a:	vaddps %zmm8,%zmm1,%zmm9
   3c490:	vsubps %zmm8,%zmm1,%zmm1
   3c496:	vsubps %zmm13,%zmm7,%zmm7
   3c49c:	vaddps %zmm12,%zmm11,%zmm8
   3c4a2:	vsubps %zmm12,%zmm11,%zmm11
   3c4a8:	vmovups %zmm8,-0x200(%rax)
   3c4af:	vaddps %zmm9,%zmm10,%zmm8
   3c4b5:	vsubps %zmm9,%zmm10,%zmm10
   3c4bb:	vmovups %zmm11,-0x100(%rax)
   3c4c2:	vmovups %zmm8,-0x1c0(%rax)
   3c4c9:	vaddps %zmm7,%zmm6,%zmm8
   3c4cf:	vsubps %zmm7,%zmm6,%zmm6
   3c4d5:	vmovups %zmm10,-0xc0(%rax)
   3c4dc:	vmovups %zmm8,-0x180(%rax)
   3c4e3:	vaddps %zmm1,%zmm0,%zmm8
   3c4e9:	vsubps %zmm1,%zmm0,%zmm0
   3c4ef:	vmovups %zmm6,-0x80(%rax)
   3c4f6:	vmovups %zmm8,-0x140(%rax)
   3c4fd:	vmovups %zmm0,-0x40(%rax)
   3c504:	cmp    %rdx,%rax
   3c507:	jne    3c1e0 <hf2_tb8_nat+0x80>
   3c50d:	vzeroupper
   3c510:	ret
   3c511:	data16 cs nopw 0x0(%rax,%rax,1)
   3c51c:	nopl   0x0(%rax)

000000000003c520 <hf2_tb8_balS>:
   3c520:	endbr64
   3c524:	vbroadcastss 0x21ad2(%rip),%zmm1        # 5e000 <_IO_stdin_used+0x1000>
   3c52e:	test   %rsi,%rsi
   3c531:	je     3c8e5 <hf2_tb8_balS+0x3c5>
   3c537:	mov    $0xffffaaaa,%ecx
   3c53c:	mov    %rdi,%rax
   3c53f:	lea    -0x4(,%rsi,4),%rdx
   3c547:	vmovdqa32 0x218af(%rip),%zmm6        # 5de00 <_IO_stdin_used+0xe00>
   3c551:	kmovw  %ecx,%k4
   3c555:	mov    $0xffffcccc,%ecx
   3c55a:	and    $0xfffffffffffffe00,%rdx
   3c561:	vmovdqa32 0x218d5(%rip),%zmm5        # 5de40 <_IO_stdin_used+0xe40>
   3c56b:	kmovw  %ecx,%k3
   3c56f:	mov    $0xfffff0f0,%ecx
   3c574:	vmovdqa32 0x21902(%rip),%zmm4        # 5de80 <_IO_stdin_used+0xe80>
   3c57e:	vmovdqa32 0x21938(%rip),%zmm3        # 5dec0 <_IO_stdin_used+0xec0>
   3c588:	kmovw  %ecx,%k2
   3c58c:	lea    0x200(%rdi,%rdx,1),%rdx
   3c594:	mov    $0xffffff00,%ecx
   3c599:	kmovw  %ecx,%k1
   3c59d:	nopl   (%rax)
   3c5a0:	vpermps (%rax),%zmm6,%zmm2
   3c5a6:	vaddps (%rax),%zmm2,%zmm0
   3c5ac:	add    $0x200,%rax
   3c5b2:	vsubps -0x200(%rax),%zmm2,%zmm0{%k4}
   3c5b9:	vpermps %zmm0,%zmm5,%zmm7
   3c5bf:	vaddps %zmm7,%zmm0,%zmm2
   3c5c5:	vsubps %zmm0,%zmm7,%zmm2{%k3}
   3c5cb:	vpermps %zmm2,%zmm4,%zmm7
   3c5d1:	vaddps %zmm7,%zmm2,%zmm0
   3c5d7:	vsubps %zmm2,%zmm7,%zmm0{%k2}
   3c5dd:	vpermps %zmm0,%zmm3,%zmm2
   3c5e3:	vaddps %zmm2,%zmm0,%zmm12
   3c5e9:	vsubps %zmm0,%zmm2,%zmm12{%k1}
   3c5ef:	vpermps -0x1c0(%rax),%zmm6,%zmm2
   3c5f6:	vaddps -0x1c0(%rax),%zmm2,%zmm0
   3c5fd:	vsubps -0x1c0(%rax),%zmm2,%zmm0{%k4}
   3c604:	vpermps %zmm0,%zmm5,%zmm7
   3c60a:	vaddps %zmm7,%zmm0,%zmm2
   3c610:	vsubps %zmm0,%zmm7,%zmm2{%k3}
   3c616:	vpermps %zmm2,%zmm4,%zmm7
   3c61c:	vaddps %zmm7,%zmm2,%zmm0
   3c622:	vsubps %zmm2,%zmm7,%zmm0{%k2}
   3c628:	vpermps %zmm0,%zmm3,%zmm2
   3c62e:	vaddps %zmm2,%zmm0,%zmm10
   3c634:	vsubps %zmm0,%zmm2,%zmm10{%k1}
   3c63a:	vpermps -0x180(%rax),%zmm6,%zmm2
   3c641:	vaddps -0x180(%rax),%zmm2,%zmm0
   3c648:	vsubps -0x180(%rax),%zmm2,%zmm0{%k4}
   3c64f:	vsubps %zmm10,%zmm12,%zmm15
   3c655:	vfmadd132ps %zmm1,%zmm12,%zmm10
   3c65b:	vpermps %zmm0,%zmm5,%zmm7
   3c661:	vaddps %zmm7,%zmm0,%zmm2
   3c667:	vsubps %zmm0,%zmm7,%zmm2{%k3}
   3c66d:	vpermps %zmm2,%zmm4,%zmm7
   3c673:	vaddps %zmm7,%zmm2,%zmm0
   3c679:	vsubps %zmm2,%zmm7,%zmm0{%k2}
   3c67f:	vpermps %zmm0,%zmm3,%zmm2
   3c685:	vaddps %zmm2,%zmm0,%zmm11
   3c68b:	vsubps %zmm0,%zmm2,%zmm11{%k1}
   3c691:	vpermps -0x140(%rax),%zmm6,%zmm0
   3c698:	vaddps -0x140(%rax),%zmm0,%zmm2
   3c69f:	vsubps -0x140(%rax),%zmm0,%zmm2{%k4}
   3c6a6:	vpermps %zmm2,%zmm5,%zmm7
   3c6ac:	vaddps %zmm7,%zmm2,%zmm0
   3c6b2:	vsubps %zmm2,%zmm7,%zmm0{%k3}
   3c6b8:	vpermps %zmm0,%zmm4,%zmm7
   3c6be:	vaddps %zmm7,%zmm0,%zmm2
   3c6c4:	vsubps %zmm0,%zmm7,%zmm2{%k2}
   3c6ca:	vpermps %zmm2,%zmm3,%zmm7
   3c6d0:	vaddps %zmm7,%zmm2,%zmm0
   3c6d6:	vsubps %zmm2,%zmm7,%zmm0{%k1}
   3c6dc:	vpermps -0x100(%rax),%zmm6,%zmm7
   3c6e3:	vaddps -0x100(%rax),%zmm7,%zmm2
   3c6ea:	vsubps -0x100(%rax),%zmm7,%zmm2{%k4}
   3c6f1:	vpermps %zmm2,%zmm5,%zmm8
   3c6f7:	vaddps %zmm8,%zmm2,%zmm7
   3c6fd:	vsubps %zmm2,%zmm8,%zmm7{%k3}
   3c703:	vpermps %zmm7,%zmm4,%zmm8
   3c709:	vaddps %zmm8,%zmm7,%zmm2
   3c70f:	vsubps %zmm7,%zmm8,%zmm2{%k2}
   3c715:	vpermps %zmm2,%zmm3,%zmm7
   3c71b:	vaddps %zmm7,%zmm2,%zmm8
   3c721:	vsubps %zmm2,%zmm7,%zmm8{%k1}
   3c727:	vpermps -0xc0(%rax),%zmm6,%zmm7
   3c72e:	vaddps -0xc0(%rax),%zmm7,%zmm2
   3c735:	vsubps -0xc0(%rax),%zmm7,%zmm2{%k4}
   3c73c:	vpermps %zmm2,%zmm5,%zmm9
   3c742:	vaddps %zmm9,%zmm2,%zmm7
   3c748:	vsubps %zmm2,%zmm9,%zmm7{%k3}
   3c74e:	vpermps %zmm7,%zmm4,%zmm9
   3c754:	vaddps %zmm9,%zmm7,%zmm2
   3c75a:	vsubps %zmm7,%zmm9,%zmm2{%k2}
   3c760:	vpermps %zmm2,%zmm3,%zmm7
   3c766:	vaddps %zmm7,%zmm2,%zmm9
   3c76c:	vsubps %zmm2,%zmm7,%zmm9{%k1}
   3c772:	vpermps -0x80(%rax),%zmm6,%zmm7
   3c779:	vaddps -0x80(%rax),%zmm7,%zmm2
   3c780:	vsubps -0x80(%rax),%zmm7,%zmm2{%k4}
   3c787:	vpermps %zmm2,%zmm5,%zmm13
   3c78d:	vaddps %zmm13,%zmm2,%zmm7
   3c793:	vsubps %zmm2,%zmm13,%zmm7{%k3}
   3c799:	vpermps %zmm7,%zmm4,%zmm13
   3c79f:	vaddps %zmm13,%zmm7,%zmm2
   3c7a5:	vsubps %zmm7,%zmm13,%zmm2{%k2}
   3c7ab:	vpermps %zmm2,%zmm3,%zmm7
   3c7b1:	vaddps %zmm7,%zmm2,%zmm13
   3c7b7:	vsubps %zmm2,%zmm7,%zmm13{%k1}
   3c7bd:	vpermps -0x40(%rax),%zmm6,%zmm2
   3c7c4:	vaddps -0x40(%rax),%zmm2,%zmm7
   3c7cb:	vsubps -0x40(%rax),%zmm2,%zmm7{%k4}
   3c7d2:	vpermps %zmm7,%zmm5,%zmm14
   3c7d8:	vaddps %zmm7,%zmm14,%zmm2
   3c7de:	vsubps %zmm7,%zmm14,%zmm2{%k3}
   3c7e4:	vpermps %zmm2,%zmm4,%zmm14
   3c7ea:	vaddps %zmm14,%zmm2,%zmm7
   3c7f0:	vsubps %zmm2,%zmm14,%zmm7{%k2}
   3c7f6:	vpermps %zmm7,%zmm3,%zmm14
   3c7fc:	vaddps %zmm7,%zmm14,%zmm2
   3c802:	vsubps %zmm7,%zmm14,%zmm2{%k1}
   3c808:	vsubps %zmm9,%zmm8,%zmm14
   3c80e:	vfmadd132ps %zmm1,%zmm8,%zmm9
   3c814:	vsubps %zmm0,%zmm11,%zmm7
   3c81a:	vfmadd132ps %zmm1,%zmm11,%zmm0
   3c820:	vsubps %zmm2,%zmm13,%zmm8
   3c826:	vfmadd132ps %zmm1,%zmm13,%zmm2
   3c82c:	vsubps %zmm0,%zmm10,%zmm11
   3c832:	vfmadd132ps %zmm1,%zmm10,%zmm0
   3c838:	vsubps %zmm7,%zmm15,%zmm10
   3c83e:	vfmadd132ps %zmm1,%zmm15,%zmm7
   3c844:	vsubps %zmm2,%zmm9,%zmm12
   3c84a:	vfmadd132ps %zmm1,%zmm9,%zmm2
   3c850:	vsubps %zmm8,%zmm14,%zmm9
   3c856:	vfmadd132ps %zmm1,%zmm14,%zmm8
   3c85c:	vmovaps %zmm9,%zmm13
   3c862:	vmovaps %zmm12,%zmm14
   3c868:	vfmadd132ps %zmm1,%zmm11,%zmm14
   3c86e:	vfmadd132ps %zmm1,%zmm10,%zmm13
   3c874:	vsubps %zmm12,%zmm11,%zmm11
   3c87a:	vmovaps %zmm2,%zmm16
   3c880:	vsubps %zmm9,%zmm10,%zmm10
   3c886:	vmovaps %zmm8,%zmm15
   3c88c:	vfmadd132ps %zmm1,%zmm0,%zmm16
   3c892:	vsubps %zmm2,%zmm0,%zmm0
   3c898:	vfmadd132ps %zmm1,%zmm7,%zmm15
   3c89e:	vsubps %zmm8,%zmm7,%zmm7
   3c8a4:	vmovups %zmm11,-0x80(%rax)
   3c8ab:	vmovups %zmm10,-0x40(%rax)
   3c8b2:	vmovups %zmm14,-0x180(%rax)
   3c8b9:	vmovups %zmm13,-0x140(%rax)
   3c8c0:	vmovups %zmm16,-0x200(%rax)
   3c8c7:	vmovups %zmm15,-0x1c0(%rax)
   3c8ce:	vmovups %zmm0,-0x100(%rax)
   3c8d5:	vmovups %zmm7,-0xc0(%rax)
   3c8dc:	cmp    %rdx,%rax
   3c8df:	jne    3c5a0 <hf2_tb8_balS+0x80>
   3c8e5:	vzeroupper
   3c8e8:	ret
   3c8e9:	nopl   0x0(%rax)

000000000003c8f0 <hf2_tb8_bal>:
   3c8f0:	endbr64
   3c8f4:	vbroadcastss 0x21702(%rip),%zmm1        # 5e000 <_IO_stdin_used+0x1000>
   3c8fe:	test   %rsi,%rsi
   3c901:	je     3cce5 <hf2_tb8_bal+0x3f5>
   3c907:	mov    $0xffffaaaa,%ecx
   3c90c:	mov    %rdi,%rax
   3c90f:	lea    -0x4(,%rsi,4),%rdx
   3c917:	vmovdqa32 0x214df(%rip),%zmm6        # 5de00 <_IO_stdin_used+0xe00>
   3c921:	kmovw  %ecx,%k4
   3c925:	mov    $0xffffcccc,%ecx
   3c92a:	and    $0xfffffffffffffe00,%rdx
   3c931:	vmovdqa32 0x21505(%rip),%zmm5        # 5de40 <_IO_stdin_used+0xe40>
   3c93b:	kmovw  %ecx,%k3
   3c93f:	mov    $0xfffff0f0,%ecx
   3c944:	vmovdqa32 0x21532(%rip),%zmm4        # 5de80 <_IO_stdin_used+0xe80>
   3c94e:	vmovdqa32 0x21568(%rip),%zmm3        # 5dec0 <_IO_stdin_used+0xec0>
   3c958:	kmovw  %ecx,%k2
   3c95c:	lea    0x200(%rdi,%rdx,1),%rdx
   3c964:	mov    $0xffffff00,%ecx
   3c969:	kmovw  %ecx,%k1
   3c96d:	nopl   (%rax)
   3c970:	vpermps (%rax),%zmm6,%zmm0
   3c976:	vaddps (%rax),%zmm0,%zmm2
   3c97c:	add    $0x200,%rax
   3c982:	vsubps -0x200(%rax),%zmm0,%zmm2{%k4}
   3c989:	vpermps %zmm2,%zmm5,%zmm7
   3c98f:	vaddps %zmm7,%zmm2,%zmm0
   3c995:	vsubps %zmm2,%zmm7,%zmm0{%k3}
   3c99b:	vpermps %zmm0,%zmm4,%zmm7
   3c9a1:	vaddps %zmm7,%zmm0,%zmm2
   3c9a7:	vsubps %zmm0,%zmm7,%zmm2{%k2}
   3c9ad:	vpermps %zmm2,%zmm3,%zmm7
   3c9b3:	vaddps %zmm7,%zmm2,%zmm0
   3c9b9:	vsubps %zmm2,%zmm7,%zmm0{%k1}
   3c9bf:	vpermps -0x1c0(%rax),%zmm6,%zmm7
   3c9c6:	vaddps -0x1c0(%rax),%zmm7,%zmm2
   3c9cd:	vsubps -0x1c0(%rax),%zmm7,%zmm2{%k4}
   3c9d4:	vpermps %zmm2,%zmm5,%zmm8
   3c9da:	vaddps %zmm8,%zmm2,%zmm7
   3c9e0:	vsubps %zmm2,%zmm8,%zmm7{%k3}
   3c9e6:	vpermps %zmm7,%zmm4,%zmm8
   3c9ec:	vaddps %zmm8,%zmm7,%zmm2
   3c9f2:	vsubps %zmm7,%zmm8,%zmm2{%k2}
   3c9f8:	vpermps %zmm2,%zmm3,%zmm7
   3c9fe:	vaddps %zmm7,%zmm2,%zmm12
   3ca04:	vsubps %zmm2,%zmm7,%zmm12{%k1}
   3ca0a:	vpermps -0x180(%rax),%zmm6,%zmm7
   3ca11:	vaddps -0x180(%rax),%zmm7,%zmm2
   3ca18:	vsubps -0x180(%rax),%zmm7,%zmm2{%k4}
   3ca1f:	vpermps %zmm2,%zmm5,%zmm8
   3ca25:	vaddps %zmm8,%zmm2,%zmm7
   3ca2b:	vsubps %zmm2,%zmm8,%zmm7{%k3}
   3ca31:	vpermps %zmm7,%zmm4,%zmm8
   3ca37:	vaddps %zmm8,%zmm7,%zmm2
   3ca3d:	vsubps %zmm7,%zmm8,%zmm2{%k2}
   3ca43:	vpermps %zmm2,%zmm3,%zmm7
   3ca49:	vaddps %zmm7,%zmm2,%zmm10
   3ca4f:	vsubps %zmm2,%zmm7,%zmm10{%k1}
   3ca55:	vpermps -0x140(%rax),%zmm6,%zmm7
   3ca5c:	vaddps -0x140(%rax),%zmm7,%zmm2
   3ca63:	vsubps -0x140(%rax),%zmm7,%zmm2{%k4}
   3ca6a:	vpermps %zmm2,%zmm5,%zmm8
   3ca70:	vaddps %zmm8,%zmm2,%zmm7
   3ca76:	vsubps %zmm2,%zmm8,%zmm7{%k3}
   3ca7c:	vpermps %zmm7,%zmm4,%zmm8
   3ca82:	vaddps %zmm8,%zmm7,%zmm2
   3ca88:	vsubps %zmm7,%zmm8,%zmm2{%k2}
   3ca8e:	vpermps %zmm2,%zmm3,%zmm7
   3ca94:	vaddps %zmm7,%zmm2,%zmm11
   3ca9a:	vsubps %zmm2,%zmm7,%zmm11{%k1}
   3caa0:	vpermps -0x100(%rax),%zmm6,%zmm2
   3caa7:	vaddps -0x100(%rax),%zmm2,%zmm7
   3caae:	vsubps -0x100(%rax),%zmm2,%zmm7{%k4}
   3cab5:	vmovaps %zmm11,%zmm15
   3cabb:	vpermps %zmm7,%zmm5,%zmm8
   3cac1:	vfmadd132ps %zmm1,%zmm10,%zmm15
   3cac7:	vsubps %zmm11,%zmm10,%zmm10
   3cacd:	vaddps %zmm8,%zmm7,%zmm2
   3cad3:	vmovaps %zmm10,%zmm11
   3cad9:	vsubps %zmm7,%zmm8,%zmm2{%k3}
   3cadf:	vpermps %zmm2,%zmm4,%zmm8
   3cae5:	vaddps %zmm8,%zmm2,%zmm7
   3caeb:	vsubps %zmm2,%zmm8,%zmm7{%k2}
   3caf1:	vpermps %zmm7,%zmm3,%zmm8
   3caf7:	vaddps %zmm8,%zmm7,%zmm2
   3cafd:	vsubps %zmm7,%zmm8,%zmm2{%k1}
   3cb03:	vpermps -0xc0(%rax),%zmm6,%zmm8
   3cb0a:	vaddps -0xc0(%rax),%zmm8,%zmm7
   3cb11:	vsubps -0xc0(%rax),%zmm8,%zmm7{%k4}
   3cb18:	vpermps %zmm7,%zmm5,%zmm9
   3cb1e:	vaddps %zmm9,%zmm7,%zmm8
   3cb24:	vsubps %zmm7,%zmm9,%zmm8{%k3}
   3cb2a:	vpermps %zmm8,%zmm4,%zmm9
   3cb30:	vaddps %zmm9,%zmm8,%zmm7
   3cb36:	vsubps %zmm8,%zmm9,%zmm7{%k2}
   3cb3c:	vpermps %zmm7,%zmm3,%zmm8
   3cb42:	vaddps %zmm8,%zmm7,%zmm14
   3cb48:	vsubps %zmm7,%zmm8,%zmm14{%k1}
   3cb4e:	vpermps -0x80(%rax),%zmm6,%zmm8
   3cb55:	vaddps -0x80(%rax),%zmm8,%zmm7
   3cb5c:	vsubps -0x80(%rax),%zmm8,%zmm7{%k4}
   3cb63:	vpermps %zmm7,%zmm5,%zmm9
   3cb69:	vaddps %zmm9,%zmm7,%zmm8
   3cb6f:	vsubps %zmm7,%zmm9,%zmm8{%k3}
   3cb75:	vpermps %zmm8,%zmm4,%zmm9
   3cb7b:	vaddps %zmm9,%zmm8,%zmm7
   3cb81:	vsubps %zmm8,%zmm9,%zmm7{%k2}
   3cb87:	vpermps %zmm7,%zmm3,%zmm8
   3cb8d:	vaddps %zmm8,%zmm7,%zmm9
   3cb93:	vsubps %zmm7,%zmm8,%zmm9{%k1}
   3cb99:	vpermps -0x40(%rax),%zmm6,%zmm8
   3cba0:	vaddps -0x40(%rax),%zmm8,%zmm7
   3cba7:	vsubps -0x40(%rax),%zmm8,%zmm7{%k4}
   3cbae:	vpermps %zmm7,%zmm5,%zmm13
   3cbb4:	vaddps %zmm7,%zmm13,%zmm8
   3cbba:	vsubps %zmm7,%zmm13,%zmm8{%k3}
   3cbc0:	vpermps %zmm8,%zmm4,%zmm13
   3cbc6:	vaddps %zmm13,%zmm8,%zmm7
   3cbcc:	vsubps %zmm8,%zmm13,%zmm7{%k2}
   3cbd2:	vpermps %zmm7,%zmm3,%zmm8
   3cbd8:	vaddps %zmm7,%zmm8,%zmm13
   3cbde:	vsubps %zmm7,%zmm8,%zmm13{%k1}
   3cbe4:	vmovaps %zmm14,%zmm8
   3cbea:	vmovaps %zmm12,%zmm7
   3cbf0:	vfmadd132ps %zmm1,%zmm2,%zmm8
   3cbf6:	vsubps %zmm14,%zmm2,%zmm2
   3cbfc:	vfmadd132ps %zmm1,%zmm0,%zmm7
   3cc02:	vsubps %zmm12,%zmm0,%zmm0
   3cc08:	vmovaps %zmm15,%zmm12
   3cc0e:	vmovaps %zmm13,%zmm14
   3cc14:	vfmadd132ps %zmm1,%zmm9,%zmm14
   3cc1a:	vsubps %zmm13,%zmm9,%zmm9
   3cc20:	vfmadd132ps %zmm1,%zmm0,%zmm11
   3cc26:	vsubps %zmm10,%zmm0,%zmm0
   3cc2c:	vmovaps %zmm9,%zmm10
   3cc32:	vfmadd132ps %zmm1,%zmm7,%zmm12
   3cc38:	vsubps %zmm15,%zmm7,%zmm7
   3cc3e:	vfmadd132ps %zmm1,%zmm2,%zmm10
   3cc44:	vsubps %zmm9,%zmm2,%zmm2
   3cc4a:	vmovaps %zmm14,%zmm13
   3cc50:	vfmadd132ps %zmm1,%zmm8,%zmm13
   3cc56:	vsubps %zmm14,%zmm8,%zmm8
   3cc5c:	vmovaps %zmm2,%zmm9
   3cc62:	vfmadd132ps %zmm1,%zmm0,%zmm9
   3cc68:	vsubps %zmm2,%zmm0,%zmm0
   3cc6e:	vmovaps %zmm10,%zmm15
   3cc74:	vmovaps %zmm8,%zmm14
   3cc7a:	vfmadd132ps %zmm1,%zmm11,%zmm15
   3cc80:	vfmadd132ps %zmm1,%zmm7,%zmm14
   3cc86:	vsubps %zmm10,%zmm11,%zmm11
   3cc8c:	vmovaps %zmm13,%zmm16
   3cc92:	vsubps %zmm8,%zmm7,%zmm7
   3cc98:	vmovups %zmm0,-0x40(%rax)
   3cc9f:	vfmadd132ps %zmm1,%zmm12,%zmm16
   3cca5:	vsubps %zmm13,%zmm12,%zmm12
   3ccab:	vmovups %zmm9,-0x140(%rax)
   3ccb2:	vmovups %zmm11,-0xc0(%rax)
   3ccb9:	vmovups %zmm15,-0x1c0(%rax)
   3ccc0:	vmovups %zmm14,-0x180(%rax)
   3ccc7:	vmovups %zmm16,-0x200(%rax)
   3ccce:	vmovups %zmm12,-0x100(%rax)
   3ccd5:	vmovups %zmm7,-0x80(%rax)
   3ccdc:	cmp    %rdx,%rax
   3ccdf:	jne    3c970 <hf2_tb8_bal+0x80>
   3cce5:	vzeroupper
   3cce8:	ret
   3cce9:	nopl   0x0(%rax)

000000000003ccf0 <hf0_h20_nat>:
   3ccf0:	endbr64
   3ccf4:	push   %rbp
   3ccf5:	mov    %rdi,%rdx
   3ccf8:	mov    %rsp,%rbp
   3ccfb:	and    $0xffffffffffffffc0,%rsp
   3ccff:	sub    $0x140,%rsp
   3cd06:	vbroadcastss 0x212f0(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   3cd10:	mov    %fs:0x28,%rax
   3cd19:	mov    %rax,0x138(%rsp)
   3cd21:	xor    %eax,%eax
   3cd23:	mov    %rsp,%rdi
   3cd26:	vzeroupper
   3cd29:	call   10170 <inl_consts.constprop.1>
   3cd2e:	vmovaps (%rsp),%zmm3
   3cd35:	vmovaps 0x40(%rsp),%zmm4
   3cd3d:	vmovaps 0x80(%rsp),%zmm5
   3cd45:	vmovaps 0xc0(%rsp),%zmm6
   3cd4d:	test   %rsi,%rsi
   3cd50:	je     3cfff <hf0_h20_nat+0x30f>
   3cd56:	vbroadcastss 0x202a4(%rip),%zmm7        # 5d004 <_IO_stdin_used+0x4>
   3cd60:	mov    %rdx,%rax
   3cd63:	lea    -0x4(,%rsi,4),%rdx
   3cd6b:	and    $0xfffffffffffffe00,%rdx
   3cd72:	lea    0x200(%rax,%rdx,1),%rdx
   3cd7a:	nopw   0x0(%rax,%rax,1)
   3cd80:	vpermilps $0xb1,(%rax),%zmm9
   3cd87:	vfmadd231ps (%rax),%zmm3,%zmm9
   3cd8d:	add    $0x200,%rax
   3cd93:	vpermilps $0xb1,-0x1c0(%rax),%zmm8
   3cd9b:	vfmadd231ps -0x1c0(%rax),%zmm3,%zmm8
   3cda2:	vpermilps $0x4e,%zmm9,%zmm0
   3cda9:	vfmadd132ps %zmm4,%zmm0,%zmm9
   3cdaf:	vshuff32x4 $0xb1,%zmm9,%zmm9,%zmm0
   3cdb6:	vfmadd132ps %zmm5,%zmm0,%zmm9
   3cdbc:	vshuff32x4 $0x4e,%zmm9,%zmm9,%zmm0
   3cdc3:	vfmadd132ps %zmm6,%zmm0,%zmm9
   3cdc9:	vpermilps $0x4e,%zmm8,%zmm0
   3cdd0:	vfmadd132ps %zmm4,%zmm0,%zmm8
   3cdd6:	vshuff32x4 $0xb1,%zmm8,%zmm8,%zmm0
   3cddd:	vfmadd132ps %zmm5,%zmm0,%zmm8
   3cde3:	vshuff32x4 $0x4e,%zmm8,%zmm8,%zmm0
   3cdea:	vfmadd132ps %zmm6,%zmm0,%zmm8
   3cdf0:	vpermilps $0xb1,-0x180(%rax),%zmm0
   3cdf8:	vfmadd231ps -0x180(%rax),%zmm3,%zmm0
   3cdff:	vpermilps $0x4e,%zmm0,%zmm1
   3ce06:	vfmadd132ps %zmm4,%zmm1,%zmm0
   3ce0c:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3ce13:	vfmadd132ps %zmm5,%zmm1,%zmm0
   3ce19:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3ce20:	vfmadd132ps %zmm6,%zmm1,%zmm0
   3ce26:	vmovaps %zmm0,%zmm11
   3ce2c:	vpermilps $0xb1,-0x140(%rax),%zmm0
   3ce34:	vfmadd231ps -0x140(%rax),%zmm3,%zmm0
   3ce3b:	vpermilps $0x4e,%zmm0,%zmm1
   3ce42:	vfmadd132ps %zmm4,%zmm1,%zmm0
   3ce48:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3ce4f:	vfmadd132ps %zmm5,%zmm1,%zmm0
   3ce55:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3ce5c:	vfmadd132ps %zmm6,%zmm1,%zmm0
   3ce62:	vmovaps %zmm0,%zmm12
   3ce68:	vpermilps $0xb1,-0x100(%rax),%zmm0
   3ce70:	vfmadd231ps -0x100(%rax),%zmm3,%zmm0
   3ce77:	vpermilps $0x4e,%zmm0,%zmm1
   3ce7e:	vfmadd132ps %zmm4,%zmm1,%zmm0
   3ce84:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3ce8b:	vfmadd132ps %zmm5,%zmm1,%zmm0
   3ce91:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3ce98:	vfmadd132ps %zmm6,%zmm1,%zmm0
   3ce9e:	vmovaps %zmm0,%zmm13
   3cea4:	vpermilps $0xb1,-0xc0(%rax),%zmm0
   3ceac:	vfmadd231ps -0xc0(%rax),%zmm3,%zmm0
   3ceb3:	vsubps %zmm13,%zmm12,%zmm14
   3ceb9:	vpermilps $0x4e,%zmm0,%zmm1
   3cec0:	vfmadd132ps %zmm4,%zmm1,%zmm0
   3cec6:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3cecd:	vfmadd132ps %zmm5,%zmm1,%zmm0
   3ced3:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3ceda:	vmovaps %zmm0,%zmm2
   3cee0:	vpermilps $0xb1,-0x80(%rax),%zmm0
   3cee8:	vfmadd231ps -0x80(%rax),%zmm3,%zmm0
   3ceef:	vfmadd132ps %zmm6,%zmm1,%zmm2
   3cef5:	vpermilps $0x4e,%zmm0,%zmm1
   3cefc:	vsubps %zmm2,%zmm11,%zmm11
   3cf02:	vfmadd132ps %zmm4,%zmm1,%zmm0
   3cf08:	vaddps %zmm14,%zmm11,%zmm17
   3cf0e:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3cf15:	vfmadd132ps %zmm5,%zmm1,%zmm0
   3cf1b:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3cf22:	vfmadd231ps %zmm6,%zmm0,%zmm1
   3cf28:	vpermilps $0xb1,-0x40(%rax),%zmm0
   3cf30:	vfmadd231ps -0x40(%rax),%zmm3,%zmm0
   3cf37:	vaddps %zmm1,%zmm8,%zmm15
   3cf3d:	vpermilps $0x4e,%zmm0,%zmm10
   3cf44:	vfmadd132ps %zmm4,%zmm10,%zmm0
   3cf4a:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm10
   3cf51:	vfmadd132ps %zmm5,%zmm10,%zmm0
   3cf57:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm10
   3cf5e:	vfmadd132ps %zmm6,%zmm10,%zmm0
   3cf64:	vaddps %zmm0,%zmm9,%zmm9
   3cf6a:	vsubps %zmm15,%zmm9,%zmm16
   3cf70:	vsubps %zmm17,%zmm16,%zmm10
   3cf76:	vfmsub231ps %zmm7,%zmm10,%zmm0
   3cf7c:	vfmsub231ps %zmm7,%zmm10,%zmm2
   3cf82:	vaddps %zmm1,%zmm0,%zmm1
   3cf88:	vsubps %zmm13,%zmm2,%zmm10
   3cf8e:	vaddps %zmm8,%zmm0,%zmm0
   3cf94:	vaddps %zmm12,%zmm2,%zmm2
   3cf9a:	vsubps %zmm10,%zmm9,%zmm9
   3cfa0:	vaddps %zmm1,%zmm11,%zmm11
   3cfa6:	vaddps %zmm0,%zmm17,%zmm17
   3cfac:	vsubps %zmm2,%zmm16,%zmm16
   3cfb2:	vmovups %zmm0,-0x180(%rax)
   3cfb9:	vaddps %zmm10,%zmm15,%zmm15
   3cfbf:	vaddps %zmm1,%zmm14,%zmm14
   3cfc5:	vmovups %zmm2,-0x140(%rax)
   3cfcc:	vmovups %zmm9,-0x200(%rax)
   3cfd3:	vmovups %zmm11,-0x1c0(%rax)
   3cfda:	vmovups %zmm17,-0x100(%rax)
   3cfe1:	vmovups %zmm16,-0xc0(%rax)
   3cfe8:	vmovups %zmm15,-0x80(%rax)
   3cfef:	vmovups %zmm14,-0x40(%rax)
   3cff6:	cmp    %rax,%rdx
   3cff9:	jne    3cd80 <hf0_h20_nat+0x90>
   3cfff:	mov    0x138(%rsp),%rax
   3d007:	sub    %fs:0x28,%rax
   3d010:	jne    3d017 <hf0_h20_nat+0x327>
   3d012:	vzeroupper
   3d015:	leave
   3d016:	ret
   3d017:	vzeroupper
   3d01a:	call   4280 <__stack_chk_fail@plt>
   3d01f:	nop

000000000003d020 <hf0_g20_nat>:
   3d020:	endbr64
   3d024:	push   %rbp
   3d025:	mov    %rdi,%rdx
   3d028:	mov    %rsp,%rbp
   3d02b:	and    $0xffffffffffffffc0,%rsp
   3d02f:	sub    $0x140,%rsp
   3d036:	vbroadcastss 0x20fc0(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   3d040:	mov    %fs:0x28,%rax
   3d049:	mov    %rax,0x138(%rsp)
   3d051:	xor    %eax,%eax
   3d053:	mov    %rsp,%rdi
   3d056:	vzeroupper
   3d059:	call   10170 <inl_consts.constprop.1>
   3d05e:	vmovaps (%rsp),%zmm6
   3d065:	vmovaps 0x40(%rsp),%zmm7
   3d06d:	vmovaps 0x80(%rsp),%zmm8
   3d075:	vmovaps 0xc0(%rsp),%zmm9
   3d07d:	test   %rsi,%rsi
   3d080:	je     3d32f <hf0_g20_nat+0x30f>
   3d086:	vbroadcastss 0x1ff78(%rip),%zmm5        # 5d008 <_IO_stdin_used+0x8>
   3d090:	mov    %rdx,%rax
   3d093:	lea    -0x4(,%rsi,4),%rdx
   3d09b:	and    $0xfffffffffffffe00,%rdx
   3d0a2:	lea    0x200(%rax,%rdx,1),%rdx
   3d0aa:	nopw   0x0(%rax,%rax,1)
   3d0b0:	vpermilps $0xb1,(%rax),%zmm4
   3d0b7:	vfmadd231ps (%rax),%zmm6,%zmm4
   3d0bd:	add    $0x200,%rax
   3d0c3:	vpermilps $0xb1,-0x1c0(%rax),%zmm3
   3d0cb:	vfmadd231ps -0x1c0(%rax),%zmm6,%zmm3
   3d0d2:	vpermilps $0x4e,%zmm4,%zmm0
   3d0d9:	vfmadd132ps %zmm7,%zmm0,%zmm4
   3d0df:	vshuff32x4 $0xb1,%zmm4,%zmm4,%zmm0
   3d0e6:	vfmadd132ps %zmm8,%zmm0,%zmm4
   3d0ec:	vshuff32x4 $0x4e,%zmm4,%zmm4,%zmm0
   3d0f3:	vfmadd132ps %zmm9,%zmm0,%zmm4
   3d0f9:	vpermilps $0x4e,%zmm3,%zmm0
   3d100:	vfmadd132ps %zmm7,%zmm0,%zmm3
   3d106:	vshuff32x4 $0xb1,%zmm3,%zmm3,%zmm0
   3d10d:	vfmadd132ps %zmm8,%zmm0,%zmm3
   3d113:	vshuff32x4 $0x4e,%zmm3,%zmm3,%zmm0
   3d11a:	vfmadd132ps %zmm9,%zmm0,%zmm3
   3d120:	vpermilps $0xb1,-0x180(%rax),%zmm0
   3d128:	vfmadd231ps -0x180(%rax),%zmm6,%zmm0
   3d12f:	vaddps %zmm3,%zmm4,%zmm3
   3d135:	vpermilps $0x4e,%zmm0,%zmm1
   3d13c:	vfmadd132ps %zmm7,%zmm1,%zmm0
   3d142:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3d149:	vfmadd132ps %zmm8,%zmm1,%zmm0
   3d14f:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3d156:	vfmadd132ps %zmm9,%zmm1,%zmm0
   3d15c:	vmovaps %zmm0,%zmm11
   3d162:	vpermilps $0xb1,-0x140(%rax),%zmm0
   3d16a:	vfmadd231ps -0x140(%rax),%zmm6,%zmm0
   3d171:	vpermilps $0x4e,%zmm0,%zmm1
   3d178:	vfmadd132ps %zmm7,%zmm1,%zmm0
   3d17e:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3d185:	vfmadd132ps %zmm8,%zmm1,%zmm0
   3d18b:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3d192:	vfmadd132ps %zmm9,%zmm1,%zmm0
   3d198:	vmovaps %zmm0,%zmm12
   3d19e:	vpermilps $0xb1,-0x100(%rax),%zmm0
   3d1a6:	vfmadd231ps -0x100(%rax),%zmm6,%zmm0
   3d1ad:	vsubps %zmm12,%zmm11,%zmm12
   3d1b3:	vpermilps $0x4e,%zmm0,%zmm1
   3d1ba:	vfmadd132ps %zmm7,%zmm1,%zmm0
   3d1c0:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3d1c7:	vfmadd132ps %zmm8,%zmm1,%zmm0
   3d1cd:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3d1d4:	vfmadd132ps %zmm9,%zmm1,%zmm0
   3d1da:	vmovaps %zmm0,%zmm10
   3d1e0:	vpermilps $0xb1,-0xc0(%rax),%zmm0
   3d1e8:	vfmadd231ps -0xc0(%rax),%zmm6,%zmm0
   3d1ef:	vpermilps $0x4e,%zmm0,%zmm1
   3d1f6:	vfmadd132ps %zmm7,%zmm1,%zmm0
   3d1fc:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3d203:	vfmadd132ps %zmm8,%zmm1,%zmm0
   3d209:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3d210:	vfmadd132ps %zmm9,%zmm1,%zmm0
   3d216:	vpermilps $0xb1,-0x80(%rax),%zmm1
   3d21e:	vfmadd231ps -0x80(%rax),%zmm6,%zmm1
   3d225:	vaddps %zmm0,%zmm10,%zmm0
   3d22b:	vpermilps $0x4e,%zmm1,%zmm2
   3d232:	vfmadd132ps %zmm7,%zmm2,%zmm1
   3d238:	vshuff32x4 $0xb1,%zmm1,%zmm1,%zmm2
   3d23f:	vfmadd132ps %zmm8,%zmm2,%zmm1
   3d245:	vshuff32x4 $0x4e,%zmm1,%zmm1,%zmm2
   3d24c:	vfmadd132ps %zmm9,%zmm2,%zmm1
   3d252:	vpermilps $0xb1,-0x40(%rax),%zmm2
   3d25a:	vfmadd231ps -0x40(%rax),%zmm6,%zmm2
   3d261:	vpermilps $0x4e,%zmm2,%zmm13
   3d268:	vfmadd132ps %zmm7,%zmm13,%zmm2
   3d26e:	vshuff32x4 $0xb1,%zmm2,%zmm2,%zmm13
   3d275:	vfmadd132ps %zmm8,%zmm13,%zmm2
   3d27b:	vshuff32x4 $0x4e,%zmm2,%zmm2,%zmm13
   3d282:	vfmadd132ps %zmm9,%zmm13,%zmm2
   3d288:	vsubps %zmm12,%zmm3,%zmm13
   3d28e:	vfmadd132ps %zmm5,%zmm13,%zmm11
   3d294:	vfmsub132ps %zmm5,%zmm13,%zmm4
   3d29a:	vsubps %zmm2,%zmm1,%zmm2
   3d2a0:	vaddps %zmm2,%zmm0,%zmm13
   3d2a6:	vfnmadd132ps %zmm5,%zmm13,%zmm1
   3d2ac:	vfmsub132ps %zmm5,%zmm13,%zmm10
   3d2b2:	vaddps %zmm1,%zmm11,%zmm13
   3d2b8:	vfnmadd132ps %zmm5,%zmm13,%zmm0
   3d2be:	vfmsub132ps %zmm5,%zmm13,%zmm3
   3d2c4:	vaddps %zmm10,%zmm4,%zmm13
   3d2ca:	vfmadd132ps %zmm5,%zmm13,%zmm2
   3d2d0:	vfnmadd132ps %zmm5,%zmm13,%zmm12
   3d2d6:	vfmsub132ps %zmm5,%zmm0,%zmm11
   3d2dc:	vfmadd132ps %zmm5,%zmm3,%zmm1
   3d2e2:	vmovups %zmm0,-0x100(%rax)
   3d2e9:	vmovups %zmm3,-0x80(%rax)
   3d2f0:	vfmsub132ps %zmm5,%zmm2,%zmm4
   3d2f6:	vfnmadd132ps %zmm5,%zmm12,%zmm10
   3d2fc:	vmovups %zmm2,-0x1c0(%rax)
   3d303:	vmovups %zmm12,-0x140(%rax)
   3d30a:	vmovups %zmm11,-0x200(%rax)
   3d311:	vmovups %zmm1,-0x180(%rax)
   3d318:	vmovups %zmm4,-0xc0(%rax)
   3d31f:	vmovups %zmm10,-0x40(%rax)
   3d326:	cmp    %rax,%rdx
   3d329:	jne    3d0b0 <hf0_g20_nat+0x90>
   3d32f:	mov    0x138(%rsp),%rax
   3d337:	sub    %fs:0x28,%rax
   3d340:	jne    3d347 <hf0_g20_nat+0x327>
   3d342:	vzeroupper
   3d345:	leave
   3d346:	ret
   3d347:	vzeroupper
   3d34a:	call   4280 <__stack_chk_fail@plt>
   3d34f:	nop

000000000003d350 <hf1_g20_nat>:
   3d350:	endbr64
   3d354:	push   %rbp
   3d355:	mov    %rdi,%rdx
   3d358:	mov    %rsp,%rbp
   3d35b:	and    $0xffffffffffffffc0,%rsp
   3d35f:	sub    $0x140,%rsp
   3d366:	vbroadcastss 0x20c90(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   3d370:	mov    %fs:0x28,%rax
   3d379:	mov    %rax,0x138(%rsp)
   3d381:	xor    %eax,%eax
   3d383:	mov    %rsp,%rdi
   3d386:	vzeroupper
   3d389:	call   10120 <inl_consts.constprop.0>
   3d38e:	vmovaps (%rsp),%zmm8
   3d395:	vmovaps 0x40(%rsp),%zmm7
   3d39d:	vmovaps 0x80(%rsp),%zmm6
   3d3a5:	vmovaps 0xc0(%rsp),%zmm5
   3d3ad:	test   %rsi,%rsi
   3d3b0:	je     3d713 <hf1_g20_nat+0x3c3>
   3d3b6:	vbroadcastss 0x1fc48(%rip),%zmm1        # 5d008 <_IO_stdin_used+0x8>
   3d3c0:	mov    %rdx,%rax
   3d3c3:	lea    -0x4(,%rsi,4),%rdx
   3d3cb:	and    $0xfffffffffffffe00,%rdx
   3d3d2:	lea    0x200(%rax,%rdx,1),%rdx
   3d3da:	nopw   0x0(%rax,%rax,1)
   3d3e0:	vpxord (%rax),%zmm8,%zmm2
   3d3e6:	vpermilps $0xb1,(%rax),%zmm0
   3d3ed:	add    $0x200,%rax
   3d3f3:	vpxord -0x180(%rax),%zmm8,%zmm4
   3d3fa:	vpxord -0x140(%rax),%zmm8,%zmm10
   3d401:	vaddps %zmm2,%zmm0,%zmm0
   3d407:	vpxord %zmm0,%zmm7,%zmm2
   3d40d:	vpermilps $0x4e,%zmm0,%zmm0
   3d414:	vaddps %zmm2,%zmm0,%zmm0
   3d41a:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm2
   3d421:	vpxord %zmm0,%zmm6,%zmm0
   3d427:	vaddps %zmm0,%zmm2,%zmm0
   3d42d:	vpxord -0x1c0(%rax),%zmm8,%zmm2
   3d434:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm3
   3d43b:	vpxord %zmm0,%zmm5,%zmm0
   3d441:	vaddps %zmm0,%zmm3,%zmm3
   3d447:	vpermilps $0xb1,-0x1c0(%rax),%zmm0
   3d44f:	vaddps %zmm2,%zmm0,%zmm0
   3d455:	vpxord %zmm0,%zmm7,%zmm2
   3d45b:	vpermilps $0x4e,%zmm0,%zmm0
   3d462:	vaddps %zmm2,%zmm0,%zmm0
   3d468:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm9
   3d46f:	vpxord %zmm0,%zmm6,%zmm0
   3d475:	vaddps %zmm0,%zmm9,%zmm9
   3d47b:	vpermilps $0xb1,-0x180(%rax),%zmm0
   3d483:	vaddps %zmm4,%zmm0,%zmm0
   3d489:	vshuff32x4 $0x4e,%zmm9,%zmm9,%zmm2
   3d490:	vpxord %zmm9,%zmm5,%zmm9
   3d496:	vaddps %zmm9,%zmm2,%zmm2
   3d49c:	vpxord %zmm0,%zmm7,%zmm4
   3d4a2:	vpermilps $0x4e,%zmm0,%zmm0
   3d4a9:	vaddps %zmm4,%zmm0,%zmm0
   3d4af:	vaddps %zmm3,%zmm2,%zmm17
   3d4b5:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm4
   3d4bc:	vpxord %zmm0,%zmm6,%zmm0
   3d4c2:	vaddps %zmm0,%zmm4,%zmm0
   3d4c8:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm4
   3d4cf:	vpxord %zmm0,%zmm5,%zmm0
   3d4d5:	vaddps %zmm0,%zmm4,%zmm4
   3d4db:	vpermilps $0xb1,-0x140(%rax),%zmm0
   3d4e3:	vaddps %zmm10,%zmm0,%zmm0
   3d4e9:	vpxord %zmm0,%zmm7,%zmm10
   3d4ef:	vpermilps $0x4e,%zmm0,%zmm0
   3d4f6:	vaddps %zmm10,%zmm0,%zmm0
   3d4fc:	vpxord -0x100(%rax),%zmm8,%zmm10
   3d503:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm12
   3d50a:	vpxord %zmm0,%zmm6,%zmm0
   3d510:	vaddps %zmm0,%zmm12,%zmm12
   3d516:	vpermilps $0xb1,-0x100(%rax),%zmm0
   3d51e:	vaddps %zmm10,%zmm0,%zmm0
   3d524:	vshuff32x4 $0x4e,%zmm12,%zmm12,%zmm11
   3d52b:	vpxord %zmm12,%zmm5,%zmm12
   3d531:	vaddps %zmm12,%zmm11,%zmm11
   3d537:	vpxord %zmm0,%zmm7,%zmm10
   3d53d:	vpermilps $0x4e,%zmm0,%zmm0
   3d544:	vaddps %zmm10,%zmm0,%zmm0
   3d54a:	vsubps %zmm11,%zmm4,%zmm11
   3d550:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm10
   3d557:	vpxord %zmm0,%zmm6,%zmm0
   3d55d:	vaddps %zmm0,%zmm10,%zmm0
   3d563:	vpxord -0xc0(%rax),%zmm8,%zmm10
   3d56a:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm13
   3d571:	vpxord %zmm0,%zmm5,%zmm0
   3d577:	vaddps %zmm0,%zmm13,%zmm13
   3d57d:	vpermilps $0xb1,-0xc0(%rax),%zmm0
   3d585:	vaddps %zmm10,%zmm0,%zmm0
   3d58b:	vpxord %zmm0,%zmm7,%zmm10
   3d591:	vpermilps $0x4e,%zmm0,%zmm0
   3d598:	vaddps %zmm10,%zmm0,%zmm0
   3d59e:	vpxord -0x80(%rax),%zmm8,%zmm10
   3d5a5:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm16
   3d5ac:	vpxord %zmm0,%zmm6,%zmm0
   3d5b2:	vaddps %zmm0,%zmm16,%zmm16
   3d5b8:	vpermilps $0xb1,-0x80(%rax),%zmm0
   3d5c0:	vaddps %zmm10,%zmm0,%zmm0
   3d5c6:	vshuff32x4 $0x4e,%zmm16,%zmm16,%zmm15
   3d5cd:	vpxord %zmm16,%zmm5,%zmm16
   3d5d3:	vpxord %zmm0,%zmm7,%zmm10
   3d5d9:	vpermilps $0x4e,%zmm0,%zmm0
   3d5e0:	vaddps %zmm10,%zmm0,%zmm0
   3d5e6:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm14
   3d5ed:	vpxord %zmm0,%zmm6,%zmm0
   3d5f3:	vaddps %zmm0,%zmm14,%zmm14
   3d5f9:	vpermilps $0xb1,-0x40(%rax),%zmm0
   3d601:	vshuff32x4 $0x4e,%zmm14,%zmm14,%zmm10
   3d608:	vpxord %zmm14,%zmm5,%zmm14
   3d60e:	vaddps %zmm14,%zmm10,%zmm18
   3d614:	vpxord -0x40(%rax),%zmm8,%zmm10
   3d61b:	vaddps %zmm10,%zmm0,%zmm0
   3d621:	vpxord %zmm0,%zmm7,%zmm10
   3d627:	vpermilps $0x4e,%zmm0,%zmm0
   3d62e:	vaddps %zmm10,%zmm0,%zmm0
   3d634:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm14
   3d63b:	vpxord %zmm0,%zmm6,%zmm0
   3d641:	vaddps %zmm0,%zmm14,%zmm14
   3d647:	vsubps %zmm11,%zmm17,%zmm0
   3d64d:	vshuff32x4 $0x4e,%zmm14,%zmm14,%zmm10
   3d654:	vfmadd132ps %zmm1,%zmm0,%zmm4
   3d65a:	vpxord %zmm14,%zmm5,%zmm14
   3d660:	vfmsub132ps %zmm1,%zmm0,%zmm3
   3d666:	vaddps %zmm14,%zmm10,%zmm2
   3d66c:	vaddps %zmm16,%zmm15,%zmm0
   3d672:	vmovaps %zmm18,%zmm10
   3d678:	vaddps %zmm13,%zmm0,%zmm0
   3d67e:	vsubps %zmm2,%zmm18,%zmm2
   3d684:	vaddps %zmm2,%zmm0,%zmm9
   3d68a:	vfnmadd132ps %zmm1,%zmm9,%zmm10
   3d690:	vfmsub231ps %zmm1,%zmm13,%zmm9
   3d696:	vaddps %zmm10,%zmm4,%zmm12
   3d69c:	vaddps %zmm9,%zmm3,%zmm13
   3d6a2:	vfnmadd132ps %zmm1,%zmm12,%zmm0
   3d6a8:	vfmadd132ps %zmm1,%zmm13,%zmm2
   3d6ae:	vfmsub231ps %zmm1,%zmm17,%zmm12
   3d6b4:	vfnmadd132ps %zmm1,%zmm13,%zmm11
   3d6ba:	vfmsub132ps %zmm1,%zmm0,%zmm4
   3d6c0:	vfmsub132ps %zmm1,%zmm2,%zmm3
   3d6c6:	vmovups %zmm2,-0x1c0(%rax)
   3d6cd:	vfmadd132ps %zmm1,%zmm12,%zmm10
   3d6d3:	vfnmadd132ps %zmm1,%zmm11,%zmm9
   3d6d9:	vmovups %zmm11,-0x140(%rax)
   3d6e0:	vmovups %zmm0,-0x100(%rax)
   3d6e7:	vmovups %zmm12,-0x80(%rax)
   3d6ee:	vmovups %zmm4,-0x200(%rax)
   3d6f5:	vmovups %zmm10,-0x180(%rax)
   3d6fc:	vmovups %zmm3,-0xc0(%rax)
   3d703:	vmovups %zmm9,-0x40(%rax)
   3d70a:	cmp    %rax,%rdx
   3d70d:	jne    3d3e0 <hf1_g20_nat+0x90>
   3d713:	mov    0x138(%rsp),%rax
   3d71b:	sub    %fs:0x28,%rax
   3d724:	jne    3d72b <hf1_g20_nat+0x3db>
   3d726:	vzeroupper
   3d729:	leave
   3d72a:	ret
   3d72b:	vzeroupper
   3d72e:	call   4280 <__stack_chk_fail@plt>
   3d733:	data16 cs nopw 0x0(%rax,%rax,1)
   3d73e:	xchg   %ax,%ax

000000000003d740 <hf0_broken_g20>:
   3d740:	endbr64
   3d744:	push   %rbp
   3d745:	mov    %rdi,%rdx
   3d748:	mov    %rsp,%rbp
   3d74b:	and    $0xffffffffffffffc0,%rsp
   3d74f:	sub    $0x140,%rsp
   3d756:	vbroadcastss 0x208a0(%rip),%zmm0        # 5e000 <_IO_stdin_used+0x1000>
   3d760:	mov    %fs:0x28,%rax
   3d769:	mov    %rax,0x138(%rsp)
   3d771:	xor    %eax,%eax
   3d773:	mov    %rsp,%rdi
   3d776:	vzeroupper
   3d779:	call   10170 <inl_consts.constprop.1>
   3d77e:	vmovaps (%rsp),%zmm6
   3d785:	vmovaps 0x40(%rsp),%zmm7
   3d78d:	vmovaps 0x80(%rsp),%zmm8
   3d795:	vmovaps 0xc0(%rsp),%zmm9
   3d79d:	test   %rsi,%rsi
   3d7a0:	je     3da4f <hf0_broken_g20+0x30f>
   3d7a6:	vbroadcastss 0x1f858(%rip),%zmm5        # 5d008 <_IO_stdin_used+0x8>
   3d7b0:	mov    %rdx,%rax
   3d7b3:	lea    -0x4(,%rsi,4),%rdx
   3d7bb:	and    $0xfffffffffffffe00,%rdx
   3d7c2:	lea    0x200(%rax,%rdx,1),%rdx
   3d7ca:	nopw   0x0(%rax,%rax,1)
   3d7d0:	vpermilps $0xb1,(%rax),%zmm3
   3d7d7:	vfmadd231ps (%rax),%zmm6,%zmm3
   3d7dd:	add    $0x200,%rax
   3d7e3:	vpermilps $0xb1,-0x1c0(%rax),%zmm4
   3d7eb:	vfmadd231ps -0x1c0(%rax),%zmm6,%zmm4
   3d7f2:	vpermilps $0x4e,%zmm3,%zmm0
   3d7f9:	vfmadd132ps %zmm7,%zmm0,%zmm3
   3d7ff:	vshuff32x4 $0xb1,%zmm3,%zmm3,%zmm0
   3d806:	vfmadd132ps %zmm8,%zmm0,%zmm3
   3d80c:	vshuff32x4 $0x4e,%zmm3,%zmm3,%zmm0
   3d813:	vfmadd132ps %zmm9,%zmm0,%zmm3
   3d819:	vpermilps $0x4e,%zmm4,%zmm0
   3d820:	vfmadd132ps %zmm7,%zmm0,%zmm4
   3d826:	vshuff32x4 $0xb1,%zmm4,%zmm4,%zmm0
   3d82d:	vfmadd132ps %zmm8,%zmm0,%zmm4
   3d833:	vshuff32x4 $0x4e,%zmm4,%zmm4,%zmm0
   3d83a:	vfmadd132ps %zmm9,%zmm0,%zmm4
   3d840:	vpermilps $0xb1,-0x180(%rax),%zmm0
   3d848:	vfmadd231ps -0x180(%rax),%zmm6,%zmm0
   3d84f:	vaddps %zmm4,%zmm3,%zmm4
   3d855:	vpermilps $0x4e,%zmm0,%zmm1
   3d85c:	vfmadd132ps %zmm7,%zmm1,%zmm0
   3d862:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3d869:	vfmadd132ps %zmm8,%zmm1,%zmm0
   3d86f:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3d876:	vfmadd132ps %zmm9,%zmm1,%zmm0
   3d87c:	vmovaps %zmm0,%zmm11
   3d882:	vpermilps $0xb1,-0x140(%rax),%zmm0
   3d88a:	vfmadd231ps -0x140(%rax),%zmm6,%zmm0
   3d891:	vpermilps $0x4e,%zmm0,%zmm1
   3d898:	vfmadd132ps %zmm7,%zmm1,%zmm0
   3d89e:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3d8a5:	vfmadd132ps %zmm8,%zmm1,%zmm0
   3d8ab:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3d8b2:	vfmadd132ps %zmm9,%zmm1,%zmm0
   3d8b8:	vmovaps %zmm0,%zmm12
   3d8be:	vpermilps $0xb1,-0x100(%rax),%zmm0
   3d8c6:	vfmadd231ps -0x100(%rax),%zmm6,%zmm0
   3d8cd:	vsubps %zmm12,%zmm11,%zmm12
   3d8d3:	vpermilps $0x4e,%zmm0,%zmm1
   3d8da:	vfmadd132ps %zmm7,%zmm1,%zmm0
   3d8e0:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3d8e7:	vfmadd132ps %zmm8,%zmm1,%zmm0
   3d8ed:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3d8f4:	vfmadd132ps %zmm9,%zmm1,%zmm0
   3d8fa:	vmovaps %zmm0,%zmm10
   3d900:	vpermilps $0xb1,-0xc0(%rax),%zmm0
   3d908:	vfmadd231ps -0xc0(%rax),%zmm6,%zmm0
   3d90f:	vpermilps $0x4e,%zmm0,%zmm1
   3d916:	vfmadd132ps %zmm7,%zmm1,%zmm0
   3d91c:	vshuff32x4 $0xb1,%zmm0,%zmm0,%zmm1
   3d923:	vfmadd132ps %zmm8,%zmm1,%zmm0
   3d929:	vshuff32x4 $0x4e,%zmm0,%zmm0,%zmm1
   3d930:	vfmadd132ps %zmm9,%zmm1,%zmm0
   3d936:	vpermilps $0xb1,-0x80(%rax),%zmm1
   3d93e:	vfmadd231ps -0x80(%rax),%zmm6,%zmm1
   3d945:	vaddps %zmm0,%zmm10,%zmm0
   3d94b:	vpermilps $0x4e,%zmm1,%zmm2
   3d952:	vfmadd132ps %zmm7,%zmm2,%zmm1
   3d958:	vshuff32x4 $0xb1,%zmm1,%zmm1,%zmm2
   3d95f:	vfmadd132ps %zmm8,%zmm2,%zmm1
   3d965:	vshuff32x4 $0x4e,%zmm1,%zmm1,%zmm2
   3d96c:	vfmadd132ps %zmm9,%zmm2,%zmm1
   3d972:	vpermilps $0xb1,-0x40(%rax),%zmm2
   3d97a:	vfmadd231ps -0x40(%rax),%zmm6,%zmm2
   3d981:	vpermilps $0x4e,%zmm2,%zmm13
   3d988:	vfmadd132ps %zmm7,%zmm13,%zmm2
   3d98e:	vshuff32x4 $0xb1,%zmm2,%zmm2,%zmm13
   3d995:	vfmadd132ps %zmm8,%zmm13,%zmm2
   3d99b:	vshuff32x4 $0x4e,%zmm2,%zmm2,%zmm13
   3d9a2:	vfmadd132ps %zmm9,%zmm13,%zmm2
   3d9a8:	vsubps %zmm12,%zmm4,%zmm13
   3d9ae:	vfmadd132ps %zmm5,%zmm13,%zmm11
   3d9b4:	vfmsub132ps %zmm5,%zmm13,%zmm3
   3d9ba:	vsubps %zmm2,%zmm1,%zmm2
   3d9c0:	vaddps %zmm2,%zmm0,%zmm13
   3d9c6:	vfnmadd132ps %zmm5,%zmm13,%zmm1
   3d9cc:	vfmsub132ps %zmm5,%zmm13,%zmm10
   3d9d2:	vaddps %zmm1,%zmm11,%zmm13
   3d9d8:	vfnmadd132ps %zmm5,%zmm13,%zmm0
   3d9de:	vfmsub132ps %zmm5,%zmm13,%zmm4
   3d9e4:	vaddps %zmm10,%zmm3,%zmm13
   3d9ea:	vfmadd132ps %zmm5,%zmm13,%zmm2
   3d9f0:	vfnmadd132ps %zmm5,%zmm13,%zmm12
   3d9f6:	vfmsub132ps %zmm5,%zmm0,%zmm11
   3d9fc:	vfmadd132ps %zmm5,%zmm4,%zmm1
   3da02:	vmovups %zmm0,-0x100(%rax)
   3da09:	vmovups %zmm4,-0xc0(%rax)
   3da10:	vfmsub132ps %zmm5,%zmm2,%zmm3
   3da16:	vfnmadd132ps %zmm5,%zmm12,%zmm10
   3da1c:	vmovups %zmm2,-0x1c0(%rax)
   3da23:	vmovups %zmm12,-0x140(%rax)
   3da2a:	vmovups %zmm11,-0x200(%rax)
   3da31:	vmovups %zmm1,-0x180(%rax)
   3da38:	vmovups %zmm3,-0x80(%rax)
   3da3f:	vmovups %zmm10,-0x40(%rax)
   3da46:	cmp    %rax,%rdx
   3da49:	jne    3d7d0 <hf0_broken_g20+0x90>
   3da4f:	mov    0x138(%rsp),%rax
   3da57:	sub    %fs:0x28,%rax
   3da60:	jne    3da67 <hf0_broken_g20+0x327>
   3da62:	vzeroupper
   3da65:	leave
   3da66:	ret
   3da67:	vzeroupper
   3da6a:	call   4280 <__stack_chk_fail@plt>
   3da6f:	nop

