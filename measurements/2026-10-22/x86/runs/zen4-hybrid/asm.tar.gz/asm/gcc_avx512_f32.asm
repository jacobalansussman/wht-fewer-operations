0000000000006640 <hstep_tb2_nat>:
    6640:	endbr64
    6644:	vbroadcastss 0x4657a(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
    664e:	test   %rsi,%rsi
    6651:	je     66b7 <hstep_tb2_nat+0x77>
    6653:	lea    (%rdx,%rdx,1),%r11
    6657:	test   %rdx,%rdx
    665a:	je     66b7 <hstep_tb2_nat+0x77>
    665c:	lea    -0x1(%rdx),%r9
    6660:	xor    %r8d,%r8d
    6663:	lea    0x40(%rdi),%r10
    6667:	and    $0xfffffffffffffff0,%r9
    666b:	nopl   0x0(%rax,%rax,1)
    6670:	lea    (%r9,%r8,1),%rcx
    6674:	lea    (%rdi,%r8,4),%rax
    6678:	lea    (%r10,%rcx,4),%rcx
    667c:	nopl   0x0(%rax)
    6680:	vmovups (%rax),%zmm0
    6686:	vmovups (%rax,%rdx,4),%zmm1
    668d:	vaddps %zmm1,%zmm0,%zmm2
    6693:	vsubps %zmm1,%zmm0,%zmm0
    6699:	vmovups %zmm2,(%rax)
    669f:	vmovups %zmm0,(%rax,%rdx,4)
    66a6:	add    $0x40,%rax
    66aa:	cmp    %rax,%rcx
    66ad:	jne    6680 <hstep_tb2_nat+0x40>
    66af:	add    %r11,%r8
    66b2:	cmp    %rsi,%r8
    66b5:	jb     6670 <hstep_tb2_nat+0x30>
    66b7:	vzeroupper
    66ba:	ret
    66bb:	nopl   0x0(%rax,%rax,1)

00000000000066c0 <hstep_tb4_nat>:
    66c0:	endbr64
    66c4:	vbroadcastss 0x464fa(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
    66ce:	test   %rsi,%rsi
    66d1:	je     678f <hstep_tb4_nat+0xcf>
    66d7:	push   %rbp
    66d8:	mov    %rsp,%rbp
    66db:	push   %rbx
    66dc:	lea    0x0(,%rdx,4),%rbx
    66e4:	test   %rdx,%rdx
    66e7:	je     6786 <hstep_tb4_nat+0xc6>
    66ed:	lea    -0x1(%rdx),%r10
    66f1:	lea    (%rdx,%rdx,2),%rcx
    66f5:	xor    %r9d,%r9d
    66f8:	and    $0xfffffffffffffff0,%r10
    66fc:	shl    $0x2,%rcx
    6700:	lea    0x40(%rdi),%r11
    6704:	nopl   0x0(%rax)
    6708:	lea    (%r9,%r10,1),%r8
    670c:	lea    (%rdi,%r9,4),%rax
    6710:	lea    (%r11,%r8,4),%r8
    6714:	nopl   0x0(%rax)
    6718:	vmovups (%rax),%zmm5
    671e:	vmovups (%rax,%rdx,8),%zmm7
    6725:	vaddps (%rax,%rdx,4),%zmm5,%zmm2
    672c:	vaddps (%rax,%rcx,1),%zmm7,%zmm3
    6733:	vsubps (%rax,%rdx,4),%zmm5,%zmm0
    673a:	vsubps (%rax,%rcx,1),%zmm7,%zmm1
    6741:	vaddps %zmm3,%zmm2,%zmm4
    6747:	vsubps %zmm3,%zmm2,%zmm2
    674d:	vmovups %zmm4,(%rax)
    6753:	vaddps %zmm1,%zmm0,%zmm4
    6759:	vsubps %zmm1,%zmm0,%zmm0
    675f:	vmovups %zmm4,(%rax,%rdx,4)
    6766:	vmovups %zmm2,(%rax,%rdx,8)
    676d:	add    $0x40,%rax
    6771:	vmovups %zmm0,-0x40(%rax,%rcx,1)
    6779:	cmp    %rax,%r8
    677c:	jne    6718 <hstep_tb4_nat+0x58>
    677e:	add    %rbx,%r9
    6781:	cmp    %rsi,%r9
    6784:	jb     6708 <hstep_tb4_nat+0x48>
    6786:	vzeroupper
    6789:	mov    -0x8(%rbp),%rbx
    678d:	leave
    678e:	ret
    678f:	vzeroupper
    6792:	ret
    6793:	data16 cs nopw 0x0(%rax,%rax,1)
    679e:	xchg   %ax,%ax

0000000000006860 <hfirst_kid_nat>:
    6860:	endbr64
    6864:	vbroadcastss 0x4635a(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
    686e:	test   %rsi,%rsi
    6871:	je     6931 <hfirst_kid_nat+0xd1>
    6877:	lea    -0x4(,%rsi,4),%rax
    687f:	mov    $0xffffaaaa,%edx
    6884:	mov    $0xffffcccc,%ecx
    6889:	vmovdqa32 0x461ed(%rip),%zmm6        # 4ca80 <FFHT_THR_F+0x80>
    6893:	and    $0xffffffffffffffc0,%rax
    6897:	kmovw  %edx,%k4
    689b:	vmovdqa32 0x4621b(%rip),%zmm5        # 4cac0 <FFHT_THR_F+0xc0>
    68a5:	vmovdqa32 0x46251(%rip),%zmm4        # 4cb00 <FFHT_THR_F+0x100>
    68af:	mov    $0xfffff0f0,%edx
    68b4:	kmovw  %ecx,%k3
    68b8:	lea    0x40(%rdi,%rax,1),%rax
    68bd:	vmovdqa32 0x46279(%rip),%zmm3        # 4cb40 <FFHT_THR_F+0x140>
    68c7:	mov    $0xffffff00,%ecx
    68cc:	kmovw  %edx,%k2
    68d0:	kmovw  %ecx,%k1
    68d4:	nopl   0x0(%rax)
    68d8:	vpermps (%rdi),%zmm6,%zmm1
    68de:	vaddps (%rdi),%zmm1,%zmm0
    68e4:	add    $0x40,%rdi
    68e8:	vsubps -0x40(%rdi),%zmm1,%zmm0{%k4}
    68ef:	vpermps %zmm0,%zmm5,%zmm2
    68f5:	vaddps %zmm2,%zmm0,%zmm1
    68fb:	vsubps %zmm0,%zmm2,%zmm1{%k3}
    6901:	vpermps %zmm1,%zmm4,%zmm2
    6907:	vaddps %zmm2,%zmm1,%zmm0
    690d:	vsubps %zmm1,%zmm2,%zmm0{%k2}
    6913:	vpermps %zmm0,%zmm3,%zmm2
    6919:	vaddps %zmm0,%zmm2,%zmm1
    691f:	vsubps %zmm0,%zmm2,%zmm1{%k1}
    6925:	vmovups %zmm1,-0x40(%rdi)
    692c:	cmp    %rdi,%rax
    692f:	jne    68d8 <hfirst_kid_nat+0x78>
    6931:	vzeroupper
    6934:	ret
    6935:	data16 cs nopw 0x0(%rax,%rax,1)

0000000000006940 <hfirst_tb2_nat>:
    6940:	endbr64
    6944:	vbroadcastss 0x4627a(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
    694e:	test   %rsi,%rsi
    6951:	je     6a7b <hfirst_tb2_nat+0x13b>
    6957:	lea    -0x4(,%rsi,4),%rax
    695f:	mov    $0xffffaaaa,%edx
    6964:	mov    $0xffffcccc,%ecx
    6969:	vmovdqa32 0x4610d(%rip),%zmm7        # 4ca80 <FFHT_THR_F+0x80>
    6973:	and    $0xffffffffffffff80,%rax
    6977:	kmovw  %edx,%k4
    697b:	vmovdqa32 0x4613b(%rip),%zmm6        # 4cac0 <FFHT_THR_F+0xc0>
    6985:	vmovdqa32 0x46171(%rip),%zmm5        # 4cb00 <FFHT_THR_F+0x100>
    698f:	vmovdqa32 0x461a7(%rip),%zmm4        # 4cb40 <FFHT_THR_F+0x140>
    6999:	mov    $0xfffff0f0,%edx
    699e:	kmovw  %ecx,%k3
    69a2:	lea    0x80(%rdi,%rax,1),%rax
    69aa:	mov    $0xffffff00,%ecx
    69af:	kmovw  %edx,%k2
    69b3:	kmovw  %ecx,%k1
    69b7:	nopw   0x0(%rax,%rax,1)
    69c0:	vpermps (%rdi),%zmm7,%zmm0
    69c6:	vaddps (%rdi),%zmm0,%zmm1
    69cc:	sub    $0xffffffffffffff80,%rdi
    69d0:	vsubps -0x80(%rdi),%zmm0,%zmm1{%k4}
    69d7:	vpermps %zmm1,%zmm6,%zmm2
    69dd:	vaddps %zmm2,%zmm1,%zmm0
    69e3:	vsubps %zmm1,%zmm2,%zmm0{%k3}
    69e9:	vpermps %zmm0,%zmm5,%zmm2
    69ef:	vaddps %zmm2,%zmm0,%zmm1
    69f5:	vsubps %zmm0,%zmm2,%zmm1{%k2}
    69fb:	vpermps %zmm1,%zmm4,%zmm2
    6a01:	vaddps %zmm2,%zmm1,%zmm0
    6a07:	vsubps %zmm1,%zmm2,%zmm0{%k1}
    6a0d:	vpermps -0x40(%rdi),%zmm7,%zmm2
    6a14:	vaddps -0x40(%rdi),%zmm2,%zmm1
    6a1b:	vsubps -0x40(%rdi),%zmm2,%zmm1{%k4}
    6a22:	vpermps %zmm1,%zmm6,%zmm3
    6a28:	vaddps %zmm3,%zmm1,%zmm2
    6a2e:	vsubps %zmm1,%zmm3,%zmm2{%k3}
    6a34:	vpermps %zmm2,%zmm5,%zmm3
    6a3a:	vaddps %zmm3,%zmm2,%zmm1
    6a40:	vsubps %zmm2,%zmm3,%zmm1{%k2}
    6a46:	vpermps %zmm1,%zmm4,%zmm3
    6a4c:	vaddps %zmm1,%zmm3,%zmm2
    6a52:	vsubps %zmm1,%zmm3,%zmm2{%k1}
    6a58:	vaddps %zmm0,%zmm2,%zmm1
    6a5e:	vsubps %zmm2,%zmm0,%zmm0
    6a64:	vmovups %zmm1,-0x80(%rdi)
    6a6b:	vmovups %zmm0,-0x40(%rdi)
    6a72:	cmp    %rax,%rdi
    6a75:	jne    69c0 <hfirst_tb2_nat+0x80>
    6a7b:	vzeroupper
    6a7e:	ret
    6a7f:	nop

0000000000006a80 <hfirst_tb4_nat>:
    6a80:	endbr64
    6a84:	vbroadcastss 0x4613a(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
    6a8e:	test   %rsi,%rsi
    6a91:	je     6c85 <hfirst_tb4_nat+0x205>
    6a97:	mov    $0xffffaaaa,%ecx
    6a9c:	mov    %rdi,%rax
    6a9f:	lea    -0x4(,%rsi,4),%rdx
    6aa7:	vmovdqa32 0x45fcf(%rip),%zmm7        # 4ca80 <FFHT_THR_F+0x80>
    6ab1:	vmovdqa32 0x46005(%rip),%zmm6        # 4cac0 <FFHT_THR_F+0xc0>
    6abb:	xor    %dl,%dl
    6abd:	kmovw  %ecx,%k4
    6ac1:	vmovdqa32 0x46035(%rip),%zmm5        # 4cb00 <FFHT_THR_F+0x100>
    6acb:	mov    $0xffffcccc,%ecx
    6ad0:	lea    0x100(%rdi,%rdx,1),%rdx
    6ad8:	vmovdqa32 0x4605e(%rip),%zmm4        # 4cb40 <FFHT_THR_F+0x140>
    6ae2:	mov    $0xffffff00,%edi
    6ae7:	kmovw  %ecx,%k3
    6aeb:	mov    $0xfffff0f0,%ecx
    6af0:	kmovw  %edi,%k1
    6af4:	kmovw  %ecx,%k2
    6af8:	nopl   0x0(%rax,%rax,1)
    6b00:	vpermps (%rax),%zmm7,%zmm0
    6b06:	vaddps (%rax),%zmm0,%zmm1
    6b0c:	add    $0x100,%rax
    6b12:	vsubps -0x100(%rax),%zmm0,%zmm1{%k4}
    6b19:	vpermps %zmm1,%zmm6,%zmm2
    6b1f:	vaddps %zmm2,%zmm1,%zmm0
    6b25:	vsubps %zmm1,%zmm2,%zmm0{%k3}
    6b2b:	vpermps %zmm0,%zmm5,%zmm2
    6b31:	vaddps %zmm2,%zmm0,%zmm1
    6b37:	vsubps %zmm0,%zmm2,%zmm1{%k2}
    6b3d:	vpermps %zmm1,%zmm4,%zmm2
    6b43:	vaddps %zmm2,%zmm1,%zmm0
    6b49:	vsubps %zmm1,%zmm2,%zmm0{%k1}
    6b4f:	vpermps -0xc0(%rax),%zmm7,%zmm2
    6b56:	vaddps -0xc0(%rax),%zmm2,%zmm1
    6b5d:	vsubps -0xc0(%rax),%zmm2,%zmm1{%k4}
    6b64:	vpermps %zmm1,%zmm6,%zmm3
    6b6a:	vaddps %zmm3,%zmm1,%zmm2
    6b70:	vsubps %zmm1,%zmm3,%zmm2{%k3}
    6b76:	vpermps %zmm2,%zmm5,%zmm3
    6b7c:	vaddps %zmm3,%zmm2,%zmm1
    6b82:	vsubps %zmm2,%zmm3,%zmm1{%k2}
    6b88:	vpermps %zmm1,%zmm4,%zmm2
    6b8e:	vaddps %zmm2,%zmm1,%zmm8
    6b94:	vsubps %zmm1,%zmm2,%zmm8{%k1}
    6b9a:	vpermps -0x80(%rax),%zmm7,%zmm1
    6ba1:	vaddps -0x80(%rax),%zmm1,%zmm2
    6ba8:	vsubps -0x80(%rax),%zmm1,%zmm2{%k4}
    6baf:	vpermps %zmm2,%zmm6,%zmm3
    6bb5:	vaddps %zmm3,%zmm2,%zmm1
    6bbb:	vsubps %zmm2,%zmm3,%zmm1{%k3}
    6bc1:	vpermps %zmm1,%zmm5,%zmm3
    6bc7:	vaddps %zmm3,%zmm1,%zmm2
    6bcd:	vsubps %zmm1,%zmm3,%zmm2{%k2}
    6bd3:	vpermps %zmm2,%zmm4,%zmm3
    6bd9:	vaddps %zmm3,%zmm2,%zmm1
    6bdf:	vsubps %zmm2,%zmm3,%zmm1{%k1}
    6be5:	vpermps -0x40(%rax),%zmm7,%zmm3
    6bec:	vaddps -0x40(%rax),%zmm3,%zmm2
    6bf3:	vsubps -0x40(%rax),%zmm3,%zmm2{%k4}
    6bfa:	vpermps %zmm2,%zmm6,%zmm9
    6c00:	vaddps %zmm9,%zmm2,%zmm3
    6c06:	vsubps %zmm2,%zmm9,%zmm3{%k3}
    6c0c:	vpermps %zmm3,%zmm5,%zmm9
    6c12:	vaddps %zmm9,%zmm3,%zmm2
    6c18:	vsubps %zmm3,%zmm9,%zmm2{%k2}
    6c1e:	vpermps %zmm2,%zmm4,%zmm9
    6c24:	vaddps %zmm2,%zmm9,%zmm3
    6c2a:	vsubps %zmm2,%zmm9,%zmm3{%k1}
    6c30:	vaddps %zmm8,%zmm0,%zmm2
    6c36:	vsubps %zmm8,%zmm0,%zmm0
    6c3c:	vaddps %zmm1,%zmm3,%zmm8
    6c42:	vsubps %zmm3,%zmm1,%zmm1
    6c48:	vaddps %zmm8,%zmm2,%zmm3
    6c4e:	vsubps %zmm8,%zmm2,%zmm2
    6c54:	vmovups %zmm3,-0x100(%rax)
    6c5b:	vaddps %zmm1,%zmm0,%zmm3
    6c61:	vsubps %zmm1,%zmm0,%zmm0
    6c67:	vmovups %zmm2,-0x80(%rax)
    6c6e:	vmovups %zmm3,-0xc0(%rax)
    6c75:	vmovups %zmm0,-0x40(%rax)
    6c7c:	cmp    %rdx,%rax
    6c7f:	jne    6b00 <hfirst_tb4_nat+0x80>
    6c85:	vzeroupper
    6c88:	ret
    6c89:	nopl   0x0(%rax)

0000000000009480 <hfirst_h20_nat>:
    9480:	endbr64
    9484:	vbroadcastss 0x4373a(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
    948e:	test   %rsi,%rsi
    9491:	je     981f <hfirst_h20_nat+0x39f>
    9497:	mov    $0xffffaaaa,%ecx
    949c:	mov    %rdi,%rax
    949f:	lea    -0x4(,%rsi,4),%rdx
    94a7:	vmovdqa32 0x435cf(%rip),%zmm7        # 4ca80 <FFHT_THR_F+0x80>
    94b1:	kmovw  %ecx,%k4
    94b5:	mov    $0xffffcccc,%ecx
    94ba:	and    $0xfffffffffffffe00,%rdx
    94c1:	vmovdqa32 0x435f5(%rip),%zmm6        # 4cac0 <FFHT_THR_F+0xc0>
    94cb:	kmovw  %ecx,%k3
    94cf:	mov    $0xfffff0f0,%ecx
    94d4:	vmovdqa32 0x43622(%rip),%zmm5        # 4cb00 <FFHT_THR_F+0x100>
    94de:	vmovdqa32 0x43658(%rip),%zmm4        # 4cb40 <FFHT_THR_F+0x140>
    94e8:	vbroadcastss 0x42b12(%rip),%zmm10        # 4c004 <_IO_stdin_used+0x4>
    94f2:	kmovw  %ecx,%k2
    94f6:	lea    0x200(%rdi,%rdx,1),%rdx
    94fe:	mov    $0xffffff00,%ecx
    9503:	kmovw  %ecx,%k1
    9507:	nopw   0x0(%rax,%rax,1)
    9510:	vpermps (%rax),%zmm7,%zmm1
    9516:	vaddps (%rax),%zmm1,%zmm0
    951c:	add    $0x200,%rax
    9522:	vsubps -0x200(%rax),%zmm1,%zmm0{%k4}
    9529:	vpermps %zmm0,%zmm6,%zmm2
    952f:	vaddps %zmm2,%zmm0,%zmm1
    9535:	vsubps %zmm0,%zmm2,%zmm1{%k3}
    953b:	vpermps %zmm1,%zmm5,%zmm2
    9541:	vaddps %zmm2,%zmm1,%zmm0
    9547:	vsubps %zmm1,%zmm2,%zmm0{%k2}
    954d:	vpermps %zmm0,%zmm4,%zmm1
    9553:	vaddps %zmm1,%zmm0,%zmm3
    9559:	vsubps %zmm0,%zmm1,%zmm3{%k1}
    955f:	vpermps -0x1c0(%rax),%zmm7,%zmm1
    9566:	vaddps -0x1c0(%rax),%zmm1,%zmm0
    956d:	vsubps -0x1c0(%rax),%zmm1,%zmm0{%k4}
    9574:	vpermps %zmm0,%zmm6,%zmm2
    957a:	vaddps %zmm2,%zmm0,%zmm1
    9580:	vsubps %zmm0,%zmm2,%zmm1{%k3}
    9586:	vpermps %zmm1,%zmm5,%zmm2
    958c:	vaddps %zmm2,%zmm1,%zmm0
    9592:	vsubps %zmm1,%zmm2,%zmm0{%k2}
    9598:	vpermps %zmm0,%zmm4,%zmm1
    959e:	vaddps %zmm1,%zmm0,%zmm11
    95a4:	vsubps %zmm0,%zmm1,%zmm11{%k1}
    95aa:	vpermps -0x180(%rax),%zmm7,%zmm1
    95b1:	vaddps -0x180(%rax),%zmm1,%zmm0
    95b8:	vsubps -0x180(%rax),%zmm1,%zmm0{%k4}
    95bf:	vpermps %zmm0,%zmm6,%zmm2
    95c5:	vaddps %zmm2,%zmm0,%zmm1
    95cb:	vsubps %zmm0,%zmm2,%zmm1{%k3}
    95d1:	vpermps %zmm1,%zmm5,%zmm2
    95d7:	vaddps %zmm2,%zmm1,%zmm0
    95dd:	vsubps %zmm1,%zmm2,%zmm0{%k2}
    95e3:	vpermps %zmm0,%zmm4,%zmm1
    95e9:	vaddps %zmm1,%zmm0,%zmm2
    95ef:	vsubps %zmm0,%zmm1,%zmm2{%k1}
    95f5:	vpermps -0x140(%rax),%zmm7,%zmm1
    95fc:	vaddps -0x140(%rax),%zmm1,%zmm0
    9603:	vsubps -0x140(%rax),%zmm1,%zmm0{%k4}
    960a:	vpermps %zmm0,%zmm6,%zmm8
    9610:	vaddps %zmm8,%zmm0,%zmm1
    9616:	vsubps %zmm0,%zmm8,%zmm1{%k3}
    961c:	vpermps %zmm1,%zmm5,%zmm8
    9622:	vaddps %zmm8,%zmm1,%zmm0
    9628:	vsubps %zmm1,%zmm8,%zmm0{%k2}
    962e:	vpermps %zmm0,%zmm4,%zmm1
    9634:	vaddps %zmm1,%zmm0,%zmm12
    963a:	vsubps %zmm0,%zmm1,%zmm12{%k1}
    9640:	vpermps -0x100(%rax),%zmm7,%zmm1
    9647:	vaddps -0x100(%rax),%zmm1,%zmm0
    964e:	vsubps -0x100(%rax),%zmm1,%zmm0{%k4}
    9655:	vpermps %zmm0,%zmm6,%zmm8
    965b:	vaddps %zmm8,%zmm0,%zmm1
    9661:	vsubps %zmm0,%zmm8,%zmm1{%k3}
    9667:	vpermps %zmm1,%zmm5,%zmm8
    966d:	vaddps %zmm8,%zmm1,%zmm0
    9673:	vsubps %zmm1,%zmm8,%zmm0{%k2}
    9679:	vpermps %zmm0,%zmm4,%zmm1
    967f:	vaddps %zmm1,%zmm0,%zmm9
    9685:	vsubps %zmm0,%zmm1,%zmm9{%k1}
    968b:	vpermps -0xc0(%rax),%zmm7,%zmm1
    9692:	vaddps -0xc0(%rax),%zmm1,%zmm0
    9699:	vsubps -0xc0(%rax),%zmm1,%zmm0{%k4}
    96a0:	vpermps %zmm0,%zmm6,%zmm8
    96a6:	vaddps %zmm8,%zmm0,%zmm1
    96ac:	vsubps %zmm0,%zmm8,%zmm1{%k3}
    96b2:	vpermps %zmm1,%zmm5,%zmm8
    96b8:	vaddps %zmm8,%zmm1,%zmm0
    96be:	vsubps %zmm1,%zmm8,%zmm0{%k2}
    96c4:	vpermps %zmm0,%zmm4,%zmm1
    96ca:	vaddps %zmm1,%zmm0,%zmm14
    96d0:	vsubps %zmm0,%zmm1,%zmm14{%k1}
    96d6:	vpermps -0x80(%rax),%zmm7,%zmm1
    96dd:	vaddps -0x80(%rax),%zmm1,%zmm0
    96e4:	vsubps -0x80(%rax),%zmm1,%zmm0{%k4}
    96eb:	vsubps %zmm14,%zmm2,%zmm2
    96f1:	vpermps %zmm0,%zmm6,%zmm8
    96f7:	vaddps %zmm8,%zmm0,%zmm1
    96fd:	vsubps %zmm0,%zmm8,%zmm1{%k3}
    9703:	vpermps %zmm1,%zmm5,%zmm8
    9709:	vaddps %zmm8,%zmm1,%zmm0
    970f:	vsubps %zmm1,%zmm8,%zmm0{%k2}
    9715:	vpermps %zmm0,%zmm4,%zmm1
    971b:	vaddps %zmm1,%zmm0,%zmm8
    9721:	vsubps %zmm0,%zmm1,%zmm8{%k1}
    9727:	vpermps -0x40(%rax),%zmm7,%zmm0
    972e:	vaddps -0x40(%rax),%zmm0,%zmm1
    9735:	vsubps -0x40(%rax),%zmm0,%zmm1{%k4}
    973c:	vaddps %zmm8,%zmm11,%zmm15
    9742:	vpermps %zmm1,%zmm6,%zmm13
    9748:	vaddps %zmm1,%zmm13,%zmm0
    974e:	vsubps %zmm1,%zmm13,%zmm0{%k3}
    9754:	vpermps %zmm0,%zmm5,%zmm13
    975a:	vaddps %zmm13,%zmm0,%zmm1
    9760:	vsubps %zmm0,%zmm13,%zmm1{%k2}
    9766:	vpermps %zmm1,%zmm4,%zmm13
    976c:	vaddps %zmm1,%zmm13,%zmm0
    9772:	vsubps %zmm1,%zmm13,%zmm0{%k1}
    9778:	vsubps %zmm9,%zmm12,%zmm13
    977e:	vaddps %zmm3,%zmm0,%zmm3
    9784:	vaddps %zmm13,%zmm2,%zmm17
    978a:	vsubps %zmm15,%zmm3,%zmm16
    9790:	vsubps %zmm17,%zmm16,%zmm1
    9796:	vfmsub231ps %zmm10,%zmm1,%zmm0
    979c:	vfmsub132ps %zmm10,%zmm14,%zmm1
    97a2:	vaddps %zmm8,%zmm0,%zmm8
    97a8:	vsubps %zmm9,%zmm1,%zmm9
    97ae:	vaddps %zmm11,%zmm0,%zmm0
    97b4:	vaddps %zmm12,%zmm1,%zmm1
    97ba:	vsubps %zmm9,%zmm3,%zmm3
    97c0:	vaddps %zmm8,%zmm2,%zmm2
    97c6:	vaddps %zmm0,%zmm17,%zmm17
    97cc:	vsubps %zmm1,%zmm16,%zmm16
    97d2:	vmovups %zmm0,-0x180(%rax)
    97d9:	vaddps %zmm9,%zmm15,%zmm15
    97df:	vaddps %zmm8,%zmm13,%zmm13
    97e5:	vmovups %zmm1,-0x140(%rax)
    97ec:	vmovups %zmm3,-0x200(%rax)
    97f3:	vmovups %zmm2,-0x1c0(%rax)
    97fa:	vmovups %zmm17,-0x100(%rax)
    9801:	vmovups %zmm16,-0xc0(%rax)
    9808:	vmovups %zmm15,-0x80(%rax)
    980f:	vmovups %zmm13,-0x40(%rax)
    9816:	cmp    %rdx,%rax
    9819:	jne    9510 <hfirst_h20_nat+0x90>
    981f:	vzeroupper
    9822:	ret
    9823:	data16 cs nopw 0x0(%rax,%rax,1)
    982e:	xchg   %ax,%ax

0000000000009a70 <hfirst_g19_nat>:
    9a70:	endbr64
    9a74:	vbroadcastss 0x4314a(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
    9a7e:	test   %rsi,%rsi
    9a81:	je     9e15 <hfirst_g19_nat+0x3a5>
    9a87:	mov    $0xffffaaaa,%ecx
    9a8c:	mov    %rdi,%rax
    9a8f:	lea    -0x4(,%rsi,4),%rdx
    9a97:	vmovdqa32 0x42fdf(%rip),%zmm7        # 4ca80 <FFHT_THR_F+0x80>
    9aa1:	kmovw  %ecx,%k4
    9aa5:	mov    $0xffffcccc,%ecx
    9aaa:	and    $0xfffffffffffffe00,%rdx
    9ab1:	vmovdqa32 0x43005(%rip),%zmm6        # 4cac0 <FFHT_THR_F+0xc0>
    9abb:	kmovw  %ecx,%k3
    9abf:	mov    $0xfffff0f0,%ecx
    9ac4:	vmovdqa32 0x43032(%rip),%zmm5        # 4cb00 <FFHT_THR_F+0x100>
    9ace:	vmovdqa32 0x43068(%rip),%zmm4        # 4cb40 <FFHT_THR_F+0x140>
    9ad8:	vbroadcastss 0x42526(%rip),%zmm0        # 4c008 <_IO_stdin_used+0x8>
    9ae2:	kmovw  %ecx,%k2
    9ae6:	lea    0x200(%rdi,%rdx,1),%rdx
    9aee:	mov    $0xffffff00,%ecx
    9af3:	kmovw  %ecx,%k1
    9af7:	nopw   0x0(%rax,%rax,1)
    9b00:	vpermps (%rax),%zmm7,%zmm2
    9b06:	vaddps (%rax),%zmm2,%zmm1
    9b0c:	add    $0x200,%rax
    9b12:	vsubps -0x200(%rax),%zmm2,%zmm1{%k4}
    9b19:	vpermps %zmm1,%zmm6,%zmm3
    9b1f:	vaddps %zmm3,%zmm1,%zmm2
    9b25:	vsubps %zmm1,%zmm3,%zmm2{%k3}
    9b2b:	vpermps %zmm2,%zmm5,%zmm3
    9b31:	vaddps %zmm3,%zmm2,%zmm1
    9b37:	vsubps %zmm2,%zmm3,%zmm1{%k2}
    9b3d:	vpermps %zmm1,%zmm4,%zmm2
    9b43:	vaddps %zmm2,%zmm1,%zmm3
    9b49:	vsubps %zmm1,%zmm2,%zmm3{%k1}
    9b4f:	vpermps -0x1c0(%rax),%zmm7,%zmm1
    9b56:	vaddps -0x1c0(%rax),%zmm1,%zmm2
    9b5d:	vsubps -0x1c0(%rax),%zmm1,%zmm2{%k4}
    9b64:	vpermps %zmm2,%zmm6,%zmm8
    9b6a:	vaddps %zmm8,%zmm2,%zmm1
    9b70:	vsubps %zmm2,%zmm8,%zmm1{%k3}
    9b76:	vpermps %zmm1,%zmm5,%zmm8
    9b7c:	vaddps %zmm8,%zmm1,%zmm2
    9b82:	vsubps %zmm1,%zmm8,%zmm2{%k2}
    9b88:	vpermps %zmm2,%zmm4,%zmm8
    9b8e:	vaddps %zmm8,%zmm2,%zmm1
    9b94:	vsubps %zmm2,%zmm8,%zmm1{%k1}
    9b9a:	vpermps -0x180(%rax),%zmm7,%zmm2
    9ba1:	vmovaps %zmm1,%zmm9
    9ba7:	vaddps -0x180(%rax),%zmm2,%zmm1
    9bae:	vsubps -0x180(%rax),%zmm2,%zmm1{%k4}
    9bb5:	vpermps %zmm1,%zmm6,%zmm8
    9bbb:	vaddps %zmm8,%zmm1,%zmm2
    9bc1:	vsubps %zmm1,%zmm8,%zmm2{%k3}
    9bc7:	vpermps %zmm2,%zmm5,%zmm8
    9bcd:	vaddps %zmm8,%zmm2,%zmm1
    9bd3:	vsubps %zmm2,%zmm8,%zmm1{%k2}
    9bd9:	vpermps %zmm1,%zmm4,%zmm8
    9bdf:	vaddps %zmm8,%zmm1,%zmm2
    9be5:	vsubps %zmm1,%zmm8,%zmm2{%k1}
    9beb:	vpermps -0x140(%rax),%zmm7,%zmm8
    9bf2:	vaddps -0x140(%rax),%zmm8,%zmm1
    9bf9:	vsubps -0x140(%rax),%zmm8,%zmm1{%k4}
    9c00:	vpermps %zmm1,%zmm6,%zmm10
    9c06:	vaddps %zmm10,%zmm1,%zmm8
    9c0c:	vsubps %zmm1,%zmm10,%zmm8{%k3}
    9c12:	vpermps %zmm8,%zmm5,%zmm10
    9c18:	vaddps %zmm10,%zmm8,%zmm1
    9c1e:	vsubps %zmm8,%zmm10,%zmm1{%k2}
    9c24:	vpermps %zmm1,%zmm4,%zmm10
    9c2a:	vaddps %zmm10,%zmm1,%zmm8
    9c30:	vsubps %zmm1,%zmm10,%zmm8{%k1}
    9c36:	vpermps -0x100(%rax),%zmm7,%zmm10
    9c3d:	vaddps -0x100(%rax),%zmm10,%zmm1
    9c44:	vsubps -0x100(%rax),%zmm10,%zmm1{%k4}
    9c4b:	vpermps %zmm1,%zmm6,%zmm11
    9c51:	vaddps %zmm11,%zmm1,%zmm10
    9c57:	vsubps %zmm1,%zmm11,%zmm10{%k3}
    9c5d:	vpermps %zmm10,%zmm5,%zmm11
    9c63:	vaddps %zmm11,%zmm10,%zmm1
    9c69:	vsubps %zmm10,%zmm11,%zmm1{%k2}
    9c6f:	vpermps %zmm1,%zmm4,%zmm11
    9c75:	vaddps %zmm11,%zmm1,%zmm10
    9c7b:	vsubps %zmm1,%zmm11,%zmm10{%k1}
    9c81:	vpermps -0xc0(%rax),%zmm7,%zmm11
    9c88:	vaddps -0xc0(%rax),%zmm11,%zmm1
    9c8f:	vsubps -0xc0(%rax),%zmm11,%zmm1{%k4}
    9c96:	vpermps %zmm1,%zmm6,%zmm12
    9c9c:	vaddps %zmm12,%zmm1,%zmm11
    9ca2:	vsubps %zmm1,%zmm12,%zmm11{%k3}
    9ca8:	vpermps %zmm11,%zmm5,%zmm12
    9cae:	vaddps %zmm12,%zmm11,%zmm1
    9cb4:	vsubps %zmm11,%zmm12,%zmm1{%k2}
    9cba:	vpermps %zmm1,%zmm4,%zmm11
    9cc0:	vaddps %zmm11,%zmm1,%zmm12
    9cc6:	vsubps %zmm1,%zmm11,%zmm12{%k1}
    9ccc:	vpermps -0x80(%rax),%zmm7,%zmm11
    9cd3:	vaddps -0x80(%rax),%zmm11,%zmm1
    9cda:	vsubps -0x80(%rax),%zmm11,%zmm1{%k4}
    9ce1:	vsubps %zmm12,%zmm2,%zmm2
    9ce7:	vpermps %zmm1,%zmm6,%zmm13
    9ced:	vaddps %zmm13,%zmm1,%zmm11
    9cf3:	vsubps %zmm1,%zmm13,%zmm11{%k3}
    9cf9:	vpermps %zmm11,%zmm5,%zmm13
    9cff:	vaddps %zmm13,%zmm11,%zmm1
    9d05:	vsubps %zmm11,%zmm13,%zmm1{%k2}
    9d0b:	vpermps %zmm1,%zmm4,%zmm13
    9d11:	vaddps %zmm13,%zmm1,%zmm11
    9d17:	vsubps %zmm1,%zmm13,%zmm11{%k1}
    9d1d:	vpermps -0x40(%rax),%zmm7,%zmm1
    9d24:	vaddps -0x40(%rax),%zmm1,%zmm13
    9d2b:	vsubps -0x40(%rax),%zmm1,%zmm13{%k4}
    9d32:	vpermps %zmm13,%zmm6,%zmm14
    9d38:	vaddps %zmm13,%zmm14,%zmm1
    9d3e:	vsubps %zmm13,%zmm14,%zmm1{%k3}
    9d44:	vpermps %zmm1,%zmm5,%zmm14
    9d4a:	vaddps %zmm14,%zmm1,%zmm13
    9d50:	vsubps %zmm1,%zmm14,%zmm13{%k2}
    9d56:	vpermps %zmm13,%zmm4,%zmm14
    9d5c:	vaddps %zmm13,%zmm14,%zmm1
    9d62:	vsubps %zmm13,%zmm14,%zmm1{%k1}
    9d68:	vsubps %zmm10,%zmm8,%zmm13
    9d6e:	vaddps %zmm11,%zmm9,%zmm14
    9d74:	vaddps %zmm3,%zmm1,%zmm3
    9d7a:	vaddps %zmm13,%zmm2,%zmm16
    9d80:	vsubps %zmm14,%zmm3,%zmm15
    9d86:	vsubps %zmm16,%zmm15,%zmm17
    9d8c:	vfnmadd132ps %zmm0,%zmm17,%zmm1
    9d92:	vfnmadd132ps %zmm0,%zmm17,%zmm12
    9d98:	vfmadd132ps %zmm0,%zmm1,%zmm11
    9d9e:	vfnmadd132ps %zmm0,%zmm12,%zmm10
    9da4:	vfmadd132ps %zmm0,%zmm12,%zmm8
    9daa:	vfmadd231ps %zmm0,%zmm9,%zmm1
    9db0:	vfmadd132ps %zmm0,%zmm11,%zmm13
    9db6:	vfmadd132ps %zmm0,%zmm11,%zmm2
    9dbc:	vfmsub132ps %zmm0,%zmm8,%zmm15
    9dc2:	vfmadd132ps %zmm0,%zmm10,%zmm14
    9dc8:	vmovups %zmm1,-0x180(%rax)
    9dcf:	vfmadd132ps %zmm0,%zmm1,%zmm16
    9dd5:	vfmsub132ps %zmm0,%zmm10,%zmm3
    9ddb:	vmovups %zmm8,-0x140(%rax)
    9de2:	vmovups %zmm2,-0x1c0(%rax)
    9de9:	vmovups %zmm15,-0xc0(%rax)
    9df0:	vmovups %zmm3,-0x200(%rax)
    9df7:	vmovups %zmm16,-0x100(%rax)
    9dfe:	vmovups %zmm14,-0x80(%rax)
    9e05:	vmovups %zmm13,-0x40(%rax)
    9e0c:	cmp    %rdx,%rax
    9e0f:	jne    9b00 <hfirst_g19_nat+0x90>
    9e15:	vzeroupper
    9e18:	ret
    9e19:	nopl   0x0(%rax)

0000000000009e20 <hfirst_tb8_nat>:
    9e20:	endbr64
    9e24:	vbroadcastss 0x42d9a(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
    9e2e:	test   %rsi,%rsi
    9e31:	je     a1cd <hfirst_tb8_nat+0x3ad>
    9e37:	mov    $0xffffaaaa,%ecx
    9e3c:	mov    %rdi,%rax
    9e3f:	lea    -0x4(,%rsi,4),%rdx
    9e47:	vmovdqa32 0x42c2f(%rip),%zmm5        # 4ca80 <FFHT_THR_F+0x80>
    9e51:	kmovw  %ecx,%k4
    9e55:	mov    $0xffffcccc,%ecx
    9e5a:	and    $0xfffffffffffffe00,%rdx
    9e61:	vmovdqa32 0x42c55(%rip),%zmm4        # 4cac0 <FFHT_THR_F+0xc0>
    9e6b:	kmovw  %ecx,%k3
    9e6f:	mov    $0xfffff0f0,%ecx
    9e74:	vmovdqa32 0x42c82(%rip),%zmm3        # 4cb00 <FFHT_THR_F+0x100>
    9e7e:	vmovdqa32 0x42cb8(%rip),%zmm2        # 4cb40 <FFHT_THR_F+0x140>
    9e88:	kmovw  %ecx,%k2
    9e8c:	lea    0x200(%rdi,%rdx,1),%rdx
    9e94:	mov    $0xffffff00,%ecx
    9e99:	kmovw  %ecx,%k1
    9e9d:	nopl   (%rax)
    9ea0:	vpermps (%rax),%zmm5,%zmm0
    9ea6:	vaddps (%rax),%zmm0,%zmm1
    9eac:	add    $0x200,%rax
    9eb2:	vsubps -0x200(%rax),%zmm0,%zmm1{%k4}
    9eb9:	vpermps %zmm1,%zmm4,%zmm6
    9ebf:	vaddps %zmm6,%zmm1,%zmm0
    9ec5:	vsubps %zmm1,%zmm6,%zmm0{%k3}
    9ecb:	vpermps %zmm0,%zmm3,%zmm6
    9ed1:	vaddps %zmm6,%zmm0,%zmm1
    9ed7:	vsubps %zmm0,%zmm6,%zmm1{%k2}
    9edd:	vpermps %zmm1,%zmm2,%zmm6
    9ee3:	vaddps %zmm6,%zmm1,%zmm0
    9ee9:	vsubps %zmm1,%zmm6,%zmm0{%k1}
    9eef:	vpermps -0x1c0(%rax),%zmm5,%zmm6
    9ef6:	vaddps -0x1c0(%rax),%zmm6,%zmm1
    9efd:	vsubps -0x1c0(%rax),%zmm6,%zmm1{%k4}
    9f04:	vpermps %zmm1,%zmm4,%zmm7
    9f0a:	vaddps %zmm7,%zmm1,%zmm6
    9f10:	vsubps %zmm1,%zmm7,%zmm6{%k3}
    9f16:	vpermps %zmm6,%zmm3,%zmm7
    9f1c:	vaddps %zmm7,%zmm6,%zmm1
    9f22:	vsubps %zmm6,%zmm7,%zmm1{%k2}
    9f28:	vpermps %zmm1,%zmm2,%zmm6
    9f2e:	vaddps %zmm6,%zmm1,%zmm11
    9f34:	vsubps %zmm1,%zmm6,%zmm11{%k1}
    9f3a:	vpermps -0x180(%rax),%zmm5,%zmm6
    9f41:	vaddps -0x180(%rax),%zmm6,%zmm1
    9f48:	vsubps -0x180(%rax),%zmm6,%zmm1{%k4}
    9f4f:	vpermps %zmm1,%zmm4,%zmm7
    9f55:	vaddps %zmm7,%zmm1,%zmm6
    9f5b:	vsubps %zmm1,%zmm7,%zmm6{%k3}
    9f61:	vpermps %zmm6,%zmm3,%zmm7
    9f67:	vaddps %zmm7,%zmm6,%zmm1
    9f6d:	vsubps %zmm6,%zmm7,%zmm1{%k2}
    9f73:	vpermps %zmm1,%zmm2,%zmm6
    9f79:	vaddps %zmm6,%zmm1,%zmm9
    9f7f:	vsubps %zmm1,%zmm6,%zmm9{%k1}
    9f85:	vpermps -0x140(%rax),%zmm5,%zmm6
    9f8c:	vaddps -0x140(%rax),%zmm6,%zmm1
    9f93:	vsubps -0x140(%rax),%zmm6,%zmm1{%k4}
    9f9a:	vpermps %zmm1,%zmm4,%zmm7
    9fa0:	vaddps %zmm7,%zmm1,%zmm6
    9fa6:	vsubps %zmm1,%zmm7,%zmm6{%k3}
    9fac:	vpermps %zmm6,%zmm3,%zmm7
    9fb2:	vaddps %zmm7,%zmm6,%zmm1
    9fb8:	vsubps %zmm6,%zmm7,%zmm1{%k2}
    9fbe:	vpermps %zmm1,%zmm2,%zmm6
    9fc4:	vaddps %zmm6,%zmm1,%zmm10
    9fca:	vsubps %zmm1,%zmm6,%zmm10{%k1}
    9fd0:	vpermps -0x100(%rax),%zmm5,%zmm1
    9fd7:	vaddps -0x100(%rax),%zmm1,%zmm6
    9fde:	vsubps -0x100(%rax),%zmm1,%zmm6{%k4}
    9fe5:	vaddps %zmm10,%zmm9,%zmm14
    9feb:	vsubps %zmm10,%zmm9,%zmm9
    9ff1:	vpermps %zmm6,%zmm4,%zmm7
    9ff7:	vaddps %zmm7,%zmm6,%zmm1
    9ffd:	vsubps %zmm6,%zmm7,%zmm1{%k3}
    a003:	vpermps %zmm1,%zmm3,%zmm7
    a009:	vaddps %zmm7,%zmm1,%zmm6
    a00f:	vsubps %zmm1,%zmm7,%zmm6{%k2}
    a015:	vpermps %zmm6,%zmm2,%zmm7
    a01b:	vaddps %zmm7,%zmm6,%zmm1
    a021:	vsubps %zmm6,%zmm7,%zmm1{%k1}
    a027:	vpermps -0xc0(%rax),%zmm5,%zmm7
    a02e:	vaddps -0xc0(%rax),%zmm7,%zmm6
    a035:	vsubps -0xc0(%rax),%zmm7,%zmm6{%k4}
    a03c:	vpermps %zmm6,%zmm4,%zmm8
    a042:	vaddps %zmm8,%zmm6,%zmm7
    a048:	vsubps %zmm6,%zmm8,%zmm7{%k3}
    a04e:	vpermps %zmm7,%zmm3,%zmm8
    a054:	vaddps %zmm8,%zmm7,%zmm6
    a05a:	vsubps %zmm7,%zmm8,%zmm6{%k2}
    a060:	vpermps %zmm6,%zmm2,%zmm7
    a066:	vaddps %zmm7,%zmm6,%zmm13
    a06c:	vsubps %zmm6,%zmm7,%zmm13{%k1}
    a072:	vpermps -0x80(%rax),%zmm5,%zmm7
    a079:	vaddps -0x80(%rax),%zmm7,%zmm6
    a080:	vsubps -0x80(%rax),%zmm7,%zmm6{%k4}
    a087:	vpermps %zmm6,%zmm4,%zmm8
    a08d:	vaddps %zmm8,%zmm6,%zmm7
    a093:	vsubps %zmm6,%zmm8,%zmm7{%k3}
    a099:	vpermps %zmm7,%zmm3,%zmm8
    a09f:	vaddps %zmm8,%zmm7,%zmm6
    a0a5:	vsubps %zmm7,%zmm8,%zmm6{%k2}
    a0ab:	vpermps %zmm6,%zmm2,%zmm7
    a0b1:	vaddps %zmm7,%zmm6,%zmm8
    a0b7:	vsubps %zmm6,%zmm7,%zmm8{%k1}
    a0bd:	vpermps -0x40(%rax),%zmm5,%zmm7
    a0c4:	vaddps -0x40(%rax),%zmm7,%zmm6
    a0cb:	vsubps -0x40(%rax),%zmm7,%zmm6{%k4}
    a0d2:	vpermps %zmm6,%zmm4,%zmm12
    a0d8:	vaddps %zmm6,%zmm12,%zmm7
    a0de:	vsubps %zmm6,%zmm12,%zmm7{%k3}
    a0e4:	vpermps %zmm7,%zmm3,%zmm12
    a0ea:	vaddps %zmm12,%zmm7,%zmm6
    a0f0:	vsubps %zmm7,%zmm12,%zmm6{%k2}
    a0f6:	vpermps %zmm6,%zmm2,%zmm7
    a0fc:	vaddps %zmm6,%zmm7,%zmm12
    a102:	vsubps %zmm6,%zmm7,%zmm12{%k1}
    a108:	vaddps %zmm13,%zmm1,%zmm7
    a10e:	vaddps %zmm11,%zmm0,%zmm6
    a114:	vsubps %zmm13,%zmm1,%zmm1
    a11a:	vsubps %zmm11,%zmm0,%zmm0
    a120:	vaddps %zmm8,%zmm12,%zmm13
    a126:	vsubps %zmm12,%zmm8,%zmm8
    a12c:	vaddps %zmm14,%zmm6,%zmm11
    a132:	vsubps %zmm14,%zmm6,%zmm6
    a138:	vaddps %zmm9,%zmm0,%zmm10
    a13e:	vsubps %zmm9,%zmm0,%zmm0
    a144:	vaddps %zmm13,%zmm7,%zmm12
    a14a:	vaddps %zmm8,%zmm1,%zmm9
    a150:	vsubps %zmm8,%zmm1,%zmm1
    a156:	vsubps %zmm13,%zmm7,%zmm7
    a15c:	vaddps %zmm12,%zmm11,%zmm8
    a162:	vsubps %zmm12,%zmm11,%zmm11
    a168:	vmovups %zmm8,-0x200(%rax)
    a16f:	vaddps %zmm9,%zmm10,%zmm8
    a175:	vsubps %zmm9,%zmm10,%zmm10
    a17b:	vmovups %zmm11,-0x100(%rax)
    a182:	vmovups %zmm8,-0x1c0(%rax)
    a189:	vaddps %zmm7,%zmm6,%zmm8
    a18f:	vsubps %zmm7,%zmm6,%zmm6
    a195:	vmovups %zmm10,-0xc0(%rax)
    a19c:	vmovups %zmm8,-0x180(%rax)
    a1a3:	vaddps %zmm1,%zmm0,%zmm8
    a1a9:	vsubps %zmm1,%zmm0,%zmm0
    a1af:	vmovups %zmm6,-0x80(%rax)
    a1b6:	vmovups %zmm8,-0x140(%rax)
    a1bd:	vmovups %zmm0,-0x40(%rax)
    a1c4:	cmp    %rdx,%rax
    a1c7:	jne    9ea0 <hfirst_tb8_nat+0x80>
    a1cd:	vzeroupper
    a1d0:	ret
    a1d1:	data16 cs nopw 0x0(%rax,%rax,1)
    a1dc:	nopl   0x0(%rax)

000000000000a7a0 <hfirst_g52_nat>:
    a7a0:	endbr64
    a7a4:	push   %rbp
    a7a5:	mov    %rsp,%rbp
    a7a8:	and    $0xffffffffffffffc0,%rsp
    a7ac:	sub    $0x440,%rsp
    a7b3:	vbroadcastss 0x4240b(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
    a7bd:	mov    %fs:0x28,%rax
    a7c6:	mov    %rax,0x438(%rsp)
    a7ce:	xor    %eax,%eax
    a7d0:	test   %rsi,%rsi
    a7d3:	je     aae9 <hfirst_g52_nat+0x349>
    a7d9:	mov    $0xffffaaaa,%eax
    a7de:	mov    %rdi,%rdx
    a7e1:	mov    %rsp,%rcx
    a7e4:	vmovdqa32 0x42292(%rip),%zmm7        # 4ca80 <FFHT_THR_F+0x80>
    a7ee:	vmovdqa32 0x422c8(%rip),%zmm6        # 4cac0 <FFHT_THR_F+0xc0>
    a7f8:	kmovw  %eax,%k4
    a7fc:	xor    %edi,%edi
    a7fe:	mov    $0xffffcccc,%eax
    a803:	vmovdqa32 0x422f3(%rip),%zmm5        # 4cb00 <FFHT_THR_F+0x100>
    a80d:	kmovw  %eax,%k3
    a811:	vmovdqa32 0x42325(%rip),%zmm4        # 4cb40 <FFHT_THR_F+0x140>
    a81b:	mov    $0xfffff0f0,%eax
    a820:	vbroadcastss 0x417de(%rip),%zmm3        # 4c008 <_IO_stdin_used+0x8>
    a82a:	kmovw  %eax,%k2
    a82e:	mov    $0xffffff00,%eax
    a833:	kmovw  %eax,%k1
    a837:	nopw   0x0(%rax,%rax,1)
    a840:	xor    %eax,%eax
    a842:	nopw   0x0(%rax,%rax,1)
    a848:	vpermps (%rdx,%rax,1),%zmm7,%zmm1
    a84f:	vaddps (%rdx,%rax,1),%zmm1,%zmm0
    a856:	vsubps (%rdx,%rax,1),%zmm1,%zmm0{%k4}
    a85d:	vpermps %zmm0,%zmm6,%zmm2
    a863:	vaddps %zmm0,%zmm2,%zmm1
    a869:	vsubps %zmm0,%zmm2,%zmm1{%k3}
    a86f:	vpermps %zmm1,%zmm5,%zmm2
    a875:	vaddps %zmm1,%zmm2,%zmm0
    a87b:	vsubps %zmm1,%zmm2,%zmm0{%k2}
    a881:	vpermps %zmm0,%zmm4,%zmm2
    a887:	vaddps %zmm0,%zmm2,%zmm1
    a88d:	vsubps %zmm0,%zmm2,%zmm1{%k1}
    a893:	vmovaps %zmm1,(%rcx,%rax,1)
    a89a:	add    $0x40,%rax
    a89e:	cmp    $0x400,%rax
    a8a4:	jne    a848 <hfirst_g52_nat+0xa8>
    a8a6:	vmovaps (%rsp),%zmm2
    a8ad:	vaddps 0x40(%rsp),%zmm2,%zmm17
    a8b5:	vmovaps %zmm3,%zmm0
    a8bb:	vmovaps %zmm3,%zmm11
    a8c1:	vmovaps %zmm3,%zmm13
    a8c7:	add    $0x100,%rdi
    a8ce:	vmovaps 0x80(%rsp),%zmm2
    a8d6:	vsubps 0xc0(%rsp),%zmm2,%zmm16
    a8de:	vmovaps 0x300(%rsp),%zmm8
    a8e6:	add    $0x400,%rdx
    a8ed:	vaddps 0x340(%rsp),%zmm8,%zmm9
    a8f5:	vmovaps 0x380(%rsp),%zmm12
    a8fd:	vsubps 0x3c0(%rsp),%zmm12,%zmm8
    a905:	vsubps %zmm16,%zmm17,%zmm1
    a90b:	vaddps %zmm8,%zmm9,%zmm12
    a911:	vfnmadd132ps 0x380(%rsp),%zmm12,%zmm13
    a919:	vfmadd132ps %zmm2,%zmm1,%zmm0
    a91f:	vfmsub231ps (%rsp),%zmm3,%zmm1
    a926:	vmovaps 0x100(%rsp),%zmm2
    a92e:	vaddps 0x140(%rsp),%zmm2,%zmm19
    a936:	vmovaps 0x180(%rsp),%zmm2
    a93e:	vsubps 0x1c0(%rsp),%zmm2,%zmm21
    a946:	vfmsub231ps 0x300(%rsp),%zmm3,%zmm12
    a94e:	vmovaps %zmm1,%zmm22
    a954:	vaddps %zmm21,%zmm19,%zmm1
    a95a:	vfnmadd132ps %zmm2,%zmm1,%zmm11
    a960:	vfmsub231ps 0x100(%rsp),%zmm3,%zmm1
    a968:	vmovaps 0x200(%rsp),%zmm2
    a970:	vaddps 0x240(%rsp),%zmm2,%zmm14
    a978:	vmovaps 0x280(%rsp),%zmm2
    a980:	vsubps 0x2c0(%rsp),%zmm2,%zmm15
    a988:	vmovaps %zmm3,%zmm2
    a98e:	vmovaps %zmm1,%zmm10
    a994:	vsubps %zmm11,%zmm0,%zmm1
    a99a:	vfmadd132ps %zmm3,%zmm1,%zmm19
    a9a0:	vfmsub132ps %zmm3,%zmm1,%zmm17
    a9a6:	vaddps %zmm10,%zmm22,%zmm1
    a9ac:	vfmadd132ps %zmm3,%zmm1,%zmm21
    a9b2:	vfnmadd132ps %zmm3,%zmm1,%zmm16
    a9b8:	vsubps %zmm15,%zmm14,%zmm1
    a9be:	vfmadd132ps 0x280(%rsp),%zmm1,%zmm2
    a9c6:	vfmsub231ps 0x200(%rsp),%zmm3,%zmm1
    a9ce:	vaddps %zmm13,%zmm2,%zmm18
    a9d4:	vfnmadd132ps %zmm3,%zmm18,%zmm9
    a9da:	vfmsub132ps %zmm3,%zmm18,%zmm14
    a9e0:	vsubps %zmm12,%zmm1,%zmm18
    a9e6:	vfnmadd132ps %zmm3,%zmm18,%zmm8
    a9ec:	vfnmadd132ps %zmm3,%zmm18,%zmm15
    a9f2:	vaddps %zmm9,%zmm19,%zmm18
    a9f8:	vfmsub132ps %zmm3,%zmm18,%zmm0
    a9fe:	vfnmadd132ps %zmm3,%zmm18,%zmm2
    aa04:	vaddps %zmm14,%zmm17,%zmm18
    aa0a:	vfmadd132ps %zmm3,%zmm18,%zmm13
    aa10:	vfnmadd132ps %zmm3,%zmm18,%zmm11
    aa16:	vaddps %zmm15,%zmm16,%zmm18
    aa1c:	vfmadd132ps %zmm3,%zmm0,%zmm9
    aa22:	vfmsub132ps %zmm3,%zmm2,%zmm19
    aa28:	vmovups %zmm2,-0x200(%rdx)
    aa2f:	vfmadd132ps %zmm3,%zmm18,%zmm12
    aa35:	vfnmadd132ps %zmm3,%zmm18,%zmm10
    aa3b:	vfmsub132ps %zmm3,%zmm13,%zmm17
    aa41:	vfnmadd132ps %zmm3,%zmm11,%zmm14
    aa47:	vmovups %zmm13,-0x380(%rdx)
    aa4e:	vmovups %zmm11,-0x280(%rdx)
    aa55:	vmovups %zmm19,-0x400(%rdx)
    aa5c:	vmovaps %zmm9,%zmm20
    aa62:	vaddps %zmm8,%zmm21,%zmm9
    aa68:	vfmsub132ps %zmm3,%zmm12,%zmm16
    aa6e:	vfnmadd132ps %zmm3,%zmm10,%zmm15
    aa74:	vmovups %zmm12,-0x340(%rdx)
    aa7b:	vmovups %zmm20,-0x300(%rdx)
    aa82:	vmovups %zmm10,-0x240(%rdx)
    aa89:	vfnmadd132ps %zmm3,%zmm9,%zmm1
    aa8f:	vfmsub231ps %zmm3,%zmm22,%zmm9
    aa95:	vfmsub132ps %zmm3,%zmm1,%zmm21
    aa9b:	vfmadd132ps %zmm3,%zmm9,%zmm8
    aaa1:	vmovups %zmm1,-0x1c0(%rdx)
    aaa8:	vmovups %zmm21,-0x3c0(%rdx)
    aaaf:	vmovups %zmm8,-0x2c0(%rdx)
    aab6:	vmovups %zmm17,-0x180(%rdx)
    aabd:	vmovups %zmm16,-0x140(%rdx)
    aac4:	vmovups %zmm0,-0x100(%rdx)
    aacb:	vmovups %zmm9,-0xc0(%rdx)
    aad2:	vmovups %zmm14,-0x80(%rdx)
    aad9:	vmovups %zmm15,-0x40(%rdx)
    aae0:	cmp    %rsi,%rdi
    aae3:	jb     a840 <hfirst_g52_nat+0xa0>
    aae9:	mov    0x438(%rsp),%rax
    aaf1:	sub    %fs:0x28,%rax
    aafa:	jne    ab01 <hfirst_g52_nat+0x361>
    aafc:	vzeroupper
    aaff:	leave
    ab00:	ret
    ab01:	vzeroupper
    ab04:	call   21e0 <__stack_chk_fail@plt>
    ab09:	nopl   0x0(%rax)

000000000000ab10 <hstep_tb8_balS>:
    ab10:	endbr64
    ab14:	vbroadcastss 0x420aa(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
    ab1e:	test   %rsi,%rsi
    ab21:	je     ace3 <hstep_tb8_balS+0x1d3>
    ab27:	push   %rbp
    ab28:	mov    %rsp,%rbp
    ab2b:	push   %r15
    ab2d:	lea    0x0(,%rdx,8),%r15
    ab35:	push   %r14
    ab37:	push   %r13
    ab39:	push   %r12
    ab3b:	push   %rbx
    ab3c:	test   %rdx,%rdx
    ab3f:	je     acd5 <hstep_tb8_balS+0x1c5>
    ab45:	mov    %rdx,%r9
    ab48:	mov    %rdi,%rbx
    ab4b:	lea    (%rdx,%rdx,2),%rcx
    ab4f:	mov    %rdx,%r10
    ab52:	lea    -0x1(%rdx),%r13
    ab56:	neg    %r9
    ab59:	lea    (%rdx,%rdx,4),%r8
    ab5d:	mov    %rsi,%r12
    ab60:	and    $0xfffffffffffffff0,%r13
    ab64:	shl    $0x2,%r9
    ab68:	mov    %rdx,%rdi
    ab6b:	lea    0x40(%rbx),%r14
    ab6f:	lea    0x0(,%rcx,4),%r11
    ab77:	shl    $0x4,%r10
    ab7b:	shl    $0x2,%r8
    ab7f:	shl    $0x3,%rcx
    ab83:	nopl   0x0(%rax,%rax,1)
    ab88:	lea    (%rdi,%r13,1),%rsi
    ab8c:	lea    (%rbx,%rdi,4),%rax
    ab90:	lea    (%r14,%rsi,4),%rsi
    ab94:	nopl   0x0(%rax)
    ab98:	vmovups (%rax,%r9,1),%zmm7
    ab9f:	vmovups (%rax),%zmm6
    aba5:	vsubps (%rax),%zmm7,%zmm8
    abab:	vmovups (%rax,%rdx,4),%zmm4
    abb2:	vmovups (%rax,%rdx,8),%zmm1
    abb9:	vmovups (%rax,%r10,1),%zmm5
    abc0:	vfmadd132ps %zmm0,%zmm7,%zmm6
    abc6:	vmovups (%rax,%r11,1),%zmm7
    abcd:	vmovups (%rax,%rcx,1),%zmm2
    abd4:	vfmadd132ps %zmm0,%zmm4,%zmm1
    abda:	vfmadd213ps (%rax,%r8,1),%zmm0,%zmm2
    abe1:	vsubps (%rax,%r10,1),%zmm7,%zmm9
    abe8:	vfmadd132ps %zmm0,%zmm7,%zmm5
    abee:	vsubps (%rax,%rdx,8),%zmm4,%zmm3
    abf5:	vmovups (%rax,%r8,1),%zmm4
    abfc:	vsubps (%rax,%rcx,1),%zmm4,%zmm4
    ac03:	vsubps %zmm1,%zmm6,%zmm7
    ac09:	vfmadd132ps %zmm0,%zmm6,%zmm1
    ac0f:	vsubps %zmm3,%zmm8,%zmm6
    ac15:	vfmadd132ps %zmm0,%zmm8,%zmm3
    ac1b:	vsubps %zmm2,%zmm5,%zmm8
    ac21:	vfmadd132ps %zmm0,%zmm5,%zmm2
    ac27:	vsubps %zmm4,%zmm9,%zmm5
    ac2d:	vfmadd132ps %zmm0,%zmm9,%zmm4
    ac33:	vmovaps %zmm8,%zmm10
    ac39:	vmovaps %zmm5,%zmm9
    ac3f:	vfmadd132ps %zmm0,%zmm7,%zmm10
    ac45:	vsubps %zmm8,%zmm7,%zmm7
    ac4b:	vfmadd132ps %zmm0,%zmm6,%zmm9
    ac51:	vsubps %zmm5,%zmm6,%zmm6
    ac57:	vmovaps %zmm2,%zmm12
    ac5d:	vmovaps %zmm4,%zmm11
    ac63:	vfmadd132ps %zmm0,%zmm1,%zmm12
    ac69:	vsubps %zmm2,%zmm1,%zmm1
    ac6f:	vfmadd132ps %zmm0,%zmm3,%zmm11
    ac75:	vsubps %zmm4,%zmm3,%zmm3
    ac7b:	vmovups %zmm12,(%rax,%r9,1)
    ac82:	vmovups %zmm11,(%rax)
    ac88:	vmovups %zmm10,(%rax,%rdx,4)
    ac8f:	vmovups %zmm9,(%rax,%rdx,8)
    ac96:	add    $0x40,%rax
    ac9a:	vmovups %zmm1,-0x40(%rax,%r11,1)
    aca2:	vmovups %zmm3,-0x40(%rax,%r10,1)
    acaa:	vmovups %zmm7,-0x40(%rax,%r8,1)
    acb2:	vmovups %zmm6,-0x40(%rax,%rcx,1)
    acba:	cmp    %rax,%rsi
    acbd:	jne    ab98 <hstep_tb8_balS+0x88>
    acc3:	add    %r15,%rdi
    acc6:	mov    %rdi,%rax
    acc9:	sub    %rdx,%rax
    accc:	cmp    %r12,%rax
    accf:	jb     ab88 <hstep_tb8_balS+0x78>
    acd5:	vzeroupper
    acd8:	pop    %rbx
    acd9:	pop    %r12
    acdb:	pop    %r13
    acdd:	pop    %r14
    acdf:	pop    %r15
    ace1:	pop    %rbp
    ace2:	ret
    ace3:	vzeroupper
    ace6:	ret
    ace7:	nopw   0x0(%rax,%rax,1)

000000000000f610 <hfirst_tb8_balS>:
    f610:	endbr64
    f614:	vbroadcastss 0x3d5aa(%rip),%zmm1        # 4cbc8 <FFHT_THR_F+0x1c8>
    f61e:	test   %rsi,%rsi
    f621:	je     f9d5 <hfirst_tb8_balS+0x3c5>
    f627:	mov    $0xffffaaaa,%ecx
    f62c:	mov    %rdi,%rax
    f62f:	lea    -0x4(,%rsi,4),%rdx
    f637:	vmovdqa32 0x3d43f(%rip),%zmm6        # 4ca80 <FFHT_THR_F+0x80>
    f641:	kmovw  %ecx,%k4
    f645:	mov    $0xffffcccc,%ecx
    f64a:	and    $0xfffffffffffffe00,%rdx
    f651:	vmovdqa32 0x3d465(%rip),%zmm5        # 4cac0 <FFHT_THR_F+0xc0>
    f65b:	kmovw  %ecx,%k3
    f65f:	mov    $0xfffff0f0,%ecx
    f664:	vmovdqa32 0x3d492(%rip),%zmm4        # 4cb00 <FFHT_THR_F+0x100>
    f66e:	vmovdqa32 0x3d4c8(%rip),%zmm3        # 4cb40 <FFHT_THR_F+0x140>
    f678:	kmovw  %ecx,%k2
    f67c:	lea    0x200(%rdi,%rdx,1),%rdx
    f684:	mov    $0xffffff00,%ecx
    f689:	kmovw  %ecx,%k1
    f68d:	nopl   (%rax)
    f690:	vpermps (%rax),%zmm6,%zmm2
    f696:	vaddps (%rax),%zmm2,%zmm0
    f69c:	add    $0x200,%rax
    f6a2:	vsubps -0x200(%rax),%zmm2,%zmm0{%k4}
    f6a9:	vpermps %zmm0,%zmm5,%zmm7
    f6af:	vaddps %zmm7,%zmm0,%zmm2
    f6b5:	vsubps %zmm0,%zmm7,%zmm2{%k3}
    f6bb:	vpermps %zmm2,%zmm4,%zmm7
    f6c1:	vaddps %zmm7,%zmm2,%zmm0
    f6c7:	vsubps %zmm2,%zmm7,%zmm0{%k2}
    f6cd:	vpermps %zmm0,%zmm3,%zmm2
    f6d3:	vaddps %zmm2,%zmm0,%zmm12
    f6d9:	vsubps %zmm0,%zmm2,%zmm12{%k1}
    f6df:	vpermps -0x1c0(%rax),%zmm6,%zmm2
    f6e6:	vaddps -0x1c0(%rax),%zmm2,%zmm0
    f6ed:	vsubps -0x1c0(%rax),%zmm2,%zmm0{%k4}
    f6f4:	vpermps %zmm0,%zmm5,%zmm7
    f6fa:	vaddps %zmm7,%zmm0,%zmm2
    f700:	vsubps %zmm0,%zmm7,%zmm2{%k3}
    f706:	vpermps %zmm2,%zmm4,%zmm7
    f70c:	vaddps %zmm7,%zmm2,%zmm0
    f712:	vsubps %zmm2,%zmm7,%zmm0{%k2}
    f718:	vpermps %zmm0,%zmm3,%zmm2
    f71e:	vaddps %zmm2,%zmm0,%zmm10
    f724:	vsubps %zmm0,%zmm2,%zmm10{%k1}
    f72a:	vpermps -0x180(%rax),%zmm6,%zmm2
    f731:	vaddps -0x180(%rax),%zmm2,%zmm0
    f738:	vsubps -0x180(%rax),%zmm2,%zmm0{%k4}
    f73f:	vsubps %zmm10,%zmm12,%zmm15
    f745:	vfmadd132ps %zmm1,%zmm12,%zmm10
    f74b:	vpermps %zmm0,%zmm5,%zmm7
    f751:	vaddps %zmm7,%zmm0,%zmm2
    f757:	vsubps %zmm0,%zmm7,%zmm2{%k3}
    f75d:	vpermps %zmm2,%zmm4,%zmm7
    f763:	vaddps %zmm7,%zmm2,%zmm0
    f769:	vsubps %zmm2,%zmm7,%zmm0{%k2}
    f76f:	vpermps %zmm0,%zmm3,%zmm2
    f775:	vaddps %zmm2,%zmm0,%zmm11
    f77b:	vsubps %zmm0,%zmm2,%zmm11{%k1}
    f781:	vpermps -0x140(%rax),%zmm6,%zmm0
    f788:	vaddps -0x140(%rax),%zmm0,%zmm2
    f78f:	vsubps -0x140(%rax),%zmm0,%zmm2{%k4}
    f796:	vpermps %zmm2,%zmm5,%zmm7
    f79c:	vaddps %zmm7,%zmm2,%zmm0
    f7a2:	vsubps %zmm2,%zmm7,%zmm0{%k3}
    f7a8:	vpermps %zmm0,%zmm4,%zmm7
    f7ae:	vaddps %zmm7,%zmm0,%zmm2
    f7b4:	vsubps %zmm0,%zmm7,%zmm2{%k2}
    f7ba:	vpermps %zmm2,%zmm3,%zmm7
    f7c0:	vaddps %zmm7,%zmm2,%zmm0
    f7c6:	vsubps %zmm2,%zmm7,%zmm0{%k1}
    f7cc:	vpermps -0x100(%rax),%zmm6,%zmm7
    f7d3:	vaddps -0x100(%rax),%zmm7,%zmm2
    f7da:	vsubps -0x100(%rax),%zmm7,%zmm2{%k4}
    f7e1:	vpermps %zmm2,%zmm5,%zmm8
    f7e7:	vaddps %zmm8,%zmm2,%zmm7
    f7ed:	vsubps %zmm2,%zmm8,%zmm7{%k3}
    f7f3:	vpermps %zmm7,%zmm4,%zmm8
    f7f9:	vaddps %zmm8,%zmm7,%zmm2
    f7ff:	vsubps %zmm7,%zmm8,%zmm2{%k2}
    f805:	vpermps %zmm2,%zmm3,%zmm7
    f80b:	vaddps %zmm7,%zmm2,%zmm8
    f811:	vsubps %zmm2,%zmm7,%zmm8{%k1}
    f817:	vpermps -0xc0(%rax),%zmm6,%zmm7
    f81e:	vaddps -0xc0(%rax),%zmm7,%zmm2
    f825:	vsubps -0xc0(%rax),%zmm7,%zmm2{%k4}
    f82c:	vpermps %zmm2,%zmm5,%zmm9
    f832:	vaddps %zmm9,%zmm2,%zmm7
    f838:	vsubps %zmm2,%zmm9,%zmm7{%k3}
    f83e:	vpermps %zmm7,%zmm4,%zmm9
    f844:	vaddps %zmm9,%zmm7,%zmm2
    f84a:	vsubps %zmm7,%zmm9,%zmm2{%k2}
    f850:	vpermps %zmm2,%zmm3,%zmm7
    f856:	vaddps %zmm7,%zmm2,%zmm9
    f85c:	vsubps %zmm2,%zmm7,%zmm9{%k1}
    f862:	vpermps -0x80(%rax),%zmm6,%zmm7
    f869:	vaddps -0x80(%rax),%zmm7,%zmm2
    f870:	vsubps -0x80(%rax),%zmm7,%zmm2{%k4}
    f877:	vpermps %zmm2,%zmm5,%zmm13
    f87d:	vaddps %zmm13,%zmm2,%zmm7
    f883:	vsubps %zmm2,%zmm13,%zmm7{%k3}
    f889:	vpermps %zmm7,%zmm4,%zmm13
    f88f:	vaddps %zmm13,%zmm7,%zmm2
    f895:	vsubps %zmm7,%zmm13,%zmm2{%k2}
    f89b:	vpermps %zmm2,%zmm3,%zmm7
    f8a1:	vaddps %zmm7,%zmm2,%zmm13
    f8a7:	vsubps %zmm2,%zmm7,%zmm13{%k1}
    f8ad:	vpermps -0x40(%rax),%zmm6,%zmm2
    f8b4:	vaddps -0x40(%rax),%zmm2,%zmm7
    f8bb:	vsubps -0x40(%rax),%zmm2,%zmm7{%k4}
    f8c2:	vpermps %zmm7,%zmm5,%zmm14
    f8c8:	vaddps %zmm7,%zmm14,%zmm2
    f8ce:	vsubps %zmm7,%zmm14,%zmm2{%k3}
    f8d4:	vpermps %zmm2,%zmm4,%zmm14
    f8da:	vaddps %zmm14,%zmm2,%zmm7
    f8e0:	vsubps %zmm2,%zmm14,%zmm7{%k2}
    f8e6:	vpermps %zmm7,%zmm3,%zmm14
    f8ec:	vaddps %zmm7,%zmm14,%zmm2
    f8f2:	vsubps %zmm7,%zmm14,%zmm2{%k1}
    f8f8:	vsubps %zmm9,%zmm8,%zmm14
    f8fe:	vfmadd132ps %zmm1,%zmm8,%zmm9
    f904:	vsubps %zmm0,%zmm11,%zmm7
    f90a:	vfmadd132ps %zmm1,%zmm11,%zmm0
    f910:	vsubps %zmm2,%zmm13,%zmm8
    f916:	vfmadd132ps %zmm1,%zmm13,%zmm2
    f91c:	vsubps %zmm0,%zmm10,%zmm11
    f922:	vfmadd132ps %zmm1,%zmm10,%zmm0
    f928:	vsubps %zmm7,%zmm15,%zmm10
    f92e:	vfmadd132ps %zmm1,%zmm15,%zmm7
    f934:	vsubps %zmm2,%zmm9,%zmm12
    f93a:	vfmadd132ps %zmm1,%zmm9,%zmm2
    f940:	vsubps %zmm8,%zmm14,%zmm9
    f946:	vfmadd132ps %zmm1,%zmm14,%zmm8
    f94c:	vmovaps %zmm9,%zmm13
    f952:	vmovaps %zmm12,%zmm14
    f958:	vfmadd132ps %zmm1,%zmm11,%zmm14
    f95e:	vfmadd132ps %zmm1,%zmm10,%zmm13
    f964:	vsubps %zmm12,%zmm11,%zmm11
    f96a:	vmovaps %zmm2,%zmm16
    f970:	vsubps %zmm9,%zmm10,%zmm10
    f976:	vmovaps %zmm8,%zmm15
    f97c:	vfmadd132ps %zmm1,%zmm0,%zmm16
    f982:	vsubps %zmm2,%zmm0,%zmm0
    f988:	vfmadd132ps %zmm1,%zmm7,%zmm15
    f98e:	vsubps %zmm8,%zmm7,%zmm7
    f994:	vmovups %zmm11,-0x80(%rax)
    f99b:	vmovups %zmm10,-0x40(%rax)
    f9a2:	vmovups %zmm14,-0x180(%rax)
    f9a9:	vmovups %zmm13,-0x140(%rax)
    f9b0:	vmovups %zmm16,-0x200(%rax)
    f9b7:	vmovups %zmm15,-0x1c0(%rax)
    f9be:	vmovups %zmm0,-0x100(%rax)
    f9c5:	vmovups %zmm7,-0xc0(%rax)
    f9cc:	cmp    %rdx,%rax
    f9cf:	jne    f690 <hfirst_tb8_balS+0x80>
    f9d5:	vzeroupper
    f9d8:	ret
    f9d9:	nopl   0x0(%rax)

000000000000f9e0 <hstep_g19_nat>:
    f9e0:	endbr64
    f9e4:	vbroadcastss 0x3d1da(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
    f9ee:	test   %rsi,%rsi
    f9f1:	je     fb80 <hstep_g19_nat+0x1a0>
    f9f7:	push   %rbp
    f9f8:	mov    %rsp,%rbp
    f9fb:	push   %r15
    f9fd:	lea    0x0(,%rdx,8),%r15
    fa05:	push   %r14
    fa07:	push   %r13
    fa09:	push   %r12
    fa0b:	push   %rbx
    fa0c:	test   %rdx,%rdx
    fa0f:	je     fb72 <hstep_g19_nat+0x192>
    fa15:	mov    %rdx,%r9
    fa18:	mov    %rdi,%rbx
    fa1b:	lea    (%rdx,%rdx,2),%rcx
    fa1f:	mov    %rdx,%r10
    fa22:	lea    -0x1(%rdx),%r13
    fa26:	neg    %r9
    fa29:	lea    (%rdx,%rdx,4),%r8
    fa2d:	mov    %rsi,%r12
    fa30:	and    $0xfffffffffffffff0,%r13
    fa34:	shl    $0x2,%r9
    fa38:	mov    %rdx,%rdi
    fa3b:	lea    0x40(%rbx),%r14
    fa3f:	lea    0x0(,%rcx,4),%r11
    fa47:	shl    $0x4,%r10
    fa4b:	shl    $0x2,%r8
    fa4f:	vbroadcastss 0x3c5af(%rip),%zmm0        # 4c008 <_IO_stdin_used+0x8>
    fa59:	shl    $0x3,%rcx
    fa5d:	nopl   (%rax)
    fa60:	lea    (%rdi,%r13,1),%rsi
    fa64:	lea    (%rbx,%rdi,4),%rax
    fa68:	lea    (%r14,%rsi,4),%rsi
    fa6c:	nopl   0x0(%rax)
    fa70:	vmovups (%rax,%r9,1),%zmm1
    fa77:	vmovups (%rax),%zmm6
    fa7d:	vmovaps %zmm0,%zmm3
    fa83:	vaddps (%rax,%rcx,1),%zmm1,%zmm10
    fa8a:	vaddps (%rax,%r8,1),%zmm6,%zmm7
    fa91:	vmovups (%rax,%rdx,4),%zmm4
    fa98:	vmovups (%rax,%rdx,8),%zmm5
    fa9f:	vsubps (%rax,%r10,1),%zmm4,%zmm1
    faa6:	vsubps (%rax,%r11,1),%zmm5,%zmm6
    faad:	vmovaps %zmm0,%zmm4
    fab3:	vsubps %zmm7,%zmm10,%zmm8
    fab9:	vmovaps %zmm0,%zmm5
    fabf:	vaddps %zmm6,%zmm1,%zmm9
    fac5:	vsubps %zmm9,%zmm8,%zmm2
    facb:	vfnmadd132ps (%rax,%rcx,1),%zmm2,%zmm3
    fad2:	vfnmadd231ps (%rax,%r10,1),%zmm0,%zmm2
    fad9:	vfmadd132ps (%rax,%r8,1),%zmm3,%zmm5
    fae0:	vfnmadd132ps (%rax,%r11,1),%zmm2,%zmm4
    fae7:	vfmadd231ps (%rax),%zmm0,%zmm3
    faed:	vfmadd231ps (%rax,%rdx,8),%zmm0,%zmm2
    faf4:	vfmadd132ps %zmm0,%zmm5,%zmm6
    fafa:	vfmadd132ps %zmm0,%zmm5,%zmm1
    fb00:	vfmadd132ps %zmm0,%zmm4,%zmm7
    fb06:	vfmadd132ps %zmm0,%zmm3,%zmm9
    fb0c:	vfmsub132ps %zmm0,%zmm2,%zmm8
    fb12:	vfmsub132ps %zmm0,%zmm4,%zmm10
    fb18:	vmovups %zmm10,(%rax,%r9,1)
    fb1f:	vmovups %zmm1,(%rax)
    fb25:	vmovups %zmm3,(%rax,%rdx,4)
    fb2c:	vmovups %zmm2,(%rax,%rdx,8)
    fb33:	add    $0x40,%rax
    fb37:	vmovups %zmm9,-0x40(%rax,%r11,1)
    fb3f:	vmovups %zmm8,-0x40(%rax,%r10,1)
    fb47:	vmovups %zmm7,-0x40(%rax,%r8,1)
    fb4f:	vmovups %zmm6,-0x40(%rax,%rcx,1)
    fb57:	cmp    %rax,%rsi
    fb5a:	jne    fa70 <hstep_g19_nat+0x90>
    fb60:	add    %r15,%rdi
    fb63:	mov    %rdi,%rax
    fb66:	sub    %rdx,%rax
    fb69:	cmp    %r12,%rax
    fb6c:	jb     fa60 <hstep_g19_nat+0x80>
    fb72:	vzeroupper
    fb75:	pop    %rbx
    fb76:	pop    %r12
    fb78:	pop    %r13
    fb7a:	pop    %r14
    fb7c:	pop    %r15
    fb7e:	pop    %rbp
    fb7f:	ret
    fb80:	vzeroupper
    fb83:	ret
    fb84:	data16 cs nopw 0x0(%rax,%rax,1)
    fb8f:	nop

000000000000fed0 <hstep_h20_nat>:
    fed0:	endbr64
    fed4:	vbroadcastss 0x3ccea(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
    fede:	test   %rsi,%rsi
    fee1:	je     10064 <hstep_h20_nat+0x194>
    fee7:	push   %rbp
    fee8:	mov    %rsp,%rbp
    feeb:	push   %r15
    feed:	lea    0x0(,%rdx,8),%r15
    fef5:	push   %r14
    fef7:	push   %r13
    fef9:	push   %r12
    fefb:	push   %rbx
    fefc:	test   %rdx,%rdx
    feff:	je     10056 <hstep_h20_nat+0x186>
    ff05:	mov    %rdx,%r9
    ff08:	mov    %rdi,%rbx
    ff0b:	lea    (%rdx,%rdx,2),%rcx
    ff0f:	mov    %rdx,%r10
    ff12:	lea    -0x1(%rdx),%r13
    ff16:	neg    %r9
    ff19:	lea    (%rdx,%rdx,4),%r8
    ff1d:	mov    %rsi,%r12
    ff20:	and    $0xfffffffffffffff0,%r13
    ff24:	shl    $0x2,%r9
    ff28:	mov    %rdx,%rdi
    ff2b:	lea    0x40(%rbx),%r14
    ff2f:	lea    0x0(,%rcx,4),%r11
    ff37:	shl    $0x4,%r10
    ff3b:	shl    $0x2,%r8
    ff3f:	vbroadcastss 0x3c0bb(%rip),%zmm10        # 4c004 <_IO_stdin_used+0x4>
    ff49:	shl    $0x3,%rcx
    ff4d:	nopl   (%rax)
    ff50:	lea    (%rdi,%r13,1),%rsi
    ff54:	lea    (%rbx,%rdi,4),%rax
    ff58:	lea    (%r14,%rsi,4),%rsi
    ff5c:	nopl   0x0(%rax)
    ff60:	vmovups (%rax,%r9,1),%zmm3
    ff67:	vmovups (%rax),%zmm4
    ff6d:	vaddps (%rax,%rcx,1),%zmm3,%zmm9
    ff74:	vaddps (%rax,%r8,1),%zmm4,%zmm6
    ff7b:	vmovups (%rax,%rdx,8),%zmm3
    ff82:	vmovups (%rax,%rdx,4),%zmm2
    ff89:	vsubps (%rax,%r11,1),%zmm3,%zmm5
    ff90:	vsubps (%rax,%r10,1),%zmm2,%zmm2
    ff97:	vsubps %zmm6,%zmm9,%zmm7
    ff9d:	vaddps %zmm5,%zmm2,%zmm8
    ffa3:	vsubps %zmm8,%zmm7,%zmm0
    ffa9:	vmovaps %zmm0,%zmm1
    ffaf:	vfmsub213ps (%rax,%r10,1),%zmm10,%zmm0
    ffb6:	vfmsub213ps (%rax,%rcx,1),%zmm10,%zmm1
    ffbd:	vsubps (%rax,%r11,1),%zmm0,%zmm4
    ffc4:	vaddps (%rax,%r8,1),%zmm1,%zmm3
    ffcb:	vaddps (%rax,%rdx,8),%zmm0,%zmm0
    ffd2:	vaddps (%rax),%zmm1,%zmm1
    ffd8:	vsubps %zmm4,%zmm9,%zmm9
    ffde:	vaddps %zmm4,%zmm6,%zmm6
    ffe4:	vaddps %zmm3,%zmm2,%zmm2
    ffea:	vsubps %zmm0,%zmm7,%zmm7
    fff0:	vaddps %zmm1,%zmm8,%zmm8
    fff6:	vaddps %zmm3,%zmm5,%zmm5
    fffc:	vmovups %zmm9,(%rax,%r9,1)
   10003:	vmovups %zmm2,(%rax)
   10009:	vmovups %zmm1,(%rax,%rdx,4)
   10010:	vmovups %zmm0,(%rax,%rdx,8)
   10017:	add    $0x40,%rax
   1001b:	vmovups %zmm8,-0x40(%rax,%r11,1)
   10023:	vmovups %zmm7,-0x40(%rax,%r10,1)
   1002b:	vmovups %zmm6,-0x40(%rax,%r8,1)
   10033:	vmovups %zmm5,-0x40(%rax,%rcx,1)
   1003b:	cmp    %rax,%rsi
   1003e:	jne    ff60 <hstep_h20_nat+0x90>
   10044:	add    %r15,%rdi
   10047:	mov    %rdi,%rax
   1004a:	sub    %rdx,%rax
   1004d:	cmp    %r12,%rax
   10050:	jb     ff50 <hstep_h20_nat+0x80>
   10056:	vzeroupper
   10059:	pop    %rbx
   1005a:	pop    %r12
   1005c:	pop    %r13
   1005e:	pop    %r14
   10060:	pop    %r15
   10062:	pop    %rbp
   10063:	ret
   10064:	vzeroupper
   10067:	ret
   10068:	nopl   0x0(%rax,%rax,1)

0000000000012120 <hstep_g20_nat>:
   12120:	endbr64
   12124:	vbroadcastss 0x3aa9a(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
   1212e:	test   %rsi,%rsi
   12131:	je     122c4 <hstep_g20_nat+0x1a4>
   12137:	push   %rbp
   12138:	mov    %rsp,%rbp
   1213b:	push   %r15
   1213d:	lea    0x0(,%rdx,8),%r15
   12145:	push   %r14
   12147:	push   %r13
   12149:	push   %r12
   1214b:	push   %rbx
   1214c:	test   %rdx,%rdx
   1214f:	je     122b6 <hstep_g20_nat+0x196>
   12155:	mov    %rdx,%r9
   12158:	mov    %rdi,%rbx
   1215b:	lea    (%rdx,%rdx,2),%rcx
   1215f:	mov    %rdx,%r10
   12162:	lea    -0x1(%rdx),%r13
   12166:	neg    %r9
   12169:	lea    (%rdx,%rdx,4),%r8
   1216d:	mov    %rsi,%r12
   12170:	and    $0xfffffffffffffff0,%r13
   12174:	shl    $0x2,%r9
   12178:	mov    %rdx,%rdi
   1217b:	lea    0x40(%rbx),%r14
   1217f:	lea    0x0(,%rcx,4),%r11
   12187:	shl    $0x4,%r10
   1218b:	shl    $0x2,%r8
   1218f:	vbroadcastss 0x39e6f(%rip),%zmm0        # 4c008 <_IO_stdin_used+0x8>
   12199:	shl    $0x3,%rcx
   1219d:	nopl   (%rax)
   121a0:	lea    (%rdi,%r13,1),%rsi
   121a4:	lea    (%rbx,%rdi,4),%rax
   121a8:	lea    (%r14,%rsi,4),%rsi
   121ac:	nopl   0x0(%rax)
   121b0:	vmovups (%rax,%rdx,4),%zmm6
   121b7:	vmovups (%rax),%zmm5
   121bd:	vmovaps %zmm0,%zmm4
   121c3:	vsubps (%rax,%rdx,8),%zmm6,%zmm7
   121ca:	vaddps (%rax,%r9,1),%zmm5,%zmm5
   121d1:	vmovups (%rax,%r10,1),%zmm3
   121d8:	vsubps %zmm7,%zmm5,%zmm1
   121de:	vfmadd132ps %zmm6,%zmm1,%zmm4
   121e4:	vaddps (%rax,%r11,1),%zmm3,%zmm6
   121eb:	vmovups (%rax,%r8,1),%zmm3
   121f2:	vmovaps %zmm1,%zmm2
   121f8:	vsubps (%rax,%rcx,1),%zmm3,%zmm8
   121ff:	vmovaps %zmm0,%zmm3
   12205:	vfmsub231ps (%rax,%r9,1),%zmm0,%zmm2
   1220c:	vaddps %zmm8,%zmm6,%zmm1
   12212:	vfnmadd132ps (%rax,%r8,1),%zmm1,%zmm3
   12219:	vfmsub231ps (%rax,%r11,1),%zmm0,%zmm1
   12220:	vaddps %zmm3,%zmm4,%zmm9
   12226:	vfnmadd132ps %zmm0,%zmm9,%zmm6
   1222c:	vfmsub132ps %zmm0,%zmm9,%zmm5
   12232:	vaddps %zmm1,%zmm2,%zmm9
   12238:	vfmadd132ps %zmm0,%zmm9,%zmm8
   1223e:	vfnmadd132ps %zmm0,%zmm9,%zmm7
   12244:	vfmsub132ps %zmm0,%zmm6,%zmm4
   1224a:	vfmadd132ps %zmm0,%zmm5,%zmm3
   12250:	vfmsub132ps %zmm0,%zmm8,%zmm2
   12256:	vfnmadd132ps %zmm0,%zmm7,%zmm1
   1225c:	vmovups %zmm4,(%rax,%r9,1)
   12263:	vmovups %zmm8,(%rax)
   12269:	vmovups %zmm3,(%rax,%rdx,4)
   12270:	vmovups %zmm7,(%rax,%rdx,8)
   12277:	add    $0x40,%rax
   1227b:	vmovups %zmm6,-0x40(%rax,%r11,1)
   12283:	vmovups %zmm2,-0x40(%rax,%r10,1)
   1228b:	vmovups %zmm5,-0x40(%rax,%r8,1)
   12293:	vmovups %zmm1,-0x40(%rax,%rcx,1)
   1229b:	cmp    %rax,%rsi
   1229e:	jne    121b0 <hstep_g20_nat+0x90>
   122a4:	add    %r15,%rdi
   122a7:	mov    %rdi,%rax
   122aa:	sub    %rdx,%rax
   122ad:	cmp    %r12,%rax
   122b0:	jb     121a0 <hstep_g20_nat+0x80>
   122b6:	vzeroupper
   122b9:	pop    %rbx
   122ba:	pop    %r12
   122bc:	pop    %r13
   122be:	pop    %r14
   122c0:	pop    %r15
   122c2:	pop    %rbp
   122c3:	ret
   122c4:	vzeroupper
   122c7:	ret
   122c8:	nopl   0x0(%rax,%rax,1)

0000000000013140 <hstep_broken_g20>:
   13140:	endbr64
   13144:	vbroadcastss 0x39a7a(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
   1314e:	test   %rsi,%rsi
   13151:	je     132e4 <hstep_broken_g20+0x1a4>
   13157:	push   %rbp
   13158:	mov    %rsp,%rbp
   1315b:	push   %r15
   1315d:	lea    0x0(,%rdx,8),%r15
   13165:	push   %r14
   13167:	push   %r13
   13169:	push   %r12
   1316b:	push   %rbx
   1316c:	test   %rdx,%rdx
   1316f:	je     132d6 <hstep_broken_g20+0x196>
   13175:	mov    %rdx,%r9
   13178:	mov    %rdi,%rbx
   1317b:	lea    (%rdx,%rdx,2),%rcx
   1317f:	mov    %rdx,%r10
   13182:	lea    -0x1(%rdx),%r13
   13186:	neg    %r9
   13189:	lea    (%rdx,%rdx,4),%r8
   1318d:	mov    %rsi,%r12
   13190:	and    $0xfffffffffffffff0,%r13
   13194:	shl    $0x2,%r9
   13198:	mov    %rdx,%rdi
   1319b:	lea    0x40(%rbx),%r14
   1319f:	lea    0x0(,%rcx,4),%r11
   131a7:	shl    $0x4,%r10
   131ab:	shl    $0x2,%r8
   131af:	vbroadcastss 0x38e4f(%rip),%zmm0        # 4c008 <_IO_stdin_used+0x8>
   131b9:	shl    $0x3,%rcx
   131bd:	nopl   (%rax)
   131c0:	lea    (%rdi,%r13,1),%rsi
   131c4:	lea    (%rbx,%rdi,4),%rax
   131c8:	lea    (%r14,%rsi,4),%rsi
   131cc:	nopl   0x0(%rax)
   131d0:	vmovups (%rax,%rdx,4),%zmm6
   131d7:	vmovups (%rax),%zmm5
   131dd:	vmovaps %zmm0,%zmm4
   131e3:	vsubps (%rax,%rdx,8),%zmm6,%zmm7
   131ea:	vaddps (%rax,%r9,1),%zmm5,%zmm5
   131f1:	vmovups (%rax,%r10,1),%zmm3
   131f8:	vsubps %zmm7,%zmm5,%zmm1
   131fe:	vfmadd132ps %zmm6,%zmm1,%zmm4
   13204:	vaddps (%rax,%r11,1),%zmm3,%zmm6
   1320b:	vmovups (%rax,%r8,1),%zmm3
   13212:	vmovaps %zmm1,%zmm2
   13218:	vsubps (%rax,%rcx,1),%zmm3,%zmm8
   1321f:	vmovaps %zmm0,%zmm3
   13225:	vfmsub231ps (%rax,%r9,1),%zmm0,%zmm2
   1322c:	vaddps %zmm8,%zmm6,%zmm1
   13232:	vfnmadd132ps (%rax,%r8,1),%zmm1,%zmm3
   13239:	vfmsub231ps (%rax,%r11,1),%zmm0,%zmm1
   13240:	vaddps %zmm3,%zmm4,%zmm9
   13246:	vfnmadd132ps %zmm0,%zmm9,%zmm6
   1324c:	vfmsub132ps %zmm0,%zmm9,%zmm5
   13252:	vaddps %zmm1,%zmm2,%zmm9
   13258:	vfmadd132ps %zmm0,%zmm9,%zmm8
   1325e:	vfnmadd132ps %zmm0,%zmm9,%zmm7
   13264:	vfmsub132ps %zmm0,%zmm6,%zmm4
   1326a:	vfmadd132ps %zmm0,%zmm5,%zmm3
   13270:	vfmsub132ps %zmm0,%zmm8,%zmm2
   13276:	vfnmadd132ps %zmm0,%zmm7,%zmm1
   1327c:	vmovups %zmm4,(%rax,%r9,1)
   13283:	vmovups %zmm8,(%rax)
   13289:	vmovups %zmm3,(%rax,%rdx,4)
   13290:	vmovups %zmm7,(%rax,%rdx,8)
   13297:	add    $0x40,%rax
   1329b:	vmovups %zmm6,-0x40(%rax,%r11,1)
   132a3:	vmovups %zmm5,-0x40(%rax,%r10,1)
   132ab:	vmovups %zmm2,-0x40(%rax,%r8,1)
   132b3:	vmovups %zmm1,-0x40(%rax,%rcx,1)
   132bb:	cmp    %rax,%rsi
   132be:	jne    131d0 <hstep_broken_g20+0x90>
   132c4:	add    %r15,%rdi
   132c7:	mov    %rdi,%rax
   132ca:	sub    %rdx,%rax
   132cd:	cmp    %r12,%rax
   132d0:	jb     131c0 <hstep_broken_g20+0x80>
   132d6:	vzeroupper
   132d9:	pop    %rbx
   132da:	pop    %r12
   132dc:	pop    %r13
   132de:	pop    %r14
   132e0:	pop    %r15
   132e2:	pop    %rbp
   132e3:	ret
   132e4:	vzeroupper
   132e7:	ret
   132e8:	nopl   0x0(%rax,%rax,1)

00000000000132f0 <hstep_tb8_nat>:
   132f0:	endbr64
   132f4:	vbroadcastss 0x398ca(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
   132fe:	test   %rsi,%rsi
   13301:	je     13492 <hstep_tb8_nat+0x1a2>
   13307:	push   %rbp
   13308:	mov    %rsp,%rbp
   1330b:	push   %r15
   1330d:	lea    0x0(,%rdx,8),%r15
   13315:	push   %r14
   13317:	push   %r13
   13319:	push   %r12
   1331b:	push   %rbx
   1331c:	test   %rdx,%rdx
   1331f:	je     13484 <hstep_tb8_nat+0x194>
   13325:	mov    %rdx,%r9
   13328:	mov    %rdi,%rbx
   1332b:	lea    (%rdx,%rdx,2),%rcx
   1332f:	mov    %rdx,%r10
   13332:	lea    -0x1(%rdx),%r13
   13336:	neg    %r9
   13339:	lea    (%rdx,%rdx,4),%r8
   1333d:	mov    %rsi,%r12
   13340:	and    $0xfffffffffffffff0,%r13
   13344:	shl    $0x2,%r9
   13348:	mov    %rdx,%rdi
   1334b:	lea    0x40(%rbx),%r14
   1334f:	lea    0x0(,%rcx,4),%r11
   13357:	shl    $0x4,%r10
   1335b:	shl    $0x2,%r8
   1335f:	shl    $0x3,%rcx
   13363:	nopl   0x0(%rax,%rax,1)
   13368:	lea    (%rdi,%r13,1),%rsi
   1336c:	lea    (%rbx,%rdi,4),%rax
   13370:	lea    (%r14,%rsi,4),%rsi
   13374:	nopl   0x0(%rax)
   13378:	vmovups (%rax,%r9,1),%zmm7
   1337f:	vmovups (%rax,%rdx,4),%zmm3
   13386:	vaddps (%rax),%zmm7,%zmm2
   1338c:	vaddps (%rax,%rdx,8),%zmm3,%zmm6
   13393:	vsubps (%rax,%rdx,8),%zmm3,%zmm5
   1339a:	vsubps (%rax),%zmm7,%zmm0
   133a0:	vmovups (%rax,%r11,1),%zmm7
   133a7:	vaddps (%rax,%r10,1),%zmm7,%zmm3
   133ae:	vsubps (%rax,%r10,1),%zmm7,%zmm1
   133b5:	vmovups (%rax,%r8,1),%zmm7
   133bc:	vaddps (%rax,%rcx,1),%zmm7,%zmm9
   133c3:	vsubps (%rax,%rcx,1),%zmm7,%zmm4
   133ca:	vaddps %zmm6,%zmm2,%zmm7
   133d0:	vsubps %zmm6,%zmm2,%zmm2
   133d6:	vaddps %zmm5,%zmm0,%zmm6
   133dc:	vsubps %zmm5,%zmm0,%zmm0
   133e2:	vaddps %zmm9,%zmm3,%zmm8
   133e8:	vaddps %zmm4,%zmm1,%zmm5
   133ee:	vsubps %zmm4,%zmm1,%zmm1
   133f4:	vsubps %zmm9,%zmm3,%zmm3
   133fa:	vaddps %zmm8,%zmm7,%zmm4
   13400:	vsubps %zmm8,%zmm7,%zmm7
   13406:	vmovups %zmm4,(%rax,%r9,1)
   1340d:	vaddps %zmm5,%zmm6,%zmm4
   13413:	vsubps %zmm5,%zmm6,%zmm6
   13419:	vmovups %zmm4,(%rax)
   1341f:	vaddps %zmm3,%zmm2,%zmm4
   13425:	vsubps %zmm3,%zmm2,%zmm2
   1342b:	vmovups %zmm4,(%rax,%rdx,4)
   13432:	vaddps %zmm1,%zmm0,%zmm4
   13438:	vsubps %zmm1,%zmm0,%zmm0
   1343e:	vmovups %zmm4,(%rax,%rdx,8)
   13445:	add    $0x40,%rax
   13449:	vmovups %zmm7,-0x40(%rax,%r11,1)
   13451:	vmovups %zmm6,-0x40(%rax,%r10,1)
   13459:	vmovups %zmm2,-0x40(%rax,%r8,1)
   13461:	vmovups %zmm0,-0x40(%rax,%rcx,1)
   13469:	cmp    %rax,%rsi
   1346c:	jne    13378 <hstep_tb8_nat+0x88>
   13472:	add    %r15,%rdi
   13475:	mov    %rdi,%rax
   13478:	sub    %rdx,%rax
   1347b:	cmp    %r12,%rax
   1347e:	jb     13368 <hstep_tb8_nat+0x78>
   13484:	vzeroupper
   13487:	pop    %rbx
   13488:	pop    %r12
   1348a:	pop    %r13
   1348c:	pop    %r14
   1348e:	pop    %r15
   13490:	pop    %rbp
   13491:	ret
   13492:	vzeroupper
   13495:	ret
   13496:	cs nopw 0x0(%rax,%rax,1)

00000000000161d0 <hstep_tb8_bal>:
   161d0:	endbr64
   161d4:	vbroadcastss 0x369ea(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
   161de:	test   %rsi,%rsi
   161e1:	je     163be <hstep_tb8_bal+0x1ee>
   161e7:	push   %rbp
   161e8:	mov    %rsp,%rbp
   161eb:	push   %r15
   161ed:	lea    0x0(,%rdx,8),%r15
   161f5:	push   %r14
   161f7:	push   %r13
   161f9:	push   %r12
   161fb:	push   %rbx
   161fc:	test   %rdx,%rdx
   161ff:	je     163b0 <hstep_tb8_bal+0x1e0>
   16205:	mov    %rdx,%r9
   16208:	mov    %rdi,%rbx
   1620b:	lea    (%rdx,%rdx,2),%rcx
   1620f:	mov    %rdx,%r10
   16212:	lea    -0x1(%rdx),%r13
   16216:	neg    %r9
   16219:	lea    (%rdx,%rdx,4),%r8
   1621d:	mov    %rsi,%r12
   16220:	and    $0xfffffffffffffff0,%r13
   16224:	shl    $0x2,%r9
   16228:	mov    %rdx,%rdi
   1622b:	lea    0x40(%rbx),%r14
   1622f:	lea    0x0(,%rcx,4),%r11
   16237:	shl    $0x4,%r10
   1623b:	shl    $0x2,%r8
   1623f:	shl    $0x3,%rcx
   16243:	nopl   0x0(%rax,%rax,1)
   16248:	lea    (%rdi,%r13,1),%rsi
   1624c:	lea    (%rbx,%rdi,4),%rax
   16250:	lea    (%r14,%rsi,4),%rsi
   16254:	nopl   0x0(%rax)
   16258:	vmovups (%rax,%rdx,8),%zmm7
   1625f:	vfmadd213ps (%rax,%rdx,4),%zmm0,%zmm7
   16266:	vmovups (%rax),%zmm3
   1626c:	vfmadd213ps (%rax,%r9,1),%zmm0,%zmm3
   16273:	vmovups (%rax,%rcx,1),%zmm10
   1627a:	vfmadd213ps (%rax,%r8,1),%zmm0,%zmm10
   16281:	vmovups (%rax,%r9,1),%zmm2
   16288:	vmovups (%rax,%r10,1),%zmm4
   1628f:	vsubps (%rax),%zmm2,%zmm1
   16295:	vfmadd213ps (%rax,%r11,1),%zmm0,%zmm4
   1629c:	vmovups (%rax,%rdx,4),%zmm2
   162a3:	vsubps (%rax,%rdx,8),%zmm2,%zmm6
   162aa:	vmovaps %zmm7,%zmm8
   162b0:	vmovups (%rax,%r11,1),%zmm5
   162b7:	vsubps (%rax,%r10,1),%zmm5,%zmm2
   162be:	vfmadd132ps %zmm0,%zmm3,%zmm8
   162c4:	vsubps %zmm7,%zmm3,%zmm3
   162ca:	vmovups (%rax,%r8,1),%zmm5
   162d1:	vsubps (%rax,%rcx,1),%zmm5,%zmm5
   162d8:	vmovaps %zmm10,%zmm9
   162de:	vmovaps %zmm6,%zmm7
   162e4:	vfmadd132ps %zmm0,%zmm1,%zmm7
   162ea:	vsubps %zmm6,%zmm1,%zmm1
   162f0:	vmovaps %zmm5,%zmm6
   162f6:	vfmadd132ps %zmm0,%zmm4,%zmm9
   162fc:	vsubps %zmm10,%zmm4,%zmm4
   16302:	vfmadd132ps %zmm0,%zmm2,%zmm6
   16308:	vsubps %zmm5,%zmm2,%zmm2
   1630e:	vmovaps %zmm4,%zmm10
   16314:	vmovaps %zmm2,%zmm5
   1631a:	vfmadd132ps %zmm0,%zmm3,%zmm10
   16320:	vsubps %zmm4,%zmm3,%zmm3
   16326:	vmovaps %zmm9,%zmm12
   1632c:	vfmadd132ps %zmm0,%zmm1,%zmm5
   16332:	vsubps %zmm2,%zmm1,%zmm1
   16338:	vmovaps %zmm6,%zmm11
   1633e:	vfmadd132ps %zmm0,%zmm8,%zmm12
   16344:	vsubps %zmm9,%zmm8,%zmm8
   1634a:	vfmadd132ps %zmm0,%zmm7,%zmm11
   16350:	vsubps %zmm6,%zmm7,%zmm7
   16356:	vmovups %zmm12,(%rax,%r9,1)
   1635d:	vmovups %zmm11,(%rax)
   16363:	vmovups %zmm10,(%rax,%rdx,4)
   1636a:	vmovups %zmm5,(%rax,%rdx,8)
   16371:	add    $0x40,%rax
   16375:	vmovups %zmm8,-0x40(%rax,%r11,1)
   1637d:	vmovups %zmm7,-0x40(%rax,%r10,1)
   16385:	vmovups %zmm3,-0x40(%rax,%r8,1)
   1638d:	vmovups %zmm1,-0x40(%rax,%rcx,1)
   16395:	cmp    %rax,%rsi
   16398:	jne    16258 <hstep_tb8_bal+0x88>
   1639e:	add    %r15,%rdi
   163a1:	mov    %rdi,%rax
   163a4:	sub    %rdx,%rax
   163a7:	cmp    %r12,%rax
   163aa:	jb     16248 <hstep_tb8_bal+0x78>
   163b0:	vzeroupper
   163b3:	pop    %rbx
   163b4:	pop    %r12
   163b6:	pop    %r13
   163b8:	pop    %r14
   163ba:	pop    %r15
   163bc:	pop    %rbp
   163bd:	ret
   163be:	vzeroupper
   163c1:	ret
   163c2:	data16 cs nopw 0x0(%rax,%rax,1)
   163cd:	nopl   (%rax)

000000000001e8b0 <hstep_g52_nat>:
   1e8b0:	endbr64
   1e8b4:	vbroadcastss 0x2e30a(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
   1e8be:	test   %rsi,%rsi
   1e8c1:	je     1eb9e <hstep_g52_nat+0x2ee>
   1e8c7:	push   %rbp
   1e8c8:	lea    (%rdx,%rdx,2),%r11
   1e8cc:	mov    %rdx,%rcx
   1e8cf:	lea    0x0(,%rdx,8),%r9
   1e8d7:	shl    $0x2,%r11
   1e8db:	mov    %rsp,%rbp
   1e8de:	push   %r15
   1e8e0:	push   %r14
   1e8e2:	push   %r13
   1e8e4:	push   %r12
   1e8e6:	mov    %rsi,%r12
   1e8e9:	mov    %rdx,%rsi
   1e8ec:	push   %rbx
   1e8ed:	shl    $0x4,%rsi
   1e8f1:	test   %rdx,%rdx
   1e8f4:	je     1eb90 <hstep_g52_nat+0x2e0>
   1e8fa:	lea    (%rdi,%r9,1),%rax
   1e8fe:	mov    %rdx,%r10
   1e901:	lea    (%rdx,%rdx,4),%r8
   1e905:	neg    %r9
   1e908:	vmovq  %rax,%xmm16
   1e90e:	lea    -0x1(%rdx),%rax
   1e912:	neg    %r10
   1e915:	xor    %ebx,%ebx
   1e917:	shr    $0x4,%rax
   1e91b:	lea    (%rdi,%r8,8),%r15
   1e91f:	shl    $0x2,%r10
   1e923:	lea    0x40(%rdi),%r14
   1e927:	lea    (%rdx,%rax,8),%r13
   1e92b:	shl    $0x2,%r8
   1e92f:	vbroadcastss 0x2d6cf(%rip),%zmm0        # 4c008 <_IO_stdin_used+0x8>
   1e939:	add    %r13,%r13
   1e93c:	lea    0x0(,%rbx,4),%rdx
   1e944:	vmovq  %xmm16,%rax
   1e94a:	lea    (%rbx,%r13,1),%rdi
   1e94e:	add    %rdx,%rax
   1e951:	lea    (%r14,%rdi,4),%rdi
   1e955:	add    %r15,%rdx
   1e958:	nopl   0x0(%rax,%rax,1)
   1e960:	vmovups (%rax),%zmm3
   1e966:	vmovups (%rax,%rsi,1),%zmm5
   1e96d:	vmovaps %zmm0,%zmm7
   1e973:	vmovaps %zmm0,%zmm12
   1e979:	vsubps (%rax,%rcx,4),%zmm3,%zmm14
   1e980:	vsubps (%rax,%r8,1),%zmm5,%zmm17
   1e987:	vmovups (%rax,%r10,1),%zmm1
   1e98e:	vmovups (%rax,%r11,1),%zmm4
   1e995:	vaddps (%rax,%r9,1),%zmm1,%zmm15
   1e99c:	vaddps (%rax,%rcx,8),%zmm4,%zmm11
   1e9a3:	vmovaps %zmm0,%zmm4
   1e9a9:	vmovups (%rdx,%r10,1),%zmm6
   1e9b0:	vaddps (%rdx,%r9,1),%zmm6,%zmm9
   1e9b7:	vmovups (%rdx,%r11,1),%zmm6
   1e9be:	vaddps (%rdx,%rcx,8),%zmm6,%zmm10
   1e9c5:	vmovaps %zmm0,%zmm6
   1e9cb:	vaddps %zmm17,%zmm11,%zmm2
   1e9d1:	vsubps %zmm14,%zmm15,%zmm1
   1e9d7:	vfnmadd132ps %zmm5,%zmm2,%zmm4
   1e9dd:	vfmadd132ps %zmm3,%zmm1,%zmm7
   1e9e3:	vmovaps %zmm2,%zmm3
   1e9e9:	vmovups (%rdx),%zmm5
   1e9ef:	vfmsub231ps (%rax,%r9,1),%zmm0,%zmm1
   1e9f6:	vfmsub231ps (%rax,%rcx,8),%zmm0,%zmm3
   1e9fd:	vsubps (%rdx,%rcx,4),%zmm5,%zmm13
   1ea04:	vsubps %zmm4,%zmm7,%zmm2
   1ea0a:	vfmadd132ps %zmm0,%zmm2,%zmm11
   1ea10:	vfmsub132ps %zmm0,%zmm2,%zmm15
   1ea16:	vaddps %zmm3,%zmm1,%zmm2
   1ea1c:	vfmadd132ps %zmm0,%zmm2,%zmm17
   1ea22:	vfnmadd132ps %zmm0,%zmm2,%zmm14
   1ea28:	vsubps %zmm13,%zmm9,%zmm2
   1ea2e:	vfmadd132ps %zmm5,%zmm2,%zmm12
   1ea34:	vfmsub231ps (%rdx,%r9,1),%zmm0,%zmm2
   1ea3b:	vmovups (%rdx,%rsi,1),%zmm5
   1ea42:	vmovaps %zmm2,%zmm8
   1ea48:	vsubps (%rdx,%r8,1),%zmm5,%zmm2
   1ea4f:	vaddps %zmm2,%zmm10,%zmm5
   1ea55:	vfnmadd132ps (%rdx,%rsi,1),%zmm5,%zmm6
   1ea5c:	vfmsub231ps (%rdx,%rcx,8),%zmm0,%zmm5
   1ea63:	vaddps %zmm6,%zmm12,%zmm18
   1ea69:	vfnmadd132ps %zmm0,%zmm18,%zmm10
   1ea6f:	vfmsub132ps %zmm0,%zmm18,%zmm9
   1ea75:	vsubps %zmm5,%zmm8,%zmm18
   1ea7b:	vfnmadd132ps %zmm0,%zmm18,%zmm2
   1ea81:	vfnmadd132ps %zmm0,%zmm18,%zmm13
   1ea87:	vaddps %zmm10,%zmm11,%zmm18
   1ea8d:	vfnmadd132ps %zmm0,%zmm18,%zmm12
   1ea93:	vfmsub132ps %zmm0,%zmm18,%zmm7
   1ea99:	vaddps %zmm2,%zmm17,%zmm18
   1ea9f:	vfnmadd132ps %zmm0,%zmm18,%zmm8
   1eaa5:	vfmsub132ps %zmm0,%zmm18,%zmm1
   1eaab:	vaddps %zmm9,%zmm15,%zmm18
   1eab1:	vfmsub132ps %zmm0,%zmm12,%zmm11
   1eab7:	vfmadd132ps %zmm0,%zmm7,%zmm10
   1eabd:	vfmadd132ps %zmm0,%zmm18,%zmm6
   1eac3:	vfnmadd132ps %zmm0,%zmm18,%zmm4
   1eac9:	vaddps %zmm13,%zmm14,%zmm18
   1eacf:	vfmsub132ps %zmm0,%zmm8,%zmm17
   1ead5:	vfmadd132ps %zmm0,%zmm1,%zmm2
   1eadb:	vfmadd132ps %zmm0,%zmm18,%zmm5
   1eae1:	vfnmadd132ps %zmm0,%zmm18,%zmm3
   1eae7:	vmovups %zmm11,(%rax,%r9,1)
   1eaee:	vfmsub132ps %zmm0,%zmm6,%zmm15
   1eaf4:	vfnmadd132ps %zmm0,%zmm4,%zmm9
   1eafa:	vmovups %zmm17,(%rax,%r10,1)
   1eb01:	vfmsub132ps %zmm0,%zmm5,%zmm14
   1eb07:	vfnmadd132ps %zmm0,%zmm3,%zmm13
   1eb0d:	vmovups %zmm6,(%rax)
   1eb13:	vmovups %zmm5,(%rax,%rcx,4)
   1eb1a:	vmovups %zmm10,(%rax,%rcx,8)
   1eb21:	add    $0x40,%rax
   1eb25:	vmovups %zmm2,-0x40(%rax,%r11,1)
   1eb2d:	vmovups %zmm4,-0x40(%rax,%rsi,1)
   1eb35:	vmovups %zmm3,-0x40(%rax,%r8,1)
   1eb3d:	vmovups %zmm12,(%rdx,%r9,1)
   1eb44:	vmovups %zmm8,(%rdx,%r10,1)
   1eb4b:	vmovups %zmm15,(%rdx)
   1eb51:	vmovups %zmm14,(%rdx,%rcx,4)
   1eb58:	vmovups %zmm7,(%rdx,%rcx,8)
   1eb5f:	add    $0x40,%rdx
   1eb63:	vmovups %zmm1,-0x40(%rdx,%r11,1)
   1eb6b:	vmovups %zmm9,-0x40(%rdx,%rsi,1)
   1eb73:	vmovups %zmm13,-0x40(%rdx,%r8,1)
   1eb7b:	cmp    %rdi,%rax
   1eb7e:	jne    1e960 <hstep_g52_nat+0xb0>
   1eb84:	add    %rsi,%rbx
   1eb87:	cmp    %r12,%rbx
   1eb8a:	jb     1e93c <hstep_g52_nat+0x8c>
   1eb90:	vzeroupper
   1eb93:	pop    %rbx
   1eb94:	pop    %r12
   1eb96:	pop    %r13
   1eb98:	pop    %r14
   1eb9a:	pop    %r15
   1eb9c:	pop    %rbp
   1eb9d:	ret
   1eb9e:	vzeroupper
   1eba1:	ret
   1eba2:	data16 cs nopw 0x0(%rax,%rax,1)
   1ebad:	nopl   (%rax)

000000000001fd30 <hstep_tb16_nat>:
   1fd30:	endbr64
   1fd34:	vbroadcastss 0x2ce8a(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
   1fd3e:	test   %rsi,%rsi
   1fd41:	je     20035 <hstep_tb16_nat+0x305>
   1fd47:	push   %rbp
   1fd48:	lea    (%rdx,%rdx,2),%r11
   1fd4c:	mov    %rdx,%rcx
   1fd4f:	lea    0x0(,%rdx,8),%r9
   1fd57:	shl    $0x2,%r11
   1fd5b:	mov    %rsp,%rbp
   1fd5e:	push   %r15
   1fd60:	push   %r14
   1fd62:	push   %r13
   1fd64:	push   %r12
   1fd66:	mov    %rsi,%r12
   1fd69:	mov    %rdx,%rsi
   1fd6c:	push   %rbx
   1fd6d:	shl    $0x4,%rsi
   1fd71:	test   %rdx,%rdx
   1fd74:	je     20027 <hstep_tb16_nat+0x2f7>
   1fd7a:	lea    (%rdi,%r9,1),%rax
   1fd7e:	mov    %rdx,%r10
   1fd81:	lea    (%rdx,%rdx,4),%r8
   1fd85:	neg    %r9
   1fd88:	vmovq  %rax,%xmm15
   1fd8d:	lea    -0x1(%rdx),%rax
   1fd91:	neg    %r10
   1fd94:	xor    %ebx,%ebx
   1fd96:	shr    $0x4,%rax
   1fd9a:	lea    (%rdi,%r8,8),%r15
   1fd9e:	shl    $0x2,%r10
   1fda2:	lea    0x40(%rdi),%r14
   1fda6:	lea    (%rdx,%rax,8),%r13
   1fdaa:	shl    $0x2,%r8
   1fdae:	add    %r13,%r13
   1fdb1:	lea    0x0(,%rbx,4),%rdx
   1fdb9:	vmovq  %xmm15,%rax
   1fdbe:	lea    (%rbx,%r13,1),%rdi
   1fdc2:	add    %rdx,%rax
   1fdc5:	lea    (%r14,%rdi,4),%rdi
   1fdc9:	add    %r15,%rdx
   1fdcc:	nopl   0x0(%rax)
   1fdd0:	vmovups (%rax,%r9,1),%zmm2
   1fdd7:	vmovups (%rax),%zmm6
   1fddd:	vaddps (%rax,%r10,1),%zmm2,%zmm9
   1fde4:	vaddps (%rax,%rcx,4),%zmm6,%zmm16
   1fdeb:	vsubps (%rax,%rcx,4),%zmm6,%zmm7
   1fdf2:	vsubps (%rax,%r10,1),%zmm2,%zmm0
   1fdf9:	vmovups (%rdx),%zmm3
   1fdff:	vmovups (%rax,%rcx,8),%zmm2
   1fe06:	vaddps (%rdx,%rcx,4),%zmm3,%zmm11
   1fe0d:	vsubps (%rdx,%rcx,4),%zmm3,%zmm4
   1fe14:	vaddps (%rax,%r11,1),%zmm2,%zmm14
   1fe1b:	vsubps (%rax,%r11,1),%zmm2,%zmm1
   1fe22:	vmovups (%rax,%rsi,1),%zmm6
   1fe29:	vmovups (%rdx,%r9,1),%zmm2
   1fe30:	vaddps %zmm16,%zmm9,%zmm20
   1fe36:	vaddps %zmm7,%zmm0,%zmm19
   1fe3c:	vaddps (%rax,%r8,1),%zmm6,%zmm12
   1fe43:	vaddps (%rdx,%r10,1),%zmm2,%zmm13
   1fe4a:	vsubps (%rax,%r8,1),%zmm6,%zmm6
   1fe51:	vsubps (%rdx,%r10,1),%zmm2,%zmm5
   1fe58:	vmovups (%rdx,%rcx,8),%zmm3
   1fe5f:	vmovups (%rdx,%rsi,1),%zmm2
   1fe66:	vsubps %zmm7,%zmm0,%zmm0
   1fe6c:	vsubps %zmm16,%zmm9,%zmm9
   1fe72:	vaddps (%rdx,%r8,1),%zmm2,%zmm8
   1fe79:	vaddps (%rdx,%r11,1),%zmm3,%zmm10
   1fe80:	vsubps (%rdx,%r8,1),%zmm2,%zmm2
   1fe87:	vsubps (%rdx,%r11,1),%zmm3,%zmm3
   1fe8e:	vaddps %zmm12,%zmm14,%zmm7
   1fe94:	vaddps %zmm6,%zmm1,%zmm18
   1fe9a:	vaddps %zmm11,%zmm13,%zmm17
   1fea0:	vsubps %zmm12,%zmm14,%zmm14
   1fea6:	vaddps %zmm8,%zmm10,%zmm12
   1feac:	vaddps %zmm4,%zmm5,%zmm16
   1feb2:	vsubps %zmm6,%zmm1,%zmm1
   1feb8:	vsubps %zmm4,%zmm5,%zmm5
   1febe:	vsubps %zmm8,%zmm10,%zmm10
   1fec4:	vsubps %zmm11,%zmm13,%zmm13
   1feca:	vaddps %zmm7,%zmm20,%zmm8
   1fed0:	vaddps %zmm2,%zmm3,%zmm11
   1fed6:	vsubps %zmm7,%zmm20,%zmm4
   1fedc:	vsubps %zmm2,%zmm3,%zmm3
   1fee2:	vaddps %zmm18,%zmm19,%zmm7
   1fee8:	vsubps %zmm18,%zmm19,%zmm2
   1feee:	vaddps %zmm12,%zmm17,%zmm18
   1fef4:	vaddps %zmm14,%zmm9,%zmm6
   1fefa:	vsubps %zmm12,%zmm17,%zmm12
   1ff00:	vsubps %zmm14,%zmm9,%zmm9
   1ff06:	vaddps %zmm11,%zmm16,%zmm17
   1ff0c:	vaddps %zmm1,%zmm0,%zmm14
   1ff12:	vsubps %zmm11,%zmm16,%zmm11
   1ff18:	vsubps %zmm1,%zmm0,%zmm0
   1ff1e:	vaddps %zmm10,%zmm13,%zmm16
   1ff24:	vsubps %zmm10,%zmm13,%zmm1
   1ff2a:	vaddps %zmm3,%zmm5,%zmm10
   1ff30:	vsubps %zmm3,%zmm5,%zmm3
   1ff36:	vaddps %zmm18,%zmm8,%zmm5
   1ff3c:	vsubps %zmm18,%zmm8,%zmm8
   1ff42:	vmovups %zmm5,(%rax,%r9,1)
   1ff49:	vaddps %zmm17,%zmm7,%zmm5
   1ff4f:	vsubps %zmm17,%zmm7,%zmm7
   1ff55:	vmovups %zmm5,(%rax,%r10,1)
   1ff5c:	vaddps %zmm16,%zmm6,%zmm5
   1ff62:	vsubps %zmm16,%zmm6,%zmm6
   1ff68:	vmovups %zmm5,(%rax)
   1ff6e:	vaddps %zmm10,%zmm14,%zmm5
   1ff74:	vmovups %zmm5,(%rax,%rcx,4)
   1ff7b:	vaddps %zmm12,%zmm4,%zmm5
   1ff81:	vsubps %zmm12,%zmm4,%zmm4
   1ff87:	vmovups %zmm5,(%rax,%rcx,8)
   1ff8e:	vaddps %zmm11,%zmm2,%zmm5
   1ff94:	add    $0x40,%rax
   1ff98:	vsubps %zmm11,%zmm2,%zmm2
   1ff9e:	vmovups %zmm5,-0x40(%rax,%r11,1)
   1ffa6:	vaddps %zmm1,%zmm9,%zmm5
   1ffac:	vsubps %zmm1,%zmm9,%zmm1
   1ffb2:	vmovups %zmm5,-0x40(%rax,%rsi,1)
   1ffba:	vaddps %zmm3,%zmm0,%zmm5
   1ffc0:	vsubps %zmm3,%zmm0,%zmm0
   1ffc6:	vmovups %zmm5,-0x40(%rax,%r8,1)
   1ffce:	vsubps %zmm10,%zmm14,%zmm5
   1ffd4:	vmovups %zmm8,(%rdx,%r9,1)
   1ffdb:	vmovups %zmm7,(%rdx,%r10,1)
   1ffe2:	vmovups %zmm6,(%rdx)
   1ffe8:	vmovups %zmm5,(%rdx,%rcx,4)
   1ffef:	vmovups %zmm4,(%rdx,%rcx,8)
   1fff6:	add    $0x40,%rdx
   1fffa:	vmovups %zmm2,-0x40(%rdx,%r11,1)
   20002:	vmovups %zmm1,-0x40(%rdx,%rsi,1)
   2000a:	vmovups %zmm0,-0x40(%rdx,%r8,1)
   20012:	cmp    %rdi,%rax
   20015:	jne    1fdd0 <hstep_tb16_nat+0xa0>
   2001b:	add    %rsi,%rbx
   2001e:	cmp    %r12,%rbx
   20021:	jb     1fdb1 <hstep_tb16_nat+0x81>
   20027:	vzeroupper
   2002a:	pop    %rbx
   2002b:	pop    %r12
   2002d:	pop    %r13
   2002f:	pop    %r14
   20031:	pop    %r15
   20033:	pop    %rbp
   20034:	ret
   20035:	vzeroupper
   20038:	ret
   20039:	nopl   0x0(%rax)

0000000000022610 <hfirst_g20_nat>:
   22610:	endbr64
   22614:	vbroadcastss 0x2a5aa(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
   2261e:	test   %rsi,%rsi
   22621:	je     229b5 <hfirst_g20_nat+0x3a5>
   22627:	mov    $0xffffaaaa,%ecx
   2262c:	mov    %rdi,%rax
   2262f:	lea    -0x4(,%rsi,4),%rdx
   22637:	vmovdqa32 0x2a43f(%rip),%zmm12        # 4ca80 <FFHT_THR_F+0x80>
   22641:	kmovw  %ecx,%k4
   22645:	mov    $0xffffcccc,%ecx
   2264a:	and    $0xfffffffffffffe00,%rdx
   22651:	vmovdqa32 0x2a465(%rip),%zmm11        # 4cac0 <FFHT_THR_F+0xc0>
   2265b:	kmovw  %ecx,%k3
   2265f:	mov    $0xfffff0f0,%ecx
   22664:	vmovdqa32 0x2a492(%rip),%zmm10        # 4cb00 <FFHT_THR_F+0x100>
   2266e:	vmovdqa32 0x2a4c8(%rip),%zmm9        # 4cb40 <FFHT_THR_F+0x140>
   22678:	vbroadcastss 0x29986(%rip),%zmm0        # 4c008 <_IO_stdin_used+0x8>
   22682:	kmovw  %ecx,%k2
   22686:	lea    0x200(%rdi,%rdx,1),%rdx
   2268e:	mov    $0xffffff00,%ecx
   22693:	kmovw  %ecx,%k1
   22697:	nopw   0x0(%rax,%rax,1)
   226a0:	vpermps (%rax),%zmm12,%zmm2
   226a6:	vaddps (%rax),%zmm2,%zmm1
   226ac:	add    $0x200,%rax
   226b2:	vsubps -0x200(%rax),%zmm2,%zmm1{%k4}
   226b9:	vpermps %zmm1,%zmm11,%zmm3
   226bf:	vaddps %zmm3,%zmm1,%zmm2
   226c5:	vsubps %zmm1,%zmm3,%zmm2{%k3}
   226cb:	vpermps %zmm2,%zmm10,%zmm3
   226d1:	vaddps %zmm3,%zmm2,%zmm1
   226d7:	vsubps %zmm2,%zmm3,%zmm1{%k2}
   226dd:	vpermps %zmm1,%zmm9,%zmm2
   226e3:	vaddps %zmm2,%zmm1,%zmm4
   226e9:	vsubps %zmm1,%zmm2,%zmm4{%k1}
   226ef:	vpermps -0x1c0(%rax),%zmm12,%zmm2
   226f6:	vaddps -0x1c0(%rax),%zmm2,%zmm1
   226fd:	vsubps -0x1c0(%rax),%zmm2,%zmm1{%k4}
   22704:	vpermps %zmm1,%zmm11,%zmm3
   2270a:	vaddps %zmm3,%zmm1,%zmm2
   22710:	vsubps %zmm1,%zmm3,%zmm2{%k3}
   22716:	vpermps %zmm2,%zmm10,%zmm3
   2271c:	vaddps %zmm3,%zmm2,%zmm1
   22722:	vsubps %zmm2,%zmm3,%zmm1{%k2}
   22728:	vpermps %zmm1,%zmm9,%zmm2
   2272e:	vaddps %zmm2,%zmm1,%zmm3
   22734:	vsubps %zmm1,%zmm2,%zmm3{%k1}
   2273a:	vpermps -0x180(%rax),%zmm12,%zmm2
   22741:	vaddps -0x180(%rax),%zmm2,%zmm1
   22748:	vsubps -0x180(%rax),%zmm2,%zmm1{%k4}
   2274f:	vaddps %zmm3,%zmm4,%zmm3
   22755:	vpermps %zmm1,%zmm11,%zmm5
   2275b:	vaddps %zmm5,%zmm1,%zmm2
   22761:	vsubps %zmm1,%zmm5,%zmm2{%k3}
   22767:	vpermps %zmm2,%zmm10,%zmm5
   2276d:	vaddps %zmm5,%zmm2,%zmm1
   22773:	vsubps %zmm2,%zmm5,%zmm1{%k2}
   22779:	vpermps %zmm1,%zmm9,%zmm2
   2277f:	vaddps %zmm2,%zmm1,%zmm8
   22785:	vsubps %zmm1,%zmm2,%zmm8{%k1}
   2278b:	vpermps -0x140(%rax),%zmm12,%zmm2
   22792:	vaddps -0x140(%rax),%zmm2,%zmm1
   22799:	vsubps -0x140(%rax),%zmm2,%zmm1{%k4}
   227a0:	vpermps %zmm1,%zmm11,%zmm5
   227a6:	vaddps %zmm5,%zmm1,%zmm2
   227ac:	vsubps %zmm1,%zmm5,%zmm2{%k3}
   227b2:	vpermps %zmm2,%zmm10,%zmm5
   227b8:	vaddps %zmm5,%zmm2,%zmm1
   227be:	vsubps %zmm2,%zmm5,%zmm1{%k2}
   227c4:	vpermps %zmm1,%zmm9,%zmm2
   227ca:	vaddps %zmm2,%zmm1,%zmm6
   227d0:	vsubps %zmm1,%zmm2,%zmm6{%k1}
   227d6:	vpermps -0x100(%rax),%zmm12,%zmm2
   227dd:	vaddps -0x100(%rax),%zmm2,%zmm1
   227e4:	vsubps -0x100(%rax),%zmm2,%zmm1{%k4}
   227eb:	vsubps %zmm6,%zmm8,%zmm6
   227f1:	vpermps %zmm1,%zmm11,%zmm5
   227f7:	vaddps %zmm5,%zmm1,%zmm2
   227fd:	vsubps %zmm1,%zmm5,%zmm2{%k3}
   22803:	vpermps %zmm2,%zmm10,%zmm5
   22809:	vaddps %zmm5,%zmm2,%zmm1
   2280f:	vsubps %zmm2,%zmm5,%zmm1{%k2}
   22815:	vpermps %zmm1,%zmm9,%zmm5
   2281b:	vaddps %zmm5,%zmm1,%zmm2
   22821:	vsubps %zmm1,%zmm5,%zmm2{%k1}
   22827:	vpermps -0xc0(%rax),%zmm12,%zmm5
   2282e:	vaddps -0xc0(%rax),%zmm5,%zmm1
   22835:	vsubps -0xc0(%rax),%zmm5,%zmm1{%k4}
   2283c:	vpermps %zmm1,%zmm11,%zmm7
   22842:	vaddps %zmm7,%zmm1,%zmm5
   22848:	vsubps %zmm1,%zmm7,%zmm5{%k3}
   2284e:	vpermps %zmm5,%zmm10,%zmm7
   22854:	vaddps %zmm7,%zmm5,%zmm1
   2285a:	vsubps %zmm5,%zmm7,%zmm1{%k2}
   22860:	vpermps %zmm1,%zmm9,%zmm7
   22866:	vaddps %zmm7,%zmm1,%zmm5
   2286c:	vsubps %zmm1,%zmm7,%zmm5{%k1}
   22872:	vpermps -0x80(%rax),%zmm12,%zmm7
   22879:	vaddps -0x80(%rax),%zmm7,%zmm1
   22880:	vsubps -0x80(%rax),%zmm7,%zmm1{%k4}
   22887:	vaddps %zmm5,%zmm2,%zmm5
   2288d:	vpermps %zmm1,%zmm11,%zmm13
   22893:	vaddps %zmm13,%zmm1,%zmm7
   22899:	vsubps %zmm1,%zmm13,%zmm7{%k3}
   2289f:	vpermps %zmm7,%zmm10,%zmm13
   228a5:	vaddps %zmm13,%zmm7,%zmm1
   228ab:	vsubps %zmm7,%zmm13,%zmm1{%k2}
   228b1:	vpermps %zmm1,%zmm9,%zmm13
   228b7:	vaddps %zmm13,%zmm1,%zmm7
   228bd:	vsubps %zmm1,%zmm13,%zmm7{%k1}
   228c3:	vpermps -0x40(%rax),%zmm12,%zmm1
   228ca:	vaddps -0x40(%rax),%zmm1,%zmm13
   228d1:	vsubps -0x40(%rax),%zmm1,%zmm13{%k4}
   228d8:	vpermps %zmm13,%zmm11,%zmm14
   228de:	vaddps %zmm13,%zmm14,%zmm1
   228e4:	vsubps %zmm13,%zmm14,%zmm1{%k3}
   228ea:	vpermps %zmm1,%zmm10,%zmm14
   228f0:	vaddps %zmm14,%zmm1,%zmm13
   228f6:	vsubps %zmm1,%zmm14,%zmm13{%k2}
   228fc:	vpermps %zmm13,%zmm9,%zmm14
   22902:	vaddps %zmm13,%zmm14,%zmm1
   22908:	vsubps %zmm13,%zmm14,%zmm1{%k1}
   2290e:	vsubps %zmm6,%zmm3,%zmm13
   22914:	vsubps %zmm1,%zmm7,%zmm1
   2291a:	vfmadd132ps %zmm0,%zmm13,%zmm8
   22920:	vfmsub132ps %zmm0,%zmm13,%zmm4
   22926:	vaddps %zmm1,%zmm5,%zmm13
   2292c:	vfnmadd132ps %zmm0,%zmm13,%zmm7
   22932:	vfmsub132ps %zmm0,%zmm13,%zmm2
   22938:	vaddps %zmm7,%zmm8,%zmm13
   2293e:	vfnmadd132ps %zmm0,%zmm13,%zmm5
   22944:	vfmsub132ps %zmm0,%zmm13,%zmm3
   2294a:	vaddps %zmm2,%zmm4,%zmm13
   22950:	vfmadd132ps %zmm0,%zmm13,%zmm1
   22956:	vfnmadd132ps %zmm0,%zmm13,%zmm6
   2295c:	vfmsub132ps %zmm0,%zmm5,%zmm8
   22962:	vfmadd132ps %zmm0,%zmm3,%zmm7
   22968:	vmovups %zmm5,-0x100(%rax)
   2296f:	vmovups %zmm3,-0x80(%rax)
   22976:	vfmsub132ps %zmm0,%zmm1,%zmm4
   2297c:	vfnmadd132ps %zmm0,%zmm6,%zmm2
   22982:	vmovups %zmm1,-0x1c0(%rax)
   22989:	vmovups %zmm6,-0x140(%rax)
   22990:	vmovups %zmm8,-0x200(%rax)
   22997:	vmovups %zmm7,-0x180(%rax)
   2299e:	vmovups %zmm4,-0xc0(%rax)
   229a5:	vmovups %zmm2,-0x40(%rax)
   229ac:	cmp    %rdx,%rax
   229af:	jne    226a0 <hfirst_g20_nat+0x90>
   229b5:	vzeroupper
   229b8:	ret
   229b9:	nopl   0x0(%rax)

0000000000024280 <hfirst_broken_g20>:
   24280:	endbr64
   24284:	vbroadcastss 0x2893a(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
   2428e:	test   %rsi,%rsi
   24291:	je     24625 <hfirst_broken_g20+0x3a5>
   24297:	mov    $0xffffaaaa,%ecx
   2429c:	mov    %rdi,%rax
   2429f:	lea    -0x4(,%rsi,4),%rdx
   242a7:	vmovdqa32 0x287cf(%rip),%zmm12        # 4ca80 <FFHT_THR_F+0x80>
   242b1:	kmovw  %ecx,%k4
   242b5:	mov    $0xffffcccc,%ecx
   242ba:	and    $0xfffffffffffffe00,%rdx
   242c1:	vmovdqa32 0x287f5(%rip),%zmm11        # 4cac0 <FFHT_THR_F+0xc0>
   242cb:	kmovw  %ecx,%k3
   242cf:	mov    $0xfffff0f0,%ecx
   242d4:	vmovdqa32 0x28822(%rip),%zmm10        # 4cb00 <FFHT_THR_F+0x100>
   242de:	vmovdqa32 0x28858(%rip),%zmm9        # 4cb40 <FFHT_THR_F+0x140>
   242e8:	vbroadcastss 0x27d16(%rip),%zmm0        # 4c008 <_IO_stdin_used+0x8>
   242f2:	kmovw  %ecx,%k2
   242f6:	lea    0x200(%rdi,%rdx,1),%rdx
   242fe:	mov    $0xffffff00,%ecx
   24303:	kmovw  %ecx,%k1
   24307:	nopw   0x0(%rax,%rax,1)
   24310:	vpermps (%rax),%zmm12,%zmm2
   24316:	vaddps (%rax),%zmm2,%zmm1
   2431c:	add    $0x200,%rax
   24322:	vsubps -0x200(%rax),%zmm2,%zmm1{%k4}
   24329:	vpermps %zmm1,%zmm11,%zmm3
   2432f:	vaddps %zmm3,%zmm1,%zmm2
   24335:	vsubps %zmm1,%zmm3,%zmm2{%k3}
   2433b:	vpermps %zmm2,%zmm10,%zmm3
   24341:	vaddps %zmm3,%zmm2,%zmm1
   24347:	vsubps %zmm2,%zmm3,%zmm1{%k2}
   2434d:	vpermps %zmm1,%zmm9,%zmm2
   24353:	vaddps %zmm2,%zmm1,%zmm3
   24359:	vsubps %zmm1,%zmm2,%zmm3{%k1}
   2435f:	vpermps -0x1c0(%rax),%zmm12,%zmm2
   24366:	vaddps -0x1c0(%rax),%zmm2,%zmm1
   2436d:	vsubps -0x1c0(%rax),%zmm2,%zmm1{%k4}
   24374:	vpermps %zmm1,%zmm11,%zmm4
   2437a:	vaddps %zmm4,%zmm1,%zmm2
   24380:	vsubps %zmm1,%zmm4,%zmm2{%k3}
   24386:	vpermps %zmm2,%zmm10,%zmm4
   2438c:	vaddps %zmm4,%zmm2,%zmm1
   24392:	vsubps %zmm2,%zmm4,%zmm1{%k2}
   24398:	vpermps %zmm1,%zmm9,%zmm2
   2439e:	vaddps %zmm2,%zmm1,%zmm4
   243a4:	vsubps %zmm1,%zmm2,%zmm4{%k1}
   243aa:	vpermps -0x180(%rax),%zmm12,%zmm2
   243b1:	vaddps -0x180(%rax),%zmm2,%zmm1
   243b8:	vsubps -0x180(%rax),%zmm2,%zmm1{%k4}
   243bf:	vaddps %zmm4,%zmm3,%zmm4
   243c5:	vpermps %zmm1,%zmm11,%zmm5
   243cb:	vaddps %zmm5,%zmm1,%zmm2
   243d1:	vsubps %zmm1,%zmm5,%zmm2{%k3}
   243d7:	vpermps %zmm2,%zmm10,%zmm5
   243dd:	vaddps %zmm5,%zmm2,%zmm1
   243e3:	vsubps %zmm2,%zmm5,%zmm1{%k2}
   243e9:	vpermps %zmm1,%zmm9,%zmm2
   243ef:	vaddps %zmm2,%zmm1,%zmm8
   243f5:	vsubps %zmm1,%zmm2,%zmm8{%k1}
   243fb:	vpermps -0x140(%rax),%zmm12,%zmm2
   24402:	vaddps -0x140(%rax),%zmm2,%zmm1
   24409:	vsubps -0x140(%rax),%zmm2,%zmm1{%k4}
   24410:	vpermps %zmm1,%zmm11,%zmm5
   24416:	vaddps %zmm5,%zmm1,%zmm2
   2441c:	vsubps %zmm1,%zmm5,%zmm2{%k3}
   24422:	vpermps %zmm2,%zmm10,%zmm5
   24428:	vaddps %zmm5,%zmm2,%zmm1
   2442e:	vsubps %zmm2,%zmm5,%zmm1{%k2}
   24434:	vpermps %zmm1,%zmm9,%zmm2
   2443a:	vaddps %zmm2,%zmm1,%zmm6
   24440:	vsubps %zmm1,%zmm2,%zmm6{%k1}
   24446:	vpermps -0x100(%rax),%zmm12,%zmm2
   2444d:	vaddps -0x100(%rax),%zmm2,%zmm1
   24454:	vsubps -0x100(%rax),%zmm2,%zmm1{%k4}
   2445b:	vsubps %zmm6,%zmm8,%zmm6
   24461:	vpermps %zmm1,%zmm11,%zmm5
   24467:	vaddps %zmm5,%zmm1,%zmm2
   2446d:	vsubps %zmm1,%zmm5,%zmm2{%k3}
   24473:	vpermps %zmm2,%zmm10,%zmm5
   24479:	vaddps %zmm5,%zmm2,%zmm1
   2447f:	vsubps %zmm2,%zmm5,%zmm1{%k2}
   24485:	vpermps %zmm1,%zmm9,%zmm5
   2448b:	vaddps %zmm5,%zmm1,%zmm2
   24491:	vsubps %zmm1,%zmm5,%zmm2{%k1}
   24497:	vpermps -0xc0(%rax),%zmm12,%zmm5
   2449e:	vaddps -0xc0(%rax),%zmm5,%zmm1
   244a5:	vsubps -0xc0(%rax),%zmm5,%zmm1{%k4}
   244ac:	vpermps %zmm1,%zmm11,%zmm7
   244b2:	vaddps %zmm7,%zmm1,%zmm5
   244b8:	vsubps %zmm1,%zmm7,%zmm5{%k3}
   244be:	vpermps %zmm5,%zmm10,%zmm7
   244c4:	vaddps %zmm7,%zmm5,%zmm1
   244ca:	vsubps %zmm5,%zmm7,%zmm1{%k2}
   244d0:	vpermps %zmm1,%zmm9,%zmm7
   244d6:	vaddps %zmm7,%zmm1,%zmm5
   244dc:	vsubps %zmm1,%zmm7,%zmm5{%k1}
   244e2:	vpermps -0x80(%rax),%zmm12,%zmm7
   244e9:	vaddps -0x80(%rax),%zmm7,%zmm1
   244f0:	vsubps -0x80(%rax),%zmm7,%zmm1{%k4}
   244f7:	vaddps %zmm5,%zmm2,%zmm5
   244fd:	vpermps %zmm1,%zmm11,%zmm13
   24503:	vaddps %zmm13,%zmm1,%zmm7
   24509:	vsubps %zmm1,%zmm13,%zmm7{%k3}
   2450f:	vpermps %zmm7,%zmm10,%zmm13
   24515:	vaddps %zmm13,%zmm7,%zmm1
   2451b:	vsubps %zmm7,%zmm13,%zmm1{%k2}
   24521:	vpermps %zmm1,%zmm9,%zmm13
   24527:	vaddps %zmm13,%zmm1,%zmm7
   2452d:	vsubps %zmm1,%zmm13,%zmm7{%k1}
   24533:	vpermps -0x40(%rax),%zmm12,%zmm1
   2453a:	vaddps -0x40(%rax),%zmm1,%zmm13
   24541:	vsubps -0x40(%rax),%zmm1,%zmm13{%k4}
   24548:	vpermps %zmm13,%zmm11,%zmm14
   2454e:	vaddps %zmm13,%zmm14,%zmm1
   24554:	vsubps %zmm13,%zmm14,%zmm1{%k3}
   2455a:	vpermps %zmm1,%zmm10,%zmm14
   24560:	vaddps %zmm14,%zmm1,%zmm13
   24566:	vsubps %zmm1,%zmm14,%zmm13{%k2}
   2456c:	vpermps %zmm13,%zmm9,%zmm14
   24572:	vaddps %zmm13,%zmm14,%zmm1
   24578:	vsubps %zmm13,%zmm14,%zmm1{%k1}
   2457e:	vsubps %zmm6,%zmm4,%zmm13
   24584:	vsubps %zmm1,%zmm7,%zmm1
   2458a:	vfmadd132ps %zmm0,%zmm13,%zmm8
   24590:	vfmsub132ps %zmm0,%zmm13,%zmm3
   24596:	vaddps %zmm1,%zmm5,%zmm13
   2459c:	vfnmadd132ps %zmm0,%zmm13,%zmm7
   245a2:	vfmsub132ps %zmm0,%zmm13,%zmm2
   245a8:	vaddps %zmm7,%zmm8,%zmm13
   245ae:	vfnmadd132ps %zmm0,%zmm13,%zmm5
   245b4:	vfmsub132ps %zmm0,%zmm13,%zmm4
   245ba:	vaddps %zmm2,%zmm3,%zmm13
   245c0:	vfmadd132ps %zmm0,%zmm13,%zmm1
   245c6:	vfnmadd132ps %zmm0,%zmm13,%zmm6
   245cc:	vfmsub132ps %zmm0,%zmm5,%zmm8
   245d2:	vfmadd132ps %zmm0,%zmm4,%zmm7
   245d8:	vmovups %zmm5,-0x100(%rax)
   245df:	vmovups %zmm4,-0xc0(%rax)
   245e6:	vfmsub132ps %zmm0,%zmm1,%zmm3
   245ec:	vfnmadd132ps %zmm0,%zmm6,%zmm2
   245f2:	vmovups %zmm1,-0x1c0(%rax)
   245f9:	vmovups %zmm6,-0x140(%rax)
   24600:	vmovups %zmm8,-0x200(%rax)
   24607:	vmovups %zmm7,-0x180(%rax)
   2460e:	vmovups %zmm3,-0x80(%rax)
   24615:	vmovups %zmm2,-0x40(%rax)
   2461c:	cmp    %rdx,%rax
   2461f:	jne    24310 <hfirst_broken_g20+0x90>
   24625:	vzeroupper
   24628:	ret
   24629:	nopl   0x0(%rax)

0000000000025b00 <hfirst_tb8_bal>:
   25b00:	endbr64
   25b04:	vbroadcastss 0x270ba(%rip),%zmm1        # 4cbc8 <FFHT_THR_F+0x1c8>
   25b0e:	test   %rsi,%rsi
   25b11:	je     25ef5 <hfirst_tb8_bal+0x3f5>
   25b17:	mov    $0xffffaaaa,%ecx
   25b1c:	mov    %rdi,%rax
   25b1f:	lea    -0x4(,%rsi,4),%rdx
   25b27:	vmovdqa32 0x26f4f(%rip),%zmm6        # 4ca80 <FFHT_THR_F+0x80>
   25b31:	kmovw  %ecx,%k4
   25b35:	mov    $0xffffcccc,%ecx
   25b3a:	and    $0xfffffffffffffe00,%rdx
   25b41:	vmovdqa32 0x26f75(%rip),%zmm5        # 4cac0 <FFHT_THR_F+0xc0>
   25b4b:	kmovw  %ecx,%k3
   25b4f:	mov    $0xfffff0f0,%ecx
   25b54:	vmovdqa32 0x26fa2(%rip),%zmm4        # 4cb00 <FFHT_THR_F+0x100>
   25b5e:	vmovdqa32 0x26fd8(%rip),%zmm3        # 4cb40 <FFHT_THR_F+0x140>
   25b68:	kmovw  %ecx,%k2
   25b6c:	lea    0x200(%rdi,%rdx,1),%rdx
   25b74:	mov    $0xffffff00,%ecx
   25b79:	kmovw  %ecx,%k1
   25b7d:	nopl   (%rax)
   25b80:	vpermps (%rax),%zmm6,%zmm0
   25b86:	vaddps (%rax),%zmm0,%zmm2
   25b8c:	add    $0x200,%rax
   25b92:	vsubps -0x200(%rax),%zmm0,%zmm2{%k4}
   25b99:	vpermps %zmm2,%zmm5,%zmm7
   25b9f:	vaddps %zmm7,%zmm2,%zmm0
   25ba5:	vsubps %zmm2,%zmm7,%zmm0{%k3}
   25bab:	vpermps %zmm0,%zmm4,%zmm7
   25bb1:	vaddps %zmm7,%zmm0,%zmm2
   25bb7:	vsubps %zmm0,%zmm7,%zmm2{%k2}
   25bbd:	vpermps %zmm2,%zmm3,%zmm7
   25bc3:	vaddps %zmm7,%zmm2,%zmm0
   25bc9:	vsubps %zmm2,%zmm7,%zmm0{%k1}
   25bcf:	vpermps -0x1c0(%rax),%zmm6,%zmm7
   25bd6:	vaddps -0x1c0(%rax),%zmm7,%zmm2
   25bdd:	vsubps -0x1c0(%rax),%zmm7,%zmm2{%k4}
   25be4:	vpermps %zmm2,%zmm5,%zmm8
   25bea:	vaddps %zmm8,%zmm2,%zmm7
   25bf0:	vsubps %zmm2,%zmm8,%zmm7{%k3}
   25bf6:	vpermps %zmm7,%zmm4,%zmm8
   25bfc:	vaddps %zmm8,%zmm7,%zmm2
   25c02:	vsubps %zmm7,%zmm8,%zmm2{%k2}
   25c08:	vpermps %zmm2,%zmm3,%zmm7
   25c0e:	vaddps %zmm7,%zmm2,%zmm12
   25c14:	vsubps %zmm2,%zmm7,%zmm12{%k1}
   25c1a:	vpermps -0x180(%rax),%zmm6,%zmm7
   25c21:	vaddps -0x180(%rax),%zmm7,%zmm2
   25c28:	vsubps -0x180(%rax),%zmm7,%zmm2{%k4}
   25c2f:	vpermps %zmm2,%zmm5,%zmm8
   25c35:	vaddps %zmm8,%zmm2,%zmm7
   25c3b:	vsubps %zmm2,%zmm8,%zmm7{%k3}
   25c41:	vpermps %zmm7,%zmm4,%zmm8
   25c47:	vaddps %zmm8,%zmm7,%zmm2
   25c4d:	vsubps %zmm7,%zmm8,%zmm2{%k2}
   25c53:	vpermps %zmm2,%zmm3,%zmm7
   25c59:	vaddps %zmm7,%zmm2,%zmm10
   25c5f:	vsubps %zmm2,%zmm7,%zmm10{%k1}
   25c65:	vpermps -0x140(%rax),%zmm6,%zmm7
   25c6c:	vaddps -0x140(%rax),%zmm7,%zmm2
   25c73:	vsubps -0x140(%rax),%zmm7,%zmm2{%k4}
   25c7a:	vpermps %zmm2,%zmm5,%zmm8
   25c80:	vaddps %zmm8,%zmm2,%zmm7
   25c86:	vsubps %zmm2,%zmm8,%zmm7{%k3}
   25c8c:	vpermps %zmm7,%zmm4,%zmm8
   25c92:	vaddps %zmm8,%zmm7,%zmm2
   25c98:	vsubps %zmm7,%zmm8,%zmm2{%k2}
   25c9e:	vpermps %zmm2,%zmm3,%zmm7
   25ca4:	vaddps %zmm7,%zmm2,%zmm11
   25caa:	vsubps %zmm2,%zmm7,%zmm11{%k1}
   25cb0:	vpermps -0x100(%rax),%zmm6,%zmm2
   25cb7:	vaddps -0x100(%rax),%zmm2,%zmm7
   25cbe:	vsubps -0x100(%rax),%zmm2,%zmm7{%k4}
   25cc5:	vmovaps %zmm11,%zmm15
   25ccb:	vpermps %zmm7,%zmm5,%zmm8
   25cd1:	vfmadd132ps %zmm1,%zmm10,%zmm15
   25cd7:	vsubps %zmm11,%zmm10,%zmm10
   25cdd:	vaddps %zmm8,%zmm7,%zmm2
   25ce3:	vmovaps %zmm10,%zmm11
   25ce9:	vsubps %zmm7,%zmm8,%zmm2{%k3}
   25cef:	vpermps %zmm2,%zmm4,%zmm8
   25cf5:	vaddps %zmm8,%zmm2,%zmm7
   25cfb:	vsubps %zmm2,%zmm8,%zmm7{%k2}
   25d01:	vpermps %zmm7,%zmm3,%zmm8
   25d07:	vaddps %zmm8,%zmm7,%zmm2
   25d0d:	vsubps %zmm7,%zmm8,%zmm2{%k1}
   25d13:	vpermps -0xc0(%rax),%zmm6,%zmm8
   25d1a:	vaddps -0xc0(%rax),%zmm8,%zmm7
   25d21:	vsubps -0xc0(%rax),%zmm8,%zmm7{%k4}
   25d28:	vpermps %zmm7,%zmm5,%zmm9
   25d2e:	vaddps %zmm9,%zmm7,%zmm8
   25d34:	vsubps %zmm7,%zmm9,%zmm8{%k3}
   25d3a:	vpermps %zmm8,%zmm4,%zmm9
   25d40:	vaddps %zmm9,%zmm8,%zmm7
   25d46:	vsubps %zmm8,%zmm9,%zmm7{%k2}
   25d4c:	vpermps %zmm7,%zmm3,%zmm8
   25d52:	vaddps %zmm8,%zmm7,%zmm14
   25d58:	vsubps %zmm7,%zmm8,%zmm14{%k1}
   25d5e:	vpermps -0x80(%rax),%zmm6,%zmm8
   25d65:	vaddps -0x80(%rax),%zmm8,%zmm7
   25d6c:	vsubps -0x80(%rax),%zmm8,%zmm7{%k4}
   25d73:	vpermps %zmm7,%zmm5,%zmm9
   25d79:	vaddps %zmm9,%zmm7,%zmm8
   25d7f:	vsubps %zmm7,%zmm9,%zmm8{%k3}
   25d85:	vpermps %zmm8,%zmm4,%zmm9
   25d8b:	vaddps %zmm9,%zmm8,%zmm7
   25d91:	vsubps %zmm8,%zmm9,%zmm7{%k2}
   25d97:	vpermps %zmm7,%zmm3,%zmm8
   25d9d:	vaddps %zmm8,%zmm7,%zmm9
   25da3:	vsubps %zmm7,%zmm8,%zmm9{%k1}
   25da9:	vpermps -0x40(%rax),%zmm6,%zmm8
   25db0:	vaddps -0x40(%rax),%zmm8,%zmm7
   25db7:	vsubps -0x40(%rax),%zmm8,%zmm7{%k4}
   25dbe:	vpermps %zmm7,%zmm5,%zmm13
   25dc4:	vaddps %zmm7,%zmm13,%zmm8
   25dca:	vsubps %zmm7,%zmm13,%zmm8{%k3}
   25dd0:	vpermps %zmm8,%zmm4,%zmm13
   25dd6:	vaddps %zmm13,%zmm8,%zmm7
   25ddc:	vsubps %zmm8,%zmm13,%zmm7{%k2}
   25de2:	vpermps %zmm7,%zmm3,%zmm8
   25de8:	vaddps %zmm7,%zmm8,%zmm13
   25dee:	vsubps %zmm7,%zmm8,%zmm13{%k1}
   25df4:	vmovaps %zmm14,%zmm8
   25dfa:	vmovaps %zmm12,%zmm7
   25e00:	vfmadd132ps %zmm1,%zmm2,%zmm8
   25e06:	vsubps %zmm14,%zmm2,%zmm2
   25e0c:	vfmadd132ps %zmm1,%zmm0,%zmm7
   25e12:	vsubps %zmm12,%zmm0,%zmm0
   25e18:	vmovaps %zmm15,%zmm12
   25e1e:	vmovaps %zmm13,%zmm14
   25e24:	vfmadd132ps %zmm1,%zmm9,%zmm14
   25e2a:	vsubps %zmm13,%zmm9,%zmm9
   25e30:	vfmadd132ps %zmm1,%zmm0,%zmm11
   25e36:	vsubps %zmm10,%zmm0,%zmm0
   25e3c:	vmovaps %zmm9,%zmm10
   25e42:	vfmadd132ps %zmm1,%zmm7,%zmm12
   25e48:	vsubps %zmm15,%zmm7,%zmm7
   25e4e:	vfmadd132ps %zmm1,%zmm2,%zmm10
   25e54:	vsubps %zmm9,%zmm2,%zmm2
   25e5a:	vmovaps %zmm14,%zmm13
   25e60:	vfmadd132ps %zmm1,%zmm8,%zmm13
   25e66:	vsubps %zmm14,%zmm8,%zmm8
   25e6c:	vmovaps %zmm2,%zmm9
   25e72:	vfmadd132ps %zmm1,%zmm0,%zmm9
   25e78:	vsubps %zmm2,%zmm0,%zmm0
   25e7e:	vmovaps %zmm10,%zmm15
   25e84:	vmovaps %zmm8,%zmm14
   25e8a:	vfmadd132ps %zmm1,%zmm11,%zmm15
   25e90:	vfmadd132ps %zmm1,%zmm7,%zmm14
   25e96:	vsubps %zmm10,%zmm11,%zmm11
   25e9c:	vmovaps %zmm13,%zmm16
   25ea2:	vsubps %zmm8,%zmm7,%zmm7
   25ea8:	vmovups %zmm0,-0x40(%rax)
   25eaf:	vfmadd132ps %zmm1,%zmm12,%zmm16
   25eb5:	vsubps %zmm13,%zmm12,%zmm12
   25ebb:	vmovups %zmm9,-0x140(%rax)
   25ec2:	vmovups %zmm11,-0xc0(%rax)
   25ec9:	vmovups %zmm15,-0x1c0(%rax)
   25ed0:	vmovups %zmm14,-0x180(%rax)
   25ed7:	vmovups %zmm16,-0x200(%rax)
   25ede:	vmovups %zmm12,-0x100(%rax)
   25ee5:	vmovups %zmm7,-0x80(%rax)
   25eec:	cmp    %rdx,%rax
   25eef:	jne    25b80 <hfirst_tb8_bal+0x80>
   25ef5:	vzeroupper
   25ef8:	ret
   25ef9:	nopl   0x0(%rax)

000000000002aa10 <hfirst_tb16_nat>:
   2aa10:	endbr64
   2aa14:	push   %rbp
   2aa15:	mov    %rsp,%rbp
   2aa18:	and    $0xffffffffffffffc0,%rsp
   2aa1c:	sub    $0x440,%rsp
   2aa23:	vbroadcastss 0x2219b(%rip),%zmm0        # 4cbc8 <FFHT_THR_F+0x1c8>
   2aa2d:	mov    %fs:0x28,%rax
   2aa36:	mov    %rax,0x438(%rsp)
   2aa3e:	xor    %eax,%eax
   2aa40:	test   %rsi,%rsi
   2aa43:	je     2ad6c <hfirst_tb16_nat+0x35c>
   2aa49:	mov    $0xffffaaaa,%eax
   2aa4e:	mov    %rdi,%rdx
   2aa51:	mov    %rsp,%rcx
   2aa54:	vmovdqa32 0x22022(%rip),%zmm6        # 4ca80 <FFHT_THR_F+0x80>
   2aa5e:	vmovdqa32 0x22058(%rip),%zmm5        # 4cac0 <FFHT_THR_F+0xc0>
   2aa68:	kmovw  %eax,%k4
   2aa6c:	xor    %edi,%edi
   2aa6e:	mov    $0xffffcccc,%eax
   2aa73:	vmovdqa32 0x22083(%rip),%zmm4        # 4cb00 <FFHT_THR_F+0x100>
   2aa7d:	kmovw  %eax,%k3
   2aa81:	vmovdqa32 0x220b5(%rip),%zmm3        # 4cb40 <FFHT_THR_F+0x140>
   2aa8b:	mov    $0xfffff0f0,%eax
   2aa90:	kmovw  %eax,%k2
   2aa94:	mov    $0xffffff00,%eax
   2aa99:	kmovw  %eax,%k1
   2aa9d:	nopl   (%rax)
   2aaa0:	xor    %eax,%eax
   2aaa2:	nopw   0x0(%rax,%rax,1)
   2aaa8:	vpermps (%rdx,%rax,1),%zmm6,%zmm1
   2aaaf:	vaddps (%rdx,%rax,1),%zmm1,%zmm0
   2aab6:	vsubps (%rdx,%rax,1),%zmm1,%zmm0{%k4}
   2aabd:	vpermps %zmm0,%zmm5,%zmm2
   2aac3:	vaddps %zmm0,%zmm2,%zmm1
   2aac9:	vsubps %zmm0,%zmm2,%zmm1{%k3}
   2aacf:	vpermps %zmm1,%zmm4,%zmm2
   2aad5:	vaddps %zmm1,%zmm2,%zmm0
   2aadb:	vsubps %zmm1,%zmm2,%zmm0{%k2}
   2aae1:	vpermps %zmm0,%zmm3,%zmm2
   2aae7:	vaddps %zmm0,%zmm2,%zmm1
   2aaed:	vsubps %zmm0,%zmm2,%zmm1{%k1}
   2aaf3:	vmovaps %zmm1,(%rcx,%rax,1)
   2aafa:	add    $0x40,%rax
   2aafe:	cmp    $0x400,%rax
   2ab04:	jne    2aaa8 <hfirst_tb16_nat+0x98>
   2ab06:	vmovaps (%rsp),%zmm7
   2ab0d:	vaddps 0x40(%rsp),%zmm7,%zmm13
   2ab15:	add    $0x100,%rdi
   2ab1c:	add    $0x400,%rdx
   2ab23:	vsubps 0x40(%rsp),%zmm7,%zmm0
   2ab2b:	vmovaps 0x380(%rsp),%zmm2
   2ab33:	vmovaps 0x80(%rsp),%zmm7
   2ab3b:	vaddps 0x3c0(%rsp),%zmm2,%zmm12
   2ab43:	vaddps 0xc0(%rsp),%zmm7,%zmm19
   2ab4b:	vsubps 0xc0(%rsp),%zmm7,%zmm11
   2ab53:	vmovaps 0x100(%rsp),%zmm7
   2ab5b:	vaddps 0x140(%rsp),%zmm7,%zmm18
   2ab63:	vsubps 0x140(%rsp),%zmm7,%zmm1
   2ab6b:	vmovaps 0x180(%rsp),%zmm7
   2ab73:	vaddps %zmm19,%zmm13,%zmm23
   2ab79:	vaddps %zmm11,%zmm0,%zmm22
   2ab7f:	vsubps %zmm11,%zmm0,%zmm0
   2ab85:	vsubps %zmm19,%zmm13,%zmm13
   2ab8b:	vaddps 0x1c0(%rsp),%zmm7,%zmm16
   2ab93:	vsubps 0x1c0(%rsp),%zmm7,%zmm10
   2ab9b:	vmovaps 0x200(%rsp),%zmm7
   2aba3:	vaddps 0x240(%rsp),%zmm7,%zmm17
   2abab:	vsubps 0x240(%rsp),%zmm7,%zmm9
   2abb3:	vmovaps 0x280(%rsp),%zmm7
   2abbb:	vaddps %zmm16,%zmm18,%zmm11
   2abc1:	vaddps %zmm10,%zmm1,%zmm21
   2abc7:	vsubps %zmm16,%zmm18,%zmm18
   2abcd:	vsubps %zmm10,%zmm1,%zmm1
   2abd3:	vaddps 0x2c0(%rsp),%zmm7,%zmm15
   2abdb:	vsubps 0x2c0(%rsp),%zmm7,%zmm8
   2abe3:	vmovaps 0x300(%rsp),%zmm7
   2abeb:	vaddps 0x340(%rsp),%zmm7,%zmm14
   2abf3:	vsubps 0x3c0(%rsp),%zmm2,%zmm2
   2abfb:	vaddps %zmm18,%zmm13,%zmm10
   2ac01:	vaddps %zmm15,%zmm17,%zmm20
   2ac07:	vaddps %zmm8,%zmm9,%zmm19
   2ac0d:	vaddps %zmm12,%zmm14,%zmm16
   2ac13:	vsubps %zmm8,%zmm9,%zmm9
   2ac19:	vsubps %zmm12,%zmm14,%zmm14
   2ac1f:	vsubps %zmm15,%zmm17,%zmm17
   2ac25:	vaddps %zmm11,%zmm23,%zmm12
   2ac2b:	vsubps %zmm11,%zmm23,%zmm8
   2ac31:	vaddps %zmm21,%zmm22,%zmm11
   2ac37:	vsubps %zmm18,%zmm13,%zmm13
   2ac3d:	vsubps 0x340(%rsp),%zmm7,%zmm7
   2ac45:	vaddps %zmm1,%zmm0,%zmm18
   2ac4b:	vsubps %zmm1,%zmm0,%zmm0
   2ac51:	vsubps %zmm14,%zmm17,%zmm1
   2ac57:	vaddps %zmm2,%zmm7,%zmm15
   2ac5d:	vsubps %zmm2,%zmm7,%zmm7
   2ac63:	vsubps %zmm21,%zmm22,%zmm2
   2ac69:	vaddps %zmm16,%zmm20,%zmm21
   2ac6f:	vsubps %zmm16,%zmm20,%zmm16
   2ac75:	vaddps %zmm15,%zmm19,%zmm20
   2ac7b:	vsubps %zmm15,%zmm19,%zmm15
   2ac81:	vaddps %zmm14,%zmm17,%zmm19
   2ac87:	vaddps %zmm7,%zmm9,%zmm14
   2ac8d:	vsubps %zmm7,%zmm9,%zmm7
   2ac93:	vaddps %zmm21,%zmm12,%zmm9
   2ac99:	vsubps %zmm21,%zmm12,%zmm12
   2ac9f:	vmovups %zmm9,-0x400(%rdx)
   2aca6:	vaddps %zmm20,%zmm11,%zmm9
   2acac:	vsubps %zmm20,%zmm11,%zmm11
   2acb2:	vmovups %zmm9,-0x3c0(%rdx)
   2acb9:	vaddps %zmm19,%zmm10,%zmm9
   2acbf:	vsubps %zmm19,%zmm10,%zmm10
   2acc5:	vmovups %zmm9,-0x380(%rdx)
   2accc:	vaddps %zmm14,%zmm18,%zmm9
   2acd2:	vmovups %zmm9,-0x340(%rdx)
   2acd9:	vaddps %zmm16,%zmm8,%zmm9
   2acdf:	vsubps %zmm16,%zmm8,%zmm8
   2ace5:	vmovups %zmm9,-0x300(%rdx)
   2acec:	vaddps %zmm15,%zmm2,%zmm9
   2acf2:	vsubps %zmm15,%zmm2,%zmm2
   2acf8:	vmovups %zmm9,-0x2c0(%rdx)
   2acff:	vaddps %zmm1,%zmm13,%zmm9
   2ad05:	vsubps %zmm1,%zmm13,%zmm1
   2ad0b:	vmovups %zmm9,-0x280(%rdx)
   2ad12:	vaddps %zmm7,%zmm0,%zmm9
   2ad18:	vsubps %zmm7,%zmm0,%zmm0
   2ad1e:	vmovups %zmm9,-0x240(%rdx)
   2ad25:	vsubps %zmm14,%zmm18,%zmm9
   2ad2b:	vmovups %zmm12,-0x200(%rdx)
   2ad32:	vmovups %zmm11,-0x1c0(%rdx)
   2ad39:	vmovups %zmm10,-0x180(%rdx)
   2ad40:	vmovups %zmm9,-0x140(%rdx)
   2ad47:	vmovups %zmm8,-0x100(%rdx)
   2ad4e:	vmovups %zmm2,-0xc0(%rdx)
   2ad55:	vmovups %zmm1,-0x80(%rdx)
   2ad5c:	vmovups %zmm0,-0x40(%rdx)
   2ad63:	cmp    %rsi,%rdi
   2ad66:	jb     2aaa0 <hfirst_tb16_nat+0x90>
   2ad6c:	mov    0x438(%rsp),%rax
   2ad74:	sub    %fs:0x28,%rax
   2ad7d:	jne    2ad84 <hfirst_tb16_nat+0x374>
   2ad7f:	vzeroupper
   2ad82:	leave
   2ad83:	ret
   2ad84:	vzeroupper
   2ad87:	call   21e0 <__stack_chk_fail@plt>
   2ad8c:	nopl   0x0(%rax)

