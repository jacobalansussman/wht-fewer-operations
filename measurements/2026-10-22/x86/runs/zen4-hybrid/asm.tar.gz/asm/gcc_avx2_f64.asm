0000000000005500 <hstep_tb2_nat>:
    5500:	endbr64
    5504:	vbroadcastsd 0x49603(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
    550d:	mov    %rdi,%r8
    5510:	test   %rsi,%rsi
    5513:	je     556b <hstep_tb2_nat+0x6b>
    5515:	lea    (%rdx,%rdx,1),%r11
    5519:	test   %rdx,%rdx
    551c:	je     556b <hstep_tb2_nat+0x6b>
    551e:	lea    -0x1(%rdx),%r9
    5522:	xor    %edi,%edi
    5524:	lea    0x20(%r8),%r10
    5528:	and    $0xfffffffffffffffc,%r9
    552c:	nopl   0x0(%rax)
    5530:	lea    (%r9,%rdi,1),%rcx
    5534:	lea    (%r8,%rdi,8),%rax
    5538:	lea    (%r10,%rcx,8),%rcx
    553c:	nopl   0x0(%rax)
    5540:	vmovupd (%rax),%ymm0
    5544:	vmovupd (%rax,%rdx,8),%ymm1
    5549:	vaddpd %ymm1,%ymm0,%ymm2
    554d:	vsubpd %ymm1,%ymm0,%ymm0
    5551:	vmovupd %ymm2,(%rax)
    5555:	vmovupd %ymm0,(%rax,%rdx,8)
    555a:	add    $0x20,%rax
    555e:	cmp    %rax,%rcx
    5561:	jne    5540 <hstep_tb2_nat+0x40>
    5563:	add    %r11,%rdi
    5566:	cmp    %rsi,%rdi
    5569:	jb     5530 <hstep_tb2_nat+0x30>
    556b:	vzeroupper
    556e:	ret
    556f:	nop

0000000000005570 <hstep_tb4_nat>:
    5570:	endbr64
    5574:	vbroadcastsd 0x49593(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
    557d:	test   %rsi,%rsi
    5580:	je     5633 <hstep_tb4_nat+0xc3>
    5586:	push   %rbp
    5587:	mov    %rsp,%rbp
    558a:	push   %r12
    558c:	lea    0x0(,%rdx,4),%r12
    5594:	push   %rbx
    5595:	test   %rdx,%rdx
    5598:	je     562b <hstep_tb4_nat+0xbb>
    559e:	mov    %rsi,%r9
    55a1:	lea    -0x1(%rdx),%r11
    55a5:	mov    %rdx,%rsi
    55a8:	mov    %rdi,%r10
    55ab:	lea    (%rdx,%rdx,2),%rcx
    55af:	and    $0xfffffffffffffffc,%r11
    55b3:	shl    $0x4,%rsi
    55b7:	xor    %r8d,%r8d
    55ba:	shl    $0x3,%rcx
    55be:	lea    0x20(%rdi),%rbx
    55c2:	nopw   0x0(%rax,%rax,1)
    55c8:	lea    (%r11,%r8,1),%rdi
    55cc:	lea    (%r10,%r8,8),%rax
    55d0:	lea    (%rbx,%rdi,8),%rdi
    55d4:	nopl   0x0(%rax)
    55d8:	vmovupd (%rax),%ymm5
    55dc:	vmovupd (%rax,%rsi,1),%ymm7
    55e1:	vaddpd (%rax,%rdx,8),%ymm5,%ymm2
    55e6:	vaddpd (%rax,%rcx,1),%ymm7,%ymm3
    55eb:	vsubpd (%rax,%rdx,8),%ymm5,%ymm0
    55f0:	vsubpd (%rax,%rcx,1),%ymm7,%ymm1
    55f5:	vaddpd %ymm3,%ymm2,%ymm4
    55f9:	vsubpd %ymm3,%ymm2,%ymm2
    55fd:	vmovupd %ymm4,(%rax)
    5601:	vaddpd %ymm1,%ymm0,%ymm4
    5605:	vsubpd %ymm1,%ymm0,%ymm0
    5609:	vmovupd %ymm4,(%rax,%rdx,8)
    560e:	add    $0x20,%rax
    5612:	vmovupd %ymm2,-0x20(%rax,%rsi,1)
    5618:	vmovupd %ymm0,-0x20(%rax,%rcx,1)
    561e:	cmp    %rax,%rdi
    5621:	jne    55d8 <hstep_tb4_nat+0x68>
    5623:	add    %r12,%r8
    5626:	cmp    %r9,%r8
    5629:	jb     55c8 <hstep_tb4_nat+0x58>
    562b:	vzeroupper
    562e:	pop    %rbx
    562f:	pop    %r12
    5631:	pop    %rbp
    5632:	ret
    5633:	vzeroupper
    5636:	ret
    5637:	nopw   0x0(%rax,%rax,1)

00000000000065c0 <hfirst_kid_nat>:
    65c0:	endbr64
    65c4:	vbroadcastsd 0x48543(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
    65cd:	test   %rsi,%rsi
    65d0:	je     6626 <hfirst_kid_nat+0x66>
    65d2:	lea    -0x8(,%rsi,8),%rax
    65da:	vxorpd %xmm2,%xmm2,%xmm2
    65de:	and    $0xffffffffffffffe0,%rax
    65e2:	lea    0x20(%rdi,%rax,1),%rax
    65e7:	nopw   0x0(%rax,%rax,1)
    65f0:	vpermilpd $0xf,(%rdi),%ymm1
    65f6:	vpermilpd $0x0,(%rdi),%ymm0
    65fc:	add    $0x20,%rdi
    6600:	vsubpd %ymm1,%ymm2,%ymm1
    6604:	vaddsubpd %ymm1,%ymm0,%ymm0
    6608:	vsubpd %ymm0,%ymm2,%ymm3
    660c:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm1
    6612:	vperm2f128 $0x31,%ymm3,%ymm0,%ymm0
    6618:	vaddpd %ymm0,%ymm1,%ymm0
    661c:	vmovupd %ymm0,-0x20(%rdi)
    6621:	cmp    %rdi,%rax
    6624:	jne    65f0 <hfirst_kid_nat+0x30>
    6626:	vzeroupper
    6629:	ret
    662a:	nopw   0x0(%rax,%rax,1)

0000000000006630 <hfirst_tb2_nat>:
    6630:	endbr64
    6634:	vbroadcastsd 0x484d3(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
    663d:	test   %rsi,%rsi
    6640:	je     66cd <hfirst_tb2_nat+0x9d>
    6646:	lea    -0x8(,%rsi,8),%rax
    664e:	vxorpd %xmm3,%xmm3,%xmm3
    6652:	and    $0xffffffffffffffc0,%rax
    6656:	lea    0x40(%rdi,%rax,1),%rax
    665b:	nopl   0x0(%rax,%rax,1)
    6660:	vpermilpd $0xf,(%rdi),%ymm1
    6666:	vpermilpd $0x0,(%rdi),%ymm0
    666c:	add    $0x40,%rdi
    6670:	vsubpd %ymm1,%ymm3,%ymm1
    6674:	vaddsubpd %ymm1,%ymm0,%ymm0
    6678:	vsubpd %ymm0,%ymm3,%ymm1
    667c:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm2
    6682:	vperm2f128 $0x31,%ymm1,%ymm0,%ymm0
    6688:	vpermilpd $0xf,-0x20(%rdi),%ymm1
    668f:	vaddpd %ymm0,%ymm2,%ymm2
    6693:	vpermilpd $0x0,-0x20(%rdi),%ymm0
    669a:	vsubpd %ymm1,%ymm3,%ymm1
    669e:	vaddsubpd %ymm1,%ymm0,%ymm0
    66a2:	vsubpd %ymm0,%ymm3,%ymm4
    66a6:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm1
    66ac:	vperm2f128 $0x31,%ymm4,%ymm0,%ymm0
    66b2:	vaddpd %ymm0,%ymm1,%ymm0
    66b6:	vaddpd %ymm0,%ymm2,%ymm1
    66ba:	vsubpd %ymm0,%ymm2,%ymm2
    66be:	vmovupd %ymm1,-0x40(%rdi)
    66c3:	vmovupd %ymm2,-0x20(%rdi)
    66c8:	cmp    %rdi,%rax
    66cb:	jne    6660 <hfirst_tb2_nat+0x30>
    66cd:	vzeroupper
    66d0:	ret
    66d1:	data16 cs nopw 0x0(%rax,%rax,1)
    66dc:	nopl   0x0(%rax)

00000000000066e0 <hfirst_tb4_nat>:
    66e0:	endbr64
    66e4:	vbroadcastsd 0x48423(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
    66ed:	test   %rsi,%rsi
    66f0:	je     67f7 <hfirst_tb4_nat+0x117>
    66f6:	lea    -0x8(,%rsi,8),%rax
    66fe:	vxorpd %xmm2,%xmm2,%xmm2
    6702:	and    $0xffffffffffffff80,%rax
    6706:	lea    0x80(%rdi,%rax,1),%rax
    670e:	xchg   %ax,%ax
    6710:	vpermilpd $0xf,(%rdi),%ymm1
    6716:	vpermilpd $0x0,(%rdi),%ymm0
    671c:	sub    $0xffffffffffffff80,%rdi
    6720:	vsubpd %ymm1,%ymm2,%ymm1
    6724:	vaddsubpd %ymm1,%ymm0,%ymm0
    6728:	vsubpd %ymm0,%ymm2,%ymm3
    672c:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm1
    6732:	vperm2f128 $0x31,%ymm3,%ymm0,%ymm0
    6738:	vpermilpd $0xf,-0x60(%rdi),%ymm3
    673f:	vaddpd %ymm0,%ymm1,%ymm1
    6743:	vpermilpd $0x0,-0x60(%rdi),%ymm0
    674a:	vsubpd %ymm3,%ymm2,%ymm3
    674e:	vaddsubpd %ymm3,%ymm0,%ymm0
    6752:	vsubpd %ymm0,%ymm2,%ymm3
    6756:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm5
    675c:	vperm2f128 $0x31,%ymm3,%ymm0,%ymm0
    6762:	vpermilpd $0xf,-0x40(%rdi),%ymm3
    6769:	vaddpd %ymm0,%ymm5,%ymm5
    676d:	vpermilpd $0x0,-0x40(%rdi),%ymm0
    6774:	vsubpd %ymm3,%ymm2,%ymm3
    6778:	vaddsubpd %ymm3,%ymm0,%ymm0
    677c:	vsubpd %ymm0,%ymm2,%ymm4
    6780:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm3
    6786:	vperm2f128 $0x31,%ymm4,%ymm0,%ymm0
    678c:	vpermilpd $0xf,-0x20(%rdi),%ymm4
    6793:	vaddpd %ymm0,%ymm3,%ymm3
    6797:	vpermilpd $0x0,-0x20(%rdi),%ymm0
    679e:	vsubpd %ymm4,%ymm2,%ymm4
    67a2:	vaddsubpd %ymm4,%ymm0,%ymm0
    67a6:	vsubpd %ymm0,%ymm2,%ymm4
    67aa:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm6
    67b0:	vperm2f128 $0x31,%ymm4,%ymm0,%ymm0
    67b6:	vaddpd %ymm5,%ymm1,%ymm4
    67ba:	vaddpd %ymm0,%ymm6,%ymm6
    67be:	vsubpd %ymm5,%ymm1,%ymm0
    67c2:	vaddpd %ymm6,%ymm3,%ymm5
    67c6:	vsubpd %ymm6,%ymm3,%ymm1
    67ca:	vaddpd %ymm5,%ymm4,%ymm3
    67ce:	vsubpd %ymm5,%ymm4,%ymm4
    67d2:	vmovupd %ymm3,-0x80(%rdi)
    67d7:	vaddpd %ymm1,%ymm0,%ymm3
    67db:	vsubpd %ymm1,%ymm0,%ymm0
    67df:	vmovupd %ymm4,-0x40(%rdi)
    67e4:	vmovupd %ymm3,-0x60(%rdi)
    67e9:	vmovupd %ymm0,-0x20(%rdi)
    67ee:	cmp    %rdi,%rax
    67f1:	jne    6710 <hfirst_tb4_nat+0x30>
    67f7:	vzeroupper
    67fa:	ret
    67fb:	nopl   0x0(%rax,%rax,1)

0000000000007b60 <hfirst_h20_nat>:
    7b60:	endbr64
    7b64:	vbroadcastsd 0x46fa3(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
    7b6d:	test   %rsi,%rsi
    7b70:	je     7d9d <hfirst_h20_nat+0x23d>
    7b76:	lea    -0x8(,%rsi,8),%rax
    7b7e:	vxorpd %xmm0,%xmm0,%xmm0
    7b82:	vbroadcastsd 0x46ed5(%rip),%ymm9        # 4ea60 <FFHT_THR_D+0x80>
    7b8b:	xor    %al,%al
    7b8d:	lea    0x100(%rdi,%rax,1),%rax
    7b95:	nopl   (%rax)
    7b98:	vpermilpd $0xf,(%rdi),%ymm1
    7b9e:	vpermilpd $0x0,(%rdi),%ymm2
    7ba4:	add    $0x100,%rdi
    7bab:	vpermilpd $0xf,-0xe0(%rdi),%ymm3
    7bb5:	vpermilpd $0xf,-0xa0(%rdi),%ymm6
    7bbf:	vsubpd %ymm1,%ymm0,%ymm1
    7bc3:	vsubpd %ymm3,%ymm0,%ymm3
    7bc7:	vsubpd %ymm6,%ymm0,%ymm6
    7bcb:	vaddsubpd %ymm1,%ymm2,%ymm2
    7bcf:	vsubpd %ymm2,%ymm0,%ymm1
    7bd3:	vperm2f128 $0x0,%ymm2,%ymm2,%ymm5
    7bd9:	vperm2f128 $0x31,%ymm1,%ymm2,%ymm2
    7bdf:	vpermilpd $0x0,-0xe0(%rdi),%ymm1
    7be9:	vaddpd %ymm2,%ymm5,%ymm5
    7bed:	vaddsubpd %ymm3,%ymm1,%ymm1
    7bf1:	vsubpd %ymm1,%ymm0,%ymm3
    7bf5:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm7
    7bfb:	vperm2f128 $0x31,%ymm3,%ymm1,%ymm1
    7c01:	vpermilpd $0xf,-0xc0(%rdi),%ymm3
    7c0b:	vaddpd %ymm1,%ymm7,%ymm7
    7c0f:	vpermilpd $0x0,-0xc0(%rdi),%ymm1
    7c19:	vsubpd %ymm3,%ymm0,%ymm3
    7c1d:	vaddsubpd %ymm3,%ymm1,%ymm1
    7c21:	vsubpd %ymm1,%ymm0,%ymm3
    7c25:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm4
    7c2b:	vperm2f128 $0x31,%ymm3,%ymm1,%ymm1
    7c31:	vpermilpd $0x0,-0xa0(%rdi),%ymm3
    7c3b:	vaddpd %ymm1,%ymm4,%ymm4
    7c3f:	vaddsubpd %ymm6,%ymm3,%ymm3
    7c43:	vsubpd %ymm3,%ymm0,%ymm6
    7c47:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm8
    7c4d:	vperm2f128 $0x31,%ymm6,%ymm3,%ymm3
    7c53:	vpermilpd $0xf,-0x80(%rdi),%ymm6
    7c5a:	vaddpd %ymm3,%ymm8,%ymm8
    7c5e:	vpermilpd $0x0,-0x80(%rdi),%ymm3
    7c65:	vsubpd %ymm6,%ymm0,%ymm6
    7c69:	vaddsubpd %ymm6,%ymm3,%ymm3
    7c6d:	vsubpd %ymm3,%ymm0,%ymm10
    7c71:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm6
    7c77:	vperm2f128 $0x31,%ymm10,%ymm3,%ymm3
    7c7d:	vpermilpd $0xf,-0x60(%rdi),%ymm10
    7c84:	vaddpd %ymm3,%ymm6,%ymm6
    7c88:	vpermilpd $0x0,-0x60(%rdi),%ymm3
    7c8f:	vsubpd %ymm10,%ymm0,%ymm10
    7c94:	vaddsubpd %ymm10,%ymm3,%ymm3
    7c99:	vsubpd %ymm3,%ymm0,%ymm11
    7c9d:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm10
    7ca3:	vperm2f128 $0x31,%ymm11,%ymm3,%ymm3
    7ca9:	vpermilpd $0xf,-0x40(%rdi),%ymm11
    7cb0:	vaddpd %ymm3,%ymm10,%ymm10
    7cb4:	vpermilpd $0x0,-0x40(%rdi),%ymm3
    7cbb:	vsubpd %ymm11,%ymm0,%ymm11
    7cc0:	vsubpd %ymm10,%ymm4,%ymm4
    7cc5:	vaddsubpd %ymm11,%ymm3,%ymm3
    7cca:	vsubpd %ymm3,%ymm0,%ymm12
    7cce:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm11
    7cd4:	vperm2f128 $0x31,%ymm12,%ymm3,%ymm3
    7cda:	vpermilpd $0xf,-0x20(%rdi),%ymm12
    7ce1:	vaddpd %ymm3,%ymm11,%ymm11
    7ce5:	vpermilpd $0x0,-0x20(%rdi),%ymm3
    7cec:	vsubpd %ymm12,%ymm0,%ymm12
    7cf1:	vaddsubpd %ymm12,%ymm3,%ymm3
    7cf6:	vsubpd %ymm3,%ymm0,%ymm13
    7cfa:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm12
    7d00:	vperm2f128 $0x31,%ymm13,%ymm3,%ymm3
    7d06:	vaddpd %ymm11,%ymm7,%ymm13
    7d0b:	vaddpd %ymm3,%ymm12,%ymm3
    7d0f:	vsubpd %ymm6,%ymm8,%ymm12
    7d13:	vaddpd %ymm3,%ymm5,%ymm5
    7d17:	vaddpd %ymm12,%ymm4,%ymm15
    7d1c:	vmovapd %ymm3,%ymm2
    7d20:	vsubpd %ymm13,%ymm5,%ymm14
    7d25:	vsubpd %ymm15,%ymm14,%ymm1
    7d2a:	vfmsub231pd %ymm9,%ymm1,%ymm2
    7d2f:	vfmsub132pd %ymm9,%ymm10,%ymm1
    7d34:	vaddpd %ymm11,%ymm2,%ymm11
    7d39:	vsubpd %ymm6,%ymm1,%ymm6
    7d3d:	vaddpd %ymm7,%ymm2,%ymm2
    7d41:	vaddpd %ymm8,%ymm1,%ymm1
    7d46:	vsubpd %ymm6,%ymm5,%ymm5
    7d4a:	vaddpd %ymm11,%ymm4,%ymm4
    7d4f:	vaddpd %ymm2,%ymm15,%ymm15
    7d53:	vsubpd %ymm1,%ymm14,%ymm14
    7d57:	vmovupd %ymm2,-0xc0(%rdi)
    7d5f:	vaddpd %ymm6,%ymm13,%ymm13
    7d63:	vaddpd %ymm11,%ymm12,%ymm12
    7d68:	vmovupd %ymm1,-0xa0(%rdi)
    7d70:	vmovupd %ymm5,-0x100(%rdi)
    7d78:	vmovupd %ymm4,-0xe0(%rdi)
    7d80:	vmovupd %ymm15,-0x80(%rdi)
    7d85:	vmovupd %ymm14,-0x60(%rdi)
    7d8a:	vmovupd %ymm13,-0x40(%rdi)
    7d8f:	vmovupd %ymm12,-0x20(%rdi)
    7d94:	cmp    %rdi,%rax
    7d97:	jne    7b98 <hfirst_h20_nat+0x38>
    7d9d:	vzeroupper
    7da0:	ret
    7da1:	data16 cs nopw 0x0(%rax,%rax,1)
    7dac:	nopl   0x0(%rax)

0000000000007fb0 <hfirst_g19_nat>:
    7fb0:	endbr64
    7fb4:	vbroadcastsd 0x46b53(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
    7fbd:	test   %rsi,%rsi
    7fc0:	je     81f3 <hfirst_g19_nat+0x243>
    7fc6:	lea    -0x8(,%rsi,8),%rax
    7fce:	vxorpd %xmm0,%xmm0,%xmm0
    7fd2:	vbroadcastsd 0x46aa5(%rip),%ymm1        # 4ea80 <FFHT_THR_D+0xa0>
    7fdb:	xor    %al,%al
    7fdd:	lea    0x100(%rdi,%rax,1),%rax
    7fe5:	nopl   (%rax)
    7fe8:	vpermilpd $0xf,(%rdi),%ymm2
    7fee:	vpermilpd $0x0,(%rdi),%ymm3
    7ff4:	add    $0x100,%rdi
    7ffb:	vpermilpd $0xf,-0xe0(%rdi),%ymm4
    8005:	vpermilpd $0xf,-0xa0(%rdi),%ymm8
    800f:	vsubpd %ymm2,%ymm0,%ymm2
    8013:	vsubpd %ymm4,%ymm0,%ymm4
    8017:	vsubpd %ymm8,%ymm0,%ymm8
    801c:	vaddsubpd %ymm2,%ymm3,%ymm3
    8020:	vsubpd %ymm3,%ymm0,%ymm2
    8024:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm6
    802a:	vperm2f128 $0x31,%ymm2,%ymm3,%ymm3
    8030:	vpermilpd $0x0,-0xe0(%rdi),%ymm2
    803a:	vaddpd %ymm3,%ymm6,%ymm6
    803e:	vaddsubpd %ymm4,%ymm2,%ymm2
    8042:	vsubpd %ymm2,%ymm0,%ymm4
    8046:	vperm2f128 $0x0,%ymm2,%ymm2,%ymm7
    804c:	vperm2f128 $0x31,%ymm4,%ymm2,%ymm2
    8052:	vpermilpd $0xf,-0xc0(%rdi),%ymm4
    805c:	vaddpd %ymm2,%ymm7,%ymm7
    8060:	vpermilpd $0x0,-0xc0(%rdi),%ymm2
    806a:	vsubpd %ymm4,%ymm0,%ymm4
    806e:	vaddsubpd %ymm4,%ymm2,%ymm2
    8072:	vsubpd %ymm2,%ymm0,%ymm4
    8076:	vperm2f128 $0x0,%ymm2,%ymm2,%ymm5
    807c:	vperm2f128 $0x31,%ymm4,%ymm2,%ymm2
    8082:	vpermilpd $0x0,-0xa0(%rdi),%ymm4
    808c:	vaddpd %ymm2,%ymm5,%ymm5
    8090:	vaddsubpd %ymm8,%ymm4,%ymm4
    8095:	vsubpd %ymm4,%ymm0,%ymm8
    8099:	vperm2f128 $0x0,%ymm4,%ymm4,%ymm9
    809f:	vperm2f128 $0x31,%ymm8,%ymm4,%ymm4
    80a5:	vpermilpd $0xf,-0x80(%rdi),%ymm8
    80ac:	vaddpd %ymm4,%ymm9,%ymm9
    80b0:	vpermilpd $0x0,-0x80(%rdi),%ymm4
    80b7:	vsubpd %ymm8,%ymm0,%ymm8
    80bc:	vaddsubpd %ymm8,%ymm4,%ymm4
    80c1:	vsubpd %ymm4,%ymm0,%ymm10
    80c5:	vperm2f128 $0x0,%ymm4,%ymm4,%ymm8
    80cb:	vperm2f128 $0x31,%ymm10,%ymm4,%ymm4
    80d1:	vpermilpd $0xf,-0x60(%rdi),%ymm10
    80d8:	vaddpd %ymm4,%ymm8,%ymm8
    80dc:	vpermilpd $0x0,-0x60(%rdi),%ymm4
    80e3:	vsubpd %ymm10,%ymm0,%ymm10
    80e8:	vsubpd %ymm8,%ymm9,%ymm3
    80ed:	vaddsubpd %ymm10,%ymm4,%ymm4
    80f2:	vsubpd %ymm4,%ymm0,%ymm11
    80f6:	vperm2f128 $0x0,%ymm4,%ymm4,%ymm10
    80fc:	vperm2f128 $0x31,%ymm11,%ymm4,%ymm4
    8102:	vpermilpd $0xf,-0x40(%rdi),%ymm11
    8109:	vaddpd %ymm4,%ymm10,%ymm10
    810d:	vpermilpd $0x0,-0x40(%rdi),%ymm4
    8114:	vsubpd %ymm11,%ymm0,%ymm11
    8119:	vsubpd %ymm10,%ymm5,%ymm5
    811e:	vaddsubpd %ymm11,%ymm4,%ymm4
    8123:	vsubpd %ymm4,%ymm0,%ymm12
    8127:	vperm2f128 $0x0,%ymm4,%ymm4,%ymm11
    812d:	vperm2f128 $0x31,%ymm12,%ymm4,%ymm4
    8133:	vpermilpd $0xf,-0x20(%rdi),%ymm12
    813a:	vaddpd %ymm4,%ymm11,%ymm11
    813e:	vpermilpd $0x0,-0x20(%rdi),%ymm4
    8145:	vsubpd %ymm12,%ymm0,%ymm12
    814a:	vaddsubpd %ymm12,%ymm4,%ymm4
    814f:	vsubpd %ymm4,%ymm0,%ymm13
    8153:	vperm2f128 $0x0,%ymm4,%ymm4,%ymm12
    8159:	vperm2f128 $0x31,%ymm13,%ymm4,%ymm4
    815f:	vaddpd %ymm3,%ymm5,%ymm13
    8163:	vaddpd %ymm4,%ymm12,%ymm4
    8167:	vaddpd %ymm11,%ymm7,%ymm12
    816c:	vaddpd %ymm4,%ymm6,%ymm6
    8170:	vsubpd %ymm12,%ymm6,%ymm14
    8175:	vsubpd %ymm13,%ymm14,%ymm2
    817a:	vfnmadd132pd %ymm1,%ymm2,%ymm4
    817f:	vfnmadd231pd %ymm1,%ymm10,%ymm2
    8184:	vfmadd132pd %ymm1,%ymm4,%ymm11
    8189:	vfnmadd132pd %ymm1,%ymm2,%ymm8
    818e:	vfmadd132pd %ymm1,%ymm4,%ymm7
    8193:	vfmadd231pd %ymm1,%ymm9,%ymm2
    8198:	vfmadd132pd %ymm1,%ymm11,%ymm3
    819d:	vfmadd132pd %ymm1,%ymm11,%ymm5
    81a2:	vfmsub132pd %ymm1,%ymm2,%ymm14
    81a7:	vfmadd132pd %ymm1,%ymm8,%ymm12
    81ac:	vmovupd %ymm7,-0xc0(%rdi)
    81b4:	vfmadd132pd %ymm1,%ymm7,%ymm13
    81b9:	vfmsub132pd %ymm1,%ymm8,%ymm6
    81be:	vmovupd %ymm2,-0xa0(%rdi)
    81c6:	vmovupd %ymm5,-0xe0(%rdi)
    81ce:	vmovupd %ymm14,-0x60(%rdi)
    81d3:	vmovupd %ymm6,-0x100(%rdi)
    81db:	vmovupd %ymm13,-0x80(%rdi)
    81e0:	vmovupd %ymm12,-0x40(%rdi)
    81e5:	vmovupd %ymm3,-0x20(%rdi)
    81ea:	cmp    %rdi,%rax
    81ed:	jne    7fe8 <hfirst_g19_nat+0x38>
    81f3:	vzeroupper
    81f6:	ret
    81f7:	nopw   0x0(%rax,%rax,1)

0000000000008200 <hfirst_tb8_nat>:
    8200:	endbr64
    8204:	vbroadcastsd 0x46903(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
    820d:	test   %rsi,%rsi
    8210:	je     843c <hfirst_tb8_nat+0x23c>
    8216:	lea    -0x8(,%rsi,8),%rax
    821e:	vxorpd %xmm0,%xmm0,%xmm0
    8222:	xor    %al,%al
    8224:	lea    0x100(%rdi,%rax,1),%rax
    822c:	nopl   0x0(%rax)
    8230:	vpermilpd $0xf,(%rdi),%ymm2
    8236:	vpermilpd $0x0,(%rdi),%ymm1
    823c:	add    $0x100,%rdi
    8243:	vsubpd %ymm2,%ymm0,%ymm2
    8247:	vaddsubpd %ymm2,%ymm1,%ymm1
    824b:	vsubpd %ymm1,%ymm0,%ymm2
    824f:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm6
    8255:	vperm2f128 $0x31,%ymm2,%ymm1,%ymm1
    825b:	vpermilpd $0xf,-0xe0(%rdi),%ymm2
    8265:	vaddpd %ymm1,%ymm6,%ymm6
    8269:	vpermilpd $0x0,-0xe0(%rdi),%ymm1
    8273:	vsubpd %ymm2,%ymm0,%ymm2
    8277:	vaddsubpd %ymm2,%ymm1,%ymm1
    827b:	vsubpd %ymm1,%ymm0,%ymm2
    827f:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm4
    8285:	vperm2f128 $0x31,%ymm2,%ymm1,%ymm1
    828b:	vpermilpd $0x0,-0xc0(%rdi),%ymm2
    8295:	vaddpd %ymm1,%ymm4,%ymm4
    8299:	vpermilpd $0xf,-0xc0(%rdi),%ymm1
    82a3:	vsubpd %ymm1,%ymm0,%ymm1
    82a7:	vaddpd %ymm4,%ymm6,%ymm11
    82ab:	vaddsubpd %ymm1,%ymm2,%ymm2
    82af:	vsubpd %ymm2,%ymm0,%ymm3
    82b3:	vperm2f128 $0x0,%ymm2,%ymm2,%ymm1
    82b9:	vperm2f128 $0x31,%ymm3,%ymm2,%ymm2
    82bf:	vpermilpd $0xf,-0xa0(%rdi),%ymm3
    82c9:	vaddpd %ymm2,%ymm1,%ymm1
    82cd:	vpermilpd $0x0,-0xa0(%rdi),%ymm2
    82d7:	vsubpd %ymm3,%ymm0,%ymm3
    82db:	vaddsubpd %ymm3,%ymm2,%ymm2
    82df:	vsubpd %ymm2,%ymm0,%ymm3
    82e3:	vperm2f128 $0x0,%ymm2,%ymm2,%ymm5
    82e9:	vperm2f128 $0x31,%ymm3,%ymm2,%ymm2
    82ef:	vpermilpd $0xf,-0x80(%rdi),%ymm3
    82f6:	vaddpd %ymm2,%ymm5,%ymm5
    82fa:	vpermilpd $0x0,-0x80(%rdi),%ymm2
    8301:	vsubpd %ymm3,%ymm0,%ymm3
    8305:	vaddsubpd %ymm3,%ymm2,%ymm2
    8309:	vsubpd %ymm2,%ymm0,%ymm3
    830d:	vperm2f128 $0x0,%ymm2,%ymm2,%ymm7
    8313:	vperm2f128 $0x31,%ymm3,%ymm2,%ymm2
    8319:	vpermilpd $0x0,-0x60(%rdi),%ymm3
    8320:	vaddpd %ymm2,%ymm7,%ymm7
    8324:	vpermilpd $0xf,-0x60(%rdi),%ymm2
    832b:	vsubpd %ymm2,%ymm0,%ymm2
    832f:	vaddsubpd %ymm2,%ymm3,%ymm3
    8333:	vsubpd %ymm3,%ymm0,%ymm8
    8337:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm2
    833d:	vperm2f128 $0x31,%ymm8,%ymm3,%ymm3
    8343:	vpermilpd $0xf,-0x40(%rdi),%ymm8
    834a:	vaddpd %ymm3,%ymm2,%ymm2
    834e:	vpermilpd $0x0,-0x40(%rdi),%ymm3
    8355:	vsubpd %ymm8,%ymm0,%ymm8
    835a:	vaddpd %ymm2,%ymm7,%ymm12
    835e:	vsubpd %ymm2,%ymm7,%ymm2
    8362:	vaddsubpd %ymm8,%ymm3,%ymm3
    8367:	vsubpd %ymm3,%ymm0,%ymm8
    836b:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm9
    8371:	vperm2f128 $0x31,%ymm8,%ymm3,%ymm3
    8377:	vpermilpd $0xf,-0x20(%rdi),%ymm8
    837e:	vaddpd %ymm3,%ymm9,%ymm9
    8382:	vpermilpd $0x0,-0x20(%rdi),%ymm3
    8389:	vsubpd %ymm8,%ymm0,%ymm8
    838e:	vaddsubpd %ymm8,%ymm3,%ymm3
    8393:	vsubpd %ymm3,%ymm0,%ymm10
    8397:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm8
    839d:	vperm2f128 $0x31,%ymm10,%ymm3,%ymm3
    83a3:	vsubpd %ymm4,%ymm6,%ymm10
    83a7:	vaddpd %ymm5,%ymm1,%ymm6
    83ab:	vaddpd %ymm3,%ymm8,%ymm8
    83af:	vsubpd %ymm5,%ymm1,%ymm1
    83b3:	vaddpd %ymm8,%ymm9,%ymm3
    83b8:	vsubpd %ymm8,%ymm9,%ymm5
    83bd:	vaddpd %ymm6,%ymm11,%ymm8
    83c1:	vaddpd %ymm1,%ymm10,%ymm4
    83c5:	vsubpd %ymm6,%ymm11,%ymm6
    83c9:	vsubpd %ymm1,%ymm10,%ymm1
    83cd:	vaddpd %ymm3,%ymm12,%ymm9
    83d1:	vaddpd %ymm5,%ymm2,%ymm7
    83d5:	vsubpd %ymm5,%ymm2,%ymm2
    83d9:	vsubpd %ymm3,%ymm12,%ymm3
    83dd:	vaddpd %ymm9,%ymm8,%ymm5
    83e2:	vmovupd %ymm5,-0x100(%rdi)
    83ea:	vaddpd %ymm7,%ymm4,%ymm5
    83ee:	vsubpd %ymm7,%ymm4,%ymm4
    83f2:	vmovupd %ymm5,-0xe0(%rdi)
    83fa:	vaddpd %ymm3,%ymm6,%ymm5
    83fe:	vsubpd %ymm3,%ymm6,%ymm6
    8402:	vmovupd %ymm4,-0x60(%rdi)
    8407:	vmovupd %ymm5,-0xc0(%rdi)
    840f:	vaddpd %ymm2,%ymm1,%ymm5
    8413:	vsubpd %ymm2,%ymm1,%ymm1
    8417:	vmovupd %ymm6,-0x40(%rdi)
    841c:	vmovupd %ymm5,-0xa0(%rdi)
    8424:	vsubpd %ymm9,%ymm8,%ymm5
    8429:	vmovupd %ymm1,-0x20(%rdi)
    842e:	vmovupd %ymm5,-0x80(%rdi)
    8433:	cmp    %rdi,%rax
    8436:	jne    8230 <hfirst_tb8_nat+0x30>
    843c:	vzeroupper
    843f:	ret

0000000000008970 <hfirst_g52_nat>:
    8970:	endbr64
    8974:	vbroadcastsd 0x46193(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
    897d:	test   %rsi,%rsi
    8980:	je     8ed4 <hfirst_g52_nat+0x564>
    8986:	push   %rbp
    8987:	lea    -0x8(,%rsi,8),%rdx
    898f:	mov    %rdi,%rax
    8992:	vxorpd %xmm12,%xmm12,%xmm12
    8997:	and    $0xfffffffffffffe00,%rdx
    899e:	lea    0x200(%rdi,%rdx,1),%rdx
    89a6:	mov    %rsp,%rbp
    89a9:	and    $0xffffffffffffffe0,%rsp
    89ad:	sub    $0xe8,%rsp
    89b4:	vbroadcastsd 0x460c3(%rip),%ymm13        # 4ea80 <FFHT_THR_D+0xa0>
    89bd:	nopl   (%rax)
    89c0:	vpermilpd $0xf,(%rax),%ymm1
    89c6:	vpermilpd $0x0,(%rax),%ymm0
    89cc:	add    $0x200,%rax
    89d2:	vsubpd %ymm1,%ymm12,%ymm1
    89d6:	vaddsubpd %ymm1,%ymm0,%ymm0
    89da:	vsubpd %ymm0,%ymm12,%ymm2
    89de:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm1
    89e4:	vperm2f128 $0x31,%ymm2,%ymm0,%ymm0
    89ea:	vpermilpd $0xf,-0x1e0(%rax),%ymm2
    89f4:	vaddpd %ymm0,%ymm1,%ymm1
    89f8:	vpermilpd $0x0,-0x1e0(%rax),%ymm0
    8a02:	vsubpd %ymm2,%ymm12,%ymm2
    8a06:	vaddsubpd %ymm2,%ymm0,%ymm0
    8a0a:	vsubpd %ymm0,%ymm12,%ymm3
    8a0e:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm2
    8a14:	vperm2f128 $0x31,%ymm3,%ymm0,%ymm4
    8a1a:	vpermilpd $0xf,-0x1c0(%rax),%ymm3
    8a24:	vpermilpd $0x0,-0x1c0(%rax),%ymm0
    8a2e:	vaddpd %ymm4,%ymm2,%ymm2
    8a32:	vsubpd %ymm3,%ymm12,%ymm3
    8a36:	vaddpd %ymm1,%ymm2,%ymm2
    8a3a:	vaddsubpd %ymm3,%ymm0,%ymm0
    8a3e:	vsubpd %ymm0,%ymm12,%ymm3
    8a42:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm5
    8a48:	vperm2f128 $0x31,%ymm3,%ymm0,%ymm0
    8a4e:	vpermilpd $0xf,-0x1a0(%rax),%ymm3
    8a58:	vaddpd %ymm0,%ymm5,%ymm5
    8a5c:	vpermilpd $0x0,-0x1a0(%rax),%ymm0
    8a66:	vsubpd %ymm3,%ymm12,%ymm3
    8a6a:	vaddsubpd %ymm3,%ymm0,%ymm0
    8a6e:	vsubpd %ymm0,%ymm12,%ymm3
    8a72:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm6
    8a78:	vmovapd %ymm6,0xc8(%rsp)
    8a81:	vperm2f128 $0x31,%ymm3,%ymm0,%ymm15
    8a87:	vpermilpd $0xf,-0x180(%rax),%ymm3
    8a91:	vpermilpd $0x0,-0x180(%rax),%ymm0
    8a9b:	vsubpd %ymm3,%ymm12,%ymm3
    8a9f:	vaddsubpd %ymm3,%ymm0,%ymm0
    8aa3:	vsubpd %ymm0,%ymm12,%ymm6
    8aa7:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm3
    8aad:	vperm2f128 $0x31,%ymm6,%ymm0,%ymm0
    8ab3:	vaddpd %ymm0,%ymm3,%ymm10
    8ab7:	vpermilpd $0xf,-0x160(%rax),%ymm3
    8ac1:	vpermilpd $0x0,-0x160(%rax),%ymm0
    8acb:	vsubpd %ymm3,%ymm12,%ymm3
    8acf:	vaddsubpd %ymm3,%ymm0,%ymm0
    8ad3:	vsubpd %ymm0,%ymm12,%ymm3
    8ad7:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm7
    8add:	vmovapd %ymm7,0xa8(%rsp)
    8ae6:	vperm2f128 $0x31,%ymm3,%ymm0,%ymm11
    8aec:	vpermilpd $0xf,-0x140(%rax),%ymm3
    8af6:	vpermilpd $0x0,-0x140(%rax),%ymm0
    8b00:	vsubpd %ymm3,%ymm12,%ymm3
    8b04:	vaddsubpd %ymm3,%ymm0,%ymm0
    8b08:	vsubpd %ymm0,%ymm12,%ymm3
    8b0c:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm7
    8b12:	vperm2f128 $0x31,%ymm3,%ymm0,%ymm0
    8b18:	vpermilpd $0xf,-0x120(%rax),%ymm3
    8b22:	vaddpd %ymm0,%ymm7,%ymm7
    8b26:	vpermilpd $0x0,-0x120(%rax),%ymm0
    8b30:	vsubpd %ymm3,%ymm12,%ymm3
    8b34:	vaddsubpd %ymm3,%ymm0,%ymm0
    8b38:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm3
    8b3e:	vmovapd %ymm3,0x88(%rsp)
    8b47:	vsubpd %ymm0,%ymm12,%ymm3
    8b4b:	vperm2f128 $0x31,%ymm3,%ymm0,%ymm0
    8b51:	vpermilpd $0xf,-0x100(%rax),%ymm3
    8b5b:	vmovapd %ymm0,0x68(%rsp)
    8b61:	vpermilpd $0x0,-0x100(%rax),%ymm0
    8b6b:	vsubpd %ymm3,%ymm12,%ymm3
    8b6f:	vaddsubpd %ymm3,%ymm0,%ymm0
    8b73:	vsubpd %ymm0,%ymm12,%ymm6
    8b77:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm3
    8b7d:	vperm2f128 $0x31,%ymm6,%ymm0,%ymm0
    8b83:	vaddpd %ymm0,%ymm3,%ymm8
    8b87:	vpermilpd $0xf,-0xe0(%rax),%ymm0
    8b91:	vpermilpd $0x0,-0xe0(%rax),%ymm3
    8b9b:	vsubpd %ymm0,%ymm12,%ymm0
    8b9f:	vaddsubpd %ymm0,%ymm3,%ymm0
    8ba3:	vsubpd %ymm0,%ymm12,%ymm3
    8ba7:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm14
    8bad:	vmovapd %ymm14,0x48(%rsp)
    8bb3:	vperm2f128 $0x31,%ymm3,%ymm0,%ymm9
    8bb9:	vpermilpd $0xf,-0xc0(%rax),%ymm3
    8bc3:	vpermilpd $0x0,-0xc0(%rax),%ymm0
    8bcd:	vmovapd %ymm9,0x28(%rsp)
    8bd3:	vsubpd %ymm3,%ymm12,%ymm3
    8bd7:	vaddsubpd %ymm3,%ymm0,%ymm0
    8bdb:	vsubpd %ymm0,%ymm12,%ymm6
    8bdf:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm3
    8be5:	vperm2f128 $0x31,%ymm6,%ymm0,%ymm0
    8beb:	vaddpd %ymm0,%ymm3,%ymm9
    8bef:	vpermilpd $0xf,-0xa0(%rax),%ymm3
    8bf9:	vpermilpd $0x0,-0xa0(%rax),%ymm0
    8c03:	vsubpd %ymm3,%ymm12,%ymm3
    8c07:	vaddsubpd %ymm3,%ymm0,%ymm0
    8c0b:	vsubpd %ymm0,%ymm12,%ymm3
    8c0f:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm6
    8c15:	vmovapd %ymm6,0x8(%rsp)
    8c1b:	vperm2f128 $0x31,%ymm3,%ymm0,%ymm3
    8c21:	vmovapd %ymm3,-0x18(%rsp)
    8c27:	vpermilpd $0x0,-0x80(%rax),%ymm0
    8c2e:	vpermilpd $0xf,-0x80(%rax),%ymm3
    8c35:	vaddpd 0xa8(%rsp),%ymm11,%ymm11
    8c3e:	vsubpd %ymm3,%ymm12,%ymm3
    8c42:	vaddpd %ymm10,%ymm11,%ymm11
    8c47:	vaddsubpd %ymm3,%ymm0,%ymm0
    8c4b:	vsubpd %ymm0,%ymm12,%ymm6
    8c4f:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm3
    8c55:	vperm2f128 $0x31,%ymm6,%ymm0,%ymm0
    8c5b:	vaddpd %ymm0,%ymm3,%ymm14
    8c5f:	vpermilpd $0xf,-0x60(%rax),%ymm3
    8c66:	vpermilpd $0x0,-0x60(%rax),%ymm0
    8c6d:	vsubpd %ymm3,%ymm12,%ymm3
    8c71:	vaddsubpd %ymm3,%ymm0,%ymm0
    8c75:	vsubpd %ymm0,%ymm12,%ymm3
    8c79:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm6
    8c7f:	vmovapd %ymm6,-0x38(%rsp)
    8c85:	vperm2f128 $0x31,%ymm3,%ymm0,%ymm3
    8c8b:	vpermilpd $0x0,-0x40(%rax),%ymm0
    8c92:	vmovapd %ymm3,-0x58(%rsp)
    8c98:	vpermilpd $0xf,-0x40(%rax),%ymm3
    8c9f:	vsubpd %ymm3,%ymm12,%ymm3
    8ca3:	vaddsubpd %ymm3,%ymm0,%ymm0
    8ca7:	vsubpd %ymm0,%ymm12,%ymm3
    8cab:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm6
    8cb1:	vperm2f128 $0x31,%ymm3,%ymm0,%ymm0
    8cb7:	vpermilpd $0xf,-0x20(%rax),%ymm3
    8cbe:	vaddpd %ymm0,%ymm6,%ymm6
    8cc2:	vpermilpd $0x0,-0x20(%rax),%ymm0
    8cc9:	vsubpd %ymm3,%ymm12,%ymm3
    8ccd:	vaddsubpd %ymm3,%ymm0,%ymm0
    8cd1:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm3
    8cd7:	vmovapd %ymm3,-0x78(%rsp)
    8cdd:	vsubpd %ymm0,%ymm12,%ymm3
    8ce1:	vperm2f128 $0x31,%ymm3,%ymm0,%ymm3
    8ce7:	vaddpd -0x78(%rsp),%ymm3,%ymm3
    8ced:	vaddpd 0xc8(%rsp),%ymm15,%ymm0
    8cf6:	vsubpd %ymm0,%ymm5,%ymm0
    8cfa:	vsubpd %ymm3,%ymm6,%ymm3
    8cfe:	vsubpd %ymm0,%ymm2,%ymm4
    8d02:	vfmsub132pd %ymm13,%ymm4,%ymm1
    8d07:	vfmadd132pd %ymm13,%ymm4,%ymm5
    8d0c:	vmovapd %ymm1,%ymm15
    8d10:	vmovapd 0x68(%rsp),%ymm1
    8d16:	vaddpd 0x88(%rsp),%ymm1,%ymm4
    8d1f:	vmovapd %ymm15,0xc8(%rsp)
    8d28:	vsubpd %ymm4,%ymm7,%ymm4
    8d2c:	vaddpd %ymm4,%ymm11,%ymm1
    8d30:	vfnmadd132pd %ymm13,%ymm1,%ymm7
    8d35:	vfmsub132pd %ymm13,%ymm1,%ymm10
    8d3a:	vmovapd %ymm7,0xa8(%rsp)
    8d43:	vsubpd %ymm7,%ymm5,%ymm1
    8d47:	vmovapd -0x18(%rsp),%ymm7
    8d4d:	vmovapd %ymm10,0x88(%rsp)
    8d56:	vfmadd132pd %ymm13,%ymm1,%ymm11
    8d5b:	vfmsub132pd %ymm13,%ymm1,%ymm2
    8d60:	vaddpd %ymm15,%ymm10,%ymm1
    8d65:	vfnmadd132pd %ymm13,%ymm1,%ymm0
    8d6a:	vfmadd132pd %ymm13,%ymm1,%ymm4
    8d6f:	vmovapd %ymm0,%ymm15
    8d73:	vmovapd 0x28(%rsp),%ymm0
    8d79:	vaddpd 0x48(%rsp),%ymm0,%ymm1
    8d7f:	vaddpd 0x8(%rsp),%ymm7,%ymm0
    8d85:	vaddpd %ymm8,%ymm1,%ymm1
    8d8a:	vsubpd %ymm0,%ymm9,%ymm0
    8d8e:	vsubpd %ymm0,%ymm1,%ymm7
    8d92:	vfmadd132pd %ymm13,%ymm7,%ymm9
    8d97:	vfmsub231pd %ymm13,%ymm8,%ymm7
    8d9c:	vmovapd %ymm9,%ymm10
    8da1:	vmovapd -0x58(%rsp),%ymm9
    8da7:	vaddpd -0x38(%rsp),%ymm9,%ymm9
    8dad:	vaddpd %ymm14,%ymm9,%ymm9
    8db2:	vaddpd %ymm3,%ymm9,%ymm8
    8db6:	vfnmadd132pd %ymm13,%ymm8,%ymm6
    8dbb:	vfmsub231pd %ymm13,%ymm14,%ymm8
    8dc0:	vaddpd %ymm6,%ymm10,%ymm14
    8dc4:	vfnmadd132pd %ymm13,%ymm14,%ymm9
    8dc9:	vfmsub132pd %ymm13,%ymm14,%ymm1
    8dce:	vsubpd %ymm8,%ymm7,%ymm14
    8dd3:	vfnmadd132pd %ymm13,%ymm14,%ymm3
    8dd8:	vfnmadd132pd %ymm13,%ymm14,%ymm0
    8ddd:	vaddpd %ymm9,%ymm11,%ymm14
    8de2:	vfnmadd132pd %ymm13,%ymm14,%ymm10
    8de7:	vfmsub132pd %ymm13,%ymm14,%ymm5
    8dec:	vmovapd %ymm11,%ymm14
    8df1:	vaddpd %ymm0,%ymm15,%ymm11
    8df5:	vfmadd132pd %ymm13,%ymm11,%ymm8
    8dfa:	vfnmadd231pd 0x88(%rsp),%ymm13,%ymm11
    8e04:	vfmsub132pd %ymm13,%ymm10,%ymm14
    8e09:	vfmadd132pd %ymm13,%ymm5,%ymm9
    8e0e:	vfmsub132pd %ymm13,%ymm8,%ymm15
    8e13:	vfnmadd132pd %ymm13,%ymm11,%ymm0
    8e18:	vmovupd %ymm14,-0x200(%rax)
    8e20:	vaddpd %ymm1,%ymm2,%ymm14
    8e24:	vmovupd %ymm9,-0x180(%rax)
    8e2c:	vaddpd %ymm3,%ymm4,%ymm9
    8e30:	vfmadd132pd %ymm13,%ymm14,%ymm6
    8e35:	vfnmadd231pd 0xa8(%rsp),%ymm13,%ymm14
    8e3f:	vfnmadd132pd %ymm13,%ymm9,%ymm7
    8e44:	vfmsub231pd 0xc8(%rsp),%ymm13,%ymm9
    8e4e:	vfmsub132pd %ymm13,%ymm6,%ymm2
    8e53:	vfnmadd132pd %ymm13,%ymm14,%ymm1
    8e58:	vmovupd %ymm6,-0x1c0(%rax)
    8e60:	vfmsub132pd %ymm13,%ymm7,%ymm4
    8e65:	vfmadd132pd %ymm13,%ymm9,%ymm3
    8e6a:	vmovupd %ymm4,-0x1e0(%rax)
    8e72:	vmovupd %ymm8,-0x1a0(%rax)
    8e7a:	vmovupd %ymm3,-0x160(%rax)
    8e82:	vmovupd %ymm14,-0x140(%rax)
    8e8a:	vmovupd %ymm11,-0x120(%rax)
    8e92:	vmovupd %ymm10,-0x100(%rax)
    8e9a:	vmovupd %ymm7,-0xe0(%rax)
    8ea2:	vmovupd %ymm2,-0xc0(%rax)
    8eaa:	vmovupd %ymm15,-0xa0(%rax)
    8eb2:	vmovupd %ymm5,-0x80(%rax)
    8eb7:	vmovupd %ymm9,-0x60(%rax)
    8ebc:	vmovupd %ymm1,-0x40(%rax)
    8ec1:	vmovupd %ymm0,-0x20(%rax)
    8ec6:	cmp    %rax,%rdx
    8ec9:	jne    89c0 <hfirst_g52_nat+0x50>
    8ecf:	vzeroupper
    8ed2:	leave
    8ed3:	ret
    8ed4:	vzeroupper
    8ed7:	ret
    8ed8:	nopl   0x0(%rax,%rax,1)

0000000000008ee0 <hstep_tb8_balS>:
    8ee0:	endbr64
    8ee4:	vbroadcastsd 0x45c23(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
    8eed:	test   %rsi,%rsi
    8ef0:	je     907c <hstep_tb8_balS+0x19c>
    8ef6:	push   %rbp
    8ef7:	mov    %rsp,%rbp
    8efa:	push   %r15
    8efc:	push   %r14
    8efe:	lea    0x0(,%rdx,8),%r14
    8f06:	push   %r13
    8f08:	push   %r12
    8f0a:	push   %rbx
    8f0b:	and    $0xffffffffffffffe0,%rsp
    8f0f:	test   %rdx,%rdx
    8f12:	je     906a <hstep_tb8_balS+0x18a>
    8f18:	lea    -0x1(%rdx),%rax
    8f1c:	mov    %rdi,%r12
    8f1f:	lea    (%rdx,%rdx,2),%rcx
    8f23:	mov    %rsi,%r13
    8f26:	and    $0xfffffffffffffffc,%rax
    8f2a:	mov    %r14,%r10
    8f2d:	mov    %rdx,%r9
    8f30:	mov    %rdx,%rdi
    8f33:	mov    %rax,-0x8(%rsp)
    8f38:	lea    (%rdx,%rdx,4),%rsi
    8f3c:	neg    %r10
    8f3f:	shl    $0x4,%r9
    8f43:	shl    $0x5,%rdi
    8f47:	shl    $0x3,%rsi
    8f4b:	mov    %rdx,%rbx
    8f4e:	lea    0x20(%r12),%r15
    8f53:	lea    0x0(,%rcx,8),%r8
    8f5b:	shl    $0x4,%rcx
    8f5f:	nop
    8f60:	mov    -0x8(%rsp),%r11
    8f65:	lea    (%r12,%rbx,8),%rax
    8f69:	add    %rbx,%r11
    8f6c:	lea    (%r15,%r11,8),%r11
    8f70:	vmovupd (%rax,%r10,1),%ymm7
    8f76:	vmovupd (%rax),%ymm6
    8f7a:	vsubpd (%rax),%ymm7,%ymm9
    8f7e:	vmovupd (%rax,%r9,1),%ymm1
    8f84:	vfmadd132pd %ymm0,%ymm7,%ymm6
    8f89:	vmovupd (%rax,%rdx,8),%ymm7
    8f8e:	vmovupd (%rax,%r8,1),%ymm4
    8f94:	vsubpd (%rax,%r9,1),%ymm7,%ymm3
    8f9a:	vmovupd (%rax,%rdi,1),%ymm5
    8f9f:	vmovupd (%rax,%rcx,1),%ymm2
    8fa4:	vfmadd132pd %ymm0,%ymm7,%ymm1
    8fa9:	vmovupd (%rax,%rsi,1),%ymm7
    8fae:	vfmadd132pd %ymm0,%ymm4,%ymm5
    8fb3:	vsubpd (%rax,%rdi,1),%ymm4,%ymm8
    8fb8:	vsubpd (%rax,%rcx,1),%ymm7,%ymm4
    8fbd:	vfmadd132pd %ymm0,%ymm7,%ymm2
    8fc2:	vsubpd %ymm1,%ymm6,%ymm7
    8fc6:	vfmadd132pd %ymm0,%ymm6,%ymm1
    8fcb:	vsubpd %ymm3,%ymm9,%ymm6
    8fcf:	vfmadd132pd %ymm0,%ymm9,%ymm3
    8fd4:	vsubpd %ymm2,%ymm5,%ymm9
    8fd8:	vfmadd132pd %ymm0,%ymm5,%ymm2
    8fdd:	vsubpd %ymm4,%ymm8,%ymm5
    8fe1:	vfmadd132pd %ymm0,%ymm8,%ymm4
    8fe6:	vmovapd %ymm9,%ymm10
    8feb:	vmovapd %ymm5,%ymm8
    8fef:	vfmadd132pd %ymm0,%ymm7,%ymm10
    8ff4:	vfmadd132pd %ymm0,%ymm6,%ymm8
    8ff9:	vmovapd %ymm2,%ymm12
    8ffd:	vmovapd %ymm4,%ymm11
    9001:	vfmadd132pd %ymm0,%ymm1,%ymm12
    9006:	vsubpd %ymm2,%ymm1,%ymm1
    900a:	vfmadd132pd %ymm0,%ymm3,%ymm11
    900f:	vsubpd %ymm9,%ymm7,%ymm2
    9014:	vsubpd %ymm4,%ymm3,%ymm3
    9018:	vmovupd %ymm12,(%rax,%r10,1)
    901e:	vmovupd %ymm11,(%rax)
    9022:	vmovupd %ymm10,(%rax,%rdx,8)
    9027:	add    $0x20,%rax
    902b:	vmovupd %ymm8,-0x20(%rax,%r9,1)
    9032:	vmovupd %ymm1,-0x20(%rax,%r8,1)
    9039:	vsubpd %ymm5,%ymm6,%ymm1
    903d:	vmovupd %ymm3,-0x20(%rax,%rdi,1)
    9043:	vmovupd %ymm2,-0x20(%rax,%rsi,1)
    9049:	vmovupd %ymm1,-0x20(%rax,%rcx,1)
    904f:	cmp    %rax,%r11
    9052:	jne    8f70 <hstep_tb8_balS+0x90>
    9058:	add    %r14,%rbx
    905b:	mov    %rbx,%rax
    905e:	sub    %rdx,%rax
    9061:	cmp    %r13,%rax
    9064:	jb     8f60 <hstep_tb8_balS+0x80>
    906a:	vzeroupper
    906d:	lea    -0x28(%rbp),%rsp
    9071:	pop    %rbx
    9072:	pop    %r12
    9074:	pop    %r13
    9076:	pop    %r14
    9078:	pop    %r15
    907a:	pop    %rbp
    907b:	ret
    907c:	vzeroupper
    907f:	ret

000000000000f230 <hfirst_tb8_balS>:
    f230:	endbr64
    f234:	vbroadcastsd 0x3f8d3(%rip),%ymm2        # 4eb10 <FFHT_THR_D+0x130>
    f23d:	test   %rsi,%rsi
    f240:	je     f491 <hfirst_tb8_balS+0x261>
    f246:	lea    -0x8(,%rsi,8),%rax
    f24e:	vxorpd %xmm0,%xmm0,%xmm0
    f252:	xor    %al,%al
    f254:	lea    0x100(%rdi,%rax,1),%rax
    f25c:	nopl   0x0(%rax)
    f260:	vpermilpd $0xf,(%rdi),%ymm3
    f266:	vpermilpd $0x0,(%rdi),%ymm1
    f26c:	add    $0x100,%rdi
    f273:	vsubpd %ymm3,%ymm0,%ymm3
    f277:	vaddsubpd %ymm3,%ymm1,%ymm1
    f27b:	vsubpd %ymm1,%ymm0,%ymm3
    f27f:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm6
    f285:	vperm2f128 $0x31,%ymm3,%ymm1,%ymm1
    f28b:	vpermilpd $0xf,-0xe0(%rdi),%ymm3
    f295:	vaddpd %ymm1,%ymm6,%ymm6
    f299:	vpermilpd $0x0,-0xe0(%rdi),%ymm1
    f2a3:	vsubpd %ymm3,%ymm0,%ymm3
    f2a7:	vaddsubpd %ymm3,%ymm1,%ymm1
    f2ab:	vsubpd %ymm1,%ymm0,%ymm3
    f2af:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm4
    f2b5:	vperm2f128 $0x31,%ymm3,%ymm1,%ymm1
    f2bb:	vpermilpd $0xf,-0xc0(%rdi),%ymm3
    f2c5:	vaddpd %ymm1,%ymm4,%ymm4
    f2c9:	vpermilpd $0x0,-0xc0(%rdi),%ymm1
    f2d3:	vsubpd %ymm3,%ymm0,%ymm3
    f2d7:	vaddsubpd %ymm3,%ymm1,%ymm1
    f2db:	vsubpd %ymm1,%ymm0,%ymm3
    f2df:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm5
    f2e5:	vperm2f128 $0x31,%ymm3,%ymm1,%ymm1
    f2eb:	vpermilpd $0x0,-0xa0(%rdi),%ymm3
    f2f5:	vaddpd %ymm1,%ymm5,%ymm5
    f2f9:	vpermilpd $0xf,-0xa0(%rdi),%ymm1
    f303:	vsubpd %ymm1,%ymm0,%ymm1
    f307:	vaddsubpd %ymm1,%ymm3,%ymm3
    f30b:	vsubpd %ymm3,%ymm0,%ymm7
    f30f:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm1
    f315:	vperm2f128 $0x31,%ymm7,%ymm3,%ymm3
    f31b:	vpermilpd $0xf,-0x80(%rdi),%ymm7
    f322:	vaddpd %ymm3,%ymm1,%ymm1
    f326:	vpermilpd $0x0,-0x80(%rdi),%ymm3
    f32d:	vsubpd %ymm7,%ymm0,%ymm7
    f331:	vaddsubpd %ymm7,%ymm3,%ymm3
    f335:	vsubpd %ymm3,%ymm0,%ymm8
    f339:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm7
    f33f:	vperm2f128 $0x31,%ymm8,%ymm3,%ymm3
    f345:	vpermilpd $0xf,-0x60(%rdi),%ymm8
    f34c:	vaddpd %ymm3,%ymm7,%ymm7
    f350:	vpermilpd $0x0,-0x60(%rdi),%ymm3
    f357:	vsubpd %ymm8,%ymm0,%ymm8
    f35c:	vaddsubpd %ymm8,%ymm3,%ymm3
    f361:	vsubpd %ymm3,%ymm0,%ymm9
    f365:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm8
    f36b:	vperm2f128 $0x31,%ymm9,%ymm3,%ymm3
    f371:	vpermilpd $0xf,-0x40(%rdi),%ymm9
    f378:	vaddpd %ymm3,%ymm8,%ymm8
    f37c:	vpermilpd $0x0,-0x40(%rdi),%ymm3
    f383:	vsubpd %ymm9,%ymm0,%ymm9
    f388:	vaddsubpd %ymm9,%ymm3,%ymm3
    f38d:	vsubpd %ymm3,%ymm0,%ymm9
    f391:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm10
    f397:	vperm2f128 $0x31,%ymm9,%ymm3,%ymm3
    f39d:	vpermilpd $0xf,-0x20(%rdi),%ymm9
    f3a4:	vaddpd %ymm3,%ymm10,%ymm10
    f3a8:	vpermilpd $0x0,-0x20(%rdi),%ymm3
    f3af:	vsubpd %ymm9,%ymm0,%ymm9
    f3b4:	vaddsubpd %ymm9,%ymm3,%ymm3
    f3b9:	vsubpd %ymm3,%ymm0,%ymm11
    f3bd:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm9
    f3c3:	vperm2f128 $0x31,%ymm11,%ymm3,%ymm3
    f3c9:	vsubpd %ymm8,%ymm7,%ymm11
    f3ce:	vaddpd %ymm3,%ymm9,%ymm3
    f3d2:	vsubpd %ymm4,%ymm6,%ymm9
    f3d6:	vfmadd132pd %ymm2,%ymm6,%ymm4
    f3db:	vfmadd132pd %ymm2,%ymm7,%ymm8
    f3e0:	vsubpd %ymm1,%ymm5,%ymm6
    f3e4:	vfmadd132pd %ymm2,%ymm5,%ymm1
    f3e9:	vmovapd %ymm6,%ymm5
    f3ed:	vsubpd %ymm6,%ymm9,%ymm7
    f3f1:	vmovapd %ymm4,%ymm12
    f3f5:	vfmadd132pd %ymm2,%ymm9,%ymm5
    f3fa:	vsubpd %ymm3,%ymm10,%ymm4
    f3fe:	vfmadd132pd %ymm2,%ymm10,%ymm3
    f403:	vsubpd %ymm1,%ymm12,%ymm10
    f407:	vfmadd132pd %ymm2,%ymm12,%ymm1
    f40c:	vsubpd %ymm4,%ymm11,%ymm6
    f410:	vfmadd132pd %ymm2,%ymm11,%ymm4
    f415:	vsubpd %ymm3,%ymm8,%ymm9
    f419:	vfmadd132pd %ymm2,%ymm8,%ymm3
    f41e:	vmovapd %ymm6,%ymm8
    f422:	vfmadd132pd %ymm2,%ymm7,%ymm8
    f427:	vmovapd %ymm4,%ymm12
    f42b:	vmovapd %ymm9,%ymm11
    f430:	vfmadd132pd %ymm2,%ymm5,%ymm12
    f435:	vsubpd %ymm4,%ymm5,%ymm5
    f439:	vfmadd132pd %ymm2,%ymm10,%ymm11
    f43e:	vmovapd %ymm3,%ymm13
    f442:	vfmadd132pd %ymm2,%ymm1,%ymm13
    f447:	vsubpd %ymm3,%ymm1,%ymm1
    f44b:	vsubpd %ymm9,%ymm10,%ymm3
    f450:	vmovupd %ymm8,-0xa0(%rdi)
    f458:	vmovupd %ymm5,-0x60(%rdi)
    f45d:	vmovupd %ymm12,-0xe0(%rdi)
    f465:	vmovupd %ymm1,-0x80(%rdi)
    f46a:	vsubpd %ymm6,%ymm7,%ymm1
    f46e:	vmovupd %ymm11,-0xc0(%rdi)
    f476:	vmovupd %ymm13,-0x100(%rdi)
    f47e:	vmovupd %ymm3,-0x40(%rdi)
    f483:	vmovupd %ymm1,-0x20(%rdi)
    f488:	cmp    %rdi,%rax
    f48b:	jne    f260 <hfirst_tb8_balS+0x30>
    f491:	vzeroupper
    f494:	ret
    f495:	data16 cs nopw 0x0(%rax,%rax,1)

000000000000f590 <hstep_g19_nat>:
    f590:	endbr64
    f594:	vbroadcastsd 0x3f573(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
    f59d:	test   %rsi,%rsi
    f5a0:	je     f714 <hstep_g19_nat+0x184>
    f5a6:	push   %rbp
    f5a7:	mov    %rsp,%rbp
    f5aa:	push   %r15
    f5ac:	push   %r14
    f5ae:	lea    0x0(,%rdx,8),%r14
    f5b6:	push   %r13
    f5b8:	push   %r12
    f5ba:	push   %rbx
    f5bb:	and    $0xffffffffffffffe0,%rsp
    f5bf:	test   %rdx,%rdx
    f5c2:	je     f702 <hstep_g19_nat+0x172>
    f5c8:	lea    -0x1(%rdx),%rax
    f5cc:	mov    %rdi,%r12
    f5cf:	lea    (%rdx,%rdx,2),%rcx
    f5d3:	mov    %rsi,%r13
    f5d6:	and    $0xfffffffffffffffc,%rax
    f5da:	mov    %r14,%r10
    f5dd:	mov    %rdx,%r9
    f5e0:	mov    %rdx,%rdi
    f5e3:	mov    %rax,-0x8(%rsp)
    f5e8:	lea    (%rdx,%rdx,4),%rsi
    f5ec:	neg    %r10
    f5ef:	shl    $0x4,%r9
    f5f3:	shl    $0x5,%rdi
    f5f7:	shl    $0x3,%rsi
    f5fb:	mov    %rdx,%rbx
    f5fe:	lea    0x20(%r12),%r15
    f603:	vbroadcastsd 0x3f474(%rip),%ymm0        # 4ea80 <FFHT_THR_D+0xa0>
    f60c:	lea    0x0(,%rcx,8),%r8
    f614:	shl    $0x4,%rcx
    f618:	nopl   0x0(%rax,%rax,1)
    f620:	mov    -0x8(%rsp),%r11
    f625:	lea    (%r12,%rbx,8),%rax
    f629:	add    %rbx,%r11
    f62c:	lea    (%r15,%r11,8),%r11
    f630:	vmovupd (%rax,%r10,1),%ymm1
    f636:	vmovupd (%rax),%ymm6
    f63a:	vmovapd %ymm0,%ymm3
    f63e:	vaddpd (%rax,%rcx,1),%ymm1,%ymm10
    f643:	vaddpd (%rax,%rsi,1),%ymm6,%ymm7
    f648:	vmovupd (%rax,%rdx,8),%ymm4
    f64d:	vmovupd (%rax,%r9,1),%ymm5
    f653:	vsubpd (%rax,%rdi,1),%ymm4,%ymm1
    f658:	vsubpd (%rax,%r8,1),%ymm5,%ymm6
    f65e:	vmovapd %ymm0,%ymm4
    f662:	vsubpd %ymm7,%ymm10,%ymm8
    f666:	vmovapd %ymm0,%ymm5
    f66a:	vaddpd %ymm6,%ymm1,%ymm9
    f66e:	vsubpd %ymm9,%ymm8,%ymm2
    f673:	vfnmadd132pd (%rax,%rcx,1),%ymm2,%ymm3
    f679:	vfnmadd231pd (%rax,%rdi,1),%ymm0,%ymm2
    f67f:	vfmadd132pd (%rax,%rsi,1),%ymm3,%ymm5
    f685:	vfnmadd132pd (%rax,%r8,1),%ymm2,%ymm4
    f68b:	vfmadd231pd (%rax),%ymm0,%ymm3
    f690:	vfmadd231pd (%rax,%r9,1),%ymm0,%ymm2
    f696:	vfmadd132pd %ymm0,%ymm5,%ymm6
    f69b:	vfmadd132pd %ymm0,%ymm5,%ymm1
    f6a0:	vfmadd132pd %ymm0,%ymm4,%ymm7
    f6a5:	vfmadd132pd %ymm0,%ymm3,%ymm9
    f6aa:	vfmsub132pd %ymm0,%ymm2,%ymm8
    f6af:	vfmsub132pd %ymm0,%ymm4,%ymm10
    f6b4:	vmovupd %ymm10,(%rax,%r10,1)
    f6ba:	vmovupd %ymm1,(%rax)
    f6be:	vmovupd %ymm3,(%rax,%rdx,8)
    f6c3:	add    $0x20,%rax
    f6c7:	vmovupd %ymm2,-0x20(%rax,%r9,1)
    f6ce:	vmovupd %ymm9,-0x20(%rax,%r8,1)
    f6d5:	vmovupd %ymm8,-0x20(%rax,%rdi,1)
    f6db:	vmovupd %ymm7,-0x20(%rax,%rsi,1)
    f6e1:	vmovupd %ymm6,-0x20(%rax,%rcx,1)
    f6e7:	cmp    %rax,%r11
    f6ea:	jne    f630 <hstep_g19_nat+0xa0>
    f6f0:	add    %r14,%rbx
    f6f3:	mov    %rbx,%rax
    f6f6:	sub    %rdx,%rax
    f6f9:	cmp    %r13,%rax
    f6fc:	jb     f620 <hstep_g19_nat+0x90>
    f702:	vzeroupper
    f705:	lea    -0x28(%rbp),%rsp
    f709:	pop    %rbx
    f70a:	pop    %r12
    f70c:	pop    %r13
    f70e:	pop    %r14
    f710:	pop    %r15
    f712:	pop    %rbp
    f713:	ret
    f714:	vzeroupper
    f717:	ret
    f718:	nopl   0x0(%rax,%rax,1)

000000000000fa60 <hstep_h20_nat>:
    fa60:	endbr64
    fa64:	vbroadcastsd 0x3f0a3(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
    fa6d:	test   %rsi,%rsi
    fa70:	je     fbd4 <hstep_h20_nat+0x174>
    fa76:	push   %rbp
    fa77:	mov    %rsp,%rbp
    fa7a:	push   %r15
    fa7c:	push   %r14
    fa7e:	lea    0x0(,%rdx,8),%r14
    fa86:	push   %r13
    fa88:	push   %r12
    fa8a:	push   %rbx
    fa8b:	and    $0xffffffffffffffe0,%rsp
    fa8f:	test   %rdx,%rdx
    fa92:	je     fbc2 <hstep_h20_nat+0x162>
    fa98:	lea    -0x1(%rdx),%rax
    fa9c:	mov    %rdi,%r12
    fa9f:	lea    (%rdx,%rdx,2),%rcx
    faa3:	mov    %rsi,%r13
    faa6:	and    $0xfffffffffffffffc,%rax
    faaa:	mov    %r14,%r10
    faad:	mov    %rdx,%r9
    fab0:	mov    %rdx,%rdi
    fab3:	mov    %rax,-0x8(%rsp)
    fab8:	lea    (%rdx,%rdx,4),%rsi
    fabc:	neg    %r10
    fabf:	shl    $0x4,%r9
    fac3:	shl    $0x5,%rdi
    fac7:	shl    $0x3,%rsi
    facb:	mov    %rdx,%rbx
    face:	lea    0x20(%r12),%r15
    fad3:	vbroadcastsd 0x3ef84(%rip),%ymm8        # 4ea60 <FFHT_THR_D+0x80>
    fadc:	lea    0x0(,%rcx,8),%r8
    fae4:	shl    $0x4,%rcx
    fae8:	nopl   0x0(%rax,%rax,1)
    faf0:	mov    -0x8(%rsp),%r11
    faf5:	lea    (%r12,%rbx,8),%rax
    faf9:	add    %rbx,%r11
    fafc:	lea    (%r15,%r11,8),%r11
    fb00:	vmovupd (%rax,%r10,1),%ymm3
    fb06:	vmovupd (%rax),%ymm4
    fb0a:	vaddpd (%rax,%rcx,1),%ymm3,%ymm10
    fb0f:	vaddpd (%rax,%rsi,1),%ymm4,%ymm6
    fb14:	vmovupd (%rax,%r9,1),%ymm3
    fb1a:	vmovupd (%rax,%rdx,8),%ymm2
    fb1f:	vsubpd (%rax,%r8,1),%ymm3,%ymm5
    fb25:	vsubpd (%rax,%rdi,1),%ymm2,%ymm2
    fb2a:	vsubpd %ymm6,%ymm10,%ymm7
    fb2e:	vaddpd %ymm5,%ymm2,%ymm9
    fb32:	vsubpd %ymm9,%ymm7,%ymm0
    fb37:	vmovapd %ymm0,%ymm1
    fb3b:	vfmsub213pd (%rax,%rdi,1),%ymm8,%ymm0
    fb41:	vfmsub213pd (%rax,%rcx,1),%ymm8,%ymm1
    fb47:	vsubpd (%rax,%r8,1),%ymm0,%ymm4
    fb4d:	vaddpd (%rax,%rsi,1),%ymm1,%ymm3
    fb52:	vaddpd (%rax,%r9,1),%ymm0,%ymm0
    fb58:	vaddpd (%rax),%ymm1,%ymm1
    fb5c:	vsubpd %ymm4,%ymm10,%ymm10
    fb60:	vaddpd %ymm4,%ymm6,%ymm6
    fb64:	vaddpd %ymm3,%ymm2,%ymm2
    fb68:	vsubpd %ymm0,%ymm7,%ymm7
    fb6c:	vaddpd %ymm1,%ymm9,%ymm9
    fb70:	vaddpd %ymm3,%ymm5,%ymm5
    fb74:	vmovupd %ymm10,(%rax,%r10,1)
    fb7a:	vmovupd %ymm2,(%rax)
    fb7e:	vmovupd %ymm1,(%rax,%rdx,8)
    fb83:	add    $0x20,%rax
    fb87:	vmovupd %ymm0,-0x20(%rax,%r9,1)
    fb8e:	vmovupd %ymm9,-0x20(%rax,%r8,1)
    fb95:	vmovupd %ymm7,-0x20(%rax,%rdi,1)
    fb9b:	vmovupd %ymm6,-0x20(%rax,%rsi,1)
    fba1:	vmovupd %ymm5,-0x20(%rax,%rcx,1)
    fba7:	cmp    %rax,%r11
    fbaa:	jne    fb00 <hstep_h20_nat+0xa0>
    fbb0:	add    %r14,%rbx
    fbb3:	mov    %rbx,%rax
    fbb6:	sub    %rdx,%rax
    fbb9:	cmp    %r13,%rax
    fbbc:	jb     faf0 <hstep_h20_nat+0x90>
    fbc2:	vzeroupper
    fbc5:	lea    -0x28(%rbp),%rsp
    fbc9:	pop    %rbx
    fbca:	pop    %r12
    fbcc:	pop    %r13
    fbce:	pop    %r14
    fbd0:	pop    %r15
    fbd2:	pop    %rbp
    fbd3:	ret
    fbd4:	vzeroupper
    fbd7:	ret
    fbd8:	nopl   0x0(%rax,%rax,1)

00000000000120d0 <hstep_g20_nat>:
   120d0:	endbr64
   120d4:	vbroadcastsd 0x3ca33(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
   120dd:	test   %rsi,%rsi
   120e0:	je     12256 <hstep_g20_nat+0x186>
   120e6:	push   %rbp
   120e7:	mov    %rsp,%rbp
   120ea:	push   %r15
   120ec:	push   %r14
   120ee:	lea    0x0(,%rdx,8),%r14
   120f6:	push   %r13
   120f8:	push   %r12
   120fa:	push   %rbx
   120fb:	and    $0xffffffffffffffe0,%rsp
   120ff:	test   %rdx,%rdx
   12102:	je     12244 <hstep_g20_nat+0x174>
   12108:	lea    -0x1(%rdx),%rax
   1210c:	mov    %rdi,%r12
   1210f:	lea    (%rdx,%rdx,2),%rcx
   12113:	mov    %rsi,%r13
   12116:	and    $0xfffffffffffffffc,%rax
   1211a:	mov    %r14,%r10
   1211d:	mov    %rdx,%r9
   12120:	mov    %rdx,%rdi
   12123:	mov    %rax,-0x8(%rsp)
   12128:	lea    (%rdx,%rdx,4),%rsi
   1212c:	neg    %r10
   1212f:	shl    $0x4,%r9
   12133:	shl    $0x5,%rdi
   12137:	shl    $0x3,%rsi
   1213b:	mov    %rdx,%rbx
   1213e:	lea    0x20(%r12),%r15
   12143:	vbroadcastsd 0x3c934(%rip),%ymm0        # 4ea80 <FFHT_THR_D+0xa0>
   1214c:	lea    0x0(,%rcx,8),%r8
   12154:	shl    $0x4,%rcx
   12158:	nopl   0x0(%rax,%rax,1)
   12160:	mov    -0x8(%rsp),%r11
   12165:	lea    (%r12,%rbx,8),%rax
   12169:	add    %rbx,%r11
   1216c:	lea    (%r15,%r11,8),%r11
   12170:	vmovupd (%rax),%ymm5
   12174:	vmovupd (%rax,%rdx,8),%ymm6
   12179:	vmovapd %ymm0,%ymm4
   1217d:	vaddpd (%rax,%r10,1),%ymm5,%ymm5
   12183:	vsubpd (%rax,%r9,1),%ymm6,%ymm6
   12189:	vmovupd (%rax,%rdi,1),%ymm7
   1218e:	vmovupd (%rax,%rsi,1),%ymm3
   12193:	vaddpd (%rax,%r8,1),%ymm7,%ymm8
   12199:	vsubpd (%rax,%rcx,1),%ymm3,%ymm7
   1219e:	vmovapd %ymm0,%ymm3
   121a2:	vsubpd %ymm6,%ymm5,%ymm1
   121a6:	vfmadd132pd (%rax,%rdx,8),%ymm1,%ymm4
   121ac:	vmovapd %ymm1,%ymm2
   121b0:	vfmsub231pd (%rax,%r10,1),%ymm0,%ymm2
   121b6:	vaddpd %ymm7,%ymm8,%ymm1
   121ba:	vfnmadd132pd (%rax,%rsi,1),%ymm1,%ymm3
   121c0:	vfmsub231pd (%rax,%r8,1),%ymm0,%ymm1
   121c6:	vaddpd %ymm3,%ymm4,%ymm9
   121ca:	vfnmadd132pd %ymm0,%ymm9,%ymm8
   121cf:	vfmsub132pd %ymm0,%ymm9,%ymm5
   121d4:	vaddpd %ymm1,%ymm2,%ymm9
   121d8:	vfmadd132pd %ymm0,%ymm9,%ymm7
   121dd:	vfnmadd132pd %ymm0,%ymm9,%ymm6
   121e2:	vfmsub132pd %ymm0,%ymm8,%ymm4
   121e7:	vfmadd132pd %ymm0,%ymm5,%ymm3
   121ec:	vfmsub132pd %ymm0,%ymm7,%ymm2
   121f1:	vfnmadd132pd %ymm0,%ymm6,%ymm1
   121f6:	vmovupd %ymm4,(%rax,%r10,1)
   121fc:	vmovupd %ymm7,(%rax)
   12200:	vmovupd %ymm3,(%rax,%rdx,8)
   12205:	add    $0x20,%rax
   12209:	vmovupd %ymm6,-0x20(%rax,%r9,1)
   12210:	vmovupd %ymm8,-0x20(%rax,%r8,1)
   12217:	vmovupd %ymm2,-0x20(%rax,%rdi,1)
   1221d:	vmovupd %ymm5,-0x20(%rax,%rsi,1)
   12223:	vmovupd %ymm1,-0x20(%rax,%rcx,1)
   12229:	cmp    %rax,%r11
   1222c:	jne    12170 <hstep_g20_nat+0xa0>
   12232:	add    %r14,%rbx
   12235:	mov    %rbx,%rax
   12238:	sub    %rdx,%rax
   1223b:	cmp    %r13,%rax
   1223e:	jb     12160 <hstep_g20_nat+0x90>
   12244:	vzeroupper
   12247:	lea    -0x28(%rbp),%rsp
   1224b:	pop    %rbx
   1224c:	pop    %r12
   1224e:	pop    %r13
   12250:	pop    %r14
   12252:	pop    %r15
   12254:	pop    %rbp
   12255:	ret
   12256:	vzeroupper
   12259:	ret
   1225a:	nopw   0x0(%rax,%rax,1)

0000000000013350 <hstep_broken_g20>:
   13350:	endbr64
   13354:	vbroadcastsd 0x3b7b3(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
   1335d:	test   %rsi,%rsi
   13360:	je     134d6 <hstep_broken_g20+0x186>
   13366:	push   %rbp
   13367:	mov    %rsp,%rbp
   1336a:	push   %r15
   1336c:	push   %r14
   1336e:	lea    0x0(,%rdx,8),%r14
   13376:	push   %r13
   13378:	push   %r12
   1337a:	push   %rbx
   1337b:	and    $0xffffffffffffffe0,%rsp
   1337f:	test   %rdx,%rdx
   13382:	je     134c4 <hstep_broken_g20+0x174>
   13388:	lea    -0x1(%rdx),%rax
   1338c:	mov    %rdi,%r12
   1338f:	lea    (%rdx,%rdx,2),%rcx
   13393:	mov    %rsi,%r13
   13396:	and    $0xfffffffffffffffc,%rax
   1339a:	mov    %r14,%r10
   1339d:	mov    %rdx,%r9
   133a0:	mov    %rdx,%rdi
   133a3:	mov    %rax,-0x8(%rsp)
   133a8:	lea    (%rdx,%rdx,4),%rsi
   133ac:	neg    %r10
   133af:	shl    $0x4,%r9
   133b3:	shl    $0x5,%rdi
   133b7:	shl    $0x3,%rsi
   133bb:	mov    %rdx,%rbx
   133be:	lea    0x20(%r12),%r15
   133c3:	vbroadcastsd 0x3b6b4(%rip),%ymm0        # 4ea80 <FFHT_THR_D+0xa0>
   133cc:	lea    0x0(,%rcx,8),%r8
   133d4:	shl    $0x4,%rcx
   133d8:	nopl   0x0(%rax,%rax,1)
   133e0:	mov    -0x8(%rsp),%r11
   133e5:	lea    (%r12,%rbx,8),%rax
   133e9:	add    %rbx,%r11
   133ec:	lea    (%r15,%r11,8),%r11
   133f0:	vmovupd (%rax),%ymm5
   133f4:	vmovupd (%rax,%rdx,8),%ymm6
   133f9:	vmovapd %ymm0,%ymm4
   133fd:	vaddpd (%rax,%r10,1),%ymm5,%ymm5
   13403:	vsubpd (%rax,%r9,1),%ymm6,%ymm6
   13409:	vmovupd (%rax,%rdi,1),%ymm7
   1340e:	vmovupd (%rax,%rsi,1),%ymm3
   13413:	vaddpd (%rax,%r8,1),%ymm7,%ymm8
   13419:	vsubpd (%rax,%rcx,1),%ymm3,%ymm7
   1341e:	vmovapd %ymm0,%ymm3
   13422:	vsubpd %ymm6,%ymm5,%ymm1
   13426:	vfmadd132pd (%rax,%rdx,8),%ymm1,%ymm4
   1342c:	vmovapd %ymm1,%ymm2
   13430:	vfmsub231pd (%rax,%r10,1),%ymm0,%ymm2
   13436:	vaddpd %ymm7,%ymm8,%ymm1
   1343a:	vfnmadd132pd (%rax,%rsi,1),%ymm1,%ymm3
   13440:	vfmsub231pd (%rax,%r8,1),%ymm0,%ymm1
   13446:	vaddpd %ymm3,%ymm4,%ymm9
   1344a:	vfnmadd132pd %ymm0,%ymm9,%ymm8
   1344f:	vfmsub132pd %ymm0,%ymm9,%ymm5
   13454:	vaddpd %ymm1,%ymm2,%ymm9
   13458:	vfmadd132pd %ymm0,%ymm9,%ymm7
   1345d:	vfnmadd132pd %ymm0,%ymm9,%ymm6
   13462:	vfmsub132pd %ymm0,%ymm8,%ymm4
   13467:	vfmadd132pd %ymm0,%ymm5,%ymm3
   1346c:	vfmsub132pd %ymm0,%ymm7,%ymm2
   13471:	vfnmadd132pd %ymm0,%ymm6,%ymm1
   13476:	vmovupd %ymm4,(%rax,%r10,1)
   1347c:	vmovupd %ymm7,(%rax)
   13480:	vmovupd %ymm3,(%rax,%rdx,8)
   13485:	add    $0x20,%rax
   13489:	vmovupd %ymm6,-0x20(%rax,%r9,1)
   13490:	vmovupd %ymm8,-0x20(%rax,%r8,1)
   13497:	vmovupd %ymm5,-0x20(%rax,%rdi,1)
   1349d:	vmovupd %ymm2,-0x20(%rax,%rsi,1)
   134a3:	vmovupd %ymm1,-0x20(%rax,%rcx,1)
   134a9:	cmp    %rax,%r11
   134ac:	jne    133f0 <hstep_broken_g20+0xa0>
   134b2:	add    %r14,%rbx
   134b5:	mov    %rbx,%rax
   134b8:	sub    %rdx,%rax
   134bb:	cmp    %r13,%rax
   134be:	jb     133e0 <hstep_broken_g20+0x90>
   134c4:	vzeroupper
   134c7:	lea    -0x28(%rbp),%rsp
   134cb:	pop    %rbx
   134cc:	pop    %r12
   134ce:	pop    %r13
   134d0:	pop    %r14
   134d2:	pop    %r15
   134d4:	pop    %rbp
   134d5:	ret
   134d6:	vzeroupper
   134d9:	ret
   134da:	nopw   0x0(%rax,%rax,1)

00000000000134e0 <hstep_tb8_nat>:
   134e0:	endbr64
   134e4:	vbroadcastsd 0x3b623(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
   134ed:	test   %rsi,%rsi
   134f0:	je     13650 <hstep_tb8_nat+0x170>
   134f6:	push   %rbp
   134f7:	mov    %rsp,%rbp
   134fa:	push   %r15
   134fc:	push   %r14
   134fe:	lea    0x0(,%rdx,8),%r14
   13506:	push   %r13
   13508:	push   %r12
   1350a:	push   %rbx
   1350b:	and    $0xffffffffffffffe0,%rsp
   1350f:	test   %rdx,%rdx
   13512:	je     1363e <hstep_tb8_nat+0x15e>
   13518:	lea    -0x1(%rdx),%rax
   1351c:	mov    %rdi,%r12
   1351f:	lea    (%rdx,%rdx,2),%rcx
   13523:	mov    %rsi,%r13
   13526:	and    $0xfffffffffffffffc,%rax
   1352a:	mov    %r14,%r10
   1352d:	mov    %rdx,%r9
   13530:	mov    %rdx,%rdi
   13533:	mov    %rax,-0x8(%rsp)
   13538:	lea    (%rdx,%rdx,4),%rsi
   1353c:	neg    %r10
   1353f:	shl    $0x4,%r9
   13543:	shl    $0x5,%rdi
   13547:	shl    $0x3,%rsi
   1354b:	mov    %rdx,%rbx
   1354e:	lea    0x20(%r12),%r15
   13553:	lea    0x0(,%rcx,8),%r8
   1355b:	shl    $0x4,%rcx
   1355f:	nop
   13560:	mov    -0x8(%rsp),%r11
   13565:	lea    (%r12,%rbx,8),%rax
   13569:	add    %rbx,%r11
   1356c:	lea    (%r15,%r11,8),%r11
   13570:	vmovupd (%rax,%r10,1),%ymm7
   13576:	vmovupd (%rax,%rdx,8),%ymm1
   1357b:	vaddpd (%rax),%ymm7,%ymm5
   1357f:	vaddpd (%rax,%r9,1),%ymm1,%ymm6
   13585:	vsubpd (%rax,%r9,1),%ymm1,%ymm4
   1358b:	vsubpd (%rax),%ymm7,%ymm0
   1358f:	vmovupd (%rax,%r8,1),%ymm7
   13595:	vaddpd (%rax,%rdi,1),%ymm7,%ymm2
   1359a:	vsubpd (%rax,%rdi,1),%ymm7,%ymm1
   1359f:	vmovupd (%rax,%rsi,1),%ymm7
   135a4:	vaddpd %ymm6,%ymm5,%ymm9
   135a8:	vaddpd (%rax,%rcx,1),%ymm7,%ymm8
   135ad:	vsubpd (%rax,%rcx,1),%ymm7,%ymm3
   135b2:	vsubpd %ymm6,%ymm5,%ymm5
   135b6:	vaddpd %ymm4,%ymm0,%ymm6
   135ba:	vsubpd %ymm4,%ymm0,%ymm0
   135be:	vaddpd %ymm8,%ymm2,%ymm7
   135c3:	vaddpd %ymm3,%ymm1,%ymm4
   135c7:	vsubpd %ymm3,%ymm1,%ymm1
   135cb:	vsubpd %ymm8,%ymm2,%ymm2
   135d0:	vaddpd %ymm7,%ymm9,%ymm3
   135d4:	vmovupd %ymm3,(%rax,%r10,1)
   135da:	vaddpd %ymm4,%ymm6,%ymm3
   135de:	vsubpd %ymm4,%ymm6,%ymm6
   135e2:	vmovupd %ymm3,(%rax)
   135e6:	vaddpd %ymm2,%ymm5,%ymm3
   135ea:	vsubpd %ymm2,%ymm5,%ymm5
   135ee:	vmovupd %ymm3,(%rax,%rdx,8)
   135f3:	vaddpd %ymm1,%ymm0,%ymm3
   135f7:	vsubpd %ymm1,%ymm0,%ymm0
   135fb:	add    $0x20,%rax
   135ff:	vmovupd %ymm3,-0x20(%rax,%r9,1)
   13606:	vsubpd %ymm7,%ymm9,%ymm3
   1360a:	vmovupd %ymm3,-0x20(%rax,%r8,1)
   13611:	vmovupd %ymm6,-0x20(%rax,%rdi,1)
   13617:	vmovupd %ymm5,-0x20(%rax,%rsi,1)
   1361d:	vmovupd %ymm0,-0x20(%rax,%rcx,1)
   13623:	cmp    %rax,%r11
   13626:	jne    13570 <hstep_tb8_nat+0x90>
   1362c:	add    %r14,%rbx
   1362f:	mov    %rbx,%rax
   13632:	sub    %rdx,%rax
   13635:	cmp    %r13,%rax
   13638:	jb     13560 <hstep_tb8_nat+0x80>
   1363e:	vzeroupper
   13641:	lea    -0x28(%rbp),%rsp
   13645:	pop    %rbx
   13646:	pop    %r12
   13648:	pop    %r13
   1364a:	pop    %r14
   1364c:	pop    %r15
   1364e:	pop    %rbp
   1364f:	ret
   13650:	vzeroupper
   13653:	ret
   13654:	data16 cs nopw 0x0(%rax,%rax,1)
   1365f:	nop

0000000000016ad0 <hstep_tb8_bal>:
   16ad0:	endbr64
   16ad4:	vbroadcastsd 0x38033(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
   16add:	test   %rsi,%rsi
   16ae0:	je     16c80 <hstep_tb8_bal+0x1b0>
   16ae6:	push   %rbp
   16ae7:	mov    %rsp,%rbp
   16aea:	push   %r15
   16aec:	push   %r14
   16aee:	lea    0x0(,%rdx,8),%r14
   16af6:	push   %r13
   16af8:	push   %r12
   16afa:	push   %rbx
   16afb:	and    $0xffffffffffffffe0,%rsp
   16aff:	test   %rdx,%rdx
   16b02:	je     16c6e <hstep_tb8_bal+0x19e>
   16b08:	lea    -0x1(%rdx),%rax
   16b0c:	mov    %rdi,%r12
   16b0f:	lea    (%rdx,%rdx,2),%rcx
   16b13:	mov    %rsi,%r13
   16b16:	and    $0xfffffffffffffffc,%rax
   16b1a:	mov    %r14,%r10
   16b1d:	mov    %rdx,%r9
   16b20:	mov    %rdx,%rdi
   16b23:	mov    %rax,-0x8(%rsp)
   16b28:	lea    (%rdx,%rdx,4),%rsi
   16b2c:	neg    %r10
   16b2f:	shl    $0x4,%r9
   16b33:	shl    $0x5,%rdi
   16b37:	shl    $0x3,%rsi
   16b3b:	mov    %rdx,%rbx
   16b3e:	lea    0x20(%r12),%r15
   16b43:	lea    0x0(,%rcx,8),%r8
   16b4b:	shl    $0x4,%rcx
   16b4f:	nop
   16b50:	mov    -0x8(%rsp),%r11
   16b55:	lea    (%r12,%rbx,8),%rax
   16b59:	add    %rbx,%r11
   16b5c:	lea    (%r15,%r11,8),%r11
   16b60:	vmovupd (%rax,%r9,1),%ymm8
   16b66:	vfmadd213pd (%rax,%rdx,8),%ymm0,%ymm8
   16b6c:	vmovupd (%rax),%ymm6
   16b70:	vfmadd213pd (%rax,%r10,1),%ymm0,%ymm6
   16b76:	vmovupd (%rax,%rcx,1),%ymm7
   16b7b:	vfmadd213pd (%rax,%rsi,1),%ymm0,%ymm7
   16b81:	vmovupd (%rax,%r10,1),%ymm2
   16b87:	vmovupd (%rax,%rdi,1),%ymm3
   16b8c:	vsubpd (%rax),%ymm2,%ymm1
   16b90:	vfmadd213pd (%rax,%r8,1),%ymm0,%ymm3
   16b96:	vmovupd (%rax,%rdx,8),%ymm2
   16b9b:	vsubpd (%rax,%r9,1),%ymm2,%ymm5
   16ba1:	vmovapd %ymm8,%ymm9
   16ba6:	vmovupd (%rax,%rsi,1),%ymm4
   16bab:	vsubpd (%rax,%rcx,1),%ymm4,%ymm4
   16bb0:	vfmadd132pd %ymm0,%ymm6,%ymm9
   16bb5:	vsubpd %ymm8,%ymm6,%ymm6
   16bba:	vmovupd (%rax,%r8,1),%ymm2
   16bc0:	vsubpd (%rax,%rdi,1),%ymm2,%ymm2
   16bc5:	vmovapd %ymm5,%ymm8
   16bc9:	vfmadd132pd %ymm0,%ymm1,%ymm8
   16bce:	vsubpd %ymm5,%ymm1,%ymm1
   16bd2:	vmovapd %ymm7,%ymm5
   16bd6:	vfmadd132pd %ymm0,%ymm3,%ymm5
   16bdb:	vsubpd %ymm7,%ymm3,%ymm3
   16bdf:	vmovapd %ymm4,%ymm7
   16be3:	vfmadd132pd %ymm0,%ymm2,%ymm7
   16be8:	vsubpd %ymm4,%ymm2,%ymm2
   16bec:	vmovapd %ymm3,%ymm10
   16bf0:	vmovapd %ymm2,%ymm4
   16bf4:	vfmadd132pd %ymm0,%ymm6,%ymm10
   16bf9:	vsubpd %ymm3,%ymm6,%ymm6
   16bfd:	vmovapd %ymm5,%ymm12
   16c01:	vfmadd132pd %ymm0,%ymm1,%ymm4
   16c06:	vsubpd %ymm5,%ymm9,%ymm5
   16c0a:	vmovapd %ymm7,%ymm11
   16c0e:	vfmadd132pd %ymm0,%ymm9,%ymm12
   16c13:	vsubpd %ymm2,%ymm1,%ymm1
   16c17:	vfmadd132pd %ymm0,%ymm8,%ymm11
   16c1c:	vmovupd %ymm12,(%rax,%r10,1)
   16c22:	vmovupd %ymm11,(%rax)
   16c26:	vmovupd %ymm10,(%rax,%rdx,8)
   16c2b:	add    $0x20,%rax
   16c2f:	vmovupd %ymm4,-0x20(%rax,%r9,1)
   16c36:	vsubpd %ymm7,%ymm8,%ymm4
   16c3a:	vmovupd %ymm5,-0x20(%rax,%r8,1)
   16c41:	vmovupd %ymm4,-0x20(%rax,%rdi,1)
   16c47:	vmovupd %ymm6,-0x20(%rax,%rsi,1)
   16c4d:	vmovupd %ymm1,-0x20(%rax,%rcx,1)
   16c53:	cmp    %rax,%r11
   16c56:	jne    16b60 <hstep_tb8_bal+0x90>
   16c5c:	add    %r14,%rbx
   16c5f:	mov    %rbx,%rax
   16c62:	sub    %rdx,%rax
   16c65:	cmp    %r13,%rax
   16c68:	jb     16b50 <hstep_tb8_bal+0x80>
   16c6e:	vzeroupper
   16c71:	lea    -0x28(%rbp),%rsp
   16c75:	pop    %rbx
   16c76:	pop    %r12
   16c78:	pop    %r13
   16c7a:	pop    %r14
   16c7c:	pop    %r15
   16c7e:	pop    %rbp
   16c7f:	ret
   16c80:	vzeroupper
   16c83:	ret
   16c84:	data16 cs nopw 0x0(%rax,%rax,1)
   16c8f:	nop

0000000000021270 <hstep_g52_nat>:
   21270:	endbr64
   21274:	vbroadcastsd 0x2d893(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
   2127d:	test   %rsi,%rsi
   21280:	je     2151a <hstep_g52_nat+0x2aa>
   21286:	push   %rbp
   21287:	mov    %rdx,%rcx
   2128a:	mov    %rsp,%rbp
   2128d:	push   %r15
   2128f:	push   %r14
   21291:	push   %r13
   21293:	mov    %rsi,%r13
   21296:	mov    %rdx,%rsi
   21299:	push   %r12
   2129b:	shl    $0x4,%rsi
   2129f:	push   %rbx
   212a0:	and    $0xffffffffffffffe0,%rsp
   212a4:	test   %rdx,%rdx
   212a7:	je     21508 <hstep_g52_nat+0x298>
   212ad:	mov    %rdi,%rax
   212b0:	lea    (%rdi,%rsi,1),%r15
   212b4:	lea    (%rdx,%rdx,4),%rdi
   212b8:	mov    %rcx,%r9
   212bb:	mov    %rdi,%rdx
   212be:	mov    %rsi,%r11
   212c1:	neg    %r9
   212c4:	mov    %rcx,%r10
   212c7:	shl    $0x4,%rdx
   212cb:	lea    (%rcx,%rcx,2),%r8
   212cf:	neg    %r11
   212d2:	shl    $0x3,%r9
   212d6:	lea    (%rax,%rdx,1),%rbx
   212da:	lea    -0x1(%rcx),%rdx
   212de:	shl    $0x3,%r8
   212e2:	shl    $0x5,%r10
   212e6:	shr    $0x2,%rdx
   212ea:	mov    %rbx,-0x48(%rsp)
   212ef:	shl    $0x3,%rdi
   212f3:	xor    %r12d,%r12d
   212f6:	lea    (%rcx,%rdx,2),%rdx
   212fa:	lea    0x20(%rax),%r14
   212fe:	vbroadcastsd 0x2d779(%rip),%ymm11        # 4ea80 <FFHT_THR_D+0xa0>
   21307:	lea    (%rdx,%rdx,1),%rbx
   2130b:	mov    %rbx,-0x50(%rsp)
   21310:	mov    -0x48(%rsp),%rbx
   21315:	lea    0x0(,%r12,8),%rdx
   2131d:	lea    (%rdx,%r15,1),%rax
   21321:	add    %rbx,%rdx
   21324:	mov    -0x50(%rsp),%rbx
   21329:	add    %r12,%rbx
   2132c:	lea    (%r14,%rbx,8),%rbx
   21330:	vmovupd (%rax,%r9,1),%ymm7
   21336:	vmovupd (%rax,%r8,1),%ymm4
   2133c:	vaddpd (%rax,%r11,1),%ymm7,%ymm9
   21342:	vaddpd (%rax,%rsi,1),%ymm4,%ymm14
   21347:	vmovapd %ymm11,%ymm4
   2134b:	vmovupd (%rax,%r10,1),%ymm7
   21351:	vsubpd (%rax,%rdi,1),%ymm7,%ymm13
   21356:	vmovupd (%rax),%ymm1
   2135a:	vsubpd (%rax,%rcx,8),%ymm1,%ymm3
   2135f:	vmovapd %ymm11,%ymm1
   21363:	vmovupd (%rdx,%r9,1),%ymm5
   21369:	vaddpd (%rdx,%r11,1),%ymm5,%ymm8
   2136f:	vmovapd %ymm11,%ymm5
   21373:	vaddpd %ymm13,%ymm14,%ymm2
   21378:	vsubpd %ymm3,%ymm9,%ymm0
   2137c:	vfmadd132pd (%rax),%ymm0,%ymm1
   21381:	vfmsub231pd (%rax,%r11,1),%ymm11,%ymm0
   21387:	vfnmadd132pd %ymm7,%ymm2,%ymm4
   2138c:	vmovapd %ymm2,%ymm6
   21390:	vmovupd (%rdx),%ymm7
   21394:	vsubpd (%rdx,%rcx,8),%ymm7,%ymm7
   21399:	vfmsub231pd (%rax,%rsi,1),%ymm11,%ymm6
   2139f:	vsubpd %ymm4,%ymm1,%ymm2
   213a3:	vmovapd %ymm6,-0x20(%rsp)
   213a9:	vfmadd132pd %ymm11,%ymm2,%ymm14
   213ae:	vfmsub132pd %ymm11,%ymm2,%ymm9
   213b3:	vaddpd %ymm6,%ymm0,%ymm2
   213b7:	vmovapd %ymm11,%ymm6
   213bb:	vfmadd132pd %ymm11,%ymm2,%ymm13
   213c0:	vfnmadd132pd %ymm11,%ymm2,%ymm3
   213c5:	vsubpd %ymm7,%ymm8,%ymm2
   213c9:	vfmadd132pd (%rdx),%ymm2,%ymm5
   213ce:	vfmsub231pd (%rdx,%r11,1),%ymm11,%ymm2
   213d4:	vmovapd %ymm3,-0x40(%rsp)
   213da:	vmovapd %ymm5,%ymm3
   213de:	vmovupd (%rdx,%r8,1),%ymm5
   213e4:	vaddpd (%rdx,%rsi,1),%ymm5,%ymm12
   213e9:	vmovupd (%rdx,%r10,1),%ymm5
   213ef:	vsubpd (%rdx,%rdi,1),%ymm5,%ymm10
   213f4:	vaddpd %ymm10,%ymm12,%ymm5
   213f9:	vfnmadd132pd (%rdx,%r10,1),%ymm5,%ymm6
   213ff:	vfmsub231pd (%rdx,%rsi,1),%ymm11,%ymm5
   21405:	vaddpd %ymm6,%ymm3,%ymm15
   21409:	vfnmadd132pd %ymm11,%ymm15,%ymm12
   2140e:	vfmsub132pd %ymm11,%ymm15,%ymm8
   21413:	vsubpd %ymm5,%ymm2,%ymm15
   21417:	vfnmadd132pd %ymm11,%ymm15,%ymm10
   2141c:	vfnmadd132pd %ymm11,%ymm15,%ymm7
   21421:	vaddpd %ymm12,%ymm14,%ymm15
   21426:	vfnmadd132pd %ymm11,%ymm15,%ymm3
   2142b:	vfmsub132pd %ymm11,%ymm15,%ymm1
   21430:	vmovapd -0x40(%rsp),%ymm15
   21436:	vfmsub132pd %ymm11,%ymm3,%ymm14
   2143b:	vfmadd132pd %ymm11,%ymm1,%ymm12
   21440:	vmovupd %ymm14,(%rax,%r11,1)
   21446:	vaddpd %ymm10,%ymm13,%ymm14
   2144b:	vfnmadd132pd %ymm11,%ymm14,%ymm2
   21450:	vfmsub132pd %ymm11,%ymm14,%ymm0
   21455:	vaddpd %ymm8,%ymm9,%ymm14
   2145a:	vfmadd132pd %ymm11,%ymm14,%ymm6
   2145f:	vfnmadd132pd %ymm11,%ymm14,%ymm4
   21464:	vaddpd %ymm15,%ymm7,%ymm14
   21469:	vfmsub132pd %ymm11,%ymm2,%ymm13
   2146e:	vfmadd132pd %ymm11,%ymm0,%ymm10
   21473:	vfmadd132pd %ymm11,%ymm14,%ymm5
   21478:	vfnmadd231pd -0x20(%rsp),%ymm11,%ymm14
   2147f:	vfmsub132pd %ymm11,%ymm6,%ymm9
   21484:	vfnmadd132pd %ymm11,%ymm4,%ymm8
   21489:	vmovupd %ymm13,(%rax,%r9,1)
   2148f:	vfmsub132pd %ymm11,%ymm5,%ymm15
   21494:	vfnmadd132pd %ymm11,%ymm14,%ymm7
   21499:	vmovupd %ymm6,(%rax)
   2149d:	vmovupd %ymm5,(%rax,%rcx,8)
   214a2:	add    $0x20,%rax
   214a6:	vmovupd %ymm12,-0x20(%rax,%rsi,1)
   214ac:	vmovupd %ymm10,-0x20(%rax,%r8,1)
   214b3:	vmovupd %ymm4,-0x20(%rax,%r10,1)
   214ba:	vmovupd %ymm14,-0x20(%rax,%rdi,1)
   214c0:	vmovupd %ymm3,(%rdx,%r11,1)
   214c6:	vmovupd %ymm2,(%rdx,%r9,1)
   214cc:	vmovupd %ymm9,(%rdx)
   214d0:	vmovupd %ymm15,(%rdx,%rcx,8)
   214d5:	add    $0x20,%rdx
   214d9:	vmovupd %ymm1,-0x20(%rdx,%rsi,1)
   214df:	vmovupd %ymm0,-0x20(%rdx,%r8,1)
   214e6:	vmovupd %ymm8,-0x20(%rdx,%r10,1)
   214ed:	vmovupd %ymm7,-0x20(%rdx,%rdi,1)
   214f3:	cmp    %rbx,%rax
   214f6:	jne    21330 <hstep_g52_nat+0xc0>
   214fc:	add    %rsi,%r12
   214ff:	cmp    %r13,%r12
   21502:	jb     21310 <hstep_g52_nat+0xa0>
   21508:	vzeroupper
   2150b:	lea    -0x28(%rbp),%rsp
   2150f:	pop    %rbx
   21510:	pop    %r12
   21512:	pop    %r13
   21514:	pop    %r14
   21516:	pop    %r15
   21518:	pop    %rbp
   21519:	ret
   2151a:	vzeroupper
   2151d:	ret
   2151e:	xchg   %ax,%ax

00000000000227e0 <hstep_tb16_nat>:
   227e0:	endbr64
   227e4:	vbroadcastsd 0x2c323(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
   227ed:	test   %rsi,%rsi
   227f0:	je     22aab <hstep_tb16_nat+0x2cb>
   227f6:	push   %rbp
   227f7:	mov    %rdx,%rcx
   227fa:	mov    %rsp,%rbp
   227fd:	push   %r15
   227ff:	push   %r14
   22801:	push   %r13
   22803:	mov    %rsi,%r13
   22806:	mov    %rdx,%rsi
   22809:	push   %r12
   2280b:	shl    $0x4,%rsi
   2280f:	push   %rbx
   22810:	and    $0xffffffffffffffe0,%rsp
   22814:	test   %rdx,%rdx
   22817:	je     22a99 <hstep_tb16_nat+0x2b9>
   2281d:	mov    %rdi,%rax
   22820:	lea    (%rdi,%rsi,1),%r15
   22824:	lea    (%rdx,%rdx,4),%rdi
   22828:	mov    %rcx,%r9
   2282b:	mov    %rdi,%rdx
   2282e:	mov    %rsi,%r11
   22831:	neg    %r9
   22834:	mov    %rcx,%r10
   22837:	shl    $0x4,%rdx
   2283b:	lea    (%rcx,%rcx,2),%r8
   2283f:	neg    %r11
   22842:	shl    $0x3,%r9
   22846:	lea    (%rax,%rdx,1),%rbx
   2284a:	lea    -0x1(%rcx),%rdx
   2284e:	shl    $0x3,%r8
   22852:	shl    $0x5,%r10
   22856:	shr    $0x2,%rdx
   2285a:	mov    %rbx,-0x48(%rsp)
   2285f:	shl    $0x3,%rdi
   22863:	xor    %r12d,%r12d
   22866:	lea    (%rcx,%rdx,2),%rdx
   2286a:	lea    0x20(%rax),%r14
   2286e:	lea    (%rdx,%rdx,1),%rbx
   22872:	mov    %rbx,-0x50(%rsp)
   22877:	mov    -0x48(%rsp),%rbx
   2287c:	lea    0x0(,%r12,8),%rdx
   22884:	lea    (%rdx,%r15,1),%rax
   22888:	add    %rbx,%rdx
   2288b:	mov    -0x50(%rsp),%rbx
   22890:	add    %r12,%rbx
   22893:	lea    (%r14,%rbx,8),%rbx
   22897:	nopw   0x0(%rax,%rax,1)
   228a0:	vmovupd (%rax,%r11,1),%ymm3
   228a6:	vmovupd (%rax),%ymm7
   228aa:	vsubpd (%rax,%r9,1),%ymm3,%ymm9
   228b0:	vaddpd (%rax,%rcx,8),%ymm7,%ymm14
   228b5:	vaddpd (%rax,%r9,1),%ymm3,%ymm15
   228bb:	vsubpd (%rax,%rcx,8),%ymm7,%ymm8
   228c0:	vmovupd (%rax,%rsi,1),%ymm1
   228c5:	vaddpd (%rax,%r8,1),%ymm1,%ymm13
   228cb:	vsubpd (%rax,%r8,1),%ymm1,%ymm0
   228d1:	vmovupd (%rdx,%r10,1),%ymm1
   228d7:	vaddpd (%rdx,%rdi,1),%ymm1,%ymm1
   228dc:	vmovupd (%rax,%r10,1),%ymm3
   228e2:	vmovupd (%rdx,%r10,1),%ymm10
   228e8:	vaddpd (%rax,%rdi,1),%ymm3,%ymm2
   228ed:	vsubpd (%rax,%rdi,1),%ymm3,%ymm7
   228f2:	vmovupd (%rdx,%r11,1),%ymm4
   228f8:	vmovapd %ymm1,-0x20(%rsp)
   228fe:	vsubpd (%rdx,%rdi,1),%ymm10,%ymm1
   22903:	vaddpd %ymm14,%ymm15,%ymm10
   22908:	vmovupd (%rdx),%ymm3
   2290c:	vsubpd %ymm14,%ymm15,%ymm15
   22911:	vaddpd %ymm8,%ymm9,%ymm14
   22916:	vsubpd %ymm8,%ymm9,%ymm8
   2291b:	vsubpd (%rdx,%r9,1),%ymm4,%ymm6
   22921:	vaddpd (%rdx,%rcx,8),%ymm3,%ymm11
   22926:	vsubpd (%rdx,%rcx,8),%ymm3,%ymm5
   2292b:	vaddpd (%rdx,%r9,1),%ymm4,%ymm12
   22931:	vmovupd (%rdx,%rsi,1),%ymm4
   22936:	vaddpd %ymm7,%ymm0,%ymm9
   2293a:	vaddpd (%rdx,%r8,1),%ymm4,%ymm3
   22940:	vmovapd %ymm8,-0x40(%rsp)
   22946:	vsubpd (%rdx,%r8,1),%ymm4,%ymm4
   2294c:	vaddpd %ymm2,%ymm13,%ymm8
   22950:	vsubpd %ymm7,%ymm0,%ymm0
   22954:	vsubpd %ymm2,%ymm13,%ymm2
   22958:	vaddpd %ymm11,%ymm12,%ymm7
   2295d:	vsubpd %ymm5,%ymm6,%ymm13
   22961:	vsubpd %ymm11,%ymm12,%ymm12
   22966:	vaddpd %ymm5,%ymm6,%ymm11
   2296a:	vmovapd -0x20(%rsp),%ymm6
   22970:	vaddpd %ymm6,%ymm3,%ymm5
   22974:	vsubpd %ymm6,%ymm3,%ymm3
   22978:	vaddpd %ymm1,%ymm4,%ymm6
   2297c:	vsubpd %ymm1,%ymm4,%ymm1
   22980:	vaddpd %ymm8,%ymm10,%ymm4
   22985:	vsubpd %ymm8,%ymm10,%ymm8
   2298a:	vaddpd %ymm2,%ymm15,%ymm10
   2298e:	vsubpd %ymm2,%ymm15,%ymm2
   22992:	vmovapd -0x40(%rsp),%ymm15
   22998:	vmovapd %ymm4,-0x20(%rsp)
   2299e:	vaddpd %ymm9,%ymm14,%ymm4
   229a3:	vsubpd %ymm9,%ymm14,%ymm9
   229a8:	vaddpd %ymm15,%ymm0,%ymm14
   229ad:	vsubpd %ymm0,%ymm15,%ymm0
   229b1:	vaddpd %ymm5,%ymm7,%ymm15
   229b5:	vsubpd %ymm5,%ymm7,%ymm5
   229b9:	vaddpd %ymm6,%ymm11,%ymm7
   229bd:	vsubpd %ymm6,%ymm11,%ymm6
   229c1:	vaddpd %ymm3,%ymm12,%ymm11
   229c5:	vsubpd %ymm3,%ymm12,%ymm3
   229c9:	vaddpd %ymm1,%ymm13,%ymm12
   229cd:	vsubpd %ymm1,%ymm13,%ymm1
   229d1:	vaddpd -0x20(%rsp),%ymm15,%ymm13
   229d7:	vmovupd %ymm13,(%rax,%r11,1)
   229dd:	vaddpd %ymm7,%ymm4,%ymm13
   229e1:	vsubpd %ymm7,%ymm4,%ymm4
   229e5:	vmovupd %ymm13,(%rax,%r9,1)
   229eb:	vaddpd %ymm11,%ymm10,%ymm13
   229f0:	vsubpd %ymm11,%ymm10,%ymm10
   229f5:	vmovupd %ymm13,(%rax)
   229f9:	vaddpd %ymm12,%ymm14,%ymm13
   229fe:	vsubpd %ymm12,%ymm14,%ymm14
   22a03:	vmovupd %ymm13,(%rax,%rcx,8)
   22a08:	vaddpd %ymm5,%ymm8,%ymm13
   22a0c:	vsubpd %ymm5,%ymm8,%ymm8
   22a10:	add    $0x20,%rax
   22a14:	vmovupd %ymm13,-0x20(%rax,%rsi,1)
   22a1a:	vaddpd %ymm6,%ymm9,%ymm13
   22a1e:	vsubpd %ymm6,%ymm9,%ymm9
   22a22:	vmovupd %ymm13,-0x20(%rax,%r8,1)
   22a29:	vaddpd %ymm3,%ymm2,%ymm13
   22a2d:	vsubpd %ymm3,%ymm2,%ymm2
   22a31:	vmovupd %ymm13,-0x20(%rax,%r10,1)
   22a38:	vaddpd %ymm1,%ymm0,%ymm13
   22a3c:	vsubpd %ymm1,%ymm0,%ymm0
   22a40:	vmovupd %ymm13,-0x20(%rax,%rdi,1)
   22a46:	vmovapd -0x20(%rsp),%ymm13
   22a4c:	vsubpd %ymm15,%ymm13,%ymm13
   22a51:	vmovupd %ymm13,(%rdx,%r11,1)
   22a57:	vmovupd %ymm4,(%rdx,%r9,1)
   22a5d:	vmovupd %ymm10,(%rdx)
   22a61:	vmovupd %ymm14,(%rdx,%rcx,8)
   22a66:	add    $0x20,%rdx
   22a6a:	vmovupd %ymm8,-0x20(%rdx,%rsi,1)
   22a70:	vmovupd %ymm9,-0x20(%rdx,%r8,1)
   22a77:	vmovupd %ymm2,-0x20(%rdx,%r10,1)
   22a7e:	vmovupd %ymm0,-0x20(%rdx,%rdi,1)
   22a84:	cmp    %rbx,%rax
   22a87:	jne    228a0 <hstep_tb16_nat+0xc0>
   22a8d:	add    %rsi,%r12
   22a90:	cmp    %r13,%r12
   22a93:	jb     22877 <hstep_tb16_nat+0x97>
   22a99:	vzeroupper
   22a9c:	lea    -0x28(%rbp),%rsp
   22aa0:	pop    %rbx
   22aa1:	pop    %r12
   22aa3:	pop    %r13
   22aa5:	pop    %r14
   22aa7:	pop    %r15
   22aa9:	pop    %rbp
   22aaa:	ret
   22aab:	vzeroupper
   22aae:	ret
   22aaf:	nop

0000000000025030 <hfirst_g20_nat>:
   25030:	endbr64
   25034:	vbroadcastsd 0x29ad3(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
   2503d:	test   %rsi,%rsi
   25040:	je     25275 <hfirst_g20_nat+0x245>
   25046:	lea    -0x8(,%rsi,8),%rax
   2504e:	vxorpd %xmm0,%xmm0,%xmm0
   25052:	vbroadcastsd 0x29a25(%rip),%ymm1        # 4ea80 <FFHT_THR_D+0xa0>
   2505b:	xor    %al,%al
   2505d:	lea    0x100(%rdi,%rax,1),%rax
   25065:	nopl   (%rax)
   25068:	vpermilpd $0xf,(%rdi),%ymm3
   2506e:	vpermilpd $0x0,(%rdi),%ymm2
   25074:	add    $0x100,%rdi
   2507b:	vpermilpd $0xf,-0x80(%rdi),%ymm4
   25082:	vpermilpd $0x0,-0x60(%rdi),%ymm12
   25089:	vsubpd %ymm3,%ymm0,%ymm3
   2508d:	vpermilpd $0xf,-0x40(%rdi),%ymm10
   25094:	vpermilpd $0x0,-0xe0(%rdi),%ymm5
   2509e:	vpermilpd $0x0,-0xa0(%rdi),%ymm9
   250a8:	vsubpd %ymm4,%ymm0,%ymm4
   250ac:	vsubpd %ymm10,%ymm0,%ymm10
   250b1:	vaddsubpd %ymm3,%ymm2,%ymm2
   250b5:	vsubpd %ymm2,%ymm0,%ymm3
   250b9:	vperm2f128 $0x0,%ymm2,%ymm2,%ymm7
   250bf:	vperm2f128 $0x31,%ymm3,%ymm2,%ymm2
   250c5:	vpermilpd $0xf,-0xc0(%rdi),%ymm3
   250cf:	vaddpd %ymm2,%ymm7,%ymm7
   250d3:	vpermilpd $0xf,-0xe0(%rdi),%ymm2
   250dd:	vsubpd %ymm3,%ymm0,%ymm3
   250e1:	vsubpd %ymm2,%ymm0,%ymm2
   250e5:	vaddsubpd %ymm2,%ymm5,%ymm5
   250e9:	vsubpd %ymm5,%ymm0,%ymm2
   250ed:	vperm2f128 $0x0,%ymm5,%ymm5,%ymm6
   250f3:	vperm2f128 $0x31,%ymm2,%ymm5,%ymm5
   250f9:	vpermilpd $0x0,-0xc0(%rdi),%ymm2
   25103:	vaddpd %ymm5,%ymm6,%ymm6
   25107:	vaddsubpd %ymm3,%ymm2,%ymm2
   2510b:	vaddpd %ymm7,%ymm6,%ymm6
   2510f:	vsubpd %ymm2,%ymm0,%ymm3
   25113:	vperm2f128 $0x0,%ymm2,%ymm2,%ymm8
   25119:	vperm2f128 $0x31,%ymm3,%ymm2,%ymm2
   2511f:	vaddpd %ymm2,%ymm8,%ymm8
   25123:	vpermilpd $0xf,-0xa0(%rdi),%ymm2
   2512d:	vsubpd %ymm2,%ymm0,%ymm2
   25131:	vaddsubpd %ymm2,%ymm9,%ymm9
   25135:	vsubpd %ymm9,%ymm0,%ymm2
   2513a:	vperm2f128 $0x0,%ymm9,%ymm9,%ymm3
   25140:	vperm2f128 $0x31,%ymm2,%ymm9,%ymm9
   25146:	vpermilpd $0x0,-0x80(%rdi),%ymm2
   2514d:	vaddpd %ymm9,%ymm3,%ymm3
   25152:	vaddsubpd %ymm4,%ymm2,%ymm2
   25156:	vsubpd %ymm3,%ymm8,%ymm3
   2515a:	vsubpd %ymm2,%ymm0,%ymm4
   2515e:	vperm2f128 $0x0,%ymm2,%ymm2,%ymm11
   25164:	vsubpd %ymm3,%ymm6,%ymm5
   25168:	vperm2f128 $0x31,%ymm4,%ymm2,%ymm2
   2516e:	vaddpd %ymm2,%ymm11,%ymm11
   25172:	vpermilpd $0xf,-0x60(%rdi),%ymm2
   25179:	vfmadd132pd %ymm1,%ymm5,%ymm8
   2517e:	vfmsub231pd %ymm1,%ymm7,%ymm5
   25183:	vsubpd %ymm2,%ymm0,%ymm2
   25187:	vaddsubpd %ymm2,%ymm12,%ymm12
   2518b:	vsubpd %ymm12,%ymm0,%ymm4
   25190:	vperm2f128 $0x0,%ymm12,%ymm12,%ymm2
   25196:	vperm2f128 $0x31,%ymm4,%ymm12,%ymm12
   2519c:	vpermilpd $0x0,-0x40(%rdi),%ymm4
   251a3:	vaddpd %ymm12,%ymm2,%ymm2
   251a8:	vaddsubpd %ymm10,%ymm4,%ymm4
   251ad:	vaddpd %ymm11,%ymm2,%ymm2
   251b2:	vsubpd %ymm4,%ymm0,%ymm13
   251b6:	vperm2f128 $0x0,%ymm4,%ymm4,%ymm10
   251bc:	vperm2f128 $0x31,%ymm13,%ymm4,%ymm4
   251c2:	vpermilpd $0xf,-0x20(%rdi),%ymm13
   251c9:	vaddpd %ymm4,%ymm10,%ymm4
   251cd:	vpermilpd $0x0,-0x20(%rdi),%ymm10
   251d4:	vsubpd %ymm13,%ymm0,%ymm13
   251d9:	vaddsubpd %ymm13,%ymm10,%ymm10
   251de:	vsubpd %ymm10,%ymm0,%ymm14
   251e3:	vperm2f128 $0x0,%ymm10,%ymm10,%ymm13
   251e9:	vperm2f128 $0x31,%ymm14,%ymm10,%ymm10
   251ef:	vaddpd %ymm10,%ymm13,%ymm13
   251f4:	vsubpd %ymm13,%ymm4,%ymm13
   251f9:	vaddpd %ymm13,%ymm2,%ymm7
   251fe:	vfnmadd132pd %ymm1,%ymm7,%ymm4
   25203:	vfmsub231pd %ymm1,%ymm11,%ymm7
   25208:	vaddpd %ymm4,%ymm8,%ymm9
   2520c:	vfnmadd132pd %ymm1,%ymm9,%ymm2
   25211:	vfmsub231pd %ymm1,%ymm6,%ymm9
   25216:	vaddpd %ymm7,%ymm5,%ymm6
   2521a:	vfmadd132pd %ymm1,%ymm6,%ymm13
   2521f:	vfnmadd132pd %ymm1,%ymm6,%ymm3
   25224:	vfmsub132pd %ymm1,%ymm2,%ymm8
   25229:	vfmadd132pd %ymm1,%ymm9,%ymm4
   2522e:	vmovupd %ymm2,-0x80(%rdi)
   25233:	vmovupd %ymm9,-0x40(%rdi)
   25238:	vfmsub132pd %ymm1,%ymm13,%ymm5
   2523d:	vfnmadd132pd %ymm1,%ymm3,%ymm7
   25242:	vmovupd %ymm13,-0xe0(%rdi)
   2524a:	vmovupd %ymm3,-0xa0(%rdi)
   25252:	vmovupd %ymm8,-0x100(%rdi)
   2525a:	vmovupd %ymm4,-0xc0(%rdi)
   25262:	vmovupd %ymm5,-0x60(%rdi)
   25267:	vmovupd %ymm7,-0x20(%rdi)
   2526c:	cmp    %rdi,%rax
   2526f:	jne    25068 <hfirst_g20_nat+0x38>
   25275:	vzeroupper
   25278:	ret
   25279:	nopl   0x0(%rax)

0000000000025280 <hfirst_broken_g20>:
   25280:	endbr64
   25284:	vbroadcastsd 0x29883(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
   2528d:	test   %rsi,%rsi
   25290:	je     254c5 <hfirst_broken_g20+0x245>
   25296:	lea    -0x8(,%rsi,8),%rax
   2529e:	vxorpd %xmm0,%xmm0,%xmm0
   252a2:	vbroadcastsd 0x297d5(%rip),%ymm1        # 4ea80 <FFHT_THR_D+0xa0>
   252ab:	xor    %al,%al
   252ad:	lea    0x100(%rdi,%rax,1),%rax
   252b5:	nopl   (%rax)
   252b8:	vpermilpd $0xf,(%rdi),%ymm3
   252be:	vpermilpd $0x0,(%rdi),%ymm2
   252c4:	add    $0x100,%rdi
   252cb:	vpermilpd $0xf,-0x80(%rdi),%ymm4
   252d2:	vpermilpd $0x0,-0x60(%rdi),%ymm12
   252d9:	vsubpd %ymm3,%ymm0,%ymm3
   252dd:	vpermilpd $0xf,-0x40(%rdi),%ymm10
   252e4:	vpermilpd $0x0,-0xe0(%rdi),%ymm5
   252ee:	vpermilpd $0x0,-0xa0(%rdi),%ymm9
   252f8:	vsubpd %ymm4,%ymm0,%ymm4
   252fc:	vsubpd %ymm10,%ymm0,%ymm10
   25301:	vaddsubpd %ymm3,%ymm2,%ymm2
   25305:	vsubpd %ymm2,%ymm0,%ymm3
   25309:	vperm2f128 $0x0,%ymm2,%ymm2,%ymm7
   2530f:	vperm2f128 $0x31,%ymm3,%ymm2,%ymm2
   25315:	vpermilpd $0xf,-0xc0(%rdi),%ymm3
   2531f:	vaddpd %ymm2,%ymm7,%ymm7
   25323:	vpermilpd $0xf,-0xe0(%rdi),%ymm2
   2532d:	vsubpd %ymm3,%ymm0,%ymm3
   25331:	vsubpd %ymm2,%ymm0,%ymm2
   25335:	vaddsubpd %ymm2,%ymm5,%ymm5
   25339:	vsubpd %ymm5,%ymm0,%ymm2
   2533d:	vperm2f128 $0x0,%ymm5,%ymm5,%ymm6
   25343:	vperm2f128 $0x31,%ymm2,%ymm5,%ymm5
   25349:	vpermilpd $0x0,-0xc0(%rdi),%ymm2
   25353:	vaddpd %ymm5,%ymm6,%ymm6
   25357:	vaddsubpd %ymm3,%ymm2,%ymm2
   2535b:	vaddpd %ymm7,%ymm6,%ymm6
   2535f:	vsubpd %ymm2,%ymm0,%ymm3
   25363:	vperm2f128 $0x0,%ymm2,%ymm2,%ymm8
   25369:	vperm2f128 $0x31,%ymm3,%ymm2,%ymm2
   2536f:	vaddpd %ymm2,%ymm8,%ymm8
   25373:	vpermilpd $0xf,-0xa0(%rdi),%ymm2
   2537d:	vsubpd %ymm2,%ymm0,%ymm2
   25381:	vaddsubpd %ymm2,%ymm9,%ymm9
   25385:	vsubpd %ymm9,%ymm0,%ymm2
   2538a:	vperm2f128 $0x0,%ymm9,%ymm9,%ymm3
   25390:	vperm2f128 $0x31,%ymm2,%ymm9,%ymm9
   25396:	vpermilpd $0x0,-0x80(%rdi),%ymm2
   2539d:	vaddpd %ymm9,%ymm3,%ymm3
   253a2:	vaddsubpd %ymm4,%ymm2,%ymm2
   253a6:	vsubpd %ymm3,%ymm8,%ymm3
   253aa:	vsubpd %ymm2,%ymm0,%ymm4
   253ae:	vperm2f128 $0x0,%ymm2,%ymm2,%ymm11
   253b4:	vsubpd %ymm3,%ymm6,%ymm5
   253b8:	vperm2f128 $0x31,%ymm4,%ymm2,%ymm2
   253be:	vaddpd %ymm2,%ymm11,%ymm11
   253c2:	vpermilpd $0xf,-0x60(%rdi),%ymm2
   253c9:	vfmadd132pd %ymm1,%ymm5,%ymm8
   253ce:	vfmsub231pd %ymm1,%ymm7,%ymm5
   253d3:	vsubpd %ymm2,%ymm0,%ymm2
   253d7:	vaddsubpd %ymm2,%ymm12,%ymm12
   253db:	vsubpd %ymm12,%ymm0,%ymm4
   253e0:	vperm2f128 $0x0,%ymm12,%ymm12,%ymm2
   253e6:	vperm2f128 $0x31,%ymm4,%ymm12,%ymm12
   253ec:	vpermilpd $0x0,-0x40(%rdi),%ymm4
   253f3:	vaddpd %ymm12,%ymm2,%ymm2
   253f8:	vaddsubpd %ymm10,%ymm4,%ymm4
   253fd:	vaddpd %ymm11,%ymm2,%ymm2
   25402:	vsubpd %ymm4,%ymm0,%ymm13
   25406:	vperm2f128 $0x0,%ymm4,%ymm4,%ymm10
   2540c:	vperm2f128 $0x31,%ymm13,%ymm4,%ymm4
   25412:	vpermilpd $0xf,-0x20(%rdi),%ymm13
   25419:	vaddpd %ymm4,%ymm10,%ymm4
   2541d:	vpermilpd $0x0,-0x20(%rdi),%ymm10
   25424:	vsubpd %ymm13,%ymm0,%ymm13
   25429:	vaddsubpd %ymm13,%ymm10,%ymm10
   2542e:	vsubpd %ymm10,%ymm0,%ymm14
   25433:	vperm2f128 $0x0,%ymm10,%ymm10,%ymm13
   25439:	vperm2f128 $0x31,%ymm14,%ymm10,%ymm10
   2543f:	vaddpd %ymm10,%ymm13,%ymm13
   25444:	vsubpd %ymm13,%ymm4,%ymm13
   25449:	vaddpd %ymm13,%ymm2,%ymm7
   2544e:	vfnmadd132pd %ymm1,%ymm7,%ymm4
   25453:	vfmsub231pd %ymm1,%ymm11,%ymm7
   25458:	vaddpd %ymm4,%ymm8,%ymm9
   2545c:	vfnmadd132pd %ymm1,%ymm9,%ymm2
   25461:	vfmsub231pd %ymm1,%ymm6,%ymm9
   25466:	vaddpd %ymm7,%ymm5,%ymm6
   2546a:	vfmadd132pd %ymm1,%ymm6,%ymm13
   2546f:	vfnmadd132pd %ymm1,%ymm6,%ymm3
   25474:	vfmsub132pd %ymm1,%ymm2,%ymm8
   25479:	vfmadd132pd %ymm1,%ymm9,%ymm4
   2547e:	vmovupd %ymm2,-0x80(%rdi)
   25483:	vmovupd %ymm9,-0x60(%rdi)
   25488:	vfmsub132pd %ymm1,%ymm13,%ymm5
   2548d:	vfnmadd132pd %ymm1,%ymm3,%ymm7
   25492:	vmovupd %ymm13,-0xe0(%rdi)
   2549a:	vmovupd %ymm3,-0xa0(%rdi)
   254a2:	vmovupd %ymm8,-0x100(%rdi)
   254aa:	vmovupd %ymm4,-0xc0(%rdi)
   254b2:	vmovupd %ymm5,-0x40(%rdi)
   254b7:	vmovupd %ymm7,-0x20(%rdi)
   254bc:	cmp    %rdi,%rax
   254bf:	jne    252b8 <hfirst_broken_g20+0x38>
   254c5:	vzeroupper
   254c8:	ret
   254c9:	nopl   0x0(%rax)

0000000000027690 <hfirst_tb8_bal>:
   27690:	endbr64
   27694:	vbroadcastsd 0x27473(%rip),%ymm2        # 4eb10 <FFHT_THR_D+0x130>
   2769d:	test   %rsi,%rsi
   276a0:	je     2790b <hfirst_tb8_bal+0x27b>
   276a6:	lea    -0x8(,%rsi,8),%rax
   276ae:	vxorpd %xmm0,%xmm0,%xmm0
   276b2:	xor    %al,%al
   276b4:	lea    0x100(%rdi,%rax,1),%rax
   276bc:	nopl   0x0(%rax)
   276c0:	vpermilpd $0xf,(%rdi),%ymm3
   276c6:	vpermilpd $0x0,(%rdi),%ymm1
   276cc:	add    $0x100,%rdi
   276d3:	vsubpd %ymm3,%ymm0,%ymm3
   276d7:	vaddsubpd %ymm3,%ymm1,%ymm1
   276db:	vsubpd %ymm1,%ymm0,%ymm3
   276df:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm6
   276e5:	vperm2f128 $0x31,%ymm3,%ymm1,%ymm1
   276eb:	vpermilpd $0xf,-0xe0(%rdi),%ymm3
   276f5:	vaddpd %ymm1,%ymm6,%ymm6
   276f9:	vpermilpd $0x0,-0xe0(%rdi),%ymm1
   27703:	vsubpd %ymm3,%ymm0,%ymm3
   27707:	vaddsubpd %ymm3,%ymm1,%ymm1
   2770b:	vsubpd %ymm1,%ymm0,%ymm3
   2770f:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm4
   27715:	vperm2f128 $0x31,%ymm3,%ymm1,%ymm1
   2771b:	vpermilpd $0xf,-0xc0(%rdi),%ymm3
   27725:	vaddpd %ymm1,%ymm4,%ymm4
   27729:	vpermilpd $0x0,-0xc0(%rdi),%ymm1
   27733:	vsubpd %ymm3,%ymm0,%ymm3
   27737:	vaddsubpd %ymm3,%ymm1,%ymm1
   2773b:	vsubpd %ymm1,%ymm0,%ymm3
   2773f:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm5
   27745:	vperm2f128 $0x31,%ymm3,%ymm1,%ymm1
   2774b:	vpermilpd $0x0,-0xa0(%rdi),%ymm3
   27755:	vaddpd %ymm1,%ymm5,%ymm5
   27759:	vpermilpd $0xf,-0xa0(%rdi),%ymm1
   27763:	vsubpd %ymm1,%ymm0,%ymm1
   27767:	vaddsubpd %ymm1,%ymm3,%ymm3
   2776b:	vsubpd %ymm3,%ymm0,%ymm7
   2776f:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm1
   27775:	vperm2f128 $0x31,%ymm7,%ymm3,%ymm3
   2777b:	vpermilpd $0xf,-0x80(%rdi),%ymm7
   27782:	vaddpd %ymm3,%ymm1,%ymm1
   27786:	vpermilpd $0x0,-0x80(%rdi),%ymm3
   2778d:	vsubpd %ymm7,%ymm0,%ymm7
   27791:	vaddsubpd %ymm7,%ymm3,%ymm3
   27795:	vsubpd %ymm3,%ymm0,%ymm8
   27799:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm7
   2779f:	vperm2f128 $0x31,%ymm8,%ymm3,%ymm3
   277a5:	vpermilpd $0xf,-0x60(%rdi),%ymm8
   277ac:	vaddpd %ymm3,%ymm7,%ymm7
   277b0:	vpermilpd $0x0,-0x60(%rdi),%ymm3
   277b7:	vsubpd %ymm8,%ymm0,%ymm8
   277bc:	vaddsubpd %ymm8,%ymm3,%ymm3
   277c1:	vsubpd %ymm3,%ymm0,%ymm9
   277c5:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm8
   277cb:	vperm2f128 $0x31,%ymm9,%ymm3,%ymm3
   277d1:	vpermilpd $0xf,-0x40(%rdi),%ymm9
   277d8:	vaddpd %ymm3,%ymm8,%ymm8
   277dc:	vpermilpd $0x0,-0x40(%rdi),%ymm3
   277e3:	vsubpd %ymm9,%ymm0,%ymm9
   277e8:	vmovapd %ymm8,%ymm12
   277ed:	vsubpd %ymm8,%ymm7,%ymm8
   277f2:	vaddsubpd %ymm9,%ymm3,%ymm3
   277f7:	vfmadd132pd %ymm2,%ymm7,%ymm12
   277fc:	vsubpd %ymm3,%ymm0,%ymm9
   27800:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm10
   27806:	vperm2f128 $0x31,%ymm9,%ymm3,%ymm3
   2780c:	vpermilpd $0xf,-0x20(%rdi),%ymm9
   27813:	vaddpd %ymm3,%ymm10,%ymm10
   27817:	vpermilpd $0x0,-0x20(%rdi),%ymm3
   2781e:	vsubpd %ymm9,%ymm0,%ymm9
   27823:	vaddsubpd %ymm9,%ymm3,%ymm3
   27828:	vsubpd %ymm3,%ymm0,%ymm11
   2782c:	vperm2f128 $0x0,%ymm3,%ymm3,%ymm9
   27832:	vperm2f128 $0x31,%ymm11,%ymm3,%ymm3
   27838:	vmovapd %ymm4,%ymm11
   2783c:	vsubpd %ymm4,%ymm6,%ymm4
   27840:	vaddpd %ymm3,%ymm9,%ymm9
   27844:	vfmadd132pd %ymm2,%ymm6,%ymm11
   27849:	vmovapd %ymm1,%ymm3
   2784d:	vfmadd132pd %ymm2,%ymm5,%ymm3
   27852:	vsubpd %ymm1,%ymm5,%ymm1
   27856:	vmovapd %ymm9,%ymm7
   2785a:	vsubpd %ymm9,%ymm10,%ymm6
   2785f:	vfmadd132pd %ymm2,%ymm10,%ymm7
   27864:	vmovapd %ymm1,%ymm5
   27868:	vsubpd %ymm1,%ymm4,%ymm1
   2786c:	vfmadd132pd %ymm2,%ymm4,%ymm5
   27871:	vmovapd %ymm6,%ymm10
   27875:	vmovapd %ymm3,%ymm9
   27879:	vsubpd %ymm6,%ymm8,%ymm6
   2787d:	vfmadd132pd %ymm2,%ymm8,%ymm10
   27882:	vfmadd132pd %ymm2,%ymm11,%ymm9
   27887:	vsubpd %ymm3,%ymm11,%ymm3
   2788b:	vmovapd %ymm7,%ymm4
   2788f:	vsubpd %ymm7,%ymm12,%ymm7
   27893:	vmovapd %ymm6,%ymm8
   27897:	vfmadd132pd %ymm2,%ymm12,%ymm4
   2789c:	vfmadd132pd %ymm2,%ymm1,%ymm8
   278a1:	vsubpd %ymm6,%ymm1,%ymm1
   278a5:	vmovapd %ymm10,%ymm12
   278aa:	vmovapd %ymm7,%ymm11
   278ae:	vfmadd132pd %ymm2,%ymm5,%ymm12
   278b3:	vfmadd132pd %ymm2,%ymm3,%ymm11
   278b8:	vsubpd %ymm10,%ymm5,%ymm5
   278bd:	vmovupd %ymm1,-0x20(%rdi)
   278c2:	vsubpd %ymm7,%ymm3,%ymm3
   278c6:	vmovapd %ymm4,%ymm13
   278ca:	vsubpd %ymm4,%ymm9,%ymm4
   278ce:	vmovupd %ymm8,-0xa0(%rdi)
   278d6:	vfmadd132pd %ymm2,%ymm9,%ymm13
   278db:	vmovupd %ymm5,-0x60(%rdi)
   278e0:	vmovupd %ymm3,-0x40(%rdi)
   278e5:	vmovupd %ymm12,-0xe0(%rdi)
   278ed:	vmovupd %ymm11,-0xc0(%rdi)
   278f5:	vmovupd %ymm4,-0x80(%rdi)
   278fa:	vmovupd %ymm13,-0x100(%rdi)
   27902:	cmp    %rdi,%rax
   27905:	jne    276c0 <hfirst_tb8_bal+0x30>
   2790b:	vzeroupper
   2790e:	ret
   2790f:	nop

000000000002c5d0 <hfirst_tb16_nat>:
   2c5d0:	endbr64
   2c5d4:	vbroadcastsd 0x22533(%rip),%ymm0        # 4eb10 <FFHT_THR_D+0x130>
   2c5dd:	test   %rsi,%rsi
   2c5e0:	je     2cb05 <hfirst_tb16_nat+0x535>
   2c5e6:	push   %rbp
   2c5e7:	lea    -0x8(,%rsi,8),%rdx
   2c5ef:	mov    %rdi,%rax
   2c5f2:	vxorpd %xmm4,%xmm4,%xmm4
   2c5f6:	and    $0xfffffffffffffe00,%rdx
   2c5fd:	lea    0x200(%rdi,%rdx,1),%rdx
   2c605:	mov    %rsp,%rbp
   2c608:	and    $0xffffffffffffffe0,%rsp
   2c60c:	sub    $0x28,%rsp
   2c610:	vpermilpd $0xf,(%rax),%ymm1
   2c616:	vpermilpd $0x0,(%rax),%ymm0
   2c61c:	add    $0x200,%rax
   2c622:	vsubpd %ymm1,%ymm4,%ymm1
   2c626:	vaddsubpd %ymm1,%ymm0,%ymm0
   2c62a:	vsubpd %ymm0,%ymm4,%ymm1
   2c62e:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm8
   2c634:	vperm2f128 $0x31,%ymm1,%ymm0,%ymm0
   2c63a:	vpermilpd $0xf,-0x1e0(%rax),%ymm1
   2c644:	vaddpd %ymm0,%ymm8,%ymm8
   2c648:	vpermilpd $0x0,-0x1e0(%rax),%ymm0
   2c652:	vsubpd %ymm1,%ymm4,%ymm1
   2c656:	vaddsubpd %ymm1,%ymm0,%ymm0
   2c65a:	vsubpd %ymm0,%ymm4,%ymm1
   2c65e:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm14
   2c664:	vperm2f128 $0x31,%ymm1,%ymm0,%ymm0
   2c66a:	vpermilpd $0xf,-0x1c0(%rax),%ymm1
   2c674:	vaddpd %ymm0,%ymm14,%ymm14
   2c678:	vpermilpd $0x0,-0x1c0(%rax),%ymm0
   2c682:	vsubpd %ymm1,%ymm4,%ymm1
   2c686:	vaddsubpd %ymm1,%ymm0,%ymm0
   2c68a:	vsubpd %ymm0,%ymm4,%ymm1
   2c68e:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm7
   2c694:	vperm2f128 $0x31,%ymm1,%ymm0,%ymm0
   2c69a:	vpermilpd $0xf,-0x1a0(%rax),%ymm1
   2c6a4:	vaddpd %ymm0,%ymm7,%ymm7
   2c6a8:	vpermilpd $0x0,-0x1a0(%rax),%ymm0
   2c6b2:	vsubpd %ymm1,%ymm4,%ymm1
   2c6b6:	vaddsubpd %ymm1,%ymm0,%ymm0
   2c6ba:	vsubpd %ymm0,%ymm4,%ymm1
   2c6be:	vperm2f128 $0x0,%ymm0,%ymm0,%ymm13
   2c6c4:	vperm2f128 $0x31,%ymm1,%ymm0,%ymm0
   2c6ca:	vpermilpd $0x0,-0x180(%rax),%ymm1
   2c6d4:	vaddpd %ymm0,%ymm13,%ymm13
   2c6d8:	vpermilpd $0xf,-0x180(%rax),%ymm0
   2c6e2:	vsubpd %ymm0,%ymm4,%ymm0
   2c6e6:	vaddsubpd %ymm0,%ymm1,%ymm1
   2c6ea:	vsubpd %ymm1,%ymm4,%ymm2
   2c6ee:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm0
   2c6f4:	vperm2f128 $0x31,%ymm2,%ymm1,%ymm1
   2c6fa:	vpermilpd $0xf,-0x160(%rax),%ymm2
   2c704:	vaddpd %ymm1,%ymm0,%ymm0
   2c708:	vpermilpd $0x0,-0x160(%rax),%ymm1
   2c712:	vsubpd %ymm2,%ymm4,%ymm2
   2c716:	vaddsubpd %ymm2,%ymm1,%ymm1
   2c71a:	vsubpd %ymm1,%ymm4,%ymm2
   2c71e:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm12
   2c724:	vperm2f128 $0x31,%ymm2,%ymm1,%ymm1
   2c72a:	vpermilpd $0xf,-0x140(%rax),%ymm2
   2c734:	vaddpd %ymm1,%ymm12,%ymm12
   2c738:	vpermilpd $0x0,-0x140(%rax),%ymm1
   2c742:	vsubpd %ymm2,%ymm4,%ymm2
   2c746:	vaddsubpd %ymm2,%ymm1,%ymm1
   2c74a:	vsubpd %ymm1,%ymm4,%ymm2
   2c74e:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm6
   2c754:	vperm2f128 $0x31,%ymm2,%ymm1,%ymm1
   2c75a:	vpermilpd $0xf,-0x120(%rax),%ymm2
   2c764:	vaddpd %ymm1,%ymm6,%ymm6
   2c768:	vpermilpd $0x0,-0x120(%rax),%ymm1
   2c772:	vsubpd %ymm2,%ymm4,%ymm2
   2c776:	vaddsubpd %ymm2,%ymm1,%ymm1
   2c77a:	vsubpd %ymm1,%ymm4,%ymm2
   2c77e:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm11
   2c784:	vperm2f128 $0x31,%ymm2,%ymm1,%ymm1
   2c78a:	vpermilpd $0xf,-0x100(%rax),%ymm2
   2c794:	vaddpd %ymm1,%ymm11,%ymm11
   2c798:	vpermilpd $0x0,-0x100(%rax),%ymm1
   2c7a2:	vsubpd %ymm2,%ymm4,%ymm2
   2c7a6:	vaddsubpd %ymm2,%ymm1,%ymm1
   2c7aa:	vsubpd %ymm1,%ymm4,%ymm2
   2c7ae:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm10
   2c7b4:	vperm2f128 $0x31,%ymm2,%ymm1,%ymm1
   2c7ba:	vpermilpd $0xf,-0xe0(%rax),%ymm2
   2c7c4:	vaddpd %ymm1,%ymm10,%ymm10
   2c7c8:	vpermilpd $0x0,-0xe0(%rax),%ymm1
   2c7d2:	vsubpd %ymm2,%ymm4,%ymm2
   2c7d6:	vaddsubpd %ymm2,%ymm1,%ymm1
   2c7da:	vsubpd %ymm1,%ymm4,%ymm3
   2c7de:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm2
   2c7e4:	vperm2f128 $0x31,%ymm3,%ymm1,%ymm1
   2c7ea:	vpermilpd $0xf,-0xc0(%rax),%ymm3
   2c7f4:	vaddpd %ymm1,%ymm2,%ymm2
   2c7f8:	vpermilpd $0x0,-0xc0(%rax),%ymm1
   2c802:	vsubpd %ymm3,%ymm4,%ymm3
   2c806:	vaddsubpd %ymm3,%ymm1,%ymm1
   2c80a:	vsubpd %ymm1,%ymm4,%ymm3
   2c80e:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm5
   2c814:	vperm2f128 $0x31,%ymm3,%ymm1,%ymm1
   2c81a:	vpermilpd $0xf,-0xa0(%rax),%ymm3
   2c824:	vaddpd %ymm1,%ymm5,%ymm5
   2c828:	vpermilpd $0x0,-0xa0(%rax),%ymm1
   2c832:	vsubpd %ymm3,%ymm4,%ymm3
   2c836:	vaddsubpd %ymm3,%ymm1,%ymm1
   2c83a:	vsubpd %ymm1,%ymm4,%ymm9
   2c83e:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm3
   2c844:	vperm2f128 $0x31,%ymm9,%ymm1,%ymm1
   2c84a:	vaddpd %ymm1,%ymm3,%ymm3
   2c84e:	vpermilpd $0x0,-0x80(%rax),%ymm1
   2c855:	vmovapd %ymm3,-0x38(%rsp)
   2c85b:	vpermilpd $0xf,-0x80(%rax),%ymm3
   2c862:	vsubpd %ymm3,%ymm4,%ymm3
   2c866:	vaddsubpd %ymm3,%ymm1,%ymm1
   2c86a:	vsubpd %ymm1,%ymm4,%ymm9
   2c86e:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm3
   2c874:	vperm2f128 $0x31,%ymm9,%ymm1,%ymm1
   2c87a:	vaddpd %ymm1,%ymm3,%ymm1
   2c87e:	vpermilpd $0xf,-0x60(%rax),%ymm3
   2c885:	vsubpd %ymm3,%ymm4,%ymm3
   2c889:	vmovapd %ymm1,-0x58(%rsp)
   2c88f:	vpermilpd $0x0,-0x60(%rax),%ymm1
   2c896:	vaddsubpd %ymm3,%ymm1,%ymm1
   2c89a:	vsubpd %ymm1,%ymm4,%ymm9
   2c89e:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm3
   2c8a4:	vperm2f128 $0x31,%ymm9,%ymm1,%ymm1
   2c8aa:	vaddpd %ymm1,%ymm3,%ymm15
   2c8ae:	vpermilpd $0x0,-0x40(%rax),%ymm1
   2c8b5:	vmovapd %ymm15,-0x78(%rsp)
   2c8bb:	vpermilpd $0xf,-0x40(%rax),%ymm3
   2c8c2:	vsubpd %ymm3,%ymm4,%ymm3
   2c8c6:	vaddsubpd %ymm3,%ymm1,%ymm1
   2c8ca:	vsubpd %ymm1,%ymm4,%ymm9
   2c8ce:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm3
   2c8d4:	vperm2f128 $0x31,%ymm9,%ymm1,%ymm1
   2c8da:	vaddpd %ymm1,%ymm3,%ymm9
   2c8de:	vpermilpd $0xf,-0x20(%rax),%ymm3
   2c8e5:	vpermilpd $0x0,-0x20(%rax),%ymm1
   2c8ec:	vsubpd %ymm3,%ymm4,%ymm3
   2c8f0:	vaddsubpd %ymm3,%ymm1,%ymm1
   2c8f4:	vsubpd %ymm1,%ymm4,%ymm15
   2c8f8:	vperm2f128 $0x0,%ymm1,%ymm1,%ymm3
   2c8fe:	vperm2f128 $0x31,%ymm15,%ymm1,%ymm1
   2c904:	vaddpd %ymm14,%ymm8,%ymm15
   2c909:	vsubpd %ymm14,%ymm8,%ymm8
   2c90e:	vaddpd %ymm13,%ymm7,%ymm14
   2c913:	vsubpd %ymm13,%ymm7,%ymm7
   2c918:	vaddpd %ymm12,%ymm0,%ymm13
   2c91d:	vsubpd %ymm12,%ymm0,%ymm0
   2c922:	vaddpd %ymm2,%ymm10,%ymm12
   2c926:	vsubpd %ymm2,%ymm10,%ymm2
   2c92a:	vaddpd %ymm1,%ymm3,%ymm3
   2c92e:	vaddpd %ymm11,%ymm6,%ymm1
   2c933:	vmovapd %ymm0,-0x18(%rsp)
   2c939:	vsubpd %ymm11,%ymm6,%ymm6
   2c93e:	vmovapd -0x78(%rsp),%ymm0
   2c944:	vmovapd %ymm2,0x8(%rsp)
   2c94a:	vmovapd -0x38(%rsp),%ymm2
   2c950:	vaddpd %ymm2,%ymm5,%ymm11
   2c954:	vsubpd %ymm2,%ymm5,%ymm5
   2c958:	vmovapd -0x58(%rsp),%ymm2
   2c95e:	vaddpd %ymm2,%ymm0,%ymm10
   2c962:	vsubpd %ymm0,%ymm2,%ymm0
   2c966:	vaddpd %ymm3,%ymm9,%ymm2
   2c96a:	vsubpd %ymm3,%ymm9,%ymm3
   2c96e:	vaddpd %ymm14,%ymm15,%ymm9
   2c973:	vsubpd %ymm14,%ymm15,%ymm15
   2c978:	vaddpd %ymm7,%ymm8,%ymm14
   2c97c:	vsubpd %ymm7,%ymm8,%ymm7
   2c980:	vmovapd %ymm7,-0x38(%rsp)
   2c986:	vaddpd %ymm1,%ymm13,%ymm7
   2c98a:	vsubpd %ymm1,%ymm13,%ymm1
   2c98e:	vmovapd -0x18(%rsp),%ymm13
   2c994:	vaddpd %ymm13,%ymm6,%ymm8
   2c999:	vsubpd %ymm6,%ymm13,%ymm6
   2c99d:	vmovapd 0x8(%rsp),%ymm13
   2c9a3:	vsubpd %ymm5,%ymm13,%ymm13
   2c9a7:	vmovapd %ymm6,-0x58(%rsp)
   2c9ad:	vaddpd %ymm11,%ymm12,%ymm6
   2c9b2:	vsubpd %ymm11,%ymm12,%ymm12
   2c9b7:	vaddpd 0x8(%rsp),%ymm5,%ymm11
   2c9bd:	vaddpd %ymm10,%ymm2,%ymm5
   2c9c2:	vsubpd %ymm2,%ymm10,%ymm2
   2c9c6:	vaddpd %ymm0,%ymm3,%ymm10
   2c9ca:	vsubpd %ymm3,%ymm0,%ymm3
   2c9ce:	vaddpd %ymm7,%ymm9,%ymm0
   2c9d2:	vsubpd %ymm7,%ymm9,%ymm9
   2c9d6:	vaddpd %ymm8,%ymm14,%ymm7
   2c9db:	vsubpd %ymm8,%ymm14,%ymm8
   2c9e0:	vmovapd %ymm0,0x8(%rsp)
   2c9e6:	vmovapd -0x38(%rsp),%ymm0
   2c9ec:	vmovapd %ymm9,-0x18(%rsp)
   2c9f2:	vaddpd %ymm1,%ymm15,%ymm9
   2c9f6:	vsubpd %ymm1,%ymm15,%ymm1
   2c9fa:	vmovapd -0x58(%rsp),%ymm15
   2ca00:	vaddpd %ymm15,%ymm0,%ymm14
   2ca05:	vsubpd %ymm15,%ymm0,%ymm0
   2ca0a:	vaddpd %ymm5,%ymm6,%ymm15
   2ca0e:	vsubpd %ymm5,%ymm6,%ymm5
   2ca12:	vaddpd %ymm10,%ymm11,%ymm6
   2ca17:	vsubpd %ymm10,%ymm11,%ymm10
   2ca1c:	vaddpd %ymm2,%ymm12,%ymm11
   2ca20:	vsubpd %ymm2,%ymm12,%ymm2
   2ca24:	vaddpd %ymm3,%ymm13,%ymm12
   2ca28:	vsubpd %ymm3,%ymm13,%ymm3
   2ca2c:	vaddpd 0x8(%rsp),%ymm15,%ymm13
   2ca32:	vmovupd %ymm13,-0x200(%rax)
   2ca3a:	vaddpd %ymm6,%ymm7,%ymm13
   2ca3e:	vsubpd %ymm6,%ymm7,%ymm7
   2ca42:	vmovupd %ymm13,-0x1e0(%rax)
   2ca4a:	vaddpd %ymm11,%ymm9,%ymm13
   2ca4f:	vsubpd %ymm11,%ymm9,%ymm9
   2ca54:	vmovupd %ymm7,-0xe0(%rax)
   2ca5c:	vmovupd %ymm13,-0x1c0(%rax)
   2ca64:	vaddpd %ymm12,%ymm14,%ymm13
   2ca69:	vsubpd %ymm12,%ymm14,%ymm14
   2ca6e:	vmovupd %ymm9,-0xc0(%rax)
   2ca76:	vmovupd %ymm13,-0x1a0(%rax)
   2ca7e:	vaddpd -0x18(%rsp),%ymm5,%ymm13
   2ca84:	vmovupd %ymm14,-0xa0(%rax)
   2ca8c:	vmovupd %ymm13,-0x180(%rax)
   2ca94:	vaddpd %ymm10,%ymm8,%ymm13
   2ca99:	vsubpd %ymm10,%ymm8,%ymm8
   2ca9e:	vmovupd %ymm13,-0x160(%rax)
   2caa6:	vaddpd %ymm2,%ymm1,%ymm13
   2caaa:	vsubpd %ymm2,%ymm1,%ymm1
   2caae:	vmovupd %ymm13,-0x140(%rax)
   2cab6:	vaddpd %ymm3,%ymm0,%ymm13
   2caba:	vsubpd %ymm3,%ymm0,%ymm0
   2cabe:	vmovupd %ymm13,-0x120(%rax)
   2cac6:	vmovapd 0x8(%rsp),%ymm13
   2cacc:	vsubpd %ymm15,%ymm13,%ymm13
   2cad1:	vmovupd %ymm13,-0x100(%rax)
   2cad9:	vmovapd -0x18(%rsp),%ymm13
   2cadf:	vmovupd %ymm8,-0x60(%rax)
   2cae4:	vsubpd %ymm5,%ymm13,%ymm5
   2cae8:	vmovupd %ymm1,-0x40(%rax)
   2caed:	vmovupd %ymm0,-0x20(%rax)
   2caf2:	vmovupd %ymm5,-0x80(%rax)
   2caf7:	cmp    %rax,%rdx
   2cafa:	jne    2c610 <hfirst_tb16_nat+0x40>
   2cb00:	vzeroupper
   2cb03:	leave
   2cb04:	ret
   2cb05:	vzeroupper
   2cb08:	ret
   2cb09:	nopl   0x0(%rax)

