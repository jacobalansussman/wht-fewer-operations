0000000000005ef0 <hstep_tb2_nat>:
    5ef0:	endbr64
    5ef4:	vbroadcastsd 0x45ce2(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
    5efe:	test   %rsi,%rsi
    5f01:	je     5f67 <hstep_tb2_nat+0x77>
    5f03:	lea    (%rdx,%rdx,1),%r11
    5f07:	test   %rdx,%rdx
    5f0a:	je     5f67 <hstep_tb2_nat+0x77>
    5f0c:	lea    -0x1(%rdx),%r9
    5f10:	xor    %r8d,%r8d
    5f13:	lea    0x40(%rdi),%r10
    5f17:	and    $0xfffffffffffffff8,%r9
    5f1b:	nopl   0x0(%rax,%rax,1)
    5f20:	lea    (%r9,%r8,1),%rcx
    5f24:	lea    (%rdi,%r8,8),%rax
    5f28:	lea    (%r10,%rcx,8),%rcx
    5f2c:	nopl   0x0(%rax)
    5f30:	vmovupd (%rax),%zmm0
    5f36:	vmovupd (%rax,%rdx,8),%zmm1
    5f3d:	vaddpd %zmm1,%zmm0,%zmm2
    5f43:	vsubpd %zmm1,%zmm0,%zmm0
    5f49:	vmovupd %zmm2,(%rax)
    5f4f:	vmovupd %zmm0,(%rax,%rdx,8)
    5f56:	add    $0x40,%rax
    5f5a:	cmp    %rax,%rcx
    5f5d:	jne    5f30 <hstep_tb2_nat+0x40>
    5f5f:	add    %r11,%r8
    5f62:	cmp    %rsi,%r8
    5f65:	jb     5f20 <hstep_tb2_nat+0x30>
    5f67:	vzeroupper
    5f6a:	ret
    5f6b:	nopl   0x0(%rax,%rax,1)

0000000000005f70 <hstep_tb4_nat>:
    5f70:	endbr64
    5f74:	vbroadcastsd 0x45c62(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
    5f7e:	test   %rsi,%rsi
    5f81:	je     6047 <hstep_tb4_nat+0xd7>
    5f87:	push   %rbp
    5f88:	mov    %rsp,%rbp
    5f8b:	push   %r12
    5f8d:	lea    0x0(,%rdx,4),%r12
    5f95:	push   %rbx
    5f96:	test   %rdx,%rdx
    5f99:	je     603f <hstep_tb4_nat+0xcf>
    5f9f:	lea    -0x1(%rdx),%r11
    5fa3:	mov    %rdx,%r8
    5fa6:	lea    (%rdx,%rdx,2),%rcx
    5faa:	xor    %r10d,%r10d
    5fad:	shl    $0x4,%r8
    5fb1:	and    $0xfffffffffffffff8,%r11
    5fb5:	shl    $0x3,%rcx
    5fb9:	lea    0x40(%rdi),%rbx
    5fbd:	nopl   (%rax)
    5fc0:	lea    (%r11,%r10,1),%r9
    5fc4:	lea    (%rdi,%r10,8),%rax
    5fc8:	lea    (%rbx,%r9,8),%r9
    5fcc:	nopl   0x0(%rax)
    5fd0:	vmovupd (%rax),%zmm5
    5fd6:	vmovupd (%rax,%r8,1),%zmm7
    5fdd:	vaddpd (%rax,%rdx,8),%zmm5,%zmm2
    5fe4:	vaddpd (%rax,%rcx,1),%zmm7,%zmm3
    5feb:	vsubpd (%rax,%rdx,8),%zmm5,%zmm0
    5ff2:	vsubpd (%rax,%rcx,1),%zmm7,%zmm1
    5ff9:	vaddpd %zmm3,%zmm2,%zmm4
    5fff:	vsubpd %zmm3,%zmm2,%zmm2
    6005:	vmovupd %zmm4,(%rax)
    600b:	vaddpd %zmm1,%zmm0,%zmm4
    6011:	vsubpd %zmm1,%zmm0,%zmm0
    6017:	vmovupd %zmm4,(%rax,%rdx,8)
    601e:	add    $0x40,%rax
    6022:	vmovupd %zmm2,-0x40(%rax,%r8,1)
    602a:	vmovupd %zmm0,-0x40(%rax,%rcx,1)
    6032:	cmp    %rax,%r9
    6035:	jne    5fd0 <hstep_tb4_nat+0x60>
    6037:	add    %r12,%r10
    603a:	cmp    %rsi,%r10
    603d:	jb     5fc0 <hstep_tb4_nat+0x50>
    603f:	vzeroupper
    6042:	pop    %rbx
    6043:	pop    %r12
    6045:	pop    %rbp
    6046:	ret
    6047:	vzeroupper
    604a:	ret
    604b:	nopl   0x0(%rax,%rax,1)

0000000000006110 <hfirst_kid_nat>:
    6110:	endbr64
    6114:	vbroadcastsd 0x45ac2(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
    611e:	test   %rsi,%rsi
    6121:	je     61bf <hfirst_kid_nat+0xaf>
    6127:	lea    -0x8(,%rsi,8),%rax
    612f:	mov    $0xffffffaa,%edx
    6134:	vmovdqa64 0x45942(%rip),%zmm5        # 4ba80 <FFHT_THR_D+0x80>
    613e:	vmovdqa64 0x45978(%rip),%zmm4        # 4bac0 <FFHT_THR_D+0xc0>
    6148:	and    $0xffffffffffffffc0,%rax
    614c:	mov    $0xffffffcc,%ecx
    6151:	kmovw  %edx,%k3
    6155:	vmovdqa64 0x459a1(%rip),%zmm3        # 4bb00 <FFHT_THR_D+0x100>
    615f:	mov    $0xfffffff0,%edx
    6164:	lea    0x40(%rdi,%rax,1),%rax
    6169:	kmovw  %ecx,%k2
    616d:	kmovw  %edx,%k1
    6171:	nopl   0x0(%rax)
    6178:	vpermpd (%rdi),%zmm5,%zmm0
    617e:	vaddpd (%rdi),%zmm0,%zmm1
    6184:	add    $0x40,%rdi
    6188:	vsubpd -0x40(%rdi),%zmm0,%zmm1{%k3}
    618f:	vpermpd %zmm1,%zmm4,%zmm2
    6195:	vaddpd %zmm1,%zmm2,%zmm0
    619b:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
    61a1:	vpermpd %zmm0,%zmm3,%zmm2
    61a7:	vaddpd %zmm2,%zmm0,%zmm1
    61ad:	vsubpd %zmm0,%zmm2,%zmm1{%k1}
    61b3:	vmovupd %zmm1,-0x40(%rdi)
    61ba:	cmp    %rax,%rdi
    61bd:	jne    6178 <hfirst_kid_nat+0x68>
    61bf:	vzeroupper
    61c2:	ret
    61c3:	data16 cs nopw 0x0(%rax,%rax,1)
    61ce:	xchg   %ax,%ax

00000000000061d0 <hfirst_tb2_nat>:
    61d0:	endbr64
    61d4:	vbroadcastsd 0x45a02(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
    61de:	test   %rsi,%rsi
    61e1:	je     62cf <hfirst_tb2_nat+0xff>
    61e7:	lea    -0x8(,%rsi,8),%rax
    61ef:	mov    $0xffffffaa,%edx
    61f4:	vmovdqa64 0x45882(%rip),%zmm6        # 4ba80 <FFHT_THR_D+0x80>
    61fe:	vmovdqa64 0x458b8(%rip),%zmm5        # 4bac0 <FFHT_THR_D+0xc0>
    6208:	and    $0xffffffffffffff80,%rax
    620c:	mov    $0xffffffcc,%ecx
    6211:	kmovw  %edx,%k3
    6215:	vmovdqa64 0x458e1(%rip),%zmm4        # 4bb00 <FFHT_THR_D+0x100>
    621f:	mov    $0xfffffff0,%edx
    6224:	lea    0x80(%rdi,%rax,1),%rax
    622c:	kmovw  %ecx,%k2
    6230:	kmovw  %edx,%k1
    6234:	nopl   0x0(%rax)
    6238:	vpermpd (%rdi),%zmm6,%zmm1
    623e:	vaddpd (%rdi),%zmm1,%zmm0
    6244:	sub    $0xffffffffffffff80,%rdi
    6248:	vsubpd -0x80(%rdi),%zmm1,%zmm0{%k3}
    624f:	vpermpd %zmm0,%zmm5,%zmm2
    6255:	vaddpd %zmm0,%zmm2,%zmm1
    625b:	vsubpd %zmm0,%zmm2,%zmm1{%k2}
    6261:	vpermpd %zmm1,%zmm4,%zmm2
    6267:	vaddpd %zmm2,%zmm1,%zmm0
    626d:	vsubpd %zmm1,%zmm2,%zmm0{%k1}
    6273:	vpermpd -0x40(%rdi),%zmm6,%zmm1
    627a:	vaddpd -0x40(%rdi),%zmm1,%zmm2
    6281:	vsubpd -0x40(%rdi),%zmm1,%zmm2{%k3}
    6288:	vpermpd %zmm2,%zmm5,%zmm3
    628e:	vaddpd %zmm2,%zmm3,%zmm1
    6294:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
    629a:	vpermpd %zmm1,%zmm4,%zmm3
    62a0:	vaddpd %zmm3,%zmm1,%zmm2
    62a6:	vsubpd %zmm1,%zmm3,%zmm2{%k1}
    62ac:	vaddpd %zmm2,%zmm0,%zmm1
    62b2:	vsubpd %zmm2,%zmm0,%zmm0
    62b8:	vmovupd %zmm1,-0x80(%rdi)
    62bf:	vmovupd %zmm0,-0x40(%rdi)
    62c6:	cmp    %rax,%rdi
    62c9:	jne    6238 <hfirst_tb2_nat+0x68>
    62cf:	vzeroupper
    62d2:	ret
    62d3:	data16 cs nopw 0x0(%rax,%rax,1)
    62de:	xchg   %ax,%ax

00000000000062e0 <hfirst_tb4_nat>:
    62e0:	endbr64
    62e4:	vbroadcastsd 0x458f2(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
    62ee:	test   %rsi,%rsi
    62f1:	je     6485 <hfirst_tb4_nat+0x1a5>
    62f7:	mov    $0xffffffaa,%ecx
    62fc:	mov    %rdi,%rax
    62ff:	lea    -0x8(,%rsi,8),%rdx
    6307:	vmovdqa64 0x4576f(%rip),%zmm7        # 4ba80 <FFHT_THR_D+0x80>
    6311:	vmovdqa64 0x457a5(%rip),%zmm6        # 4bac0 <FFHT_THR_D+0xc0>
    631b:	xor    %dl,%dl
    631d:	kmovw  %ecx,%k3
    6321:	vmovdqa64 0x457d5(%rip),%zmm5        # 4bb00 <FFHT_THR_D+0x100>
    632b:	mov    $0xffffffcc,%ecx
    6330:	lea    0x100(%rdi,%rdx,1),%rdx
    6338:	kmovw  %ecx,%k2
    633c:	mov    $0xfffffff0,%ecx
    6341:	kmovw  %ecx,%k1
    6345:	nopl   (%rax)
    6348:	vpermpd (%rax),%zmm7,%zmm1
    634e:	vaddpd (%rax),%zmm1,%zmm0
    6354:	add    $0x100,%rax
    635a:	vsubpd -0x100(%rax),%zmm1,%zmm0{%k3}
    6361:	vpermpd %zmm0,%zmm6,%zmm2
    6367:	vaddpd %zmm2,%zmm0,%zmm1
    636d:	vsubpd %zmm0,%zmm2,%zmm1{%k2}
    6373:	vpermpd %zmm1,%zmm5,%zmm2
    6379:	vaddpd %zmm2,%zmm1,%zmm0
    637f:	vsubpd %zmm1,%zmm2,%zmm0{%k1}
    6385:	vpermpd -0xc0(%rax),%zmm7,%zmm1
    638c:	vaddpd -0xc0(%rax),%zmm1,%zmm2
    6393:	vsubpd -0xc0(%rax),%zmm1,%zmm2{%k3}
    639a:	vpermpd %zmm2,%zmm6,%zmm3
    63a0:	vaddpd %zmm3,%zmm2,%zmm1
    63a6:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
    63ac:	vpermpd %zmm1,%zmm5,%zmm2
    63b2:	vaddpd %zmm2,%zmm1,%zmm4
    63b8:	vsubpd %zmm1,%zmm2,%zmm4{%k1}
    63be:	vpermpd -0x80(%rax),%zmm7,%zmm2
    63c5:	vaddpd -0x80(%rax),%zmm2,%zmm1
    63cc:	vsubpd -0x80(%rax),%zmm2,%zmm1{%k3}
    63d3:	vpermpd %zmm1,%zmm6,%zmm3
    63d9:	vaddpd %zmm3,%zmm1,%zmm2
    63df:	vsubpd %zmm1,%zmm3,%zmm2{%k2}
    63e5:	vpermpd %zmm2,%zmm5,%zmm3
    63eb:	vaddpd %zmm3,%zmm2,%zmm1
    63f1:	vsubpd %zmm2,%zmm3,%zmm1{%k1}
    63f7:	vpermpd -0x40(%rax),%zmm7,%zmm2
    63fe:	vaddpd -0x40(%rax),%zmm2,%zmm3
    6405:	vsubpd -0x40(%rax),%zmm2,%zmm3{%k3}
    640c:	vpermpd %zmm3,%zmm6,%zmm8
    6412:	vaddpd %zmm3,%zmm8,%zmm2
    6418:	vsubpd %zmm3,%zmm8,%zmm2{%k2}
    641e:	vpermpd %zmm2,%zmm5,%zmm8
    6424:	vaddpd %zmm8,%zmm2,%zmm3
    642a:	vsubpd %zmm2,%zmm8,%zmm3{%k1}
    6430:	vaddpd %zmm4,%zmm0,%zmm2
    6436:	vsubpd %zmm4,%zmm0,%zmm0
    643c:	vaddpd %zmm1,%zmm3,%zmm4
    6442:	vsubpd %zmm3,%zmm1,%zmm1
    6448:	vaddpd %zmm4,%zmm2,%zmm3
    644e:	vsubpd %zmm4,%zmm2,%zmm2
    6454:	vmovupd %zmm3,-0x100(%rax)
    645b:	vaddpd %zmm1,%zmm0,%zmm3
    6461:	vsubpd %zmm1,%zmm0,%zmm0
    6467:	vmovupd %zmm2,-0x80(%rax)
    646e:	vmovupd %zmm3,-0xc0(%rax)
    6475:	vmovupd %zmm0,-0x40(%rax)
    647c:	cmp    %rdx,%rax
    647f:	jne    6348 <hfirst_tb4_nat+0x68>
    6485:	vzeroupper
    6488:	ret
    6489:	nopl   0x0(%rax)

0000000000008990 <hfirst_h20_nat>:
    8990:	endbr64
    8994:	vbroadcastsd 0x43242(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
    899e:	mov    %rdi,%rax
    89a1:	test   %rsi,%rsi
    89a4:	je     8c87 <hfirst_h20_nat+0x2f7>
    89aa:	lea    -0x8(,%rsi,8),%rdx
    89b2:	mov    $0xffffffaa,%ecx
    89b7:	vmovdqa64 0x430bf(%rip),%zmm7        # 4ba80 <FFHT_THR_D+0x80>
    89c1:	vmovdqa64 0x430f5(%rip),%zmm6        # 4bac0 <FFHT_THR_D+0xc0>
    89cb:	and    $0xfffffffffffffe00,%rdx
    89d2:	kmovw  %ecx,%k3
    89d6:	mov    $0xffffffcc,%ecx
    89db:	vmovdqa64 0x4311b(%rip),%zmm5        # 4bb00 <FFHT_THR_D+0x100>
    89e5:	vbroadcastsd 0x43151(%rip),%zmm9        # 4bb40 <FFHT_THR_D+0x140>
    89ef:	lea    0x200(%rdi,%rdx,1),%rdx
    89f7:	kmovw  %ecx,%k2
    89fb:	mov    $0xfffffff0,%edi
    8a00:	kmovw  %edi,%k1
    8a04:	nopl   0x0(%rax)
    8a08:	vpermpd (%rax),%zmm7,%zmm0
    8a0e:	vaddpd (%rax),%zmm0,%zmm1
    8a14:	add    $0x200,%rax
    8a1a:	vsubpd -0x200(%rax),%zmm0,%zmm1{%k3}
    8a21:	vpermpd %zmm1,%zmm6,%zmm2
    8a27:	vaddpd %zmm1,%zmm2,%zmm0
    8a2d:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
    8a33:	vpermpd %zmm0,%zmm5,%zmm1
    8a39:	vaddpd %zmm1,%zmm0,%zmm4
    8a3f:	vsubpd %zmm0,%zmm1,%zmm4{%k1}
    8a45:	vpermpd -0x1c0(%rax),%zmm7,%zmm0
    8a4c:	vaddpd -0x1c0(%rax),%zmm0,%zmm1
    8a53:	vsubpd -0x1c0(%rax),%zmm0,%zmm1{%k3}
    8a5a:	vpermpd %zmm1,%zmm6,%zmm2
    8a60:	vaddpd %zmm2,%zmm1,%zmm0
    8a66:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
    8a6c:	vpermpd %zmm0,%zmm5,%zmm1
    8a72:	vaddpd %zmm1,%zmm0,%zmm10
    8a78:	vsubpd %zmm0,%zmm1,%zmm10{%k1}
    8a7e:	vpermpd -0x180(%rax),%zmm7,%zmm0
    8a85:	vaddpd -0x180(%rax),%zmm0,%zmm1
    8a8c:	vsubpd -0x180(%rax),%zmm0,%zmm1{%k3}
    8a93:	vpermpd %zmm1,%zmm6,%zmm2
    8a99:	vaddpd %zmm2,%zmm1,%zmm0
    8a9f:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
    8aa5:	vpermpd %zmm0,%zmm5,%zmm1
    8aab:	vaddpd %zmm1,%zmm0,%zmm3
    8ab1:	vsubpd %zmm0,%zmm1,%zmm3{%k1}
    8ab7:	vpermpd -0x140(%rax),%zmm7,%zmm0
    8abe:	vaddpd -0x140(%rax),%zmm0,%zmm1
    8ac5:	vsubpd -0x140(%rax),%zmm0,%zmm1{%k3}
    8acc:	vpermpd %zmm1,%zmm6,%zmm2
    8ad2:	vaddpd %zmm2,%zmm1,%zmm0
    8ad8:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
    8ade:	vpermpd %zmm0,%zmm5,%zmm1
    8ae4:	vaddpd %zmm1,%zmm0,%zmm11
    8aea:	vsubpd %zmm0,%zmm1,%zmm11{%k1}
    8af0:	vpermpd -0x100(%rax),%zmm7,%zmm0
    8af7:	vaddpd -0x100(%rax),%zmm0,%zmm1
    8afe:	vsubpd -0x100(%rax),%zmm0,%zmm1{%k3}
    8b05:	vpermpd %zmm1,%zmm6,%zmm2
    8b0b:	vaddpd %zmm2,%zmm1,%zmm0
    8b11:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
    8b17:	vpermpd %zmm0,%zmm5,%zmm1
    8b1d:	vaddpd %zmm1,%zmm0,%zmm8
    8b23:	vsubpd %zmm0,%zmm1,%zmm8{%k1}
    8b29:	vpermpd -0xc0(%rax),%zmm7,%zmm0
    8b30:	vaddpd -0xc0(%rax),%zmm0,%zmm1
    8b37:	vsubpd -0xc0(%rax),%zmm0,%zmm1{%k3}
    8b3e:	vpermpd %zmm1,%zmm6,%zmm2
    8b44:	vaddpd %zmm2,%zmm1,%zmm0
    8b4a:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
    8b50:	vpermpd %zmm0,%zmm5,%zmm1
    8b56:	vaddpd %zmm1,%zmm0,%zmm16
    8b5c:	vsubpd %zmm0,%zmm1,%zmm16{%k1}
    8b62:	vpermpd -0x80(%rax),%zmm7,%zmm0
    8b69:	vaddpd -0x80(%rax),%zmm0,%zmm1
    8b70:	vsubpd -0x80(%rax),%zmm0,%zmm1{%k3}
    8b77:	vsubpd %zmm16,%zmm3,%zmm3
    8b7d:	vpermpd %zmm1,%zmm6,%zmm2
    8b83:	vaddpd %zmm2,%zmm1,%zmm0
    8b89:	vsubpd %zmm1,%zmm2,%zmm0{%k2}
    8b8f:	vpermpd %zmm0,%zmm5,%zmm1
    8b95:	vaddpd %zmm1,%zmm0,%zmm2
    8b9b:	vsubpd %zmm0,%zmm1,%zmm2{%k1}
    8ba1:	vpermpd -0x40(%rax),%zmm7,%zmm1
    8ba8:	vaddpd -0x40(%rax),%zmm1,%zmm0
    8baf:	vsubpd -0x40(%rax),%zmm1,%zmm0{%k3}
    8bb6:	vaddpd %zmm2,%zmm10,%zmm13
    8bbc:	vpermpd %zmm0,%zmm6,%zmm12
    8bc2:	vaddpd %zmm0,%zmm12,%zmm1
    8bc8:	vsubpd %zmm0,%zmm12,%zmm1{%k2}
    8bce:	vpermpd %zmm1,%zmm5,%zmm12
    8bd4:	vaddpd %zmm12,%zmm1,%zmm0
    8bda:	vsubpd %zmm1,%zmm12,%zmm0{%k1}
    8be0:	vsubpd %zmm8,%zmm11,%zmm12
    8be6:	vaddpd %zmm0,%zmm4,%zmm4
    8bec:	vaddpd %zmm12,%zmm3,%zmm15
    8bf2:	vsubpd %zmm13,%zmm4,%zmm14
    8bf8:	vsubpd %zmm15,%zmm14,%zmm1
    8bfe:	vfmsub231pd %zmm9,%zmm1,%zmm0
    8c04:	vfmsub132pd %zmm9,%zmm16,%zmm1
    8c0a:	vaddpd %zmm2,%zmm0,%zmm2
    8c10:	vsubpd %zmm8,%zmm1,%zmm8
    8c16:	vaddpd %zmm10,%zmm0,%zmm0
    8c1c:	vaddpd %zmm11,%zmm1,%zmm1
    8c22:	vsubpd %zmm8,%zmm4,%zmm4
    8c28:	vaddpd %zmm2,%zmm3,%zmm3
    8c2e:	vaddpd %zmm0,%zmm15,%zmm15
    8c34:	vsubpd %zmm1,%zmm14,%zmm14
    8c3a:	vmovupd %zmm0,-0x180(%rax)
    8c41:	vaddpd %zmm8,%zmm13,%zmm13
    8c47:	vaddpd %zmm2,%zmm12,%zmm12
    8c4d:	vmovupd %zmm1,-0x140(%rax)
    8c54:	vmovupd %zmm4,-0x200(%rax)
    8c5b:	vmovupd %zmm3,-0x1c0(%rax)
    8c62:	vmovupd %zmm15,-0x100(%rax)
    8c69:	vmovupd %zmm14,-0xc0(%rax)
    8c70:	vmovupd %zmm13,-0x80(%rax)
    8c77:	vmovupd %zmm12,-0x40(%rax)
    8c7e:	cmp    %rdx,%rax
    8c81:	jne    8a08 <hfirst_h20_nat+0x78>
    8c87:	vzeroupper
    8c8a:	ret
    8c8b:	nopl   0x0(%rax,%rax,1)

0000000000008ee0 <hfirst_g19_nat>:
    8ee0:	endbr64
    8ee4:	vbroadcastsd 0x42cf2(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
    8eee:	mov    %rdi,%rax
    8ef1:	test   %rsi,%rsi
    8ef4:	je     91dd <hfirst_g19_nat+0x2fd>
    8efa:	lea    -0x8(,%rsi,8),%rdx
    8f02:	mov    $0xffffffaa,%ecx
    8f07:	vmovdqa64 0x42b6f(%rip),%zmm7        # 4ba80 <FFHT_THR_D+0x80>
    8f11:	vmovdqa64 0x42ba5(%rip),%zmm6        # 4bac0 <FFHT_THR_D+0xc0>
    8f1b:	and    $0xfffffffffffffe00,%rdx
    8f22:	kmovw  %ecx,%k3
    8f26:	mov    $0xffffffcc,%ecx
    8f2b:	vmovdqa64 0x42bcb(%rip),%zmm5        # 4bb00 <FFHT_THR_D+0x100>
    8f35:	vbroadcastsd 0x42c09(%rip),%zmm0        # 4bb48 <FFHT_THR_D+0x148>
    8f3f:	lea    0x200(%rdi,%rdx,1),%rdx
    8f47:	kmovw  %ecx,%k2
    8f4b:	mov    $0xfffffff0,%edi
    8f50:	kmovw  %edi,%k1
    8f54:	nopl   0x0(%rax)
    8f58:	vpermpd (%rax),%zmm7,%zmm1
    8f5e:	vaddpd (%rax),%zmm1,%zmm2
    8f64:	add    $0x200,%rax
    8f6a:	vsubpd -0x200(%rax),%zmm1,%zmm2{%k3}
    8f71:	vpermpd %zmm2,%zmm6,%zmm3
    8f77:	vaddpd %zmm2,%zmm3,%zmm1
    8f7d:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
    8f83:	vpermpd %zmm1,%zmm5,%zmm2
    8f89:	vaddpd %zmm2,%zmm1,%zmm4
    8f8f:	vsubpd %zmm1,%zmm2,%zmm4{%k1}
    8f95:	vpermpd -0x1c0(%rax),%zmm7,%zmm2
    8f9c:	vaddpd -0x1c0(%rax),%zmm2,%zmm1
    8fa3:	vsubpd -0x1c0(%rax),%zmm2,%zmm1{%k3}
    8faa:	vpermpd %zmm1,%zmm6,%zmm3
    8fb0:	vaddpd %zmm3,%zmm1,%zmm2
    8fb6:	vsubpd %zmm1,%zmm3,%zmm2{%k2}
    8fbc:	vpermpd %zmm2,%zmm5,%zmm3
    8fc2:	vaddpd %zmm3,%zmm2,%zmm1
    8fc8:	vsubpd %zmm2,%zmm3,%zmm1{%k1}
    8fce:	vmovapd %zmm1,%zmm9
    8fd4:	vpermpd -0x180(%rax),%zmm7,%zmm1
    8fdb:	vaddpd -0x180(%rax),%zmm1,%zmm2
    8fe2:	vsubpd -0x180(%rax),%zmm1,%zmm2{%k3}
    8fe9:	vpermpd %zmm2,%zmm6,%zmm3
    8fef:	vaddpd %zmm3,%zmm2,%zmm1
    8ff5:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
    8ffb:	vpermpd %zmm1,%zmm5,%zmm2
    9001:	vaddpd %zmm2,%zmm1,%zmm3
    9007:	vsubpd %zmm1,%zmm2,%zmm3{%k1}
    900d:	vpermpd -0x140(%rax),%zmm7,%zmm1
    9014:	vaddpd -0x140(%rax),%zmm1,%zmm2
    901b:	vsubpd -0x140(%rax),%zmm1,%zmm2{%k3}
    9022:	vpermpd %zmm2,%zmm6,%zmm8
    9028:	vaddpd %zmm8,%zmm2,%zmm1
    902e:	vsubpd %zmm2,%zmm8,%zmm1{%k2}
    9034:	vpermpd %zmm1,%zmm5,%zmm2
    903a:	vaddpd %zmm2,%zmm1,%zmm8
    9040:	vsubpd %zmm1,%zmm2,%zmm8{%k1}
    9046:	vpermpd -0x100(%rax),%zmm7,%zmm1
    904d:	vaddpd -0x100(%rax),%zmm1,%zmm2
    9054:	vsubpd -0x100(%rax),%zmm1,%zmm2{%k3}
    905b:	vpermpd %zmm2,%zmm6,%zmm10
    9061:	vaddpd %zmm10,%zmm2,%zmm1
    9067:	vsubpd %zmm2,%zmm10,%zmm1{%k2}
    906d:	vpermpd %zmm1,%zmm5,%zmm2
    9073:	vaddpd %zmm2,%zmm1,%zmm10
    9079:	vsubpd %zmm1,%zmm2,%zmm10{%k1}
    907f:	vpermpd -0xc0(%rax),%zmm7,%zmm1
    9086:	vaddpd -0xc0(%rax),%zmm1,%zmm2
    908d:	vsubpd -0xc0(%rax),%zmm1,%zmm2{%k3}
    9094:	vpermpd %zmm2,%zmm6,%zmm11
    909a:	vaddpd %zmm11,%zmm2,%zmm1
    90a0:	vsubpd %zmm2,%zmm11,%zmm1{%k2}
    90a6:	vpermpd %zmm1,%zmm5,%zmm2
    90ac:	vaddpd %zmm2,%zmm1,%zmm11
    90b2:	vsubpd %zmm1,%zmm2,%zmm11{%k1}
    90b8:	vpermpd -0x80(%rax),%zmm7,%zmm1
    90bf:	vaddpd -0x80(%rax),%zmm1,%zmm2
    90c6:	vsubpd -0x80(%rax),%zmm1,%zmm2{%k3}
    90cd:	vsubpd %zmm11,%zmm3,%zmm3
    90d3:	vpermpd %zmm2,%zmm6,%zmm12
    90d9:	vaddpd %zmm12,%zmm2,%zmm1
    90df:	vsubpd %zmm2,%zmm12,%zmm1{%k2}
    90e5:	vpermpd %zmm1,%zmm5,%zmm12
    90eb:	vaddpd %zmm12,%zmm1,%zmm2
    90f1:	vsubpd %zmm1,%zmm12,%zmm2{%k1}
    90f7:	vpermpd -0x40(%rax),%zmm7,%zmm12
    90fe:	vaddpd -0x40(%rax),%zmm12,%zmm1
    9105:	vsubpd -0x40(%rax),%zmm12,%zmm1{%k3}
    910c:	vpermpd %zmm1,%zmm6,%zmm13
    9112:	vaddpd %zmm1,%zmm13,%zmm12
    9118:	vsubpd %zmm1,%zmm13,%zmm12{%k2}
    911e:	vpermpd %zmm12,%zmm5,%zmm13
    9124:	vaddpd %zmm13,%zmm12,%zmm1
    912a:	vsubpd %zmm12,%zmm13,%zmm1{%k1}
    9130:	vsubpd %zmm10,%zmm8,%zmm12
    9136:	vaddpd %zmm2,%zmm9,%zmm13
    913c:	vaddpd %zmm1,%zmm4,%zmm4
    9142:	vaddpd %zmm12,%zmm3,%zmm15
    9148:	vsubpd %zmm13,%zmm4,%zmm14
    914e:	vsubpd %zmm15,%zmm14,%zmm16
    9154:	vfnmadd132pd %zmm0,%zmm16,%zmm1
    915a:	vfnmadd132pd %zmm0,%zmm16,%zmm11
    9160:	vfmadd132pd %zmm0,%zmm1,%zmm2
    9166:	vfnmadd132pd %zmm0,%zmm11,%zmm10
    916c:	vfmadd132pd %zmm0,%zmm11,%zmm8
    9172:	vfmadd231pd %zmm0,%zmm9,%zmm1
    9178:	vfmadd132pd %zmm0,%zmm2,%zmm12
    917e:	vfmadd132pd %zmm0,%zmm2,%zmm3
    9184:	vfmsub132pd %zmm0,%zmm8,%zmm14
    918a:	vfmadd132pd %zmm0,%zmm10,%zmm13
    9190:	vmovupd %zmm1,-0x180(%rax)
    9197:	vfmadd132pd %zmm0,%zmm1,%zmm15
    919d:	vfmsub132pd %zmm0,%zmm10,%zmm4
    91a3:	vmovupd %zmm8,-0x140(%rax)
    91aa:	vmovupd %zmm3,-0x1c0(%rax)
    91b1:	vmovupd %zmm14,-0xc0(%rax)
    91b8:	vmovupd %zmm4,-0x200(%rax)
    91bf:	vmovupd %zmm15,-0x100(%rax)
    91c6:	vmovupd %zmm13,-0x80(%rax)
    91cd:	vmovupd %zmm12,-0x40(%rax)
    91d4:	cmp    %rdx,%rax
    91d7:	jne    8f58 <hfirst_g19_nat+0x78>
    91dd:	vzeroupper
    91e0:	ret
    91e1:	data16 cs nopw 0x0(%rax,%rax,1)
    91ec:	nopl   0x0(%rax)

00000000000091f0 <hfirst_tb8_nat>:
    91f0:	endbr64
    91f4:	vbroadcastsd 0x429e2(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
    91fe:	mov    %rdi,%rax
    9201:	test   %rsi,%rsi
    9204:	je     94fd <hfirst_tb8_nat+0x30d>
    920a:	lea    -0x8(,%rsi,8),%rdx
    9212:	mov    $0xffffffaa,%ecx
    9217:	vmovdqa64 0x4285f(%rip),%zmm4        # 4ba80 <FFHT_THR_D+0x80>
    9221:	vmovdqa64 0x42895(%rip),%zmm3        # 4bac0 <FFHT_THR_D+0xc0>
    922b:	and    $0xfffffffffffffe00,%rdx
    9232:	kmovw  %ecx,%k3
    9236:	mov    $0xffffffcc,%ecx
    923b:	vmovdqa64 0x428bb(%rip),%zmm2        # 4bb00 <FFHT_THR_D+0x100>
    9245:	lea    0x200(%rdi,%rdx,1),%rdx
    924d:	mov    $0xfffffff0,%edi
    9252:	kmovw  %ecx,%k2
    9256:	kmovw  %edi,%k1
    925a:	nopw   0x0(%rax,%rax,1)
    9260:	vpermpd (%rax),%zmm4,%zmm1
    9266:	vaddpd (%rax),%zmm1,%zmm0
    926c:	add    $0x200,%rax
    9272:	vsubpd -0x200(%rax),%zmm1,%zmm0{%k3}
    9279:	vpermpd %zmm0,%zmm3,%zmm5
    927f:	vaddpd %zmm0,%zmm5,%zmm1
    9285:	vsubpd %zmm0,%zmm5,%zmm1{%k2}
    928b:	vpermpd %zmm1,%zmm2,%zmm5
    9291:	vaddpd %zmm5,%zmm1,%zmm0
    9297:	vsubpd %zmm1,%zmm5,%zmm0{%k1}
    929d:	vpermpd -0x1c0(%rax),%zmm4,%zmm1
    92a4:	vaddpd -0x1c0(%rax),%zmm1,%zmm5
    92ab:	vsubpd -0x1c0(%rax),%zmm1,%zmm5{%k3}
    92b2:	vpermpd %zmm5,%zmm3,%zmm6
    92b8:	vaddpd %zmm6,%zmm5,%zmm1
    92be:	vsubpd %zmm5,%zmm6,%zmm1{%k2}
    92c4:	vpermpd %zmm1,%zmm2,%zmm5
    92ca:	vaddpd %zmm5,%zmm1,%zmm9
    92d0:	vsubpd %zmm1,%zmm5,%zmm9{%k1}
    92d6:	vpermpd -0x180(%rax),%zmm4,%zmm1
    92dd:	vaddpd -0x180(%rax),%zmm1,%zmm5
    92e4:	vsubpd -0x180(%rax),%zmm1,%zmm5{%k3}
    92eb:	vpermpd %zmm5,%zmm3,%zmm6
    92f1:	vaddpd %zmm6,%zmm5,%zmm1
    92f7:	vsubpd %zmm5,%zmm6,%zmm1{%k2}
    92fd:	vpermpd %zmm1,%zmm2,%zmm5
    9303:	vaddpd %zmm5,%zmm1,%zmm8
    9309:	vsubpd %zmm1,%zmm5,%zmm8{%k1}
    930f:	vpermpd -0x140(%rax),%zmm4,%zmm1
    9316:	vaddpd -0x140(%rax),%zmm1,%zmm5
    931d:	vsubpd -0x140(%rax),%zmm1,%zmm5{%k3}
    9324:	vpermpd %zmm5,%zmm3,%zmm6
    932a:	vaddpd %zmm6,%zmm5,%zmm1
    9330:	vsubpd %zmm5,%zmm6,%zmm1{%k2}
    9336:	vpermpd %zmm1,%zmm2,%zmm5
    933c:	vaddpd %zmm5,%zmm1,%zmm12
    9342:	vsubpd %zmm1,%zmm5,%zmm12{%k1}
    9348:	vpermpd -0x100(%rax),%zmm4,%zmm5
    934f:	vaddpd -0x100(%rax),%zmm5,%zmm1
    9356:	vsubpd -0x100(%rax),%zmm5,%zmm1{%k3}
    935d:	vpermpd %zmm1,%zmm3,%zmm6
    9363:	vaddpd %zmm6,%zmm1,%zmm5
    9369:	vsubpd %zmm1,%zmm6,%zmm5{%k2}
    936f:	vpermpd %zmm5,%zmm2,%zmm6
    9375:	vaddpd %zmm6,%zmm5,%zmm1
    937b:	vsubpd %zmm5,%zmm6,%zmm1{%k1}
    9381:	vpermpd -0xc0(%rax),%zmm4,%zmm5
    9388:	vaddpd -0xc0(%rax),%zmm5,%zmm6
    938f:	vsubpd -0xc0(%rax),%zmm5,%zmm6{%k3}
    9396:	vpermpd %zmm6,%zmm3,%zmm7
    939c:	vaddpd %zmm7,%zmm6,%zmm5
    93a2:	vsubpd %zmm6,%zmm7,%zmm5{%k2}
    93a8:	vpermpd %zmm5,%zmm2,%zmm6
    93ae:	vaddpd %zmm6,%zmm5,%zmm11
    93b4:	vsubpd %zmm5,%zmm6,%zmm11{%k1}
    93ba:	vpermpd -0x80(%rax),%zmm4,%zmm5
    93c1:	vaddpd -0x80(%rax),%zmm5,%zmm6
    93c8:	vsubpd -0x80(%rax),%zmm5,%zmm6{%k3}
    93cf:	vpermpd %zmm6,%zmm3,%zmm7
    93d5:	vaddpd %zmm7,%zmm6,%zmm5
    93db:	vsubpd %zmm6,%zmm7,%zmm5{%k2}
    93e1:	vpermpd %zmm5,%zmm2,%zmm7
    93e7:	vaddpd %zmm7,%zmm5,%zmm6
    93ed:	vsubpd %zmm5,%zmm7,%zmm6{%k1}
    93f3:	vpermpd -0x40(%rax),%zmm4,%zmm5
    93fa:	vaddpd -0x40(%rax),%zmm5,%zmm7
    9401:	vsubpd -0x40(%rax),%zmm5,%zmm7{%k3}
    9408:	vpermpd %zmm7,%zmm3,%zmm10
    940e:	vaddpd %zmm7,%zmm10,%zmm5
    9414:	vsubpd %zmm7,%zmm10,%zmm5{%k2}
    941a:	vpermpd %zmm5,%zmm2,%zmm7
    9420:	vaddpd %zmm7,%zmm5,%zmm10
    9426:	vsubpd %zmm5,%zmm7,%zmm10{%k1}
    942c:	vaddpd %zmm9,%zmm0,%zmm5
    9432:	vaddpd %zmm11,%zmm1,%zmm7
    9438:	vsubpd %zmm9,%zmm0,%zmm0
    943e:	vaddpd %zmm12,%zmm8,%zmm9
    9444:	vsubpd %zmm12,%zmm8,%zmm8
    944a:	vaddpd %zmm6,%zmm10,%zmm12
    9450:	vsubpd %zmm11,%zmm1,%zmm1
    9456:	vsubpd %zmm10,%zmm6,%zmm6
    945c:	vaddpd %zmm9,%zmm5,%zmm10
    9462:	vsubpd %zmm9,%zmm5,%zmm5
    9468:	vaddpd %zmm12,%zmm7,%zmm11
    946e:	vaddpd %zmm8,%zmm0,%zmm9
    9474:	vsubpd %zmm8,%zmm0,%zmm0
    947a:	vaddpd %zmm6,%zmm1,%zmm8
    9480:	vsubpd %zmm6,%zmm1,%zmm1
    9486:	vsubpd %zmm12,%zmm7,%zmm7
    948c:	vaddpd %zmm11,%zmm10,%zmm6
    9492:	vsubpd %zmm11,%zmm10,%zmm10
    9498:	vmovupd %zmm6,-0x200(%rax)
    949f:	vaddpd %zmm8,%zmm9,%zmm6
    94a5:	vsubpd %zmm8,%zmm9,%zmm9
    94ab:	vmovupd %zmm10,-0x100(%rax)
    94b2:	vmovupd %zmm6,-0x1c0(%rax)
    94b9:	vaddpd %zmm7,%zmm5,%zmm6
    94bf:	vsubpd %zmm7,%zmm5,%zmm5
    94c5:	vmovupd %zmm9,-0xc0(%rax)
    94cc:	vmovupd %zmm6,-0x180(%rax)
    94d3:	vaddpd %zmm1,%zmm0,%zmm6
    94d9:	vsubpd %zmm1,%zmm0,%zmm0
    94df:	vmovupd %zmm5,-0x80(%rax)
    94e6:	vmovupd %zmm6,-0x140(%rax)
    94ed:	vmovupd %zmm0,-0x40(%rax)
    94f4:	cmp    %rdx,%rax
    94f7:	jne    9260 <hfirst_tb8_nat+0x70>
    94fd:	vzeroupper
    9500:	ret
    9501:	data16 cs nopw 0x0(%rax,%rax,1)
    950c:	nopl   0x0(%rax)

0000000000009ad0 <hfirst_g52_nat>:
    9ad0:	endbr64
    9ad4:	vbroadcastsd 0x42102(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
    9ade:	mov    %rdi,%rax
    9ae1:	test   %rsi,%rsi
    9ae4:	je     a0ab <hfirst_g52_nat+0x5db>
    9aea:	lea    -0x8(,%rsi,8),%rdx
    9af2:	mov    $0xffffffaa,%ecx
    9af7:	vmovdqa64 0x41f7f(%rip),%zmm3        # 4ba80 <FFHT_THR_D+0x80>
    9b01:	vmovdqa64 0x41fb5(%rip),%zmm2        # 4bac0 <FFHT_THR_D+0xc0>
    9b0b:	and    $0xfffffffffffffc00,%rdx
    9b12:	kmovw  %ecx,%k3
    9b16:	mov    $0xffffffcc,%ecx
    9b1b:	vmovdqa64 0x41fdb(%rip),%zmm1        # 4bb00 <FFHT_THR_D+0x100>
    9b25:	vbroadcastsd 0x42019(%rip),%zmm0        # 4bb48 <FFHT_THR_D+0x148>
    9b2f:	lea    0x400(%rdi,%rdx,1),%rdx
    9b37:	kmovw  %ecx,%k2
    9b3b:	mov    $0xfffffff0,%edi
    9b40:	kmovw  %edi,%k1
    9b44:	nopl   0x0(%rax)
    9b48:	vpermpd (%rax),%zmm3,%zmm4
    9b4e:	vaddpd (%rax),%zmm4,%zmm5
    9b54:	add    $0x400,%rax
    9b5a:	vsubpd -0x400(%rax),%zmm4,%zmm5{%k3}
    9b61:	vpermpd %zmm5,%zmm2,%zmm6
    9b67:	vaddpd %zmm5,%zmm6,%zmm4
    9b6d:	vsubpd %zmm5,%zmm6,%zmm4{%k2}
    9b73:	vpermpd %zmm4,%zmm1,%zmm5
    9b79:	vaddpd %zmm5,%zmm4,%zmm20
    9b7f:	vsubpd %zmm4,%zmm5,%zmm20{%k1}
    9b85:	vpermpd -0x3c0(%rax),%zmm3,%zmm4
    9b8c:	vaddpd -0x3c0(%rax),%zmm4,%zmm5
    9b93:	vsubpd -0x3c0(%rax),%zmm4,%zmm5{%k3}
    9b9a:	vpermpd %zmm5,%zmm2,%zmm6
    9ba0:	vaddpd %zmm6,%zmm5,%zmm4
    9ba6:	vsubpd %zmm5,%zmm6,%zmm4{%k2}
    9bac:	vpermpd %zmm4,%zmm1,%zmm5
    9bb2:	vaddpd %zmm5,%zmm4,%zmm7
    9bb8:	vsubpd %zmm4,%zmm5,%zmm7{%k1}
    9bbe:	vpermpd -0x380(%rax),%zmm3,%zmm4
    9bc5:	vaddpd -0x380(%rax),%zmm4,%zmm5
    9bcc:	vsubpd -0x380(%rax),%zmm4,%zmm5{%k3}
    9bd3:	vaddpd %zmm7,%zmm20,%zmm7
    9bd9:	vpermpd %zmm5,%zmm2,%zmm6
    9bdf:	vaddpd %zmm6,%zmm5,%zmm4
    9be5:	vsubpd %zmm5,%zmm6,%zmm4{%k2}
    9beb:	vpermpd %zmm4,%zmm1,%zmm5
    9bf1:	vaddpd %zmm5,%zmm4,%zmm15
    9bf7:	vsubpd %zmm4,%zmm5,%zmm15{%k1}
    9bfd:	vpermpd -0x340(%rax),%zmm3,%zmm4
    9c04:	vaddpd -0x340(%rax),%zmm4,%zmm5
    9c0b:	vsubpd -0x340(%rax),%zmm4,%zmm5{%k3}
    9c12:	vpermpd %zmm5,%zmm2,%zmm6
    9c18:	vaddpd %zmm6,%zmm5,%zmm4
    9c1e:	vsubpd %zmm5,%zmm6,%zmm4{%k2}
    9c24:	vpermpd %zmm4,%zmm1,%zmm5
    9c2a:	vaddpd %zmm5,%zmm4,%zmm6
    9c30:	vsubpd %zmm4,%zmm5,%zmm6{%k1}
    9c36:	vpermpd -0x300(%rax),%zmm3,%zmm4
    9c3d:	vaddpd -0x300(%rax),%zmm4,%zmm5
    9c44:	vsubpd -0x300(%rax),%zmm4,%zmm5{%k3}
    9c4b:	vsubpd %zmm6,%zmm15,%zmm6
    9c51:	vpermpd %zmm5,%zmm2,%zmm8
    9c57:	vaddpd %zmm8,%zmm5,%zmm4
    9c5d:	vsubpd %zmm5,%zmm8,%zmm4{%k2}
    9c63:	vpermpd %zmm4,%zmm1,%zmm5
    9c69:	vaddpd %zmm5,%zmm4,%zmm19
    9c6f:	vsubpd %zmm4,%zmm5,%zmm19{%k1}
    9c75:	vpermpd -0x2c0(%rax),%zmm3,%zmm4
    9c7c:	vaddpd -0x2c0(%rax),%zmm4,%zmm5
    9c83:	vsubpd -0x2c0(%rax),%zmm4,%zmm5{%k3}
    9c8a:	vpermpd %zmm5,%zmm2,%zmm8
    9c90:	vaddpd %zmm8,%zmm5,%zmm4
    9c96:	vsubpd %zmm5,%zmm8,%zmm4{%k2}
    9c9c:	vpermpd %zmm4,%zmm1,%zmm5
    9ca2:	vaddpd %zmm5,%zmm4,%zmm11
    9ca8:	vsubpd %zmm4,%zmm5,%zmm11{%k1}
    9cae:	vpermpd -0x280(%rax),%zmm3,%zmm4
    9cb5:	vaddpd -0x280(%rax),%zmm4,%zmm5
    9cbc:	vsubpd -0x280(%rax),%zmm4,%zmm5{%k3}
    9cc3:	vaddpd %zmm11,%zmm19,%zmm11
    9cc9:	vpermpd %zmm5,%zmm2,%zmm8
    9ccf:	vaddpd %zmm8,%zmm5,%zmm4
    9cd5:	vsubpd %zmm5,%zmm8,%zmm4{%k2}
    9cdb:	vpermpd %zmm4,%zmm1,%zmm5
    9ce1:	vaddpd %zmm5,%zmm4,%zmm13
    9ce7:	vsubpd %zmm4,%zmm5,%zmm13{%k1}
    9ced:	vpermpd -0x240(%rax),%zmm3,%zmm4
    9cf4:	vaddpd -0x240(%rax),%zmm4,%zmm5
    9cfb:	vsubpd -0x240(%rax),%zmm4,%zmm5{%k3}
    9d02:	vpermpd %zmm5,%zmm2,%zmm8
    9d08:	vaddpd %zmm8,%zmm5,%zmm4
    9d0e:	vsubpd %zmm5,%zmm8,%zmm4{%k2}
    9d14:	vpermpd %zmm4,%zmm1,%zmm5
    9d1a:	vaddpd %zmm5,%zmm4,%zmm10
    9d20:	vsubpd %zmm4,%zmm5,%zmm10{%k1}
    9d26:	vpermpd -0x200(%rax),%zmm3,%zmm4
    9d2d:	vaddpd -0x200(%rax),%zmm4,%zmm5
    9d34:	vsubpd -0x200(%rax),%zmm4,%zmm5{%k3}
    9d3b:	vpermpd %zmm5,%zmm2,%zmm8
    9d41:	vaddpd %zmm8,%zmm5,%zmm4
    9d47:	vsubpd %zmm5,%zmm8,%zmm4{%k2}
    9d4d:	vpermpd %zmm4,%zmm1,%zmm5
    9d53:	vaddpd %zmm5,%zmm4,%zmm18
    9d59:	vsubpd %zmm4,%zmm5,%zmm18{%k1}
    9d5f:	vpermpd -0x1c0(%rax),%zmm3,%zmm4
    9d66:	vaddpd -0x1c0(%rax),%zmm4,%zmm5
    9d6d:	vsubpd -0x1c0(%rax),%zmm4,%zmm5{%k3}
    9d74:	vpermpd %zmm5,%zmm2,%zmm8
    9d7a:	vaddpd %zmm8,%zmm5,%zmm4
    9d80:	vsubpd %zmm5,%zmm8,%zmm4{%k2}
    9d86:	vpermpd %zmm4,%zmm1,%zmm8
    9d8c:	vaddpd %zmm8,%zmm4,%zmm5
    9d92:	vsubpd %zmm4,%zmm8,%zmm5{%k1}
    9d98:	vpermpd -0x180(%rax),%zmm3,%zmm4
    9d9f:	vaddpd -0x180(%rax),%zmm4,%zmm8
    9da6:	vsubpd -0x180(%rax),%zmm4,%zmm8{%k3}
    9dad:	vaddpd %zmm5,%zmm18,%zmm5
    9db3:	vpermpd %zmm8,%zmm2,%zmm9
    9db9:	vaddpd %zmm9,%zmm8,%zmm4
    9dbf:	vsubpd %zmm8,%zmm9,%zmm4{%k2}
    9dc5:	vpermpd %zmm4,%zmm1,%zmm8
    9dcb:	vaddpd %zmm8,%zmm4,%zmm12
    9dd1:	vsubpd %zmm4,%zmm8,%zmm12{%k1}
    9dd7:	vpermpd -0x140(%rax),%zmm3,%zmm8
    9dde:	vaddpd -0x140(%rax),%zmm8,%zmm4
    9de5:	vsubpd -0x140(%rax),%zmm8,%zmm4{%k3}
    9dec:	vpermpd %zmm4,%zmm2,%zmm9
    9df2:	vaddpd %zmm9,%zmm4,%zmm8
    9df8:	vsubpd %zmm4,%zmm9,%zmm8{%k2}
    9dfe:	vpermpd %zmm8,%zmm1,%zmm9
    9e04:	vaddpd %zmm9,%zmm8,%zmm4
    9e0a:	vsubpd %zmm8,%zmm9,%zmm4{%k1}
    9e10:	vpermpd -0x100(%rax),%zmm3,%zmm8
    9e17:	vaddpd -0x100(%rax),%zmm8,%zmm9
    9e1e:	vsubpd -0x100(%rax),%zmm8,%zmm9{%k3}
    9e25:	vsubpd %zmm4,%zmm12,%zmm4
    9e2b:	vpermpd %zmm9,%zmm2,%zmm14
    9e31:	vaddpd %zmm14,%zmm9,%zmm8
    9e37:	vsubpd %zmm9,%zmm14,%zmm8{%k2}
    9e3d:	vpermpd %zmm8,%zmm1,%zmm9
    9e43:	vaddpd %zmm9,%zmm8,%zmm17
    9e49:	vsubpd %zmm8,%zmm9,%zmm17{%k1}
    9e4f:	vpermpd -0xc0(%rax),%zmm3,%zmm8
    9e56:	vaddpd -0xc0(%rax),%zmm8,%zmm9
    9e5d:	vsubpd -0xc0(%rax),%zmm8,%zmm9{%k3}
    9e64:	vpermpd %zmm9,%zmm2,%zmm14
    9e6a:	vaddpd %zmm14,%zmm9,%zmm8
    9e70:	vsubpd %zmm9,%zmm14,%zmm8{%k2}
    9e76:	vpermpd %zmm8,%zmm1,%zmm14
    9e7c:	vaddpd %zmm14,%zmm8,%zmm9
    9e82:	vsubpd %zmm8,%zmm14,%zmm9{%k1}
    9e88:	vpermpd -0x80(%rax),%zmm3,%zmm8
    9e8f:	vaddpd -0x80(%rax),%zmm8,%zmm14
    9e96:	vsubpd -0x80(%rax),%zmm8,%zmm14{%k3}
    9e9d:	vaddpd %zmm9,%zmm17,%zmm9
    9ea3:	vpermpd %zmm14,%zmm2,%zmm16
    9ea9:	vaddpd %zmm16,%zmm14,%zmm8
    9eaf:	vsubpd %zmm14,%zmm16,%zmm8{%k2}
    9eb5:	vpermpd %zmm8,%zmm1,%zmm16
    9ebb:	vaddpd %zmm16,%zmm8,%zmm14
    9ec1:	vsubpd %zmm8,%zmm16,%zmm14{%k1}
    9ec7:	vpermpd -0x40(%rax),%zmm3,%zmm16
    9ece:	vaddpd -0x40(%rax),%zmm16,%zmm8
    9ed5:	vsubpd -0x40(%rax),%zmm16,%zmm8{%k3}
    9edc:	vpermpd %zmm8,%zmm2,%zmm21
    9ee2:	vaddpd %zmm21,%zmm8,%zmm16
    9ee8:	vsubpd %zmm8,%zmm21,%zmm16{%k2}
    9eee:	vpermpd %zmm16,%zmm1,%zmm21
    9ef4:	vaddpd %zmm21,%zmm16,%zmm8
    9efa:	vsubpd %zmm16,%zmm21,%zmm8{%k1}
    9f00:	vsubpd %zmm6,%zmm7,%zmm16
    9f06:	vfmadd132pd %zmm0,%zmm16,%zmm15
    9f0c:	vfmsub132pd %zmm0,%zmm16,%zmm20
    9f12:	vsubpd %zmm10,%zmm13,%zmm16
    9f18:	vmovapd %zmm13,%zmm10
    9f1e:	vsubpd %zmm8,%zmm14,%zmm8
    9f24:	vmovapd %zmm15,%zmm21
    9f2a:	vaddpd %zmm16,%zmm11,%zmm15
    9f30:	vfnmadd132pd %zmm0,%zmm15,%zmm10
    9f36:	vfmsub132pd %zmm0,%zmm15,%zmm19
    9f3c:	vsubpd %zmm10,%zmm21,%zmm13
    9f42:	vfmsub132pd %zmm0,%zmm13,%zmm7
    9f48:	vfmadd132pd %zmm0,%zmm13,%zmm11
    9f4e:	vaddpd %zmm8,%zmm9,%zmm13
    9f54:	vfnmadd132pd %zmm0,%zmm13,%zmm14
    9f5a:	vfmsub231pd %zmm0,%zmm17,%zmm13
    9f60:	vmovapd %zmm7,%zmm15
    9f66:	vaddpd %zmm19,%zmm20,%zmm7
    9f6c:	vfmadd132pd %zmm0,%zmm7,%zmm16
    9f72:	vfnmadd132pd %zmm0,%zmm7,%zmm6
    9f78:	vsubpd %zmm4,%zmm5,%zmm7
    9f7e:	vfmadd132pd %zmm0,%zmm7,%zmm12
    9f84:	vfmsub231pd %zmm0,%zmm18,%zmm7
    9f8a:	vaddpd %zmm14,%zmm12,%zmm17
    9f90:	vfnmadd132pd %zmm0,%zmm17,%zmm9
    9f96:	vfmsub132pd %zmm0,%zmm17,%zmm5
    9f9c:	vsubpd %zmm13,%zmm7,%zmm17
    9fa2:	vfnmadd132pd %zmm0,%zmm17,%zmm8
    9fa8:	vfnmadd132pd %zmm0,%zmm17,%zmm4
    9fae:	vaddpd %zmm9,%zmm11,%zmm17
    9fb4:	vfnmadd132pd %zmm0,%zmm17,%zmm12
    9fba:	vfmsub132pd %zmm0,%zmm17,%zmm21
    9fc0:	vfmsub132pd %zmm0,%zmm12,%zmm11
    9fc6:	vfmadd132pd %zmm0,%zmm21,%zmm9
    9fcc:	vmovupd %zmm12,-0x200(%rax)
    9fd3:	vmovupd %zmm21,-0x100(%rax)
    9fda:	vmovupd %zmm9,-0x300(%rax)
    9fe1:	vmovapd %zmm11,%zmm18
    9fe7:	vaddpd %zmm8,%zmm16,%zmm11
    9fed:	vmovupd %zmm18,-0x400(%rax)
    9ff4:	vfnmadd132pd %zmm0,%zmm11,%zmm7
    9ffa:	vfmsub231pd %zmm0,%zmm20,%zmm11
    a000:	vfmsub132pd %zmm0,%zmm7,%zmm16
    a006:	vmovapd %zmm7,%zmm17
    a00c:	vaddpd %zmm5,%zmm15,%zmm7
    a012:	vmovupd %zmm11,-0xc0(%rax)
    a019:	vmovupd %zmm17,-0x1c0(%rax)
    a020:	vfmadd132pd %zmm0,%zmm11,%zmm8
    a026:	vfmadd132pd %zmm0,%zmm7,%zmm14
    a02c:	vfnmadd132pd %zmm0,%zmm7,%zmm10
    a032:	vaddpd %zmm4,%zmm6,%zmm7
    a038:	vmovupd %zmm16,-0x3c0(%rax)
    a03f:	vmovupd %zmm8,-0x2c0(%rax)
    a046:	vfmadd132pd %zmm0,%zmm7,%zmm13
    a04c:	vfnmadd231pd %zmm0,%zmm19,%zmm7
    a052:	vfmsub132pd %zmm0,%zmm14,%zmm15
    a058:	vfnmadd132pd %zmm0,%zmm10,%zmm5
    a05e:	vmovupd %zmm14,-0x380(%rax)
    a065:	vmovupd %zmm10,-0x280(%rax)
    a06c:	vfmsub132pd %zmm0,%zmm13,%zmm6
    a072:	vfnmadd132pd %zmm0,%zmm7,%zmm4
    a078:	vmovupd %zmm13,-0x340(%rax)
    a07f:	vmovupd %zmm7,-0x240(%rax)
    a086:	vmovupd %zmm15,-0x180(%rax)
    a08d:	vmovupd %zmm5,-0x80(%rax)
    a094:	vmovupd %zmm6,-0x140(%rax)
    a09b:	vmovupd %zmm4,-0x40(%rax)
    a0a2:	cmp    %rdx,%rax
    a0a5:	jne    9b48 <hfirst_g52_nat+0x78>
    a0ab:	vzeroupper
    a0ae:	ret
    a0af:	nop

000000000000a0b0 <hstep_tb8_balS>:
    a0b0:	endbr64
    a0b4:	vbroadcastsd 0x41b22(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
    a0be:	test   %rsi,%rsi
    a0c1:	je     a2a0 <hstep_tb8_balS+0x1f0>
    a0c7:	push   %rbp
    a0c8:	mov    %rsp,%rbp
    a0cb:	push   %r15
    a0cd:	push   %r14
    a0cf:	push   %r13
    a0d1:	lea    0x0(,%rdx,8),%r13
    a0d9:	push   %r12
    a0db:	push   %rbx
    a0dc:	and    $0xffffffffffffffc0,%rsp
    a0e0:	test   %rdx,%rdx
    a0e3:	je     a28e <hstep_tb8_balS+0x1de>
    a0e9:	lea    -0x1(%rdx),%r12
    a0ed:	lea    (%rdx,%rdx,2),%rcx
    a0f1:	mov    %rsi,%r15
    a0f4:	mov    %rdx,%r11
    a0f7:	and    $0xfffffffffffffff8,%r12
    a0fb:	mov    %r13,%rsi
    a0fe:	mov    %rdx,%r9
    a101:	mov    %rdi,%r14
    a104:	mov    %r12,-0x8(%rsp)
    a109:	lea    (%rdx,%rdx,4),%r8
    a10d:	lea    0x40(%rdi),%rax
    a111:	neg    %rsi
    a114:	lea    0x0(,%rcx,8),%r10
    a11c:	shl    $0x4,%r11
    a120:	shl    $0x5,%r9
    a124:	mov    %rdx,%rbx
    a127:	shl    $0x3,%r8
    a12b:	shl    $0x4,%rcx
    a12f:	vmovq  %rax,%xmm13
    a134:	nopl   0x0(%rax)
    a138:	mov    -0x8(%rsp),%rdi
    a13d:	vmovq  %xmm13,%r12
    a142:	lea    (%r14,%rbx,8),%rax
    a146:	add    %rbx,%rdi
    a149:	lea    (%r12,%rdi,8),%rdi
    a14d:	nopl   (%rax)
    a150:	vmovupd (%rax,%rsi,1),%zmm7
    a157:	vmovupd (%rax),%zmm6
    a15d:	vsubpd (%rax),%zmm7,%zmm8
    a163:	vmovupd (%rax,%rdx,8),%zmm4
    a16a:	vmovupd (%rax,%r11,1),%zmm1
    a171:	vmovupd (%rax,%r9,1),%zmm5
    a178:	vfmadd132pd %zmm0,%zmm7,%zmm6
    a17e:	vmovupd (%rax,%r10,1),%zmm7
    a185:	vmovupd (%rax,%rcx,1),%zmm2
    a18c:	vfmadd132pd %zmm0,%zmm4,%zmm1
    a192:	vfmadd213pd (%rax,%r8,1),%zmm0,%zmm2
    a199:	vsubpd (%rax,%r9,1),%zmm7,%zmm9
    a1a0:	vfmadd132pd %zmm0,%zmm7,%zmm5
    a1a6:	vsubpd (%rax,%r11,1),%zmm4,%zmm3
    a1ad:	vmovupd (%rax,%r8,1),%zmm4
    a1b4:	vsubpd (%rax,%rcx,1),%zmm4,%zmm4
    a1bb:	vsubpd %zmm1,%zmm6,%zmm7
    a1c1:	vfmadd132pd %zmm0,%zmm6,%zmm1
    a1c7:	vsubpd %zmm3,%zmm8,%zmm6
    a1cd:	vfmadd132pd %zmm0,%zmm8,%zmm3
    a1d3:	vsubpd %zmm2,%zmm5,%zmm8
    a1d9:	vfmadd132pd %zmm0,%zmm5,%zmm2
    a1df:	vsubpd %zmm4,%zmm9,%zmm5
    a1e5:	vfmadd132pd %zmm0,%zmm9,%zmm4
    a1eb:	vmovapd %zmm8,%zmm10
    a1f1:	vmovapd %zmm5,%zmm9
    a1f7:	vfmadd132pd %zmm0,%zmm7,%zmm10
    a1fd:	vsubpd %zmm8,%zmm7,%zmm7
    a203:	vfmadd132pd %zmm0,%zmm6,%zmm9
    a209:	vsubpd %zmm5,%zmm6,%zmm6
    a20f:	vmovapd %zmm2,%zmm12
    a215:	vmovapd %zmm4,%zmm11
    a21b:	vfmadd132pd %zmm0,%zmm1,%zmm12
    a221:	vsubpd %zmm2,%zmm1,%zmm1
    a227:	vfmadd132pd %zmm0,%zmm3,%zmm11
    a22d:	vsubpd %zmm4,%zmm3,%zmm3
    a233:	vmovupd %zmm12,(%rax,%rsi,1)
    a23a:	vmovupd %zmm11,(%rax)
    a240:	vmovupd %zmm10,(%rax,%rdx,8)
    a247:	add    $0x40,%rax
    a24b:	vmovupd %zmm9,-0x40(%rax,%r11,1)
    a253:	vmovupd %zmm1,-0x40(%rax,%r10,1)
    a25b:	vmovupd %zmm3,-0x40(%rax,%r9,1)
    a263:	vmovupd %zmm7,-0x40(%rax,%r8,1)
    a26b:	vmovupd %zmm6,-0x40(%rax,%rcx,1)
    a273:	cmp    %rax,%rdi
    a276:	jne    a150 <hstep_tb8_balS+0xa0>
    a27c:	add    %r13,%rbx
    a27f:	mov    %rbx,%rax
    a282:	sub    %rdx,%rax
    a285:	cmp    %r15,%rax
    a288:	jb     a138 <hstep_tb8_balS+0x88>
    a28e:	vzeroupper
    a291:	lea    -0x28(%rbp),%rsp
    a295:	pop    %rbx
    a296:	pop    %r12
    a298:	pop    %r13
    a29a:	pop    %r14
    a29c:	pop    %r15
    a29e:	pop    %rbp
    a29f:	ret
    a2a0:	vzeroupper
    a2a3:	ret
    a2a4:	data16 cs nopw 0x0(%rax,%rax,1)
    a2af:	nop

000000000000ebd0 <hfirst_tb8_balS>:
    ebd0:	endbr64
    ebd4:	vbroadcastsd 0x3d002(%rip),%zmm1        # 4bbe0 <FFHT_THR_D+0x1e0>
    ebde:	mov    %rdi,%rax
    ebe1:	test   %rsi,%rsi
    ebe4:	je     eef5 <hfirst_tb8_balS+0x325>
    ebea:	lea    -0x8(,%rsi,8),%rdx
    ebf2:	mov    $0xffffffaa,%ecx
    ebf7:	vmovdqa64 0x3ce7f(%rip),%zmm5        # 4ba80 <FFHT_THR_D+0x80>
    ec01:	vmovdqa64 0x3ceb5(%rip),%zmm4        # 4bac0 <FFHT_THR_D+0xc0>
    ec0b:	and    $0xfffffffffffffe00,%rdx
    ec12:	kmovw  %ecx,%k3
    ec16:	mov    $0xffffffcc,%ecx
    ec1b:	vmovdqa64 0x3cedb(%rip),%zmm3        # 4bb00 <FFHT_THR_D+0x100>
    ec25:	lea    0x200(%rdi,%rdx,1),%rdx
    ec2d:	mov    $0xfffffff0,%edi
    ec32:	kmovw  %ecx,%k2
    ec36:	kmovw  %edi,%k1
    ec3a:	nopw   0x0(%rax,%rax,1)
    ec40:	vpermpd (%rax),%zmm5,%zmm0
    ec46:	vaddpd (%rax),%zmm0,%zmm2
    ec4c:	add    $0x200,%rax
    ec52:	vsubpd -0x200(%rax),%zmm0,%zmm2{%k3}
    ec59:	vpermpd %zmm2,%zmm4,%zmm6
    ec5f:	vaddpd %zmm2,%zmm6,%zmm0
    ec65:	vsubpd %zmm2,%zmm6,%zmm0{%k2}
    ec6b:	vpermpd %zmm0,%zmm3,%zmm2
    ec71:	vaddpd %zmm2,%zmm0,%zmm10
    ec77:	vsubpd %zmm0,%zmm2,%zmm10{%k1}
    ec7d:	vpermpd -0x1c0(%rax),%zmm5,%zmm0
    ec84:	vaddpd -0x1c0(%rax),%zmm0,%zmm2
    ec8b:	vsubpd -0x1c0(%rax),%zmm0,%zmm2{%k3}
    ec92:	vpermpd %zmm2,%zmm4,%zmm6
    ec98:	vaddpd %zmm6,%zmm2,%zmm0
    ec9e:	vsubpd %zmm2,%zmm6,%zmm0{%k2}
    eca4:	vpermpd %zmm0,%zmm3,%zmm2
    ecaa:	vaddpd %zmm2,%zmm0,%zmm9
    ecb0:	vsubpd %zmm0,%zmm2,%zmm9{%k1}
    ecb6:	vpermpd -0x180(%rax),%zmm5,%zmm0
    ecbd:	vaddpd -0x180(%rax),%zmm0,%zmm2
    ecc4:	vsubpd -0x180(%rax),%zmm0,%zmm2{%k3}
    eccb:	vsubpd %zmm9,%zmm10,%zmm14
    ecd1:	vfmadd132pd %zmm1,%zmm10,%zmm9
    ecd7:	vpermpd %zmm2,%zmm4,%zmm6
    ecdd:	vaddpd %zmm6,%zmm2,%zmm0
    ece3:	vsubpd %zmm2,%zmm6,%zmm0{%k2}
    ece9:	vpermpd %zmm0,%zmm3,%zmm2
    ecef:	vaddpd %zmm2,%zmm0,%zmm7
    ecf5:	vsubpd %zmm0,%zmm2,%zmm7{%k1}
    ecfb:	vpermpd -0x140(%rax),%zmm5,%zmm2
    ed02:	vaddpd -0x140(%rax),%zmm2,%zmm0
    ed09:	vsubpd -0x140(%rax),%zmm2,%zmm0{%k3}
    ed10:	vpermpd %zmm0,%zmm4,%zmm6
    ed16:	vaddpd %zmm6,%zmm0,%zmm2
    ed1c:	vsubpd %zmm0,%zmm6,%zmm2{%k2}
    ed22:	vpermpd %zmm2,%zmm3,%zmm6
    ed28:	vaddpd %zmm6,%zmm2,%zmm0
    ed2e:	vsubpd %zmm2,%zmm6,%zmm0{%k1}
    ed34:	vpermpd -0x100(%rax),%zmm5,%zmm2
    ed3b:	vaddpd -0x100(%rax),%zmm2,%zmm6
    ed42:	vsubpd -0x100(%rax),%zmm2,%zmm6{%k3}
    ed49:	vpermpd %zmm6,%zmm4,%zmm8
    ed4f:	vaddpd %zmm8,%zmm6,%zmm2
    ed55:	vsubpd %zmm6,%zmm8,%zmm2{%k2}
    ed5b:	vpermpd %zmm2,%zmm3,%zmm6
    ed61:	vaddpd %zmm6,%zmm2,%zmm12
    ed67:	vsubpd %zmm2,%zmm6,%zmm12{%k1}
    ed6d:	vpermpd -0xc0(%rax),%zmm5,%zmm2
    ed74:	vaddpd -0xc0(%rax),%zmm2,%zmm6
    ed7b:	vsubpd -0xc0(%rax),%zmm2,%zmm6{%k3}
    ed82:	vpermpd %zmm6,%zmm4,%zmm8
    ed88:	vaddpd %zmm8,%zmm6,%zmm2
    ed8e:	vsubpd %zmm6,%zmm8,%zmm2{%k2}
    ed94:	vpermpd %zmm2,%zmm3,%zmm6
    ed9a:	vaddpd %zmm6,%zmm2,%zmm8
    eda0:	vsubpd %zmm2,%zmm6,%zmm8{%k1}
    eda6:	vpermpd -0x80(%rax),%zmm5,%zmm2
    edad:	vaddpd -0x80(%rax),%zmm2,%zmm6
    edb4:	vsubpd -0x80(%rax),%zmm2,%zmm6{%k3}
    edbb:	vpermpd %zmm6,%zmm4,%zmm11
    edc1:	vaddpd %zmm11,%zmm6,%zmm2
    edc7:	vsubpd %zmm6,%zmm11,%zmm2{%k2}
    edcd:	vpermpd %zmm2,%zmm3,%zmm6
    edd3:	vaddpd %zmm6,%zmm2,%zmm11
    edd9:	vsubpd %zmm2,%zmm6,%zmm11{%k1}
    eddf:	vpermpd -0x40(%rax),%zmm5,%zmm6
    ede6:	vaddpd -0x40(%rax),%zmm6,%zmm2
    eded:	vsubpd -0x40(%rax),%zmm6,%zmm2{%k3}
    edf4:	vpermpd %zmm2,%zmm4,%zmm13
    edfa:	vaddpd %zmm2,%zmm13,%zmm6
    ee00:	vsubpd %zmm2,%zmm13,%zmm6{%k2}
    ee06:	vpermpd %zmm6,%zmm3,%zmm13
    ee0c:	vaddpd %zmm13,%zmm6,%zmm2
    ee12:	vsubpd %zmm6,%zmm13,%zmm2{%k1}
    ee18:	vsubpd %zmm8,%zmm12,%zmm13
    ee1e:	vfmadd132pd %zmm1,%zmm12,%zmm8
    ee24:	vsubpd %zmm0,%zmm7,%zmm6
    ee2a:	vfmadd132pd %zmm1,%zmm7,%zmm0
    ee30:	vsubpd %zmm2,%zmm11,%zmm7
    ee36:	vfmadd132pd %zmm1,%zmm11,%zmm2
    ee3c:	vsubpd %zmm0,%zmm9,%zmm10
    ee42:	vfmadd132pd %zmm1,%zmm9,%zmm0
    ee48:	vsubpd %zmm6,%zmm14,%zmm9
    ee4e:	vfmadd132pd %zmm1,%zmm14,%zmm6
    ee54:	vsubpd %zmm2,%zmm8,%zmm11
    ee5a:	vfmadd132pd %zmm1,%zmm8,%zmm2
    ee60:	vsubpd %zmm7,%zmm13,%zmm8
    ee66:	vfmadd132pd %zmm1,%zmm13,%zmm7
    ee6c:	vmovapd %zmm8,%zmm12
    ee72:	vmovapd %zmm11,%zmm13
    ee78:	vfmadd132pd %zmm1,%zmm10,%zmm13
    ee7e:	vfmadd132pd %zmm1,%zmm9,%zmm12
    ee84:	vsubpd %zmm11,%zmm10,%zmm10
    ee8a:	vmovapd %zmm2,%zmm15
    ee90:	vsubpd %zmm8,%zmm9,%zmm9
    ee96:	vmovapd %zmm7,%zmm14
    ee9c:	vfmadd132pd %zmm1,%zmm0,%zmm15
    eea2:	vsubpd %zmm2,%zmm0,%zmm0
    eea8:	vfmadd132pd %zmm1,%zmm6,%zmm14
    eeae:	vsubpd %zmm7,%zmm6,%zmm6
    eeb4:	vmovupd %zmm10,-0x80(%rax)
    eebb:	vmovupd %zmm9,-0x40(%rax)
    eec2:	vmovupd %zmm13,-0x180(%rax)
    eec9:	vmovupd %zmm12,-0x140(%rax)
    eed0:	vmovupd %zmm15,-0x200(%rax)
    eed7:	vmovupd %zmm14,-0x1c0(%rax)
    eede:	vmovupd %zmm0,-0x100(%rax)
    eee5:	vmovupd %zmm6,-0xc0(%rax)
    eeec:	cmp    %rdx,%rax
    eeef:	jne    ec40 <hfirst_tb8_balS+0x70>
    eef5:	vzeroupper
    eef8:	ret
    eef9:	nopl   0x0(%rax)

000000000000ef00 <hstep_g19_nat>:
    ef00:	endbr64
    ef04:	vbroadcastsd 0x3ccd2(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
    ef0e:	test   %rsi,%rsi
    ef11:	je     f0bd <hstep_g19_nat+0x1bd>
    ef17:	push   %rbp
    ef18:	mov    %rsp,%rbp
    ef1b:	push   %r15
    ef1d:	push   %r14
    ef1f:	push   %r13
    ef21:	lea    0x0(,%rdx,8),%r13
    ef29:	push   %r12
    ef2b:	push   %rbx
    ef2c:	and    $0xffffffffffffffc0,%rsp
    ef30:	test   %rdx,%rdx
    ef33:	je     f0ab <hstep_g19_nat+0x1ab>
    ef39:	lea    -0x1(%rdx),%r12
    ef3d:	lea    (%rdx,%rdx,2),%rcx
    ef41:	mov    %rsi,%r15
    ef44:	mov    %rdx,%r11
    ef47:	and    $0xfffffffffffffff8,%r12
    ef4b:	mov    %r13,%rsi
    ef4e:	mov    %rdx,%r9
    ef51:	mov    %rdi,%r14
    ef54:	mov    %r12,-0x8(%rsp)
    ef59:	lea    (%rdx,%rdx,4),%r8
    ef5d:	lea    0x40(%rdi),%rax
    ef61:	neg    %rsi
    ef64:	lea    0x0(,%rcx,8),%r10
    ef6c:	shl    $0x4,%r11
    ef70:	shl    $0x5,%r9
    ef74:	mov    %rdx,%rbx
    ef77:	shl    $0x3,%r8
    ef7b:	shl    $0x4,%rcx
    ef7f:	vmovq  %rax,%xmm11
    ef84:	vbroadcastsd 0x3cbba(%rip),%zmm0        # 4bb48 <FFHT_THR_D+0x148>
    ef8e:	xchg   %ax,%ax
    ef90:	mov    -0x8(%rsp),%rdi
    ef95:	vmovq  %xmm11,%r12
    ef9a:	lea    (%r14,%rbx,8),%rax
    ef9e:	add    %rbx,%rdi
    efa1:	lea    (%r12,%rdi,8),%rdi
    efa5:	nopl   (%rax)
    efa8:	vmovupd (%rax,%rsi,1),%zmm1
    efaf:	vmovupd (%rax),%zmm6
    efb5:	vmovapd %zmm0,%zmm3
    efbb:	vaddpd (%rax,%rcx,1),%zmm1,%zmm10
    efc2:	vaddpd (%rax,%r8,1),%zmm6,%zmm7
    efc9:	vmovupd (%rax,%rdx,8),%zmm4
    efd0:	vmovupd (%rax,%r11,1),%zmm5
    efd7:	vsubpd (%rax,%r9,1),%zmm4,%zmm1
    efde:	vsubpd (%rax,%r10,1),%zmm5,%zmm6
    efe5:	vmovapd %zmm0,%zmm4
    efeb:	vsubpd %zmm7,%zmm10,%zmm8
    eff1:	vmovapd %zmm0,%zmm5
    eff7:	vaddpd %zmm6,%zmm1,%zmm9
    effd:	vsubpd %zmm9,%zmm8,%zmm2
    f003:	vfnmadd132pd (%rax,%rcx,1),%zmm2,%zmm3
    f00a:	vfnmadd231pd (%rax,%r9,1),%zmm0,%zmm2
    f011:	vfmadd132pd (%rax,%r8,1),%zmm3,%zmm5
    f018:	vfnmadd132pd (%rax,%r10,1),%zmm2,%zmm4
    f01f:	vfmadd231pd (%rax),%zmm0,%zmm3
    f025:	vfmadd231pd (%rax,%r11,1),%zmm0,%zmm2
    f02c:	vfmadd132pd %zmm0,%zmm5,%zmm6
    f032:	vfmadd132pd %zmm0,%zmm5,%zmm1
    f038:	vfmadd132pd %zmm0,%zmm4,%zmm7
    f03e:	vfmadd132pd %zmm0,%zmm3,%zmm9
    f044:	vfmsub132pd %zmm0,%zmm2,%zmm8
    f04a:	vfmsub132pd %zmm0,%zmm4,%zmm10
    f050:	vmovupd %zmm10,(%rax,%rsi,1)
    f057:	vmovupd %zmm1,(%rax)
    f05d:	vmovupd %zmm3,(%rax,%rdx,8)
    f064:	add    $0x40,%rax
    f068:	vmovupd %zmm2,-0x40(%rax,%r11,1)
    f070:	vmovupd %zmm9,-0x40(%rax,%r10,1)
    f078:	vmovupd %zmm8,-0x40(%rax,%r9,1)
    f080:	vmovupd %zmm7,-0x40(%rax,%r8,1)
    f088:	vmovupd %zmm6,-0x40(%rax,%rcx,1)
    f090:	cmp    %rax,%rdi
    f093:	jne    efa8 <hstep_g19_nat+0xa8>
    f099:	add    %r13,%rbx
    f09c:	mov    %rbx,%rax
    f09f:	sub    %rdx,%rax
    f0a2:	cmp    %r15,%rax
    f0a5:	jb     ef90 <hstep_g19_nat+0x90>
    f0ab:	vzeroupper
    f0ae:	lea    -0x28(%rbp),%rsp
    f0b2:	pop    %rbx
    f0b3:	pop    %r12
    f0b5:	pop    %r13
    f0b7:	pop    %r14
    f0b9:	pop    %r15
    f0bb:	pop    %rbp
    f0bc:	ret
    f0bd:	vzeroupper
    f0c0:	ret
    f0c1:	data16 cs nopw 0x0(%rax,%rax,1)
    f0cc:	nopl   0x0(%rax)

000000000000f410 <hstep_h20_nat>:
    f410:	endbr64
    f414:	vbroadcastsd 0x3c7c2(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
    f41e:	test   %rsi,%rsi
    f421:	je     f5c1 <hstep_h20_nat+0x1b1>
    f427:	push   %rbp
    f428:	mov    %rsp,%rbp
    f42b:	push   %r15
    f42d:	push   %r14
    f42f:	push   %r13
    f431:	lea    0x0(,%rdx,8),%r13
    f439:	push   %r12
    f43b:	push   %rbx
    f43c:	and    $0xffffffffffffffc0,%rsp
    f440:	test   %rdx,%rdx
    f443:	je     f5af <hstep_h20_nat+0x19f>
    f449:	lea    -0x1(%rdx),%r12
    f44d:	lea    (%rdx,%rdx,2),%rcx
    f451:	mov    %rsi,%r15
    f454:	mov    %rdx,%r11
    f457:	and    $0xfffffffffffffff8,%r12
    f45b:	mov    %r13,%rsi
    f45e:	mov    %rdx,%r9
    f461:	mov    %rdi,%r14
    f464:	mov    %r12,-0x8(%rsp)
    f469:	lea    (%rdx,%rdx,4),%r8
    f46d:	lea    0x40(%rdi),%rax
    f471:	neg    %rsi
    f474:	lea    0x0(,%rcx,8),%r10
    f47c:	shl    $0x4,%r11
    f480:	shl    $0x5,%r9
    f484:	mov    %rdx,%rbx
    f487:	shl    $0x3,%r8
    f48b:	shl    $0x4,%rcx
    f48f:	vmovq  %rax,%xmm11
    f494:	vbroadcastsd 0x3c6a2(%rip),%zmm10        # 4bb40 <FFHT_THR_D+0x140>
    f49e:	xchg   %ax,%ax
    f4a0:	mov    -0x8(%rsp),%rdi
    f4a5:	vmovq  %xmm11,%r12
    f4aa:	lea    (%r14,%rbx,8),%rax
    f4ae:	add    %rbx,%rdi
    f4b1:	lea    (%r12,%rdi,8),%rdi
    f4b5:	nopl   (%rax)
    f4b8:	vmovupd (%rax,%rsi,1),%zmm3
    f4bf:	vmovupd (%rax),%zmm4
    f4c5:	vaddpd (%rax,%rcx,1),%zmm3,%zmm9
    f4cc:	vaddpd (%rax,%r8,1),%zmm4,%zmm6
    f4d3:	vmovupd (%rax,%r11,1),%zmm3
    f4da:	vmovupd (%rax,%rdx,8),%zmm2
    f4e1:	vsubpd (%rax,%r10,1),%zmm3,%zmm5
    f4e8:	vsubpd (%rax,%r9,1),%zmm2,%zmm2
    f4ef:	vsubpd %zmm6,%zmm9,%zmm7
    f4f5:	vaddpd %zmm5,%zmm2,%zmm8
    f4fb:	vsubpd %zmm8,%zmm7,%zmm0
    f501:	vmovapd %zmm0,%zmm1
    f507:	vfmsub213pd (%rax,%r9,1),%zmm10,%zmm0
    f50e:	vfmsub213pd (%rax,%rcx,1),%zmm10,%zmm1
    f515:	vsubpd (%rax,%r10,1),%zmm0,%zmm4
    f51c:	vaddpd (%rax,%r8,1),%zmm1,%zmm3
    f523:	vaddpd (%rax,%r11,1),%zmm0,%zmm0
    f52a:	vaddpd (%rax),%zmm1,%zmm1
    f530:	vsubpd %zmm4,%zmm9,%zmm9
    f536:	vaddpd %zmm4,%zmm6,%zmm6
    f53c:	vaddpd %zmm3,%zmm2,%zmm2
    f542:	vsubpd %zmm0,%zmm7,%zmm7
    f548:	vaddpd %zmm1,%zmm8,%zmm8
    f54e:	vaddpd %zmm3,%zmm5,%zmm5
    f554:	vmovupd %zmm9,(%rax,%rsi,1)
    f55b:	vmovupd %zmm2,(%rax)
    f561:	vmovupd %zmm1,(%rax,%rdx,8)
    f568:	add    $0x40,%rax
    f56c:	vmovupd %zmm0,-0x40(%rax,%r11,1)
    f574:	vmovupd %zmm8,-0x40(%rax,%r10,1)
    f57c:	vmovupd %zmm7,-0x40(%rax,%r9,1)
    f584:	vmovupd %zmm6,-0x40(%rax,%r8,1)
    f58c:	vmovupd %zmm5,-0x40(%rax,%rcx,1)
    f594:	cmp    %rax,%rdi
    f597:	jne    f4b8 <hstep_h20_nat+0xa8>
    f59d:	add    %r13,%rbx
    f5a0:	mov    %rbx,%rax
    f5a3:	sub    %rdx,%rax
    f5a6:	cmp    %r15,%rax
    f5a9:	jb     f4a0 <hstep_h20_nat+0x90>
    f5af:	vzeroupper
    f5b2:	lea    -0x28(%rbp),%rsp
    f5b6:	pop    %rbx
    f5b7:	pop    %r12
    f5b9:	pop    %r13
    f5bb:	pop    %r14
    f5bd:	pop    %r15
    f5bf:	pop    %rbp
    f5c0:	ret
    f5c1:	vzeroupper
    f5c4:	ret
    f5c5:	data16 cs nopw 0x0(%rax,%rax,1)

0000000000011680 <hstep_g20_nat>:
   11680:	endbr64
   11684:	vbroadcastsd 0x3a552(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
   1168e:	test   %rsi,%rsi
   11691:	je     11841 <hstep_g20_nat+0x1c1>
   11697:	push   %rbp
   11698:	mov    %rsp,%rbp
   1169b:	push   %r15
   1169d:	push   %r14
   1169f:	push   %r13
   116a1:	lea    0x0(,%rdx,8),%r13
   116a9:	push   %r12
   116ab:	push   %rbx
   116ac:	and    $0xffffffffffffffc0,%rsp
   116b0:	test   %rdx,%rdx
   116b3:	je     1182f <hstep_g20_nat+0x1af>
   116b9:	lea    -0x1(%rdx),%r12
   116bd:	lea    (%rdx,%rdx,2),%rcx
   116c1:	mov    %rsi,%r15
   116c4:	mov    %rdx,%r11
   116c7:	and    $0xfffffffffffffff8,%r12
   116cb:	mov    %r13,%rsi
   116ce:	mov    %rdx,%r9
   116d1:	mov    %rdi,%r14
   116d4:	mov    %r12,-0x8(%rsp)
   116d9:	lea    (%rdx,%rdx,4),%r8
   116dd:	lea    0x40(%rdi),%rax
   116e1:	neg    %rsi
   116e4:	lea    0x0(,%rcx,8),%r10
   116ec:	shl    $0x4,%r11
   116f0:	shl    $0x5,%r9
   116f4:	mov    %rdx,%rbx
   116f7:	shl    $0x3,%r8
   116fb:	shl    $0x4,%rcx
   116ff:	vmovq  %rax,%xmm10
   11704:	vbroadcastsd 0x3a43a(%rip),%zmm0        # 4bb48 <FFHT_THR_D+0x148>
   1170e:	xchg   %ax,%ax
   11710:	mov    -0x8(%rsp),%rdi
   11715:	vmovq  %xmm10,%r12
   1171a:	lea    (%r14,%rbx,8),%rax
   1171e:	add    %rbx,%rdi
   11721:	lea    (%r12,%rdi,8),%rdi
   11725:	nopl   (%rax)
   11728:	vmovupd (%rax,%rdx,8),%zmm6
   1172f:	vmovupd (%rax),%zmm5
   11735:	vmovapd %zmm0,%zmm4
   1173b:	vsubpd (%rax,%r11,1),%zmm6,%zmm7
   11742:	vaddpd (%rax,%rsi,1),%zmm5,%zmm5
   11749:	vmovupd (%rax,%r9,1),%zmm3
   11750:	vsubpd %zmm7,%zmm5,%zmm1
   11756:	vfmadd132pd %zmm6,%zmm1,%zmm4
   1175c:	vaddpd (%rax,%r10,1),%zmm3,%zmm6
   11763:	vmovupd (%rax,%r8,1),%zmm3
   1176a:	vmovapd %zmm1,%zmm2
   11770:	vsubpd (%rax,%rcx,1),%zmm3,%zmm8
   11777:	vmovapd %zmm0,%zmm3
   1177d:	vfmsub231pd (%rax,%rsi,1),%zmm0,%zmm2
   11784:	vaddpd %zmm8,%zmm6,%zmm1
   1178a:	vfnmadd132pd (%rax,%r8,1),%zmm1,%zmm3
   11791:	vfmsub231pd (%rax,%r10,1),%zmm0,%zmm1
   11798:	vaddpd %zmm3,%zmm4,%zmm9
   1179e:	vfnmadd132pd %zmm0,%zmm9,%zmm6
   117a4:	vfmsub132pd %zmm0,%zmm9,%zmm5
   117aa:	vaddpd %zmm1,%zmm2,%zmm9
   117b0:	vfmadd132pd %zmm0,%zmm9,%zmm8
   117b6:	vfnmadd132pd %zmm0,%zmm9,%zmm7
   117bc:	vfmsub132pd %zmm0,%zmm6,%zmm4
   117c2:	vfmadd132pd %zmm0,%zmm5,%zmm3
   117c8:	vfmsub132pd %zmm0,%zmm8,%zmm2
   117ce:	vfnmadd132pd %zmm0,%zmm7,%zmm1
   117d4:	vmovupd %zmm4,(%rax,%rsi,1)
   117db:	vmovupd %zmm8,(%rax)
   117e1:	vmovupd %zmm3,(%rax,%rdx,8)
   117e8:	add    $0x40,%rax
   117ec:	vmovupd %zmm7,-0x40(%rax,%r11,1)
   117f4:	vmovupd %zmm6,-0x40(%rax,%r10,1)
   117fc:	vmovupd %zmm2,-0x40(%rax,%r9,1)
   11804:	vmovupd %zmm5,-0x40(%rax,%r8,1)
   1180c:	vmovupd %zmm1,-0x40(%rax,%rcx,1)
   11814:	cmp    %rax,%rdi
   11817:	jne    11728 <hstep_g20_nat+0xa8>
   1181d:	add    %r13,%rbx
   11820:	mov    %rbx,%rax
   11823:	sub    %rdx,%rax
   11826:	cmp    %r15,%rax
   11829:	jb     11710 <hstep_g20_nat+0x90>
   1182f:	vzeroupper
   11832:	lea    -0x28(%rbp),%rsp
   11836:	pop    %rbx
   11837:	pop    %r12
   11839:	pop    %r13
   1183b:	pop    %r14
   1183d:	pop    %r15
   1183f:	pop    %rbp
   11840:	ret
   11841:	vzeroupper
   11844:	ret
   11845:	data16 cs nopw 0x0(%rax,%rax,1)

00000000000126c0 <hstep_broken_g20>:
   126c0:	endbr64
   126c4:	vbroadcastsd 0x39512(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
   126ce:	test   %rsi,%rsi
   126d1:	je     12881 <hstep_broken_g20+0x1c1>
   126d7:	push   %rbp
   126d8:	mov    %rsp,%rbp
   126db:	push   %r15
   126dd:	push   %r14
   126df:	push   %r13
   126e1:	lea    0x0(,%rdx,8),%r13
   126e9:	push   %r12
   126eb:	push   %rbx
   126ec:	and    $0xffffffffffffffc0,%rsp
   126f0:	test   %rdx,%rdx
   126f3:	je     1286f <hstep_broken_g20+0x1af>
   126f9:	lea    -0x1(%rdx),%r12
   126fd:	lea    (%rdx,%rdx,2),%rcx
   12701:	mov    %rsi,%r15
   12704:	mov    %rdx,%r11
   12707:	and    $0xfffffffffffffff8,%r12
   1270b:	mov    %r13,%rsi
   1270e:	mov    %rdx,%r9
   12711:	mov    %rdi,%r14
   12714:	mov    %r12,-0x8(%rsp)
   12719:	lea    (%rdx,%rdx,4),%r8
   1271d:	lea    0x40(%rdi),%rax
   12721:	neg    %rsi
   12724:	lea    0x0(,%rcx,8),%r10
   1272c:	shl    $0x4,%r11
   12730:	shl    $0x5,%r9
   12734:	mov    %rdx,%rbx
   12737:	shl    $0x3,%r8
   1273b:	shl    $0x4,%rcx
   1273f:	vmovq  %rax,%xmm10
   12744:	vbroadcastsd 0x393fa(%rip),%zmm0        # 4bb48 <FFHT_THR_D+0x148>
   1274e:	xchg   %ax,%ax
   12750:	mov    -0x8(%rsp),%rdi
   12755:	vmovq  %xmm10,%r12
   1275a:	lea    (%r14,%rbx,8),%rax
   1275e:	add    %rbx,%rdi
   12761:	lea    (%r12,%rdi,8),%rdi
   12765:	nopl   (%rax)
   12768:	vmovupd (%rax,%rdx,8),%zmm6
   1276f:	vmovupd (%rax),%zmm5
   12775:	vmovapd %zmm0,%zmm4
   1277b:	vsubpd (%rax,%r11,1),%zmm6,%zmm7
   12782:	vaddpd (%rax,%rsi,1),%zmm5,%zmm5
   12789:	vmovupd (%rax,%r9,1),%zmm3
   12790:	vsubpd %zmm7,%zmm5,%zmm1
   12796:	vfmadd132pd %zmm6,%zmm1,%zmm4
   1279c:	vaddpd (%rax,%r10,1),%zmm3,%zmm6
   127a3:	vmovupd (%rax,%r8,1),%zmm3
   127aa:	vmovapd %zmm1,%zmm2
   127b0:	vsubpd (%rax,%rcx,1),%zmm3,%zmm8
   127b7:	vmovapd %zmm0,%zmm3
   127bd:	vfmsub231pd (%rax,%rsi,1),%zmm0,%zmm2
   127c4:	vaddpd %zmm8,%zmm6,%zmm1
   127ca:	vfnmadd132pd (%rax,%r8,1),%zmm1,%zmm3
   127d1:	vfmsub231pd (%rax,%r10,1),%zmm0,%zmm1
   127d8:	vaddpd %zmm3,%zmm4,%zmm9
   127de:	vfnmadd132pd %zmm0,%zmm9,%zmm6
   127e4:	vfmsub132pd %zmm0,%zmm9,%zmm5
   127ea:	vaddpd %zmm1,%zmm2,%zmm9
   127f0:	vfmadd132pd %zmm0,%zmm9,%zmm8
   127f6:	vfnmadd132pd %zmm0,%zmm9,%zmm7
   127fc:	vfmsub132pd %zmm0,%zmm6,%zmm4
   12802:	vfmadd132pd %zmm0,%zmm5,%zmm3
   12808:	vfmsub132pd %zmm0,%zmm8,%zmm2
   1280e:	vfnmadd132pd %zmm0,%zmm7,%zmm1
   12814:	vmovupd %zmm4,(%rax,%rsi,1)
   1281b:	vmovupd %zmm8,(%rax)
   12821:	vmovupd %zmm3,(%rax,%rdx,8)
   12828:	add    $0x40,%rax
   1282c:	vmovupd %zmm7,-0x40(%rax,%r11,1)
   12834:	vmovupd %zmm6,-0x40(%rax,%r10,1)
   1283c:	vmovupd %zmm5,-0x40(%rax,%r9,1)
   12844:	vmovupd %zmm2,-0x40(%rax,%r8,1)
   1284c:	vmovupd %zmm1,-0x40(%rax,%rcx,1)
   12854:	cmp    %rax,%rdi
   12857:	jne    12768 <hstep_broken_g20+0xa8>
   1285d:	add    %r13,%rbx
   12860:	mov    %rbx,%rax
   12863:	sub    %rdx,%rax
   12866:	cmp    %r15,%rax
   12869:	jb     12750 <hstep_broken_g20+0x90>
   1286f:	vzeroupper
   12872:	lea    -0x28(%rbp),%rsp
   12876:	pop    %rbx
   12877:	pop    %r12
   12879:	pop    %r13
   1287b:	pop    %r14
   1287d:	pop    %r15
   1287f:	pop    %rbp
   12880:	ret
   12881:	vzeroupper
   12884:	ret
   12885:	data16 cs nopw 0x0(%rax,%rax,1)

0000000000012890 <hstep_tb8_nat>:
   12890:	endbr64
   12894:	vbroadcastsd 0x39342(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
   1289e:	test   %rsi,%rsi
   128a1:	je     12a4f <hstep_tb8_nat+0x1bf>
   128a7:	push   %rbp
   128a8:	mov    %rsp,%rbp
   128ab:	push   %r15
   128ad:	push   %r14
   128af:	push   %r13
   128b1:	lea    0x0(,%rdx,8),%r13
   128b9:	push   %r12
   128bb:	push   %rbx
   128bc:	and    $0xffffffffffffffc0,%rsp
   128c0:	test   %rdx,%rdx
   128c3:	je     12a3d <hstep_tb8_nat+0x1ad>
   128c9:	lea    -0x1(%rdx),%r12
   128cd:	lea    (%rdx,%rdx,2),%rcx
   128d1:	mov    %rsi,%r15
   128d4:	mov    %rdx,%r11
   128d7:	and    $0xfffffffffffffff8,%r12
   128db:	mov    %r13,%rsi
   128de:	mov    %rdx,%r9
   128e1:	mov    %rdi,%r14
   128e4:	mov    %r12,-0x8(%rsp)
   128e9:	lea    (%rdx,%rdx,4),%r8
   128ed:	lea    0x40(%rdi),%rax
   128f1:	neg    %rsi
   128f4:	lea    0x0(,%rcx,8),%r10
   128fc:	shl    $0x4,%r11
   12900:	shl    $0x5,%r9
   12904:	mov    %rdx,%rbx
   12907:	shl    $0x3,%r8
   1290b:	shl    $0x4,%rcx
   1290f:	vmovq  %rax,%xmm10
   12914:	nopl   0x0(%rax)
   12918:	mov    -0x8(%rsp),%rdi
   1291d:	vmovq  %xmm10,%r12
   12922:	lea    (%r14,%rbx,8),%rax
   12926:	add    %rbx,%rdi
   12929:	lea    (%r12,%rdi,8),%rdi
   1292d:	nopl   (%rax)
   12930:	vmovupd (%rax,%rsi,1),%zmm7
   12937:	vmovupd (%rax,%rdx,8),%zmm3
   1293e:	vaddpd (%rax),%zmm7,%zmm2
   12944:	vaddpd (%rax,%r11,1),%zmm3,%zmm6
   1294b:	vsubpd (%rax,%r11,1),%zmm3,%zmm5
   12952:	vsubpd (%rax),%zmm7,%zmm0
   12958:	vmovupd (%rax,%r10,1),%zmm7
   1295f:	vaddpd (%rax,%r9,1),%zmm7,%zmm3
   12966:	vsubpd (%rax,%r9,1),%zmm7,%zmm1
   1296d:	vmovupd (%rax,%r8,1),%zmm7
   12974:	vaddpd (%rax,%rcx,1),%zmm7,%zmm9
   1297b:	vsubpd (%rax,%rcx,1),%zmm7,%zmm4
   12982:	vaddpd %zmm6,%zmm2,%zmm7
   12988:	vsubpd %zmm6,%zmm2,%zmm2
   1298e:	vaddpd %zmm5,%zmm0,%zmm6
   12994:	vsubpd %zmm5,%zmm0,%zmm0
   1299a:	vaddpd %zmm9,%zmm3,%zmm8
   129a0:	vaddpd %zmm4,%zmm1,%zmm5
   129a6:	vsubpd %zmm4,%zmm1,%zmm1
   129ac:	vsubpd %zmm9,%zmm3,%zmm3
   129b2:	vaddpd %zmm8,%zmm7,%zmm4
   129b8:	vsubpd %zmm8,%zmm7,%zmm7
   129be:	vmovupd %zmm4,(%rax,%rsi,1)
   129c5:	vaddpd %zmm5,%zmm6,%zmm4
   129cb:	vsubpd %zmm5,%zmm6,%zmm6
   129d1:	vmovupd %zmm4,(%rax)
   129d7:	vaddpd %zmm3,%zmm2,%zmm4
   129dd:	vsubpd %zmm3,%zmm2,%zmm2
   129e3:	vmovupd %zmm4,(%rax,%rdx,8)
   129ea:	vaddpd %zmm1,%zmm0,%zmm4
   129f0:	add    $0x40,%rax
   129f4:	vsubpd %zmm1,%zmm0,%zmm0
   129fa:	vmovupd %zmm4,-0x40(%rax,%r11,1)
   12a02:	vmovupd %zmm7,-0x40(%rax,%r10,1)
   12a0a:	vmovupd %zmm6,-0x40(%rax,%r9,1)
   12a12:	vmovupd %zmm2,-0x40(%rax,%r8,1)
   12a1a:	vmovupd %zmm0,-0x40(%rax,%rcx,1)
   12a22:	cmp    %rax,%rdi
   12a25:	jne    12930 <hstep_tb8_nat+0xa0>
   12a2b:	add    %r13,%rbx
   12a2e:	mov    %rbx,%rax
   12a31:	sub    %rdx,%rax
   12a34:	cmp    %r15,%rax
   12a37:	jb     12918 <hstep_tb8_nat+0x88>
   12a3d:	vzeroupper
   12a40:	lea    -0x28(%rbp),%rsp
   12a44:	pop    %rbx
   12a45:	pop    %r12
   12a47:	pop    %r13
   12a49:	pop    %r14
   12a4b:	pop    %r15
   12a4d:	pop    %rbp
   12a4e:	ret
   12a4f:	vzeroupper
   12a52:	ret
   12a53:	data16 cs nopw 0x0(%rax,%rax,1)
   12a5e:	xchg   %ax,%ax

0000000000015790 <hstep_tb8_bal>:
   15790:	endbr64
   15794:	vbroadcastsd 0x36442(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
   1579e:	test   %rsi,%rsi
   157a1:	je     1599b <hstep_tb8_bal+0x20b>
   157a7:	push   %rbp
   157a8:	mov    %rsp,%rbp
   157ab:	push   %r15
   157ad:	push   %r14
   157af:	push   %r13
   157b1:	lea    0x0(,%rdx,8),%r13
   157b9:	push   %r12
   157bb:	push   %rbx
   157bc:	and    $0xffffffffffffffc0,%rsp
   157c0:	test   %rdx,%rdx
   157c3:	je     15989 <hstep_tb8_bal+0x1f9>
   157c9:	lea    -0x1(%rdx),%r12
   157cd:	lea    (%rdx,%rdx,2),%rcx
   157d1:	mov    %rsi,%r15
   157d4:	mov    %rdx,%r11
   157d7:	and    $0xfffffffffffffff8,%r12
   157db:	mov    %r13,%rsi
   157de:	mov    %rdx,%r9
   157e1:	mov    %rdi,%r14
   157e4:	mov    %r12,-0x8(%rsp)
   157e9:	lea    (%rdx,%rdx,4),%r8
   157ed:	lea    0x40(%rdi),%rax
   157f1:	neg    %rsi
   157f4:	lea    0x0(,%rcx,8),%r10
   157fc:	shl    $0x4,%r11
   15800:	shl    $0x5,%r9
   15804:	mov    %rdx,%rbx
   15807:	shl    $0x3,%r8
   1580b:	shl    $0x4,%rcx
   1580f:	vmovq  %rax,%xmm13
   15814:	nopl   0x0(%rax)
   15818:	mov    -0x8(%rsp),%rdi
   1581d:	vmovq  %xmm13,%r12
   15822:	lea    (%r14,%rbx,8),%rax
   15826:	add    %rbx,%rdi
   15829:	lea    (%r12,%rdi,8),%rdi
   1582d:	nopl   (%rax)
   15830:	vmovupd (%rax,%r11,1),%zmm7
   15837:	vfmadd213pd (%rax,%rdx,8),%zmm0,%zmm7
   1583e:	vmovupd (%rax),%zmm3
   15844:	vfmadd213pd (%rax,%rsi,1),%zmm0,%zmm3
   1584b:	vmovupd (%rax,%rcx,1),%zmm10
   15852:	vfmadd213pd (%rax,%r8,1),%zmm0,%zmm10
   15859:	vmovupd (%rax,%rsi,1),%zmm2
   15860:	vmovupd (%rax,%r9,1),%zmm4
   15867:	vsubpd (%rax),%zmm2,%zmm1
   1586d:	vfmadd213pd (%rax,%r10,1),%zmm0,%zmm4
   15874:	vmovupd (%rax,%rdx,8),%zmm2
   1587b:	vsubpd (%rax,%r11,1),%zmm2,%zmm6
   15882:	vmovapd %zmm7,%zmm8
   15888:	vmovupd (%rax,%r10,1),%zmm5
   1588f:	vsubpd (%rax,%r9,1),%zmm5,%zmm2
   15896:	vfmadd132pd %zmm0,%zmm3,%zmm8
   1589c:	vsubpd %zmm7,%zmm3,%zmm3
   158a2:	vmovupd (%rax,%r8,1),%zmm5
   158a9:	vsubpd (%rax,%rcx,1),%zmm5,%zmm5
   158b0:	vmovapd %zmm10,%zmm9
   158b6:	vmovapd %zmm6,%zmm7
   158bc:	vfmadd132pd %zmm0,%zmm1,%zmm7
   158c2:	vsubpd %zmm6,%zmm1,%zmm1
   158c8:	vmovapd %zmm5,%zmm6
   158ce:	vfmadd132pd %zmm0,%zmm4,%zmm9
   158d4:	vsubpd %zmm10,%zmm4,%zmm4
   158da:	vfmadd132pd %zmm0,%zmm2,%zmm6
   158e0:	vsubpd %zmm5,%zmm2,%zmm2
   158e6:	vmovapd %zmm4,%zmm10
   158ec:	vmovapd %zmm2,%zmm5
   158f2:	vfmadd132pd %zmm0,%zmm3,%zmm10
   158f8:	vsubpd %zmm4,%zmm3,%zmm3
   158fe:	vmovapd %zmm9,%zmm12
   15904:	vfmadd132pd %zmm0,%zmm1,%zmm5
   1590a:	vsubpd %zmm2,%zmm1,%zmm1
   15910:	vmovapd %zmm6,%zmm11
   15916:	vfmadd132pd %zmm0,%zmm8,%zmm12
   1591c:	vsubpd %zmm9,%zmm8,%zmm8
   15922:	vfmadd132pd %zmm0,%zmm7,%zmm11
   15928:	vsubpd %zmm6,%zmm7,%zmm7
   1592e:	vmovupd %zmm12,(%rax,%rsi,1)
   15935:	vmovupd %zmm11,(%rax)
   1593b:	vmovupd %zmm10,(%rax,%rdx,8)
   15942:	add    $0x40,%rax
   15946:	vmovupd %zmm5,-0x40(%rax,%r11,1)
   1594e:	vmovupd %zmm8,-0x40(%rax,%r10,1)
   15956:	vmovupd %zmm7,-0x40(%rax,%r9,1)
   1595e:	vmovupd %zmm3,-0x40(%rax,%r8,1)
   15966:	vmovupd %zmm1,-0x40(%rax,%rcx,1)
   1596e:	cmp    %rax,%rdi
   15971:	jne    15830 <hstep_tb8_bal+0xa0>
   15977:	add    %r13,%rbx
   1597a:	mov    %rbx,%rax
   1597d:	sub    %rdx,%rax
   15980:	cmp    %r15,%rax
   15983:	jb     15818 <hstep_tb8_bal+0x88>
   15989:	vzeroupper
   1598c:	lea    -0x28(%rbp),%rsp
   15990:	pop    %rbx
   15991:	pop    %r12
   15993:	pop    %r13
   15995:	pop    %r14
   15997:	pop    %r15
   15999:	pop    %rbp
   1599a:	ret
   1599b:	vzeroupper
   1599e:	ret
   1599f:	nop

000000000001dea0 <hstep_g52_nat>:
   1dea0:	endbr64
   1dea4:	vbroadcastsd 0x2dd32(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
   1deae:	test   %rsi,%rsi
   1deb1:	je     1e1d0 <hstep_g52_nat+0x330>
   1deb7:	push   %rbp
   1deb8:	mov    %rdx,%rcx
   1debb:	mov    %rsp,%rbp
   1debe:	push   %r15
   1dec0:	push   %r14
   1dec2:	push   %r13
   1dec4:	push   %r12
   1dec6:	mov    %rsi,%r12
   1dec9:	mov    %rdx,%rsi
   1decc:	push   %rbx
   1decd:	shl    $0x4,%rsi
   1ded1:	and    $0xffffffffffffffc0,%rsp
   1ded5:	test   %rdx,%rdx
   1ded8:	je     1e1be <hstep_g52_nat+0x31e>
   1dede:	lea    (%rdx,%rdx,4),%r8
   1dee2:	mov    %rdi,%rax
   1dee5:	lea    -0x1(%rdx),%rdx
   1dee9:	mov    %rcx,%r10
   1deec:	mov    %r8,%r14
   1deef:	lea    (%rdi,%rsi,1),%rbx
   1def3:	shr    $0x3,%rdx
   1def7:	add    $0x40,%rax
   1defb:	shl    $0x4,%r14
   1deff:	vmovq  %rbx,%xmm1
   1df04:	lea    (%rcx,%rdx,4),%r13
   1df08:	xor    %ebx,%ebx
   1df0a:	add    %rdi,%r14
   1df0d:	neg    %r10
   1df10:	mov    %rsi,%rdi
   1df13:	mov    %rcx,%r11
   1df16:	lea    (%rcx,%rcx,2),%r9
   1df1a:	vmovq  %rax,%xmm2
   1df1f:	add    %r13,%r13
   1df22:	neg    %rdi
   1df25:	vmovq  %r12,%xmm16
   1df2b:	shl    $0x3,%r10
   1df2f:	vmovq  %xmm1,%r12
   1df34:	vbroadcastsd 0x2dc0a(%rip),%zmm0        # 4bb48 <FFHT_THR_D+0x148>
   1df3e:	shl    $0x3,%r9
   1df42:	shl    $0x5,%r11
   1df46:	vmovdqa64 %xmm2,%xmm19
   1df4c:	shl    $0x3,%r8
   1df50:	lea    0x0(,%rbx,8),%rdx
   1df58:	lea    (%rbx,%r13,1),%r15
   1df5c:	lea    (%rdx,%r12,1),%rax
   1df60:	add    %r14,%rdx
   1df63:	mov    %rax,-0x8(%rsp)
   1df68:	vmovq  %xmm19,%rax
   1df6e:	lea    (%rax,%r15,8),%r15
   1df72:	mov    -0x8(%rsp),%rax
   1df77:	nopw   0x0(%rax,%rax,1)
   1df80:	vmovupd (%rax),%zmm4
   1df86:	vmovupd (%rax,%r10,1),%zmm3
   1df8d:	vmovapd %zmm0,%zmm8
   1df93:	vmovapd %zmm0,%zmm13
   1df99:	vaddpd (%rax,%rdi,1),%zmm3,%zmm17
   1dfa0:	vsubpd (%rax,%rcx,8),%zmm4,%zmm15
   1dfa7:	vmovupd (%rax,%r11,1),%zmm6
   1dfae:	vmovupd (%rax,%r9,1),%zmm5
   1dfb5:	vsubpd (%rax,%r8,1),%zmm6,%zmm3
   1dfbc:	vaddpd (%rax,%rsi,1),%zmm5,%zmm12
   1dfc3:	vmovapd %zmm0,%zmm5
   1dfc9:	vsubpd %zmm15,%zmm17,%zmm2
   1dfcf:	vmovupd (%rdx,%r10,1),%zmm7
   1dfd6:	vaddpd (%rdx,%rdi,1),%zmm7,%zmm10
   1dfdd:	vmovupd (%rdx,%r9,1),%zmm7
   1dfe4:	vaddpd (%rdx,%rsi,1),%zmm7,%zmm11
   1dfeb:	vmovapd %zmm0,%zmm7
   1dff1:	vfmadd132pd %zmm4,%zmm2,%zmm8
   1dff7:	vmovapd %zmm2,%zmm1
   1dffd:	vaddpd %zmm3,%zmm12,%zmm2
   1e003:	vfmsub231pd (%rax,%rdi,1),%zmm0,%zmm1
   1e00a:	vfnmadd132pd %zmm6,%zmm2,%zmm5
   1e010:	vmovapd %zmm2,%zmm4
   1e016:	vmovupd (%rdx),%zmm6
   1e01c:	vsubpd (%rdx,%rcx,8),%zmm6,%zmm14
   1e023:	vfmsub231pd (%rax,%rsi,1),%zmm0,%zmm4
   1e02a:	vsubpd %zmm5,%zmm8,%zmm2
   1e030:	vfmadd132pd %zmm0,%zmm2,%zmm12
   1e036:	vfmsub132pd %zmm0,%zmm2,%zmm17
   1e03c:	vaddpd %zmm4,%zmm1,%zmm2
   1e042:	vfmadd132pd %zmm0,%zmm2,%zmm3
   1e048:	vfnmadd132pd %zmm0,%zmm2,%zmm15
   1e04e:	vsubpd %zmm14,%zmm10,%zmm2
   1e054:	vfmadd132pd %zmm6,%zmm2,%zmm13
   1e05a:	vfmsub231pd (%rdx,%rdi,1),%zmm0,%zmm2
   1e061:	vmovupd (%rdx,%r11,1),%zmm6
   1e068:	vmovapd %zmm2,%zmm9
   1e06e:	vsubpd (%rdx,%r8,1),%zmm6,%zmm2
   1e075:	vaddpd %zmm2,%zmm11,%zmm6
   1e07b:	vfnmadd132pd (%rdx,%r11,1),%zmm6,%zmm7
   1e082:	vfmsub231pd (%rdx,%rsi,1),%zmm0,%zmm6
   1e089:	vaddpd %zmm7,%zmm13,%zmm18
   1e08f:	vfnmadd132pd %zmm0,%zmm18,%zmm11
   1e095:	vfmsub132pd %zmm0,%zmm18,%zmm10
   1e09b:	vsubpd %zmm6,%zmm9,%zmm18
   1e0a1:	vfnmadd132pd %zmm0,%zmm18,%zmm2
   1e0a7:	vfnmadd132pd %zmm0,%zmm18,%zmm14
   1e0ad:	vaddpd %zmm11,%zmm12,%zmm18
   1e0b3:	vfnmadd132pd %zmm0,%zmm18,%zmm13
   1e0b9:	vfmsub132pd %zmm0,%zmm18,%zmm8
   1e0bf:	vaddpd %zmm2,%zmm3,%zmm18
   1e0c5:	vfnmadd132pd %zmm0,%zmm18,%zmm9
   1e0cb:	vfmsub132pd %zmm0,%zmm18,%zmm1
   1e0d1:	vaddpd %zmm10,%zmm17,%zmm18
   1e0d7:	vfmsub132pd %zmm0,%zmm13,%zmm12
   1e0dd:	vfmadd132pd %zmm0,%zmm8,%zmm11
   1e0e3:	vfmadd132pd %zmm0,%zmm18,%zmm7
   1e0e9:	vfnmadd132pd %zmm0,%zmm18,%zmm5
   1e0ef:	vaddpd %zmm14,%zmm15,%zmm18
   1e0f5:	vfmsub132pd %zmm0,%zmm9,%zmm3
   1e0fb:	vfmadd132pd %zmm0,%zmm1,%zmm2
   1e101:	vfmadd132pd %zmm0,%zmm18,%zmm6
   1e107:	vfnmadd132pd %zmm0,%zmm18,%zmm4
   1e10d:	vmovupd %zmm12,(%rax,%rdi,1)
   1e114:	vfmsub132pd %zmm0,%zmm7,%zmm17
   1e11a:	vfnmadd132pd %zmm0,%zmm5,%zmm10
   1e120:	vmovupd %zmm3,(%rax,%r10,1)
   1e127:	vfmsub132pd %zmm0,%zmm6,%zmm15
   1e12d:	vfnmadd132pd %zmm0,%zmm4,%zmm14
   1e133:	vmovupd %zmm7,(%rax)
   1e139:	vmovupd %zmm6,(%rax,%rcx,8)
   1e140:	add    $0x40,%rax
   1e144:	vmovupd %zmm11,-0x40(%rax,%rsi,1)
   1e14c:	vmovupd %zmm2,-0x40(%rax,%r9,1)
   1e154:	vmovupd %zmm5,-0x40(%rax,%r11,1)
   1e15c:	vmovupd %zmm4,-0x40(%rax,%r8,1)
   1e164:	vmovupd %zmm13,(%rdx,%rdi,1)
   1e16b:	vmovupd %zmm9,(%rdx,%r10,1)
   1e172:	vmovupd %zmm17,(%rdx)
   1e178:	vmovupd %zmm15,(%rdx,%rcx,8)
   1e17f:	add    $0x40,%rdx
   1e183:	vmovupd %zmm8,-0x40(%rdx,%rsi,1)
   1e18b:	vmovupd %zmm1,-0x40(%rdx,%r9,1)
   1e193:	vmovupd %zmm10,-0x40(%rdx,%r11,1)
   1e19b:	vmovupd %zmm14,-0x40(%rdx,%r8,1)
   1e1a3:	cmp    %r15,%rax
   1e1a6:	jne    1df80 <hstep_g52_nat+0xe0>
   1e1ac:	add    %rsi,%rbx
   1e1af:	vmovq  %xmm16,%rax
   1e1b5:	cmp    %rax,%rbx
   1e1b8:	jb     1df50 <hstep_g52_nat+0xb0>
   1e1be:	vzeroupper
   1e1c1:	lea    -0x28(%rbp),%rsp
   1e1c5:	pop    %rbx
   1e1c6:	pop    %r12
   1e1c8:	pop    %r13
   1e1ca:	pop    %r14
   1e1cc:	pop    %r15
   1e1ce:	pop    %rbp
   1e1cf:	ret
   1e1d0:	vzeroupper
   1e1d3:	ret
   1e1d4:	data16 cs nopw 0x0(%rax,%rax,1)
   1e1df:	nop

000000000001f360 <hstep_tb16_nat>:
   1f360:	endbr64
   1f364:	vbroadcastsd 0x2c872(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
   1f36e:	test   %rsi,%rsi
   1f371:	je     1f6a0 <hstep_tb16_nat+0x340>
   1f377:	push   %rbp
   1f378:	mov    %rdx,%rcx
   1f37b:	mov    %rsp,%rbp
   1f37e:	push   %r15
   1f380:	push   %r14
   1f382:	push   %r13
   1f384:	push   %r12
   1f386:	mov    %rsi,%r12
   1f389:	mov    %rdx,%rsi
   1f38c:	push   %rbx
   1f38d:	shl    $0x4,%rsi
   1f391:	and    $0xffffffffffffffc0,%rsp
   1f395:	test   %rdx,%rdx
   1f398:	je     1f68e <hstep_tb16_nat+0x32e>
   1f39e:	lea    (%rdx,%rdx,4),%r8
   1f3a2:	mov    %rdi,%rax
   1f3a5:	lea    -0x1(%rdx),%rdx
   1f3a9:	mov    %rcx,%r10
   1f3ac:	mov    %r8,%r14
   1f3af:	lea    (%rdi,%rsi,1),%rbx
   1f3b3:	shr    $0x3,%rdx
   1f3b7:	add    $0x40,%rax
   1f3bb:	shl    $0x4,%r14
   1f3bf:	vmovq  %rbx,%xmm3
   1f3c4:	lea    (%rcx,%rdx,4),%r13
   1f3c8:	xor    %ebx,%ebx
   1f3ca:	add    %rdi,%r14
   1f3cd:	neg    %r10
   1f3d0:	mov    %rsi,%rdi
   1f3d3:	mov    %rcx,%r11
   1f3d6:	lea    (%rcx,%rcx,2),%r9
   1f3da:	vmovq  %rax,%xmm1
   1f3df:	add    %r13,%r13
   1f3e2:	neg    %rdi
   1f3e5:	vmovq  %r12,%xmm14
   1f3ea:	shl    $0x3,%r10
   1f3ee:	vmovq  %xmm3,%r12
   1f3f3:	vmovdqa64 %xmm1,%xmm21
   1f3f9:	shl    $0x3,%r9
   1f3fd:	shl    $0x5,%r11
   1f401:	shl    $0x3,%r8
   1f405:	lea    0x0(,%rbx,8),%rdx
   1f40d:	lea    (%rbx,%r13,1),%r15
   1f411:	lea    (%rdx,%r12,1),%rax
   1f415:	add    %r14,%rdx
   1f418:	mov    %rax,-0x8(%rsp)
   1f41d:	vmovq  %xmm21,%rax
   1f423:	lea    (%rax,%r15,8),%r15
   1f427:	mov    -0x8(%rsp),%rax
   1f42c:	nopl   0x0(%rax)
   1f430:	vmovupd (%rax,%rdi,1),%zmm2
   1f437:	vmovupd (%rax),%zmm6
   1f43d:	vaddpd (%rax,%r10,1),%zmm2,%zmm9
   1f444:	vaddpd (%rax,%rcx,8),%zmm6,%zmm16
   1f44b:	vsubpd (%rax,%rcx,8),%zmm6,%zmm7
   1f452:	vsubpd (%rax,%r10,1),%zmm2,%zmm0
   1f459:	vmovupd (%rdx),%zmm3
   1f45f:	vmovupd (%rax,%rsi,1),%zmm2
   1f466:	vaddpd (%rdx,%rcx,8),%zmm3,%zmm11
   1f46d:	vsubpd (%rdx,%rcx,8),%zmm3,%zmm4
   1f474:	vaddpd (%rax,%r9,1),%zmm2,%zmm15
   1f47b:	vsubpd (%rax,%r9,1),%zmm2,%zmm1
   1f482:	vmovupd (%rax,%r11,1),%zmm6
   1f489:	vmovupd (%rdx,%rdi,1),%zmm2
   1f490:	vaddpd %zmm16,%zmm9,%zmm20
   1f496:	vaddpd %zmm7,%zmm0,%zmm19
   1f49c:	vaddpd (%rax,%r8,1),%zmm6,%zmm12
   1f4a3:	vaddpd (%rdx,%r10,1),%zmm2,%zmm13
   1f4aa:	vsubpd (%rax,%r8,1),%zmm6,%zmm6
   1f4b1:	vsubpd (%rdx,%r10,1),%zmm2,%zmm5
   1f4b8:	vmovupd (%rdx,%rsi,1),%zmm3
   1f4bf:	vmovupd (%rdx,%r11,1),%zmm2
   1f4c6:	vsubpd %zmm7,%zmm0,%zmm0
   1f4cc:	vsubpd %zmm16,%zmm9,%zmm9
   1f4d2:	vaddpd (%rdx,%r8,1),%zmm2,%zmm8
   1f4d9:	vaddpd (%rdx,%r9,1),%zmm3,%zmm10
   1f4e0:	vsubpd (%rdx,%r8,1),%zmm2,%zmm2
   1f4e7:	vsubpd (%rdx,%r9,1),%zmm3,%zmm3
   1f4ee:	vaddpd %zmm12,%zmm15,%zmm7
   1f4f4:	vaddpd %zmm6,%zmm1,%zmm18
   1f4fa:	vaddpd %zmm11,%zmm13,%zmm17
   1f500:	vsubpd %zmm12,%zmm15,%zmm15
   1f506:	vaddpd %zmm8,%zmm10,%zmm12
   1f50c:	vaddpd %zmm4,%zmm5,%zmm16
   1f512:	vsubpd %zmm6,%zmm1,%zmm1
   1f518:	vsubpd %zmm4,%zmm5,%zmm5
   1f51e:	vsubpd %zmm8,%zmm10,%zmm10
   1f524:	vsubpd %zmm11,%zmm13,%zmm13
   1f52a:	vaddpd %zmm7,%zmm20,%zmm8
   1f530:	vaddpd %zmm2,%zmm3,%zmm11
   1f536:	vsubpd %zmm7,%zmm20,%zmm4
   1f53c:	vsubpd %zmm2,%zmm3,%zmm3
   1f542:	vaddpd %zmm18,%zmm19,%zmm7
   1f548:	vsubpd %zmm18,%zmm19,%zmm2
   1f54e:	vaddpd %zmm12,%zmm17,%zmm18
   1f554:	vaddpd %zmm15,%zmm9,%zmm6
   1f55a:	vsubpd %zmm12,%zmm17,%zmm12
   1f560:	vsubpd %zmm15,%zmm9,%zmm9
   1f566:	vaddpd %zmm11,%zmm16,%zmm17
   1f56c:	vaddpd %zmm1,%zmm0,%zmm15
   1f572:	vsubpd %zmm11,%zmm16,%zmm11
   1f578:	vsubpd %zmm1,%zmm0,%zmm0
   1f57e:	vaddpd %zmm10,%zmm13,%zmm16
   1f584:	vsubpd %zmm10,%zmm13,%zmm1
   1f58a:	vaddpd %zmm3,%zmm5,%zmm10
   1f590:	vsubpd %zmm3,%zmm5,%zmm3
   1f596:	vaddpd %zmm18,%zmm8,%zmm5
   1f59c:	vsubpd %zmm18,%zmm8,%zmm8
   1f5a2:	vmovupd %zmm5,(%rax,%rdi,1)
   1f5a9:	vaddpd %zmm17,%zmm7,%zmm5
   1f5af:	vsubpd %zmm17,%zmm7,%zmm7
   1f5b5:	vmovupd %zmm5,(%rax,%r10,1)
   1f5bc:	vaddpd %zmm16,%zmm6,%zmm5
   1f5c2:	vsubpd %zmm16,%zmm6,%zmm6
   1f5c8:	vmovupd %zmm5,(%rax)
   1f5ce:	vaddpd %zmm10,%zmm15,%zmm5
   1f5d4:	vmovupd %zmm5,(%rax,%rcx,8)
   1f5db:	vaddpd %zmm12,%zmm4,%zmm5
   1f5e1:	add    $0x40,%rax
   1f5e5:	vsubpd %zmm12,%zmm4,%zmm4
   1f5eb:	vmovupd %zmm5,-0x40(%rax,%rsi,1)
   1f5f3:	vaddpd %zmm11,%zmm2,%zmm5
   1f5f9:	vsubpd %zmm11,%zmm2,%zmm2
   1f5ff:	vmovupd %zmm5,-0x40(%rax,%r9,1)
   1f607:	vaddpd %zmm1,%zmm9,%zmm5
   1f60d:	vsubpd %zmm1,%zmm9,%zmm1
   1f613:	vmovupd %zmm5,-0x40(%rax,%r11,1)
   1f61b:	vaddpd %zmm3,%zmm0,%zmm5
   1f621:	vsubpd %zmm3,%zmm0,%zmm0
   1f627:	vmovupd %zmm5,-0x40(%rax,%r8,1)
   1f62f:	vsubpd %zmm10,%zmm15,%zmm5
   1f635:	vmovupd %zmm8,(%rdx,%rdi,1)
   1f63c:	vmovupd %zmm7,(%rdx,%r10,1)
   1f643:	vmovupd %zmm6,(%rdx)
   1f649:	vmovupd %zmm5,(%rdx,%rcx,8)
   1f650:	add    $0x40,%rdx
   1f654:	vmovupd %zmm4,-0x40(%rdx,%rsi,1)
   1f65c:	vmovupd %zmm2,-0x40(%rdx,%r9,1)
   1f664:	vmovupd %zmm1,-0x40(%rdx,%r11,1)
   1f66c:	vmovupd %zmm0,-0x40(%rdx,%r8,1)
   1f674:	cmp    %r15,%rax
   1f677:	jne    1f430 <hstep_tb16_nat+0xd0>
   1f67d:	add    %rsi,%rbx
   1f680:	vmovq  %xmm14,%rax
   1f685:	cmp    %rax,%rbx
   1f688:	jb     1f405 <hstep_tb16_nat+0xa5>
   1f68e:	vzeroupper
   1f691:	lea    -0x28(%rbp),%rsp
   1f695:	pop    %rbx
   1f696:	pop    %r12
   1f698:	pop    %r13
   1f69a:	pop    %r14
   1f69c:	pop    %r15
   1f69e:	pop    %rbp
   1f69f:	ret
   1f6a0:	vzeroupper
   1f6a3:	ret
   1f6a4:	data16 cs nopw 0x0(%rax,%rax,1)
   1f6af:	nop

0000000000021cc0 <hfirst_g20_nat>:
   21cc0:	endbr64
   21cc4:	vbroadcastsd 0x29f12(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
   21cce:	mov    %rdi,%rax
   21cd1:	test   %rsi,%rsi
   21cd4:	je     21fbd <hfirst_g20_nat+0x2fd>
   21cda:	lea    -0x8(,%rsi,8),%rdx
   21ce2:	mov    $0xffffffaa,%ecx
   21ce7:	vmovdqa64 0x29d8f(%rip),%zmm11        # 4ba80 <FFHT_THR_D+0x80>
   21cf1:	vmovdqa64 0x29dc5(%rip),%zmm10        # 4bac0 <FFHT_THR_D+0xc0>
   21cfb:	and    $0xfffffffffffffe00,%rdx
   21d02:	kmovw  %ecx,%k3
   21d06:	mov    $0xffffffcc,%ecx
   21d0b:	vmovdqa64 0x29deb(%rip),%zmm9        # 4bb00 <FFHT_THR_D+0x100>
   21d15:	vbroadcastsd 0x29e29(%rip),%zmm0        # 4bb48 <FFHT_THR_D+0x148>
   21d1f:	lea    0x200(%rdi,%rdx,1),%rdx
   21d27:	kmovw  %ecx,%k2
   21d2b:	mov    $0xfffffff0,%edi
   21d30:	kmovw  %edi,%k1
   21d34:	nopl   0x0(%rax)
   21d38:	vpermpd (%rax),%zmm11,%zmm1
   21d3e:	vaddpd (%rax),%zmm1,%zmm2
   21d44:	add    $0x200,%rax
   21d4a:	vsubpd -0x200(%rax),%zmm1,%zmm2{%k3}
   21d51:	vpermpd %zmm2,%zmm10,%zmm3
   21d57:	vaddpd %zmm2,%zmm3,%zmm1
   21d5d:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   21d63:	vpermpd %zmm1,%zmm9,%zmm2
   21d69:	vaddpd %zmm2,%zmm1,%zmm5
   21d6f:	vsubpd %zmm1,%zmm2,%zmm5{%k1}
   21d75:	vpermpd -0x1c0(%rax),%zmm11,%zmm1
   21d7c:	vaddpd -0x1c0(%rax),%zmm1,%zmm2
   21d83:	vsubpd -0x1c0(%rax),%zmm1,%zmm2{%k3}
   21d8a:	vpermpd %zmm2,%zmm10,%zmm3
   21d90:	vaddpd %zmm3,%zmm2,%zmm1
   21d96:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   21d9c:	vpermpd %zmm1,%zmm9,%zmm2
   21da2:	vaddpd %zmm2,%zmm1,%zmm4
   21da8:	vsubpd %zmm1,%zmm2,%zmm4{%k1}
   21dae:	vpermpd -0x180(%rax),%zmm11,%zmm1
   21db5:	vaddpd -0x180(%rax),%zmm1,%zmm2
   21dbc:	vsubpd -0x180(%rax),%zmm1,%zmm2{%k3}
   21dc3:	vaddpd %zmm4,%zmm5,%zmm4
   21dc9:	vpermpd %zmm2,%zmm10,%zmm3
   21dcf:	vaddpd %zmm3,%zmm2,%zmm1
   21dd5:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   21ddb:	vpermpd %zmm1,%zmm9,%zmm2
   21de1:	vaddpd %zmm2,%zmm1,%zmm8
   21de7:	vsubpd %zmm1,%zmm2,%zmm8{%k1}
   21ded:	vpermpd -0x140(%rax),%zmm11,%zmm1
   21df4:	vaddpd -0x140(%rax),%zmm1,%zmm2
   21dfb:	vsubpd -0x140(%rax),%zmm1,%zmm2{%k3}
   21e02:	vpermpd %zmm2,%zmm10,%zmm3
   21e08:	vaddpd %zmm3,%zmm2,%zmm1
   21e0e:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   21e14:	vpermpd %zmm1,%zmm9,%zmm2
   21e1a:	vaddpd %zmm2,%zmm1,%zmm7
   21e20:	vsubpd %zmm1,%zmm2,%zmm7{%k1}
   21e26:	vpermpd -0x100(%rax),%zmm11,%zmm1
   21e2d:	vaddpd -0x100(%rax),%zmm1,%zmm2
   21e34:	vsubpd -0x100(%rax),%zmm1,%zmm2{%k3}
   21e3b:	vsubpd %zmm7,%zmm8,%zmm7
   21e41:	vpermpd %zmm2,%zmm10,%zmm3
   21e47:	vaddpd %zmm3,%zmm2,%zmm1
   21e4d:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   21e53:	vpermpd %zmm1,%zmm9,%zmm2
   21e59:	vaddpd %zmm2,%zmm1,%zmm3
   21e5f:	vsubpd %zmm1,%zmm2,%zmm3{%k1}
   21e65:	vpermpd -0xc0(%rax),%zmm11,%zmm1
   21e6c:	vaddpd -0xc0(%rax),%zmm1,%zmm2
   21e73:	vsubpd -0xc0(%rax),%zmm1,%zmm2{%k3}
   21e7a:	vpermpd %zmm2,%zmm10,%zmm6
   21e80:	vaddpd %zmm6,%zmm2,%zmm1
   21e86:	vsubpd %zmm2,%zmm6,%zmm1{%k2}
   21e8c:	vpermpd %zmm1,%zmm9,%zmm2
   21e92:	vaddpd %zmm2,%zmm1,%zmm6
   21e98:	vsubpd %zmm1,%zmm2,%zmm6{%k1}
   21e9e:	vpermpd -0x80(%rax),%zmm11,%zmm2
   21ea5:	vaddpd -0x80(%rax),%zmm2,%zmm1
   21eac:	vsubpd -0x80(%rax),%zmm2,%zmm1{%k3}
   21eb3:	vaddpd %zmm6,%zmm3,%zmm6
   21eb9:	vpermpd %zmm1,%zmm10,%zmm12
   21ebf:	vaddpd %zmm12,%zmm1,%zmm2
   21ec5:	vsubpd %zmm1,%zmm12,%zmm2{%k2}
   21ecb:	vpermpd %zmm2,%zmm9,%zmm12
   21ed1:	vaddpd %zmm12,%zmm2,%zmm1
   21ed7:	vsubpd %zmm2,%zmm12,%zmm1{%k1}
   21edd:	vpermpd -0x40(%rax),%zmm11,%zmm12
   21ee4:	vaddpd -0x40(%rax),%zmm12,%zmm2
   21eeb:	vsubpd -0x40(%rax),%zmm12,%zmm2{%k3}
   21ef2:	vpermpd %zmm2,%zmm10,%zmm13
   21ef8:	vaddpd %zmm2,%zmm13,%zmm12
   21efe:	vsubpd %zmm2,%zmm13,%zmm12{%k2}
   21f04:	vpermpd %zmm12,%zmm9,%zmm13
   21f0a:	vaddpd %zmm13,%zmm12,%zmm2
   21f10:	vsubpd %zmm12,%zmm13,%zmm2{%k1}
   21f16:	vsubpd %zmm7,%zmm4,%zmm12
   21f1c:	vsubpd %zmm2,%zmm1,%zmm2
   21f22:	vfmadd132pd %zmm0,%zmm12,%zmm8
   21f28:	vfmsub132pd %zmm0,%zmm12,%zmm5
   21f2e:	vaddpd %zmm2,%zmm6,%zmm12
   21f34:	vfnmadd132pd %zmm0,%zmm12,%zmm1
   21f3a:	vfmsub132pd %zmm0,%zmm12,%zmm3
   21f40:	vaddpd %zmm1,%zmm8,%zmm12
   21f46:	vfnmadd132pd %zmm0,%zmm12,%zmm6
   21f4c:	vfmsub132pd %zmm0,%zmm12,%zmm4
   21f52:	vaddpd %zmm3,%zmm5,%zmm12
   21f58:	vfmadd132pd %zmm0,%zmm12,%zmm2
   21f5e:	vfnmadd132pd %zmm0,%zmm12,%zmm7
   21f64:	vfmsub132pd %zmm0,%zmm6,%zmm8
   21f6a:	vfmadd132pd %zmm0,%zmm4,%zmm1
   21f70:	vmovupd %zmm6,-0x100(%rax)
   21f77:	vmovupd %zmm4,-0x80(%rax)
   21f7e:	vfmsub132pd %zmm0,%zmm2,%zmm5
   21f84:	vfnmadd132pd %zmm0,%zmm7,%zmm3
   21f8a:	vmovupd %zmm2,-0x1c0(%rax)
   21f91:	vmovupd %zmm7,-0x140(%rax)
   21f98:	vmovupd %zmm8,-0x200(%rax)
   21f9f:	vmovupd %zmm1,-0x180(%rax)
   21fa6:	vmovupd %zmm5,-0xc0(%rax)
   21fad:	vmovupd %zmm3,-0x40(%rax)
   21fb4:	cmp    %rdx,%rax
   21fb7:	jne    21d38 <hfirst_g20_nat+0x78>
   21fbd:	vzeroupper
   21fc0:	ret
   21fc1:	data16 cs nopw 0x0(%rax,%rax,1)
   21fcc:	nopl   0x0(%rax)

0000000000022fc0 <hfirst_broken_g20>:
   22fc0:	endbr64
   22fc4:	vbroadcastsd 0x28c12(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
   22fce:	mov    %rdi,%rax
   22fd1:	test   %rsi,%rsi
   22fd4:	je     232bd <hfirst_broken_g20+0x2fd>
   22fda:	lea    -0x8(,%rsi,8),%rdx
   22fe2:	mov    $0xffffffaa,%ecx
   22fe7:	vmovdqa64 0x28a8f(%rip),%zmm11        # 4ba80 <FFHT_THR_D+0x80>
   22ff1:	vmovdqa64 0x28ac5(%rip),%zmm10        # 4bac0 <FFHT_THR_D+0xc0>
   22ffb:	and    $0xfffffffffffffe00,%rdx
   23002:	kmovw  %ecx,%k3
   23006:	mov    $0xffffffcc,%ecx
   2300b:	vmovdqa64 0x28aeb(%rip),%zmm9        # 4bb00 <FFHT_THR_D+0x100>
   23015:	vbroadcastsd 0x28b29(%rip),%zmm0        # 4bb48 <FFHT_THR_D+0x148>
   2301f:	lea    0x200(%rdi,%rdx,1),%rdx
   23027:	kmovw  %ecx,%k2
   2302b:	mov    $0xfffffff0,%edi
   23030:	kmovw  %edi,%k1
   23034:	nopl   0x0(%rax)
   23038:	vpermpd (%rax),%zmm11,%zmm1
   2303e:	vaddpd (%rax),%zmm1,%zmm2
   23044:	add    $0x200,%rax
   2304a:	vsubpd -0x200(%rax),%zmm1,%zmm2{%k3}
   23051:	vpermpd %zmm2,%zmm10,%zmm3
   23057:	vaddpd %zmm2,%zmm3,%zmm1
   2305d:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   23063:	vpermpd %zmm1,%zmm9,%zmm2
   23069:	vaddpd %zmm2,%zmm1,%zmm4
   2306f:	vsubpd %zmm1,%zmm2,%zmm4{%k1}
   23075:	vpermpd -0x1c0(%rax),%zmm11,%zmm1
   2307c:	vaddpd -0x1c0(%rax),%zmm1,%zmm2
   23083:	vsubpd -0x1c0(%rax),%zmm1,%zmm2{%k3}
   2308a:	vpermpd %zmm2,%zmm10,%zmm3
   23090:	vaddpd %zmm3,%zmm2,%zmm1
   23096:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   2309c:	vpermpd %zmm1,%zmm9,%zmm2
   230a2:	vaddpd %zmm2,%zmm1,%zmm5
   230a8:	vsubpd %zmm1,%zmm2,%zmm5{%k1}
   230ae:	vpermpd -0x180(%rax),%zmm11,%zmm1
   230b5:	vaddpd -0x180(%rax),%zmm1,%zmm2
   230bc:	vsubpd -0x180(%rax),%zmm1,%zmm2{%k3}
   230c3:	vaddpd %zmm5,%zmm4,%zmm5
   230c9:	vpermpd %zmm2,%zmm10,%zmm3
   230cf:	vaddpd %zmm3,%zmm2,%zmm1
   230d5:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   230db:	vpermpd %zmm1,%zmm9,%zmm2
   230e1:	vaddpd %zmm2,%zmm1,%zmm8
   230e7:	vsubpd %zmm1,%zmm2,%zmm8{%k1}
   230ed:	vpermpd -0x140(%rax),%zmm11,%zmm1
   230f4:	vaddpd -0x140(%rax),%zmm1,%zmm2
   230fb:	vsubpd -0x140(%rax),%zmm1,%zmm2{%k3}
   23102:	vpermpd %zmm2,%zmm10,%zmm3
   23108:	vaddpd %zmm3,%zmm2,%zmm1
   2310e:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   23114:	vpermpd %zmm1,%zmm9,%zmm2
   2311a:	vaddpd %zmm2,%zmm1,%zmm7
   23120:	vsubpd %zmm1,%zmm2,%zmm7{%k1}
   23126:	vpermpd -0x100(%rax),%zmm11,%zmm1
   2312d:	vaddpd -0x100(%rax),%zmm1,%zmm2
   23134:	vsubpd -0x100(%rax),%zmm1,%zmm2{%k3}
   2313b:	vsubpd %zmm7,%zmm8,%zmm7
   23141:	vpermpd %zmm2,%zmm10,%zmm3
   23147:	vaddpd %zmm3,%zmm2,%zmm1
   2314d:	vsubpd %zmm2,%zmm3,%zmm1{%k2}
   23153:	vpermpd %zmm1,%zmm9,%zmm2
   23159:	vaddpd %zmm2,%zmm1,%zmm3
   2315f:	vsubpd %zmm1,%zmm2,%zmm3{%k1}
   23165:	vpermpd -0xc0(%rax),%zmm11,%zmm1
   2316c:	vaddpd -0xc0(%rax),%zmm1,%zmm2
   23173:	vsubpd -0xc0(%rax),%zmm1,%zmm2{%k3}
   2317a:	vpermpd %zmm2,%zmm10,%zmm6
   23180:	vaddpd %zmm6,%zmm2,%zmm1
   23186:	vsubpd %zmm2,%zmm6,%zmm1{%k2}
   2318c:	vpermpd %zmm1,%zmm9,%zmm2
   23192:	vaddpd %zmm2,%zmm1,%zmm6
   23198:	vsubpd %zmm1,%zmm2,%zmm6{%k1}
   2319e:	vpermpd -0x80(%rax),%zmm11,%zmm2
   231a5:	vaddpd -0x80(%rax),%zmm2,%zmm1
   231ac:	vsubpd -0x80(%rax),%zmm2,%zmm1{%k3}
   231b3:	vaddpd %zmm6,%zmm3,%zmm6
   231b9:	vpermpd %zmm1,%zmm10,%zmm12
   231bf:	vaddpd %zmm12,%zmm1,%zmm2
   231c5:	vsubpd %zmm1,%zmm12,%zmm2{%k2}
   231cb:	vpermpd %zmm2,%zmm9,%zmm12
   231d1:	vaddpd %zmm12,%zmm2,%zmm1
   231d7:	vsubpd %zmm2,%zmm12,%zmm1{%k1}
   231dd:	vpermpd -0x40(%rax),%zmm11,%zmm12
   231e4:	vaddpd -0x40(%rax),%zmm12,%zmm2
   231eb:	vsubpd -0x40(%rax),%zmm12,%zmm2{%k3}
   231f2:	vpermpd %zmm2,%zmm10,%zmm13
   231f8:	vaddpd %zmm13,%zmm2,%zmm12
   231fe:	vsubpd %zmm2,%zmm13,%zmm12{%k2}
   23204:	vpermpd %zmm12,%zmm9,%zmm13
   2320a:	vaddpd %zmm13,%zmm12,%zmm2
   23210:	vsubpd %zmm12,%zmm13,%zmm2{%k1}
   23216:	vsubpd %zmm7,%zmm5,%zmm12
   2321c:	vsubpd %zmm2,%zmm1,%zmm2
   23222:	vfmadd132pd %zmm0,%zmm12,%zmm8
   23228:	vfmsub132pd %zmm0,%zmm12,%zmm4
   2322e:	vaddpd %zmm2,%zmm6,%zmm12
   23234:	vfnmadd132pd %zmm0,%zmm12,%zmm1
   2323a:	vfmsub132pd %zmm0,%zmm12,%zmm3
   23240:	vaddpd %zmm1,%zmm8,%zmm12
   23246:	vfnmadd132pd %zmm0,%zmm12,%zmm6
   2324c:	vfmsub132pd %zmm0,%zmm12,%zmm5
   23252:	vaddpd %zmm3,%zmm4,%zmm12
   23258:	vfmadd132pd %zmm0,%zmm12,%zmm2
   2325e:	vfnmadd132pd %zmm0,%zmm12,%zmm7
   23264:	vfmsub132pd %zmm0,%zmm6,%zmm8
   2326a:	vfmadd132pd %zmm0,%zmm5,%zmm1
   23270:	vmovupd %zmm6,-0x100(%rax)
   23277:	vmovupd %zmm5,-0xc0(%rax)
   2327e:	vfmsub132pd %zmm0,%zmm2,%zmm4
   23284:	vfnmadd132pd %zmm0,%zmm7,%zmm3
   2328a:	vmovupd %zmm2,-0x1c0(%rax)
   23291:	vmovupd %zmm7,-0x140(%rax)
   23298:	vmovupd %zmm8,-0x200(%rax)
   2329f:	vmovupd %zmm1,-0x180(%rax)
   232a6:	vmovupd %zmm4,-0x80(%rax)
   232ad:	vmovupd %zmm3,-0x40(%rax)
   232b4:	cmp    %rdx,%rax
   232b7:	jne    23038 <hfirst_broken_g20+0x78>
   232bd:	vzeroupper
   232c0:	ret
   232c1:	data16 cs nopw 0x0(%rax,%rax,1)
   232cc:	nopl   0x0(%rax)

00000000000250a0 <hfirst_tb8_bal>:
   250a0:	endbr64
   250a4:	vbroadcastsd 0x26b32(%rip),%zmm1        # 4bbe0 <FFHT_THR_D+0x1e0>
   250ae:	mov    %rdi,%rax
   250b1:	test   %rsi,%rsi
   250b4:	je     253f5 <hfirst_tb8_bal+0x355>
   250ba:	lea    -0x8(,%rsi,8),%rdx
   250c2:	mov    $0xffffffaa,%ecx
   250c7:	vmovdqa64 0x269af(%rip),%zmm5        # 4ba80 <FFHT_THR_D+0x80>
   250d1:	vmovdqa64 0x269e5(%rip),%zmm4        # 4bac0 <FFHT_THR_D+0xc0>
   250db:	and    $0xfffffffffffffe00,%rdx
   250e2:	kmovw  %ecx,%k3
   250e6:	mov    $0xffffffcc,%ecx
   250eb:	vmovdqa64 0x26a0b(%rip),%zmm3        # 4bb00 <FFHT_THR_D+0x100>
   250f5:	lea    0x200(%rdi,%rdx,1),%rdx
   250fd:	mov    $0xfffffff0,%edi
   25102:	kmovw  %ecx,%k2
   25106:	kmovw  %edi,%k1
   2510a:	nopw   0x0(%rax,%rax,1)
   25110:	vpermpd (%rax),%zmm5,%zmm2
   25116:	vaddpd (%rax),%zmm2,%zmm0
   2511c:	add    $0x200,%rax
   25122:	vsubpd -0x200(%rax),%zmm2,%zmm0{%k3}
   25129:	vpermpd %zmm0,%zmm4,%zmm6
   2512f:	vaddpd %zmm0,%zmm6,%zmm2
   25135:	vsubpd %zmm0,%zmm6,%zmm2{%k2}
   2513b:	vpermpd %zmm2,%zmm3,%zmm6
   25141:	vaddpd %zmm6,%zmm2,%zmm0
   25147:	vsubpd %zmm2,%zmm6,%zmm0{%k1}
   2514d:	vpermpd -0x1c0(%rax),%zmm5,%zmm2
   25154:	vaddpd -0x1c0(%rax),%zmm2,%zmm6
   2515b:	vsubpd -0x1c0(%rax),%zmm2,%zmm6{%k3}
   25162:	vpermpd %zmm6,%zmm4,%zmm7
   25168:	vaddpd %zmm7,%zmm6,%zmm2
   2516e:	vsubpd %zmm6,%zmm7,%zmm2{%k2}
   25174:	vpermpd %zmm2,%zmm3,%zmm6
   2517a:	vaddpd %zmm6,%zmm2,%zmm10
   25180:	vsubpd %zmm2,%zmm6,%zmm10{%k1}
   25186:	vpermpd -0x180(%rax),%zmm5,%zmm2
   2518d:	vaddpd -0x180(%rax),%zmm2,%zmm6
   25194:	vsubpd -0x180(%rax),%zmm2,%zmm6{%k3}
   2519b:	vpermpd %zmm6,%zmm4,%zmm7
   251a1:	vaddpd %zmm7,%zmm6,%zmm2
   251a7:	vsubpd %zmm6,%zmm7,%zmm2{%k2}
   251ad:	vpermpd %zmm2,%zmm3,%zmm6
   251b3:	vaddpd %zmm6,%zmm2,%zmm9
   251b9:	vsubpd %zmm2,%zmm6,%zmm9{%k1}
   251bf:	vpermpd -0x140(%rax),%zmm5,%zmm2
   251c6:	vaddpd -0x140(%rax),%zmm2,%zmm6
   251cd:	vsubpd -0x140(%rax),%zmm2,%zmm6{%k3}
   251d4:	vpermpd %zmm6,%zmm4,%zmm7
   251da:	vaddpd %zmm7,%zmm6,%zmm2
   251e0:	vsubpd %zmm6,%zmm7,%zmm2{%k2}
   251e6:	vpermpd %zmm2,%zmm3,%zmm6
   251ec:	vaddpd %zmm6,%zmm2,%zmm12
   251f2:	vsubpd %zmm2,%zmm6,%zmm12{%k1}
   251f8:	vpermpd -0x100(%rax),%zmm5,%zmm6
   251ff:	vaddpd -0x100(%rax),%zmm6,%zmm2
   25206:	vsubpd -0x100(%rax),%zmm6,%zmm2{%k3}
   2520d:	vpermpd %zmm2,%zmm4,%zmm7
   25213:	vaddpd %zmm7,%zmm2,%zmm6
   25219:	vsubpd %zmm2,%zmm7,%zmm6{%k2}
   2521f:	vpermpd %zmm6,%zmm3,%zmm7
   25225:	vaddpd %zmm7,%zmm6,%zmm2
   2522b:	vsubpd %zmm6,%zmm7,%zmm2{%k1}
   25231:	vpermpd -0xc0(%rax),%zmm5,%zmm6
   25238:	vaddpd -0xc0(%rax),%zmm6,%zmm7
   2523f:	vsubpd -0xc0(%rax),%zmm6,%zmm7{%k3}
   25246:	vpermpd %zmm7,%zmm4,%zmm8
   2524c:	vaddpd %zmm8,%zmm7,%zmm6
   25252:	vsubpd %zmm7,%zmm8,%zmm6{%k2}
   25258:	vpermpd %zmm6,%zmm3,%zmm7
   2525e:	vaddpd %zmm7,%zmm6,%zmm13
   25264:	vsubpd %zmm6,%zmm7,%zmm13{%k1}
   2526a:	vpermpd -0x80(%rax),%zmm5,%zmm6
   25271:	vaddpd -0x80(%rax),%zmm6,%zmm7
   25278:	vsubpd -0x80(%rax),%zmm6,%zmm7{%k3}
   2527f:	vpermpd %zmm7,%zmm4,%zmm8
   25285:	vaddpd %zmm8,%zmm7,%zmm6
   2528b:	vsubpd %zmm7,%zmm8,%zmm6{%k2}
   25291:	vpermpd %zmm6,%zmm3,%zmm8
   25297:	vaddpd %zmm8,%zmm6,%zmm7
   2529d:	vsubpd %zmm6,%zmm8,%zmm7{%k1}
   252a3:	vpermpd -0x40(%rax),%zmm5,%zmm6
   252aa:	vaddpd -0x40(%rax),%zmm6,%zmm8
   252b1:	vsubpd -0x40(%rax),%zmm6,%zmm8{%k3}
   252b8:	vpermpd %zmm8,%zmm4,%zmm11
   252be:	vaddpd %zmm8,%zmm11,%zmm6
   252c4:	vsubpd %zmm8,%zmm11,%zmm6{%k2}
   252ca:	vpermpd %zmm6,%zmm3,%zmm8
   252d0:	vaddpd %zmm8,%zmm6,%zmm11
   252d6:	vsubpd %zmm6,%zmm8,%zmm11{%k1}
   252dc:	vmovapd %zmm10,%zmm6
   252e2:	vmovapd %zmm13,%zmm8
   252e8:	vfmadd132pd %zmm1,%zmm0,%zmm6
   252ee:	vsubpd %zmm10,%zmm0,%zmm0
   252f4:	vmovapd %zmm12,%zmm10
   252fa:	vfmadd132pd %zmm1,%zmm9,%zmm10
   25300:	vfmadd132pd %zmm1,%zmm2,%zmm8
   25306:	vsubpd %zmm13,%zmm2,%zmm2
   2530c:	vmovapd %zmm11,%zmm13
   25312:	vsubpd %zmm12,%zmm9,%zmm9
   25318:	vfmadd132pd %zmm1,%zmm7,%zmm13
   2531e:	vsubpd %zmm11,%zmm7,%zmm7
   25324:	vmovapd %zmm10,%zmm11
   2532a:	vfmadd132pd %zmm1,%zmm6,%zmm11
   25330:	vsubpd %zmm10,%zmm6,%zmm6
   25336:	vmovapd %zmm9,%zmm10
   2533c:	vfmadd132pd %zmm1,%zmm0,%zmm10
   25342:	vmovapd %zmm13,%zmm12
   25348:	vsubpd %zmm9,%zmm0,%zmm0
   2534e:	vmovapd %zmm7,%zmm9
   25354:	vfmadd132pd %zmm1,%zmm8,%zmm12
   2535a:	vsubpd %zmm13,%zmm8,%zmm8
   25360:	vfmadd132pd %zmm1,%zmm2,%zmm9
   25366:	vsubpd %zmm7,%zmm2,%zmm2
   2536c:	vmovapd %zmm8,%zmm13
   25372:	vmovapd %zmm2,%zmm7
   25378:	vfmadd132pd %zmm1,%zmm6,%zmm13
   2537e:	vsubpd %zmm8,%zmm6,%zmm6
   25384:	vmovapd %zmm12,%zmm15
   2538a:	vfmadd132pd %zmm1,%zmm0,%zmm7
   25390:	vsubpd %zmm2,%zmm0,%zmm0
   25396:	vmovapd %zmm9,%zmm14
   2539c:	vfmadd132pd %zmm1,%zmm11,%zmm15
   253a2:	vsubpd %zmm12,%zmm11,%zmm11
   253a8:	vfmadd132pd %zmm1,%zmm10,%zmm14
   253ae:	vsubpd %zmm9,%zmm10,%zmm10
   253b4:	vmovupd %zmm6,-0x80(%rax)
   253bb:	vmovupd %zmm0,-0x40(%rax)
   253c2:	vmovupd %zmm13,-0x180(%rax)
   253c9:	vmovupd %zmm7,-0x140(%rax)
   253d0:	vmovupd %zmm15,-0x200(%rax)
   253d7:	vmovupd %zmm14,-0x1c0(%rax)
   253de:	vmovupd %zmm11,-0x100(%rax)
   253e5:	vmovupd %zmm10,-0xc0(%rax)
   253ec:	cmp    %rdx,%rax
   253ef:	jne    25110 <hfirst_tb8_bal+0x70>
   253f5:	vzeroupper
   253f8:	ret
   253f9:	nopl   0x0(%rax)

00000000000296a0 <hfirst_tb16_nat>:
   296a0:	endbr64
   296a4:	vbroadcastsd 0x22532(%rip),%zmm0        # 4bbe0 <FFHT_THR_D+0x1e0>
   296ae:	mov    %rdi,%rax
   296b1:	test   %rsi,%rsi
   296b4:	je     29c9d <hfirst_tb16_nat+0x5fd>
   296ba:	lea    -0x8(,%rsi,8),%rdx
   296c2:	mov    $0xffffffaa,%ecx
   296c7:	vmovdqa64 0x223af(%rip),%zmm2        # 4ba80 <FFHT_THR_D+0x80>
   296d1:	vmovdqa64 0x223e5(%rip),%zmm1        # 4bac0 <FFHT_THR_D+0xc0>
   296db:	and    $0xfffffffffffffc00,%rdx
   296e2:	kmovw  %ecx,%k3
   296e6:	mov    $0xffffffcc,%ecx
   296eb:	vmovdqa64 0x2240b(%rip),%zmm0        # 4bb00 <FFHT_THR_D+0x100>
   296f5:	lea    0x400(%rdi,%rdx,1),%rdx
   296fd:	mov    $0xfffffff0,%edi
   29702:	kmovw  %ecx,%k2
   29706:	kmovw  %edi,%k1
   2970a:	nopw   0x0(%rax,%rax,1)
   29710:	vpermpd (%rax),%zmm2,%zmm3
   29716:	vaddpd (%rax),%zmm3,%zmm4
   2971c:	add    $0x400,%rax
   29722:	vsubpd -0x400(%rax),%zmm3,%zmm4{%k3}
   29729:	vpermpd %zmm4,%zmm1,%zmm5
   2972f:	vaddpd %zmm4,%zmm5,%zmm3
   29735:	vsubpd %zmm4,%zmm5,%zmm3{%k2}
   2973b:	vpermpd %zmm3,%zmm0,%zmm4
   29741:	vaddpd %zmm4,%zmm3,%zmm15
   29747:	vsubpd %zmm3,%zmm4,%zmm15{%k1}
   2974d:	vpermpd -0x3c0(%rax),%zmm2,%zmm4
   29754:	vaddpd -0x3c0(%rax),%zmm4,%zmm3
   2975b:	vsubpd -0x3c0(%rax),%zmm4,%zmm3{%k3}
   29762:	vpermpd %zmm3,%zmm1,%zmm5
   29768:	vaddpd %zmm5,%zmm3,%zmm4
   2976e:	vsubpd %zmm3,%zmm5,%zmm4{%k2}
   29774:	vpermpd %zmm4,%zmm0,%zmm5
   2977a:	vaddpd %zmm5,%zmm4,%zmm3
   29780:	vsubpd %zmm4,%zmm5,%zmm3{%k1}
   29786:	vpermpd -0x380(%rax),%zmm2,%zmm4
   2978d:	vaddpd -0x380(%rax),%zmm4,%zmm5
   29794:	vsubpd -0x380(%rax),%zmm4,%zmm5{%k3}
   2979b:	vpermpd %zmm5,%zmm1,%zmm6
   297a1:	vaddpd %zmm6,%zmm5,%zmm4
   297a7:	vsubpd %zmm5,%zmm6,%zmm4{%k2}
   297ad:	vpermpd %zmm4,%zmm0,%zmm5
   297b3:	vaddpd %zmm5,%zmm4,%zmm14
   297b9:	vsubpd %zmm4,%zmm5,%zmm14{%k1}
   297bf:	vpermpd -0x340(%rax),%zmm2,%zmm4
   297c6:	vaddpd -0x340(%rax),%zmm4,%zmm5
   297cd:	vsubpd -0x340(%rax),%zmm4,%zmm5{%k3}
   297d4:	vpermpd %zmm5,%zmm1,%zmm6
   297da:	vaddpd %zmm6,%zmm5,%zmm4
   297e0:	vsubpd %zmm5,%zmm6,%zmm4{%k2}
   297e6:	vpermpd %zmm4,%zmm0,%zmm5
   297ec:	vaddpd %zmm5,%zmm4,%zmm7
   297f2:	vsubpd %zmm4,%zmm5,%zmm7{%k1}
   297f8:	vpermpd -0x300(%rax),%zmm2,%zmm4
   297ff:	vaddpd -0x300(%rax),%zmm4,%zmm5
   29806:	vsubpd -0x300(%rax),%zmm4,%zmm5{%k3}
   2980d:	vaddpd %zmm7,%zmm14,%zmm24
   29813:	vsubpd %zmm7,%zmm14,%zmm23
   29819:	vpermpd %zmm5,%zmm1,%zmm6
   2981f:	vaddpd %zmm6,%zmm5,%zmm4
   29825:	vsubpd %zmm5,%zmm6,%zmm4{%k2}
   2982b:	vpermpd %zmm4,%zmm0,%zmm5
   29831:	vaddpd %zmm5,%zmm4,%zmm13
   29837:	vsubpd %zmm4,%zmm5,%zmm13{%k1}
   2983d:	vpermpd -0x2c0(%rax),%zmm2,%zmm4
   29844:	vaddpd -0x2c0(%rax),%zmm4,%zmm5
   2984b:	vsubpd -0x2c0(%rax),%zmm4,%zmm5{%k3}
   29852:	vpermpd %zmm5,%zmm1,%zmm6
   29858:	vaddpd %zmm6,%zmm5,%zmm4
   2985e:	vsubpd %zmm5,%zmm6,%zmm4{%k2}
   29864:	vpermpd %zmm4,%zmm0,%zmm5
   2986a:	vaddpd %zmm5,%zmm4,%zmm6
   29870:	vsubpd %zmm4,%zmm5,%zmm6{%k1}
   29876:	vpermpd -0x280(%rax),%zmm2,%zmm4
   2987d:	vaddpd -0x280(%rax),%zmm4,%zmm5
   29884:	vsubpd -0x280(%rax),%zmm4,%zmm5{%k3}
   2988b:	vaddpd %zmm6,%zmm13,%zmm22
   29891:	vpermpd %zmm5,%zmm1,%zmm8
   29897:	vaddpd %zmm8,%zmm5,%zmm4
   2989d:	vsubpd %zmm5,%zmm8,%zmm4{%k2}
   298a3:	vpermpd %zmm4,%zmm0,%zmm5
   298a9:	vaddpd %zmm5,%zmm4,%zmm12
   298af:	vsubpd %zmm4,%zmm5,%zmm12{%k1}
   298b5:	vpermpd -0x240(%rax),%zmm2,%zmm4
   298bc:	vaddpd -0x240(%rax),%zmm4,%zmm5
   298c3:	vsubpd -0x240(%rax),%zmm4,%zmm5{%k3}
   298ca:	vpermpd %zmm5,%zmm1,%zmm8
   298d0:	vaddpd %zmm8,%zmm5,%zmm4
   298d6:	vsubpd %zmm5,%zmm8,%zmm4{%k2}
   298dc:	vpermpd %zmm4,%zmm0,%zmm8
   298e2:	vaddpd %zmm8,%zmm4,%zmm5
   298e8:	vsubpd %zmm4,%zmm8,%zmm5{%k1}
   298ee:	vpermpd -0x200(%rax),%zmm2,%zmm4
   298f5:	vaddpd -0x200(%rax),%zmm4,%zmm8
   298fc:	vsubpd -0x200(%rax),%zmm4,%zmm8{%k3}
   29903:	vaddpd %zmm5,%zmm12,%zmm7
   29909:	vsubpd %zmm5,%zmm12,%zmm5
   2990f:	vpermpd %zmm8,%zmm1,%zmm9
   29915:	vaddpd %zmm9,%zmm8,%zmm4
   2991b:	vsubpd %zmm8,%zmm9,%zmm4{%k2}
   29921:	vpermpd %zmm4,%zmm0,%zmm8
   29927:	vaddpd %zmm8,%zmm4,%zmm11
   2992d:	vsubpd %zmm4,%zmm8,%zmm11{%k1}
   29933:	vpermpd -0x1c0(%rax),%zmm2,%zmm8
   2993a:	vaddpd -0x1c0(%rax),%zmm8,%zmm4
   29941:	vsubpd -0x1c0(%rax),%zmm8,%zmm4{%k3}
   29948:	vpermpd %zmm4,%zmm1,%zmm9
   2994e:	vaddpd %zmm9,%zmm4,%zmm8
   29954:	vsubpd %zmm4,%zmm9,%zmm8{%k2}
   2995a:	vpermpd %zmm8,%zmm0,%zmm9
   29960:	vaddpd %zmm9,%zmm8,%zmm4
   29966:	vsubpd %zmm8,%zmm9,%zmm4{%k1}
   2996c:	vpermpd -0x180(%rax),%zmm2,%zmm8
   29973:	vaddpd -0x180(%rax),%zmm8,%zmm9
   2997a:	vsubpd -0x180(%rax),%zmm8,%zmm9{%k3}
   29981:	vaddpd %zmm4,%zmm11,%zmm21
   29987:	vpermpd %zmm9,%zmm1,%zmm10
   2998d:	vaddpd %zmm10,%zmm9,%zmm8
   29993:	vsubpd %zmm9,%zmm10,%zmm8{%k2}
   29999:	vpermpd %zmm8,%zmm0,%zmm9
   2999f:	vaddpd %zmm9,%zmm8,%zmm10
   299a5:	vsubpd %zmm8,%zmm9,%zmm10{%k1}
   299ab:	vpermpd -0x140(%rax),%zmm2,%zmm8
   299b2:	vaddpd -0x140(%rax),%zmm8,%zmm9
   299b9:	vsubpd -0x140(%rax),%zmm8,%zmm9{%k3}
   299c0:	vpermpd %zmm9,%zmm1,%zmm16
   299c6:	vaddpd %zmm16,%zmm9,%zmm8
   299cc:	vsubpd %zmm9,%zmm16,%zmm8{%k2}
   299d2:	vpermpd %zmm8,%zmm0,%zmm9
   299d8:	vaddpd %zmm9,%zmm8,%zmm16
   299de:	vsubpd %zmm8,%zmm9,%zmm16{%k1}
   299e4:	vpermpd -0x100(%rax),%zmm2,%zmm8
   299eb:	vaddpd -0x100(%rax),%zmm8,%zmm9
   299f2:	vsubpd -0x100(%rax),%zmm8,%zmm9{%k3}
   299f9:	vaddpd %zmm16,%zmm10,%zmm12
   299ff:	vsubpd %zmm16,%zmm10,%zmm16
   29a05:	vpermpd %zmm9,%zmm1,%zmm17
   29a0b:	vaddpd %zmm17,%zmm9,%zmm8
   29a11:	vsubpd %zmm9,%zmm17,%zmm8{%k2}
   29a17:	vpermpd %zmm8,%zmm0,%zmm9
   29a1d:	vaddpd %zmm9,%zmm8,%zmm17
   29a23:	vsubpd %zmm8,%zmm9,%zmm17{%k1}
   29a29:	vpermpd -0xc0(%rax),%zmm2,%zmm8
   29a30:	vaddpd -0xc0(%rax),%zmm8,%zmm9
   29a37:	vsubpd -0xc0(%rax),%zmm8,%zmm9{%k3}
   29a3e:	vpermpd %zmm9,%zmm1,%zmm18
   29a44:	vaddpd %zmm18,%zmm9,%zmm8
   29a4a:	vsubpd %zmm9,%zmm18,%zmm8{%k2}
   29a50:	vpermpd %zmm8,%zmm0,%zmm9
   29a56:	vaddpd %zmm9,%zmm8,%zmm19
   29a5c:	vsubpd %zmm8,%zmm9,%zmm19{%k1}
   29a62:	vpermpd -0x80(%rax),%zmm2,%zmm8
   29a69:	vaddpd -0x80(%rax),%zmm8,%zmm9
   29a70:	vsubpd -0x80(%rax),%zmm8,%zmm9{%k3}
   29a77:	vaddpd %zmm19,%zmm17,%zmm14
   29a7d:	vsubpd %zmm19,%zmm17,%zmm10
   29a83:	vpermpd %zmm9,%zmm1,%zmm18
   29a89:	vaddpd %zmm12,%zmm21,%zmm19
   29a8f:	vsubpd %zmm12,%zmm21,%zmm21
   29a95:	vaddpd %zmm18,%zmm9,%zmm8
   29a9b:	vsubpd %zmm9,%zmm18,%zmm8{%k2}
   29aa1:	vpermpd %zmm8,%zmm0,%zmm9
   29aa7:	vaddpd %zmm9,%zmm8,%zmm18
   29aad:	vsubpd %zmm8,%zmm9,%zmm18{%k1}
   29ab3:	vpermpd -0x40(%rax),%zmm2,%zmm8
   29aba:	vaddpd -0x40(%rax),%zmm8,%zmm9
   29ac1:	vsubpd -0x40(%rax),%zmm8,%zmm9{%k3}
   29ac8:	vpermpd %zmm9,%zmm1,%zmm20
   29ace:	vaddpd %zmm20,%zmm9,%zmm8
   29ad4:	vsubpd %zmm9,%zmm20,%zmm8{%k2}
   29ada:	vpermpd %zmm8,%zmm0,%zmm20
   29ae0:	vaddpd %zmm20,%zmm8,%zmm9
   29ae6:	vsubpd %zmm8,%zmm20,%zmm9{%k1}
   29aec:	vaddpd %zmm3,%zmm15,%zmm8
   29af2:	vsubpd %zmm3,%zmm15,%zmm3
   29af8:	vsubpd %zmm6,%zmm13,%zmm15
   29afe:	vsubpd %zmm4,%zmm11,%zmm20
   29b04:	vaddpd %zmm18,%zmm9,%zmm13
   29b0a:	vsubpd %zmm9,%zmm18,%zmm11
   29b10:	vaddpd %zmm5,%zmm15,%zmm17
   29b16:	vaddpd %zmm7,%zmm22,%zmm9
   29b1c:	vaddpd %zmm24,%zmm8,%zmm6
   29b22:	vsubpd %zmm24,%zmm8,%zmm4
   29b28:	vaddpd %zmm13,%zmm14,%zmm18
   29b2e:	vaddpd %zmm23,%zmm3,%zmm8
   29b34:	vsubpd %zmm7,%zmm22,%zmm7
   29b3a:	vsubpd %zmm5,%zmm15,%zmm15
   29b40:	vaddpd %zmm16,%zmm20,%zmm22
   29b46:	vsubpd %zmm13,%zmm14,%zmm13
   29b4c:	vsubpd %zmm17,%zmm8,%zmm5
   29b52:	vaddpd %zmm11,%zmm10,%zmm14
   29b58:	vsubpd %zmm11,%zmm10,%zmm11
   29b5e:	vaddpd %zmm9,%zmm6,%zmm10
   29b64:	vsubpd %zmm9,%zmm6,%zmm6
   29b6a:	vaddpd %zmm17,%zmm8,%zmm9
   29b70:	vaddpd %zmm18,%zmm19,%zmm17
   29b76:	vsubpd %zmm23,%zmm3,%zmm3
   29b7c:	vsubpd %zmm16,%zmm20,%zmm20
   29b82:	vsubpd %zmm18,%zmm19,%zmm18
   29b88:	vaddpd %zmm14,%zmm22,%zmm16
   29b8e:	vaddpd %zmm7,%zmm4,%zmm8
   29b94:	vaddpd %zmm17,%zmm10,%zmm19
   29b9a:	vsubpd %zmm15,%zmm3,%zmm12
   29ba0:	vsubpd %zmm7,%zmm4,%zmm4
   29ba6:	vaddpd %zmm15,%zmm3,%zmm7
   29bac:	vaddpd %zmm13,%zmm21,%zmm15
   29bb2:	vsubpd %zmm14,%zmm22,%zmm3
   29bb8:	vmovupd %zmm19,-0x400(%rax)
   29bbf:	vaddpd %zmm16,%zmm9,%zmm19
   29bc5:	vaddpd %zmm11,%zmm20,%zmm14
   29bcb:	vsubpd %zmm13,%zmm21,%zmm13
   29bd1:	vsubpd %zmm11,%zmm20,%zmm11
   29bd7:	vsubpd %zmm17,%zmm10,%zmm10
   29bdd:	vsubpd %zmm16,%zmm9,%zmm9
   29be3:	vmovupd %zmm19,-0x3c0(%rax)
   29bea:	vaddpd %zmm15,%zmm8,%zmm19
   29bf0:	vsubpd %zmm15,%zmm8,%zmm8
   29bf6:	vmovupd %zmm10,-0x200(%rax)
   29bfd:	vmovupd %zmm19,-0x380(%rax)
   29c04:	vaddpd %zmm14,%zmm7,%zmm19
   29c0a:	vsubpd %zmm14,%zmm7,%zmm7
   29c10:	vmovupd %zmm9,-0x1c0(%rax)
   29c17:	vmovupd %zmm8,-0x180(%rax)
   29c1e:	vmovupd %zmm19,-0x340(%rax)
   29c25:	vaddpd %zmm18,%zmm6,%zmm19
   29c2b:	vsubpd %zmm18,%zmm6,%zmm6
   29c31:	vmovupd %zmm7,-0x140(%rax)
   29c38:	vmovupd %zmm19,-0x300(%rax)
   29c3f:	vaddpd %zmm3,%zmm5,%zmm19
   29c45:	vsubpd %zmm3,%zmm5,%zmm5
   29c4b:	vmovupd %zmm6,-0x100(%rax)
   29c52:	vsubpd %zmm11,%zmm12,%zmm3
   29c58:	vmovupd %zmm19,-0x2c0(%rax)
   29c5f:	vaddpd %zmm13,%zmm4,%zmm19
   29c65:	vsubpd %zmm13,%zmm4,%zmm4
   29c6b:	vmovupd %zmm5,-0xc0(%rax)
   29c72:	vmovupd %zmm3,-0x40(%rax)
   29c79:	vmovupd %zmm19,-0x280(%rax)
   29c80:	vaddpd %zmm11,%zmm12,%zmm19
   29c86:	vmovupd %zmm4,-0x80(%rax)
   29c8d:	vmovupd %zmm19,-0x240(%rax)
   29c94:	cmp    %rdx,%rax
   29c97:	jne    29710 <hfirst_tb16_nat+0x70>
   29c9d:	vzeroupper
   29ca0:	ret
   29ca1:	data16 cs nopw 0x0(%rax,%rax,1)
   29cac:	nopl   0x0(%rax)

